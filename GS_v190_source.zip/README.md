# ਗੁਰਬਾਣੀ ਸਾਂਝ — Gurbani Saanjh v1.8.0 (Android private beta)

A Punjabi/English scripture **reading** app, built from the existing Capacitor project. This ZIP is the **Android source**, not an installable APK.

## What is implemented

- Continuous Gurmukhi text flow without artificial newlines between source verses. **Compact / Standard / Spacious** control line height, not paragraph gaps. Meanings, when enabled, appear underneath their corresponding verse.
- Distraction-free reading: no in-app menu, title, or buttons. Use Samsung Back to exit.
- Two modes: continuous Scroll and 3D **Page Turn**; speed defaults to **Slow** and can be set to Slow / Normal / Fast.
- Sri Guru Granth Sahib Ji **1,430 Angs** and BaniDB Sundar Gutka compositions: the GitHub build is programmed to fetch and validate the texts **at build time** and embed them in the APK; the reader does not require internet after a successful build.
- Punjabi / English app text, independently controlled English-letter Gurbani and Punjabi / English meanings where the source provides them.
- Optional Vishraam word colouring. These markings are incomplete and should NOT be treated as a complete Santhiya edition.
- **Kirtan Shabads**: full offline scripture search, save/bookmark matching lines, open the originating full Ang. This is a **text-reading collection, not a music player**.
- **Ask Gurbani**: retrieval of exact scripture passages with Ang references and Brief / Detailed / In-depth choices. Optional genuine AI explanations require a secure external AI endpoint; see `AI_SERVER_SETUP.md`.
- Daily Gurbani retrieves passages from the actual locally bundled texts.
- **No MP3, audio or synthetic Paath** in this version (postponed by request).

## What has NOT been verified or completed

- No signed APK was built in the assistant's environment; the Android SDK and internet access for the 1,430-Ang download were unavailable. GitHub must complete the download and Android build before we can call the offline library installed and functional.
- No server has been deployed for live AI; do not describe it as active yet.
- Not every named variation of historical or tradition-specific Bani has been sourced/verified. If a complete matching text is unavailable, the app does not fabricate one. In particular, a Damdami Taksal-specific Rehras text needs independent review.
- Complete expert-reviewed Vishraam and word-by-word arth require content review.
- Kirtan Shabad search navigates to the source Ang; full Shabad segmentation beyond an Ang is not yet implemented.
- Samsung hardware testing, text proofreading, licence clearance and release QA are pending.

## Build your existing app (same signing key and app ID)

1. Upload **`GS_v180_source.zip`** (unextracted) to the root of your public `karmjg/Gurbani-saanj` repository on branch `main`.
2. **Edit `.github/workflows/android-apk-1.yml`** — this is the workflow shown by your recent failed GitHub runs. Change its `zip=` line to exactly `zip='GS_v180_source.zip'`. Commit to `main`.
3. Use **Run workflow** to start a *new* run. Do not press **Re-run jobs** on an old run.
4. The action builds the full validated corpus, signs the release with the four **already configured** GitHub secrets, and uploads the signed APK in the run's Artifacts.
5. Install that signed APK over your existing app. Do not uninstall first; the app ID is `com.gurbanisaanjh.app` and the same signing key is required.

**Important:** Your repo also has `.github/workflows/android-apk.yml` (without `-1`), which can cause duplicate workflows. Use the correct one, and remove/disable the duplicate *only after* you have confirmed the intended workflow is building successfully.

## Text and licensing

See `SOURCE_AND_LICENSE.md`. This is a **private, noncommercial beta**. The full scripture texts are not in this source ZIP because they are downloaded during the build. Review the provider's licensing and permissions before any public/commercial release.
