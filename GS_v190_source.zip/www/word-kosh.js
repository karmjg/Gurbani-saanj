/* BaniDB Kosh word lookup. Previously fetched words remain available without internet.
   Never invent a definition. Full offline dictionary needs a separate licensed snapshot. */
(()=>{'use strict';
const key='gurbani-saanjh-kosh-cache-v1';let cache={};
try{cache=JSON.parse(localStorage.getItem(key)||'{}')}catch{}
function text(x){if(typeof x==='string')return x.trim();if(!x||typeof x!=='object')return '';for(const k of ['unicode','gurmukhi','meaning','definition','description','arth','translation','text','punjabi','pa','en','english']){const v=x[k];if(typeof v==='string'&&v.trim())return v.trim()}return ''}
function flatten(x,out=[],depth=0){if(!x||depth>5||out.length>120)return out;
 if(Array.isArray(x))x.forEach(a=>flatten(a,out,depth+1));else if(typeof x==='object'){
 const word=text(x.word)||text(x.gurmukhi)||text(x.headword)||text(x.term);
 const meaning=text(x.meaning)||text(x.definition)||text(x.description)||text(x.arth)||text(x.pa)||text(x.punjabi)||text(x.translation)||text(x.en);
 if(word&&meaning&&word!==meaning)out.push({word,meaning});
 for(const [k,v] of Object.entries(x))if(v&&typeof v==='object')flatten(v,out,depth+1);
 }
 return out}
function save(){try{const ks=Object.keys(cache);for(const k of ks.slice(0,Math.max(0,ks.length-250)))delete cache[k];localStorage.setItem(key,JSON.stringify(cache))}catch{}}
async function lookup(word,allowNetwork=true){
 const clean=String(word||'').replace(/[॥।੦-੯,;]+/gu,'').trim().normalize('NFC');if(!clean)return {source:'none',definitions:[]};
 if(Array.isArray(cache[clean])&&cache[clean].length)return {source:'offline-cache',definitions:cache[clean]};
 if(!allowNetwork||!navigator.onLine)return {source:'unavailable-offline',definitions:[]};
 const ctrl=new AbortController(),tid=setTimeout(()=>ctrl.abort(),9000);
 try{const r=await fetch('https://api.banidb.com/v2/kosh/word/'+encodeURIComponent(clean),{signal:ctrl.signal,headers:{Accept:'application/json'}});if(!r.ok)throw Error('HTTP '+r.status);
  const defs=flatten(await r.json()).filter(x=>x.word===clean||x.word.includes(clean)).slice(0,8);
  if(defs.length){cache[clean]=defs;save()}
  return {source:'BaniDB Kosh',definitions:defs};
 }catch{return {source:'failed',definitions:[]}}finally{clearTimeout(tid)}
}
window.GS_KOSH={lookup};
})();
