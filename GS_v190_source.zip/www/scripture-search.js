/* Complete offline scripture index. This file never calls a server. */
(()=>{
'use strict';
let loading=null, rows=[];
const norm=s=>String(s||'').normalize('NFC').toLocaleLowerCase().replace(/[\u200c\u200d]/gu,'').trim();
const part=s=>norm(s).split(/[\s,;?!.।॥:()"'\[\]\-]+/u).filter(Boolean);
const punjabi=s=>/[\u0A00-\u0A7F]/u.test(s);
const compact=s=>norm(s).replace(/[^\p{L}\p{N}]/gu,'');
const initials=s=>part(s).map(w=>Array.from(w)[0]||'').join('');
const noStop=s=>part(s).filter(w=>w.length>1&&!new Set(['why','how','can','the','and','what','where','with','about','from','are','what','does','have','for','search','find','gurbani','guru','sahib','granth','the','is','of','to','a','in','and','ਮੈਨੂੰ','ਵਿੱਚ','ਅਤੇ','ਕਿਵੇਂ','ਕੀ','ਤੋਂ','ਦਾ','ਦੀ','ਦੇ','ਹੈ']).has(w)).slice(0,10);
async function load(){
 if(!loading)loading=fetch('offline/search.json',{cache:'force-cache'}).then(async r=>{
  if(!r.ok)throw Error('Offline index missing');const arr=await r.json();
  if(!Array.isArray(arr)||arr.length<1000)throw Error('Offline scripture index incomplete');rows=arr;return arr;
 }).catch(e=>{loading=null;throw e});return loading;
}
function matchRows(arr,q,limit=40,mode='auto'){
 const needle=norm(q),c=compact(needle),terms=noStop(q);if(!needle)return [];
 const number=/^(?:ang\s*)?(\d{1,4})$/i.exec(needle);
 const selection=mode==='auto'&&number?'ang':mode;
 const found=[];
 for(const r of arr){const [a,i,g,en='',pa='',roman='']=r;if(!g)continue;
  const ang=Number(a);let score=0;const text=norm(g), tr=norm(roman),full=norm([g,en,pa,roman].join(' '));
  if(selection==='ang')score=(number&&ang===Number(number[1]))?100:0;
  else if(selection==='first')score=compact(initials(g)).startsWith(c)&&c.length>=2?120:0;
  else if(selection==='any-first')score=compact(initials(g)).includes(c)&&c.length>=2?100:0;
  else if(selection==='roman')score=(tr.includes(needle)?80:0)||(compact(initials(roman)).startsWith(c)&&c.length>=2?70:0);
  else if(selection==='word')score=part(g).some(w=>norm(w).includes(needle))||part(roman).some(w=>norm(w).includes(needle))?90:0;
  else{
    if(full.includes(needle))score=90;
    else if(terms.length){let hits=terms.filter(w=>full.includes(w)).length;
      if(hits>=Math.min(2,terms.length))score=hits*5;
    }
    if(!score&&c.length>=2){const matchInitial=compact(initials(punjabi(needle)?g:roman));if(matchInitial.startsWith(c))score=70;}
  }
  if(score)found.push({ang,idx:Number(i),g:String(g),score});
 }
 found.sort((a,b)=>b.score-a.score||a.ang-b.ang||a.idx-b.idx);
 return found.slice(0,Math.max(1,Math.min(100,Number(limit)||40))).map(({score,...rest})=>rest);
}
async function query(q,limit=40,mode='auto'){return matchRows(await load(),q,limit,mode)}
function lookup(ang,idx){const r=rows.find(x=>Number(x[0])===Number(ang)&&Number(x[1])===Number(idx));return r?{ang:Number(r[0]),idx:Number(r[1]),g:r[2]}:null}
window.GS_SCRIPTURE_SEARCH={load,query,lookup,matchRows};
})();
