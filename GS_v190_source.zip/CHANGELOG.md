## v1.8.0
- Replace verse-by-verse blocks with **genuine continuous inline scripture text** when meanings are hidden; paragraph gaps no longer appear in Compact, Standard or Spacious.
- Apply spacing settings to actual line height, and preserve meanings under individual verses when enabled.
- Page-turn animation speed control: Slow (default 1250 ms), Normal (800 ms), Fast (430 ms).
- Build a search index from the offline 1,430-Ang source as part of the GitHub build, for quoted-text search and source references.
- Search the corpus from Kirtan Shabads, save verse references and open the original Ang, offline.
- Fix Ask Gurbani home card navigation; Ask Gurbani: referenced passage retrieval locally; optional secure AI server integration (requires separate server setup).
- Daily Gurbani preview now reads from actual bundled scripture, not a hardcoded sample.
- No MP3 or audio controls. Same Android application ID and signing process.

## v1.7.0
- 3D page-flip framework, Scroll/Page Turn choice, and initial continuous layout experimentation.
