# Gurbani Saanjh v1.7.0 — Android source

A private trial of a Gurbani reader. New in this version: **3D Page Turn** and continuous Compact scroll.

## Build
1. Upload `Gurbani_Saanjh_App_Source_v1.7.0.zip` to the root of the existing GitHub repository.
2. Set `.github/workflows/android-apk.yml` to refer to that filename (the matching workflow is also included here).
3. Run the workflow on `main`, using the existing four Android signing secrets.
4. Install the signed APK over the existing app, provided the application ID and signing key match.

## On the phone
Settings > Reading > Page navigation > Page Turn. Swipe horizontally to flip; press and hold a word for its meaning. Scroll stays available.

**Note:** The existing offline corpus importer retrieves scripture during the GitHub build. Its live endpoint and all 1,430 Angs have not been verified in this environment. Refer to SOURCE_AND_LICENSE.md before any public release.
