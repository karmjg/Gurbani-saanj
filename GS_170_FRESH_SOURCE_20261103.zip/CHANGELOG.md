# Gurbani Saanjh v1.7.0 — Page Turn Reader

- Added a responsive 3D **Page Turn** animation. Swipe left/right to turn pages; tap the page edge to navigate.
- Book pages are automatically measured against screen size and selected font size; no Gurbani words are intentionally split between pages.
- Added persistent per-Ang/per-Bani page cursor position.
- Continuous text flow in Compact scroll layout; Standard and Spacious retain paragraph spacing.
- Keep the distraction-free, Paath-only reader and the optional Vishraam colours.
- No MP3 player or synthetic recitation.

## Testing
- JavaScript syntax checked.
- Browser test: on simulated Android-width viewport, Page Turn rendered Gurbani within the page bounds and a swipe navigated to another page without JS errors.
- Full 1430-Ang offline content build and real-device APK installation not run here.
- The effect is a CSS 3D book-page flip with shadows, not a physically simulated curling sheet.
