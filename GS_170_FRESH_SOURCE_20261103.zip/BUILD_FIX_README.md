# Build #14 failure — corrected source importer

The previous importer rejected an index count of 0 before Android signing. Version 1.6.1 broadens the BaniDB response parser for nested `banis` and `verse.verse` formats. Both are tested with local fixtures.

## GitHub instructions
1. Upload `Gurbani_Saanjh_App_Source_v1.6.2.zip` into the root of the public GitHub repository.
2. In `.github/workflows/android-apk.yml`, change only `zip=...` to `Gurbani_Saanjh_App_Source_v1.6.2.zip`. If desired, replace the entire workflow with the included one.
3. Commit to `main` and run Actions.
4. If `Build complete offline Gurbani library` fails again, copy the error line with the response shape. Do NOT disable the validation.

The full online scripture data cannot be fetched in this working environment, so an end-to-end successful build is not yet verified.
