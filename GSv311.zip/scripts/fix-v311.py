#!/usr/bin/env python3
"""Fix v311 (app v2.2.91) — 2 changes vs v2.2.90 (GSv310), both approved
by the user 2026-11-23 from the mockups mockup_kirtan_bar.png and
mockup_ask_no_mic.png. He said 'Build it.' Nothing else changes.

1) Kirtan Shabad reader: the Aa button and the menu bar are unreachable
   on a short shabad.
   Root cause (verified in code): the reader is full-screen by design —
   html.reading-open hides .topbar and .bottomnav (styles.css), and the
   reader's own top bar (.gs-reading-topbar, which carries Aa) starts
   hidden and only appears when the user scrolls UP by 5px or more
   (barScrollDecision / onReaderScroll). A shabad that fits on one
   screen (his Ang 250, 10 lines) has NO scroll at all, so the bar can
   never appear — Aa and the menu are unreachable. v2.2.88 fixed the
   same trap only for coming BACK from preferences; the first open of
   a short shabad was still stuck. GSv310 did not touch the reader.
   Fix: new updateShortReadingBars() — after every reader render, if
   the page cannot scroll (scrollHeight <= innerHeight + 1px), mark
   <html> gs-short-reading and show the reader top bar. CSS for that
   class re-shows the bottom nav and adds bottom padding so the last
   verse clears the nav. Long shabads are untouched: the bar stays
   hidden and pops out on scroll-back, exactly as before.
   The check also runs on window resize and when the fonts finish
   loading (a late font can change the page height).

2) Ask page: the language pills are now just 'ਪ' (Pappa) and 'EN'
   instead of the full words 'ਪੰਜਾਬੀ' / 'English' (user 2026-11-23
   11:42 — the full words took too much room). Short pills leave much
   more room in the question box to type. The Ask button stays first,
   then ਪ, then EN; its label still follows the picked answer language
   (ਪੁੱਛੋ / Ask). No other Ask change.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "www" / "app.js"
CSS = ROOT / "www" / "styles.css"


def replace(path, old, new, note):
    s = path.read_text(encoding="utf-8")
    if old not in s:
        print(f"FAIL: not found in {path.name}: {note}")
        sys.exit(1)
    if s.count(old) != 1:
        print(f"FAIL: {s.count(old)} matches in {path.name}: {note}")
        sys.exit(1)
    path.write_text(s.replace(old, new), encoding="utf-8")
    print(f"ok: {note}")


# ---- 1) Ask page: short language pills -------------------------------
replace(
    APP,
    "${[['pa','ਪੰਜਾਬੀ'],['en','English']].map(([k,label])=>`<button data-ai-lang=\"${k}\"",
    "${[['pa','ਪ'],['en','EN']].map(([k,label])=>`<button data-ai-lang=\"${k}\"",
    "Ask pills are now just ਪ and EN",
)

# ---- 2) Kirtan/short reader: show the bars when the page cannot scroll
# 2a) the checker, right after hideReaderBar()
old_bar = """function hideReaderBar(){if(readerBarHidden)return;readerBarHidden=true;const bar=document.querySelector('.gs-reading-topbar');if(bar){bar.classList.add('gs-topbar-hidden');bar.classList.remove('gs-topbar-in');}}"""
new_bar = old_bar + """
// v2.2.91: a reader page that fits on one screen has no scroll, so the
// top bar (Aa) can never be revealed by scrolling back — the bar and the
// menu are unreachable. When the page cannot scroll, keep both visible:
// mark <html> gs-short-reading (CSS re-shows the bottom nav) and show
// the reader top bar. Long pages are untouched — the bar stays hidden
// and pops out on scroll-back, exactly as before.
function updateShortReadingBars(){if(state.view!=='reader'){document.documentElement.classList.remove('gs-short-reading');return;}const short=document.documentElement.scrollHeight<=window.innerHeight+1;document.documentElement.classList.toggle('gs-short-reading',short);if(short)showReaderBar();}"""
replace(APP, old_bar, new_bar, "updateShortReadingBars() added")

# 2b) run the check after every render (covers opens + re-renders)
old_render = """$('main').innerHTML=(views[state.view]||homeScreen)();attach();"""
new_render = """$('main').innerHTML=(views[state.view]||homeScreen)();attach();updateShortReadingBars();"""
replace(APP, old_render, new_render, "updateShortReadingBars() called in render()")

# 2c) re-check on resize and when the fonts finish loading (a late font
# can change the page height and turn a short page long, or the reverse).
old_scroll = """let scrollTimer;window.addEventListener('scroll',()=>{if(!$('wordPopup').classList.contains('hidden'))closeWord();onReaderScroll();if(state.view!=='reader')return;clearTimeout(scrollTimer);scrollTimer=setTimeout(()=>{capture();captureAnchor()},130)},{passive:true});"""
new_scroll = old_scroll + """
window.addEventListener('resize',()=>{updateShortReadingBars()});
if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{updateShortReadingBars()});"""
replace(APP, old_scroll, new_scroll, "resize + fonts.ready re-check")

# 2d) CSS: re-show the bottom nav for short reading, and clear the nav
# with extra bottom padding below the last verse.
old_css = """html.reading-open .reading{padding-top:calc(20px + env(safe-area-inset-top));padding-bottom:calc(40px + env(safe-area-inset-bottom))}"""
new_css = old_css + """
/* v2.2.91: short reading — the page fits on one screen, so keep the
   bottom nav visible (the top bar is shown by updateShortReadingBars)
   and give the last verse room to clear the nav. */
html.reading-open.gs-short-reading .bottomnav{display:flex!important}
html.reading-open.gs-short-reading .reading{padding-bottom:calc(110px + env(safe-area-inset-bottom))}"""
replace(CSS, old_css, new_css, "gs-short-reading CSS (bottom nav + padding)")

print("fix-v311 done")
