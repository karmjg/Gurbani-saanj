/* v2.2.91 test - 2 changes vs v2.2.90 (GSv310). Karamjit 2026-11-23,
 * "Build it"; mockups mockup_kirtan_bar.png and mockup_ask_no_mic.png
 * approved.
 *
 * Change 1 - Kirtan Shabad reader: the Aa button and the menu bar are
 * unreachable on a short shabad. Root cause: the reader is full-screen
 * by design (html.reading-open hides .topbar/.bottomnav) and the
 * reader's own top bar (Aa) starts hidden, appearing only on scroll-up
 * >= 5px (barScrollDecision). A shabad that fits on one screen has NO
 * scroll, so the bar can never appear. New updateShortReadingBars():
 * after every reader render, if the page cannot scroll
 * (scrollHeight <= innerHeight + 1), mark <html> gs-short-reading and
 * show the reader top bar. CSS for that class re-shows the bottom nav
 * and adds bottom padding so the last verse clears the nav. Long
 * shabads are untouched: the bar stays hidden and pops out on
 * scroll-back, exactly as before. Re-checked on resize and when the
 * fonts finish loading.
 * Change 2 - Ask page: the language pills are now just 'ਪ' (Pappa) and
 * 'EN' instead of the full words, so the question box has much more
 * room to type. The Ask button stays first, then ਪ, then EN; its label
 * still follows the picked answer language (ਪੁੱਛੋ / Ask). The Settings
 * language pickers keep the full words — only the Ask box is shortened.
 *
 * The proofs below run the REAL askScreen() and the REAL
 * updateShortReadingBars() from the shipped app.js in a VM (mocked
 * DOM), and check the shipped styles.css.
 * Negative control: the same checks run against /tmp/v310-rollback
 * (pristine v2.2.90, extracted from GSv310.zip) and must show the OLD
 * behaviour (full-word Ask pills, no updateShortReadingBars, no
 * gs-short-reading CSS).
 * Run: node test-v311.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v310-rollback/www';
const rbApp = fs.readFileSync(path.join(RB, 'app.js'), 'utf8');
const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: version ----------
{
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json version is 2.2.91', pj.version === '2.2.91', `got ${pj.version}`);
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json is 2.2.91', vj.version === '2.2.91', `got ${vj.version}`);
  ok('version.json notes carry v2.2.91', vj.notes.includes('v2.2.91:'));
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js is 2.2.91', nbc.includes('"version":"2.2.91"') && nbc.match(/2\.2\.91/g).length === 1);
}

// ---------- static checks: Change 2 (Ask short pills) ----------
{
  ok('Ask inputrow uses the short pair [pa, ਪ] / [en, EN]',
    app.includes("[['pa','ਪ'],['en','EN']]"));
  ok('Ask inputrow does NOT use the full words in data-ai-lang',
    !app.includes("[['pa','ਪੰਜਾਬੀ'],['en','English']].map(([k,label])=>`<button data-ai-lang="));
  // The Settings language pickers (app language + meaning language)
  // keep the full words — only the Ask box is shortened.
  ok('Settings language pickers still use the full words (2 places)',
    (app.match(/\[\['pa','ਪੰਜਾਬੀ'\],\['en','English'\]\]/g) || []).length === 2);
}

// ---------- runtime: the REAL askScreen() (short pills render) ----------
function extractAsk(appSrc) {
  const start = appSrc.indexOf('function askButtonLabel(){');
  if (start === -1) return null;
  const askStart = appSrc.indexOf('function askScreen(){', start);
  const end = appSrc.indexOf('</section>`}', askStart);
  if (askStart === -1 || end === -1) return null;
  return appSrc.slice(start, end + '</section>`}'.length);
}
function makeAskCtx() {
  const txt = {
    pa: { askButton: 'ਪੁੱਛੋ', askTitle: 'ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਤੋਂ ਪੁੱਛੋ', askHint: 'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ...', short: 'ਸੌਖਾ', detail: 'ਵਿਸਥਾਰ', deep: 'ਡੂੰਘਾਈ' },
    en: { askButton: 'Ask', askTitle: 'Ask Guru Granth Sahib', askHint: 'Ask any question...', short: 'Simple', detail: 'Detailed', deep: 'In depth' },
  };
  const state = { lang: 'en', aiLang: 'pa', depth: 'detail', questions: [], aiApiKey: '', aiEndpoint: '' };
  const ctx = { txt, state, AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev', renderQA: () => '', esc: s => String(s) };
  ctx.t = k => (ctx.txt[ctx.state.lang] || ctx.txt.pa)[k] || k;
  ctx.age = (k, en) => ctx.state.lang === 'pa' ? k : en;
  return ctx;
}
function runAsk(appSrc) {
  const code = extractAsk(appSrc);
  if (!code) return null;
  const ctx = makeAskCtx();
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  const out = {};
  for (const aiLang of ['pa', 'en']) {
    ctx.state.aiLang = aiLang;
    out[aiLang] = vm.runInContext('askScreen()', ctx);
  }
  return out;
}
const rendered = runAsk(app);
ok('askButtonLabel + askScreen extract and run', !!rendered);
if (rendered) {
  const rowOf = html => {
    const m = html.match(/<div class="inputrow">([\s\S]*?)<\/div>/);
    return m ? m[1] : '';
  };
  for (const [aiLang, html] of Object.entries(rendered)) {
    const row = rowOf(html);
    ok(`Ask box [${aiLang}]: Punjabi pill is just 'ਪ'`, row.includes('data-ai-lang="pa"') && row.includes('>ਪ</button>'), row.slice(0, 200));
    ok(`Ask box [${aiLang}]: English pill is just 'EN'`, row.includes('data-ai-lang="en"') && row.includes('>EN</button>'));
    ok(`Ask box [${aiLang}]: NO full word 'ਪੰਜਾਬੀ' in the pills`, !row.includes('ਪੰਜਾਬੀ'));
    ok(`Ask box [${aiLang}]: NO full word 'English' in the pills`, !row.includes('>English</button>'));
    ok(`Ask box [${aiLang}]: Ask button still first, then the pills`,
      row.indexOf('id="askButton"') < row.indexOf('data-ai-lang'));
  }
  ok("Ask button label still follows aiLang (ਪੁੱਛੋ / Ask)",
    rowOf(rendered.pa).includes('>ਪੁੱਛੋ<') && rowOf(rendered.en).includes('>Ask<'));
  ok('Ask page still has NO mic (v2.2.90 intact)',
    !rendered.pa.includes('askVoiceBtn') && !rendered.en.includes('askVoiceBtn'));
}

// ---------- static checks: Change 1 (short-reading bars) ----------
{
  ok('updateShortReadingBars() exists', app.includes('function updateShortReadingBars(){'));
  ok('updateShortReadingBars() is called in render()',
    app.includes("$('main').innerHTML=(views[state.view]||homeScreen)();attach();updateShortReadingBars();"));
  ok('re-checked on window resize',
    app.includes("window.addEventListener('resize',()=>{updateShortReadingBars()});"));
  ok('re-checked when fonts finish loading',
    app.includes("if(document.fonts&&document.fonts.ready)document.fonts.ready.then(()=>{updateShortReadingBars()});"));
  ok('short-reading test uses scrollHeight <= innerHeight + 1',
    app.includes('document.documentElement.scrollHeight<=window.innerHeight+1'));
  ok('short reading adds the gs-short-reading class',
    app.includes("document.documentElement.classList.toggle('gs-short-reading',short)"));
  ok('short reading shows the reader top bar',
    app.includes('if(short)showReaderBar();'));
  ok('leaving the reader removes the gs-short-reading class',
    app.includes("document.documentElement.classList.remove('gs-short-reading');return;"));
  // CSS: the bottom nav comes back for short reading, with room below.
  ok('CSS re-shows the bottom nav for short reading',
    css.includes('html.reading-open.gs-short-reading .bottomnav{display:flex!important}'));
  ok('CSS adds bottom padding so the last verse clears the nav',
    css.includes('html.reading-open.gs-short-reading .reading{padding-bottom:calc(110px + env(safe-area-inset-bottom))}'));
  // The old behaviour is untouched: the bar still starts hidden on open,
  // and scroll-back is still the only way it appears on a long page.
  ok('reader still opens with the bar hidden (readerBarHidden=true)',
    app.includes('remoteBusy=true;readerBarHidden=true;readerAnchor=-1;readerAnchorTop=0;'));
  ok('scroll-back rule unchanged (show on up >= 5px, hide on down >= 5px)',
    app.includes("function barScrollDecision(lastY,curY){const d=curY-lastY;if(d<=-5)return 'show';if(d>=5)return 'hide';return null;}"));
  ok('reading-open still hides the top bar and bottom nav by default',
    css.includes('html.reading-open .topbar,') && css.includes('html.reading-open .bottomnav,'));
}

// ---------- runtime: the REAL updateShortReadingBars() (mocked DOM) ----------
function extractFn(src, name) {
  const start = src.indexOf(`function ${name}(){`);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { i++; break; } }
  }
  return src.slice(start, i);
}
function makeBarsCtx(view, scrollHeight, innerHeight) {
  const classes = new Set();
  const classList = {
    add: c => classes.add(c),
    remove: c => classes.delete(c),
    toggle: (c, force) => { if (force) classes.add(c); else classes.delete(c); },
    contains: c => classes.has(c),
  };
  const ctx = {
    state: { view },
    document: { documentElement: { scrollHeight, classList } },
    window: { innerHeight },
    showReaderBarCalls: 0,
    classes,
  };
  ctx.showReaderBar = () => { ctx.showReaderBarCalls++; };
  return ctx;
}
function runBars(appSrc, view, scrollHeight, innerHeight) {
  const code = extractFn(appSrc, 'updateShortReadingBars');
  if (!code) return null;
  const ctx = makeBarsCtx(view, scrollHeight, innerHeight);
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  vm.runInContext('updateShortReadingBars()', ctx);
  return ctx;
}
{
  const fn = extractFn(app, 'updateShortReadingBars');
  ok('updateShortReadingBars extracts cleanly', !!fn && fn.startsWith('function updateShortReadingBars(){'));
  // Short page (fits on screen) in the reader -> bars shown.
  let r = runBars(app, 'reader', 800, 1080);
  ok('short page in reader: gs-short-reading class added',
    r && r.classes.has('gs-short-reading'));
  ok('short page in reader: showReaderBar() called',
    r && r.showReaderBarCalls === 1);
  // Exactly at the boundary (scrollHeight == innerHeight + 1) -> short.
  r = runBars(app, 'reader', 1081, 1080);
  ok('boundary (scrollHeight == innerHeight + 1): still short, bar shown',
    r && r.classes.has('gs-short-reading') && r.showReaderBarCalls === 1);
  // One pixel over -> long, bars stay hidden.
  r = runBars(app, 'reader', 1082, 1080);
  ok('one pixel over (scrollHeight == innerHeight + 2): long, no class, no show',
    r && !r.classes.has('gs-short-reading') && r.showReaderBarCalls === 0);
  // Long page in the reader -> no class, no show.
  r = runBars(app, 'reader', 2400, 1080);
  ok('long page in reader: no gs-short-reading, showReaderBar() not called',
    r && !r.classes.has('gs-short-reading') && r.showReaderBarCalls === 0);
  // Not in the reader at all -> class removed, no show.
  r = runBars(app, 'home', 800, 1080);
  ok('not in the reader: class removed, showReaderBar() not called',
    r && !r.classes.has('gs-short-reading') && r.showReaderBarCalls === 0);
  // The v2.2.90 Ask behaviour is intact in the shipped app.js.
  ok('v2.2.90 Ask mic removal intact (no askVoiceBtn in app.js)',
    !app.includes('id="askVoiceBtn"') || !app.includes('askScreen(){return `<section class="page ask">'));
}

// ---------- negative control: pristine v2.2.90 must show the OLD behaviour ----------
{
  const rbRendered = runAsk(rbApp);
  ok('rollback (v2.2.90) has NO updateShortReadingBars()', !rbApp.includes('function updateShortReadingBars(){'));
  ok('rollback CSS has NO gs-short-reading rule', !rbCss.includes('gs-short-reading'));
  ok('rollback Ask pills are the FULL words', rbApp.includes("[['pa','ਪੰਜਾਬੀ'],['en','English']]"));
  ok('rollback Ask box has NO short pills', !rbApp.includes("[['pa','ਪ'],['en','EN']]"));
  if (rbRendered) {
    const row = (rbRendered.pa.match(/<div class="inputrow">([\s\S]*?)<\/div>/) || [])[1] || '';
    ok('rollback Ask box renders the full word ਪੰਜਾਬੀ', row.includes('>ਪੰਜਾਬੀ</button>'));
    ok('rollback Ask box renders the full word English', row.includes('>English</button>'));
  }
  const rbPj = JSON.parse(fs.readFileSync(path.join('/tmp/v310-rollback', 'package.json'), 'utf8'));
  ok('rollback version is 2.2.90', rbPj.version === '2.2.90', `got ${rbPj.version}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
