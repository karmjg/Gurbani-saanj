## v1.2.0 — Japji Sahib offline audio personal test
- Added local MP3 import and IndexedDB persistence; Android's audio controls plus 10-second skips and rate selection.
- Added Punjabi/English home-screen language toggle.
- Added independent Gurmukhi/English-letter display preference and existing independent meaning language setting.
- Added Nitnem section with Japji audio test entry.
- No source MP3 included in repository. AI remains unconnected; no verified word sync.
