# ਗੁਰਬਾਣੀ ਸਾਂਝ — Android Personal Test v1.2

Builds an Android APK through the included GitHub Actions workflow. App ID stays `com.gurbanisaanjh.app` so the user can upgrade without uninstalling, provided the *same signing key* and increasing versionCode are used.

## New in v1.2
- Authentic Japji Sahib **local MP3 import** with a persistent audio player (play/pause, seek ±10 seconds, playback speed); saved in browser IndexedDB for offline playback when storage succeeds.
- **Home language switch** Punjabi / English; separate reading script Gurmukhi / English letters (10 excerpt lines only), and Punjabi / English meanings.
- Nitnem prayer list; Japji Sahib opens the audio test reader. The other Nitnem text and recordings remain pending.
- Existing premium look, Ang-1 trial excerpts, Bani catalog, bookmarks, saved settings and reading progress are retained.

## Start listening
Open Nitnem > Japji Sahib > Play > Import MP3; select the *cleaned* MP3 you already saved on the phone. The file is stored **locally on your phone**, not sent to a server or GitHub. The public source ZIP contains **NO recording**.

## Limits
- This is a prototype, not the full Japji Sahib or 1,430-Ang SGGS corpus. The reader currently has 10 selected lines from Ang 1; neither their translations nor the English-letter reading has been formally reviewed.
- Full word-by-word audio alignment is not implemented; tapping Listen plays the whole recording, not the exact selected word.
- AI questions are still the interface only; no live model or remote service.
- Other Banis are catalog entries until verified texts and recordings are added.
- The MP3 was provided by the user for personal listening. Do not commit it to a **public** GitHub repository or redistribute it without permission.

## Building
Upload `Gurbani_Saanjh_App_Source_v1.2.zip` in the root of your existing `karmjg/Gurbani-saanj` repository (not extracted). Then replace `.github/workflows/android-apk.yml` with the supplied v1.2 YAML; run Actions > Build Gurbani Saanjh Android APK > main. Existing four Android signing secrets are reused. Open the downloaded APK over the existing app; do not uninstall or clear data.
