from pathlib import Path
import json
root=Path('/mnt/data/gs_audio_v12')
app=root/'www/app.js'
s=app.read_text()
s=s.replace('v1.0 — offline-first personal trial.', 'v1.2 — offline-first personal trial.',1)
s=s.replace("sample:'ਨਿੱਜੀ ਟਰਾਇਲ:","sample:'ਨਿੱਜੀ ਟਰਾਇਲ:",1)
# add home language toggle: UI language independent of meanings.
s=s.replace('<div class="hero-brand"><img src="icons/icon-192.png" alt="" class="hero-mark"><h1>ਗੁਰਬਾਣੀ ਸਾਂਝ</h1></div>', '<div class="hero-brand"><img src="icons/icon-192.png" alt="" class="hero-mark"><h1>ਗੁਰਬਾਣੀ ਸਾਂਝ</h1></div>\n    <button type="button" class="gs-lang-toggle" data-action="toggle-lang" aria-label="Change app language">${state.lang===\'pa\'?\'English ⇄ ਪੰਜਾਬੀ\':\'ਪੰਜਾਬੀ ⇄ English\'}</button>',1)
# make dedicated nitnem screen, no false full-text claim
idx=s.index('function comingScreen()')
s=s[:idx]+'''function nitnemScreen(){const entries=[['ਜਪੁਜੀ ਸਾਹਿਬ','Japji Sahib'],['ਜਾਪ ਸਾਹਿਬ','Jaap Sahib'],['ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ','Tav-Prasad Savaiye'],['ਚੌਪਈ ਸਾਹਿਬ','Chaupai Sahib'],['ਅਨੰਦ ਸਾਹਿਬ','Anand Sahib'],['ਰਹਿਰਾਸ ਸਾਹਿਬ','Rehras Sahib'],['ਕੀਰਤਨ ਸੋਹਿਲਾ','Kirtan Sohila']];return `<section class="page nitnem-page"><h1>${t('nitnem')}</h1><p class="muted fine">${age('ਜਪੁਜੀ ਸਾਹਿਬ ਦੀ ਆਡੀਓ ਲਈ ਆਪਣੀ ਰਿਕਾਰਡਿੰਗ ਚੁਣੋ। ਹੋਰ ਬਾਣੀਆਂ ਦੇ ਪਾਠ ਅਤੇ ਆਡੀਓ ਦੀ ਜਾਂਚ ਬਾਕੀ ਹੈ।','For Japji Sahib audio, import your own recording. Other Banis still need verified texts and recordings.')}</p>${entries.map((v,i)=>`<button class="catalog-row" data-action="${i===0?'nitnem-japji':'nitnem-pending'}"><span>${state.lang==='pa'?v[0]:v[1]}${i===0?` <small style="display:block;color:var(--muted)">${age('ਆਡੀਓ ਟੈਸਟ ਤਿਆਰ','Audio test available')}</small>`:''}</span><span>${i===0?'›':'·'}</span></button>`).join('')}</section>`}
''' +s[idx:]
# map view
s=s.replace('catalog:catalogScreen,catalogItem:catalogEntryScreen,','catalog:catalogScreen,catalogItem:catalogEntryScreen,nitnemPage:nitnemScreen,',1)
# reader audio button indicates functional
s=s.replace("case'audio':toast(t('audioPending'));break;", "case'audio':playJapjiAudio();break;",1)
s=s.replace("case'nitnem':case'dasam':case'bhai':state.comingTitle=a==='nitnem'?t('nitnem'):a==='dasam'?t('dasam'):t('bhai');go('coming');break;", "case'toggle-lang':state.lang=state.lang==='pa'?'en':'pa';persist();render();break;case'nitnem':go('nitnemPage');break;case'nitnem-japji':state.readView='sggs';go('reader');break;case'nitnem-pending':toast(age('ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਅਤੇ ਆਡੀਓ ਹਾਲੇ ਜੋੜੇ ਜਾਣੇ ਹਨ','Verified text and audio not added yet'));break;case'dasam':case'bhai':state.comingTitle=a==='dasam'?t('dasam'):t('bhai');go('coming');break;",1)
s=s.replace("type==='listen'?t('audioPending')", "type==='listen'?age('ਇਸ ਸ਼ਬਦ ਲਈ ਜਾਂਚਿਆ ਹੋਇਆ ਸਮਾਂ ਹਾਲੇ ਨਹੀਂ ਹੈ। ਪੂਰਾ ਪਾਠ ਹੇਠਾਂ ਪਲੇਅਰ ਵਿੱਚ ਸੁਣੋ।','Exact word timing is not verified yet. Play the complete recording in the audio player below.')",1)
# docking component shown reader/nitnem; we use shared audio element persistent.
s=s.replace("$('main').innerHTML=(views[state.view]||homeScreen)();attach();", "$('main').innerHTML=(views[state.view]||homeScreen)();attach();updateAudioDock();",1)
# complete native audio controller using idb Blob storage
marker='function bindGlobals(){'
assert marker in s
controller=r'''// Private offline audio import. No copyrighted audio is bundled or fetched by the public build.
const GS_AUDIO_DB='gurbani-saanjh-private-audio-v1';
let japjiAudioURL=null;
let japjiAudioName='';
function openJapjiDB(){return new Promise((resolve,reject)=>{if(!('indexedDB' in window))return reject(new Error('IndexedDB unavailable'));const r=indexedDB.open(GS_AUDIO_DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('files');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error||new Error('Database open failed'))})}
async function readJapjiAudio(){const db=await openJapjiDB();return new Promise((resolve,reject)=>{const tx=db.transaction('files','readonly');const r=tx.objectStore('files').get('japji');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);tx.oncomplete=()=>db.close();tx.onerror=()=>db.close()})}
async function storeJapjiAudio(file){const db=await openJapjiDB();return new Promise((resolve,reject)=>{const tx=db.transaction('files','readwrite');tx.objectStore('files').put({blob:file,name:file.name,updated:Date.now()},'japji');tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>{db.close();reject(tx.error||new Error('Audio storage failed'))}})}
function audioPlayer(){return $('gsJapjiAudio')}
function showAudioStatus(message){const s=$('gsAudioStatus');if(s)s.textContent=message}
function useJapjiBlob(blob,name){const a=audioPlayer();if(japjiAudioURL)URL.revokeObjectURL(japjiAudioURL);a.pause();japjiAudioURL=URL.createObjectURL(blob);japjiAudioName=name||'Japji Sahib';a.src=japjiAudioURL;a.load();showAudioStatus(age('ਫੋਨ ਵਿੱਚ ਸੰਭਾਲਿਆ ਹੋਇਆ · '+japjiAudioName,'Saved offline on this phone · '+japjiAudioName))}
function updateAudioDock(){const dock=$('gsAudioDock');if(!dock)return;const visible=state.view==='nitnemPage'||(state.view==='reader'&&state.readView==='sggs');dock.classList.toggle('hidden',!visible);document.body.classList.toggle('gs-audio-visible',visible);if(!visible&&audioPlayer()&&!audioPlayer().paused)audioPlayer().pause();if(visible&&!japjiAudioURL)showAudioStatus(age('ਜਪੁਜੀ ਸਾਹਿਬ ਦੀ MP3 ਫਾਈਲ ਚੁਣੋ','Select your Japji Sahib MP3 file'))}
function playJapjiAudio(){const a=audioPlayer();if(!japjiAudioURL){$('gsAudioFileInput').click();return;}if(a.paused){a.play().catch(()=>toast(age('ਆਡੀਓ ਨਹੀਂ ਚੱਲ ਸਕੀ','Audio could not play')))}else a.pause()}
function setupJapjiAudio(){const input=$('gsAudioFileInput');const a=audioPlayer();input.addEventListener('change',async()=>{const file=input.files?.[0];if(!file)return;input.value='';if(!(/\.mp3$/i.test(file.name)||file.type.startsWith('audio/'))){toast(age('MP3 ਫਾਈਲ ਚੁਣੋ','Select an audio file'));return}if(file.size>180*1024*1024){toast(age('ਫਾਈਲ ਬਹੁਤ ਵੱਡੀ ਹੈ','File is too large'));return}showAudioStatus(age('ਆਡੀਓ ਸੇਵ ਹੋ ਰਹੀ ਹੈ…','Saving audio on your phone…'));useJapjiBlob(file,file.name);try{await storeJapjiAudio(file);toast(age('ਆਡੀਓ ਫੋਨ ਵਿੱਚ ਸੇਵ ਹੋ ਗਈ','Audio saved offline on this phone'))}catch(err){console.warn('Private audio import error:',err);showAudioStatus(age('ਹੁਣ ਸੁਣ ਸਕਦੇ ਹੋ, ਪਰ ਆਡੀਓ ਸੇਵ ਨਹੀਂ ਹੋਈ','Ready to play now, but offline save failed'));toast(age('ਆਡੀਓ ਸੇਵ ਨਹੀਂ ਹੋਈ','Could not save offline'))}});
$('gsImportAudio').addEventListener('click',()=>input.click());
$('gsAudioRewind').addEventListener('click',()=>{if(a.readyState) a.currentTime=Math.max(0,a.currentTime-10)});
$('gsAudioForward').addEventListener('click',()=>{if(a.readyState)a.currentTime=Math.min(Number.isFinite(a.duration)?a.duration:a.currentTime+10,a.currentTime+10)});
$('gsAudioRate').addEventListener('change',e=>{a.playbackRate=Number(e.target.value)||1});
a.addEventListener('error',()=>{if(a.error)showAudioStatus(age('ਇਹ MP3 ਨਹੀਂ ਚੱਲੀ। ਹੋਰ ਫਾਈਲ ਚੁਣੋ।','This MP3 could not play. Try another audio file.'))});
readJapjiAudio().then(saved=>{if(saved?.blob)useJapjiBlob(saved.blob,saved.name)}).catch(err=>console.warn('No saved audio yet:',err));
}
'''
s=s.replace(marker,controller+'\n'+marker,1)
s=s.replace('bindGlobals();render();','bindGlobals();setupJapjiAudio();render();',1)
app.write_text(s)
# Add audio dock to index; keep persistent during re-render.
index=root/'www/index.html'; h=index.read_text()
needle=' <div id="sheetOverlay"'
assert needle in h
h=h.replace(needle, ''' <aside id="gsAudioDock" class="gs-audio-dock hidden" aria-label="Japji Sahib audio player">
  <div class="gs-audio-head"><strong>ਜਪੁਜੀ ਸਾਹਿਬ · Japji Sahib</strong><span>Bhai Jarnail Singh Ji</span></div>
  <p id="gsAudioStatus" class="gs-audio-status">Select your Japji Sahib MP3 file</p>
  <audio id="gsJapjiAudio" controls preload="metadata" aria-label="Japji Sahib audio"></audio>
  <div class="gs-audio-actions"><button id="gsImportAudio" type="button">↥ <span>MP3 / ਆਡੀਓ</span></button><button id="gsAudioRewind" type="button">−10s</button><button id="gsAudioForward" type="button">+10s</button><label for="gsAudioRate">Speed</label><select id="gsAudioRate" aria-label="Playback speed"><option value="0.75">0.75×</option><option value="1" selected>1×</option><option value="1.15">1.15×</option><option value="1.25">1.25×</option></select></div>
  <input id="gsAudioFileInput" type="file" accept="audio/mpeg,audio/mp3,.mp3,audio/*" hidden>
 </aside>
'''+needle,1)
h=h.replace('content="1.1.0"','content="1.2.0"',1)
index.write_text(h)
# CSS style
css=root/'www/styles.css';css.write_text(css.read_text()+'''
/* v1.2 personal audio trial - media stays local in IndexedDB, not in public app bundle */
.gs-audio-dock{position:fixed;left:50%;transform:translateX(-50%);bottom:calc(70px + env(safe-area-inset-bottom));width:min(100%,540px);z-index:40;box-sizing:border-box;background:var(--surface);border:1px solid var(--line);border-bottom:0;border-radius:17px 17px 0 0;box-shadow:0 -8px 26px #00000018;padding:11px 15px 8px;color:var(--ink)}
.gs-audio-dock.hidden{display:none!important}
.gs-audio-head{display:flex;flex-wrap:wrap;gap:3px 9px;align-items:baseline;justify-content:space-between}
.gs-audio-head strong{font-size:13px;color:var(--primary)}.gs-audio-head span{font-size:11px;color:var(--muted)}
.gs-audio-status{margin:4px 0 6px;font-size:10.5px;color:var(--muted);line-height:1.2;max-height:26px;overflow:hidden}
#gsJapjiAudio{display:block;width:100%;height:40px}
.gs-audio-actions{display:flex;align-items:center;justify-content:space-between;gap:6px;padding-top:6px}
.gs-audio-actions button,.gs-audio-actions select{background:var(--paper);border:1px solid var(--line);border-radius:9px;padding:6px 7px;color:var(--ink);font-size:11px;min-height:30px}
.gs-audio-actions label{font-size:10px;color:var(--muted)}
body.gs-audio-visible #main{padding-bottom:210px}
.gs-lang-toggle{position:absolute;right:14px;top:14px;z-index:5;background:#faf9f2ed;border:1px solid #d2b679;border-radius:40px;padding:6px 9px;color:#194b3b;font-size:11px;font-weight:700;box-shadow:0 2px 6px #00000019}
.premium-hero{position:relative}
''')
# Version metadata
pkg=root/'package.json'; j=json.loads(pkg.read_text());j['version']='1.2.0';j['description']='Gurbani Saanjh private Android trial; local Japji Sahib audio import/player';pkg.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
ver=root/'www/version.json';ver.write_text(json.dumps({'version':'1.2.0','releaseDate':'2026-11-02','notes':'Personal audio trial: local MP3 import, offline saved playback, playback controls and home language toggle.'},ensure_ascii=False,indent=2)+'\n')
(root/'AUDIO_PRIVATE_TEST.md').write_text('''# Gurbani Saanjh v1.2 — Private Japji Sahib audio test

This public-source ZIP contains **no copyrighted recording**. Do not upload a third-party MP3 into the public GitHub repository unless you have permission to distribute it.

## On your Android phone

1. Save `Gurbani_Saanjh_Japji_Sahib_Bhai_Jarnail_Singh_Cleaned.mp3` to Downloads.
2. Install/update the signed v1.2 APK using the SAME GitHub signing secrets and application ID as v1.1.
3. Open **Nitnem → Japji Sahib**, or the **Read** screen.
4. In the bottom audio player, press **MP3 / ਆਡੀਓ** and select the cleaned file from Downloads.
5. The MP3 is saved privately on your phone using IndexedDB. Play/pause, scrub, 10-second seek and speed controls should work even without internet after import.
6. Close and reopen the app and test that the saved audio still loads offline.
7. After updating the APK, test again without uninstalling; Android must use the same signing key to preserve stored data.

## Limitations

- Full verified Japji Sahib text, word-level audio timing, and AI answers are **not** included in this iteration. Reader contains selected Ang 1 lines only.
- The existing Nitnem catalog now has a Japji Sahib entry with the player; other Banis are marked pending.
- Imported audio is not included in data backup JSON and can be lost if app storage is cleared or the app is uninstalled. Keep the original MP3 separately.
- Playback and storage require actual testing on the Samsung Android device. Code checks are not a device test.
- A private test is not authorization to distribute a recording. Ask the rights holder before distributing publicly.
- Audio was gently filtered and denoised; final listening and text/audio matching checks are outstanding.
''')
print('Patched source')
