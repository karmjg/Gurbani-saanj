from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
import subprocess, time, os
from playwright.sync_api import sync_playwright
root=Path('/mnt/data/gs_audio_v12/www')
class H(SimpleHTTPRequestHandler):
    def __init__(self,*args,**kwargs): super().__init__(*args,directory=str(root),**kwargs)
    def log_message(self,*args): pass
server=ThreadingHTTPServer(('127.0.0.1',0),H)
Thread(target=server.serve_forever,daemon=True).start()
url='file:///mnt/data/gs_audio_v12/www/index.html'
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    context=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
    page=context.new_page()
    page.on('pageerror',lambda e: errors.append(str(e)))
    page.goto(url,wait_until='networkidle')
    assert page.locator('.premium-hero').count()==1
    assert 'ਮੁੱਖ' in page.locator('#labelHome').inner_text()
    page.locator('[data-action="toggle-lang"]').click()
    assert 'Home' in page.locator('#labelHome').inner_text()
    page.locator('[data-action="nitnem"]').click()
    assert 'Nitnem' in page.locator('main h1').inner_text()
    assert page.locator('#gsAudioDock').is_visible()
    page.locator('[data-action="nitnem-japji"]').click()
    assert 'Japji' in page.locator('main h1').inner_text()
    assert page.locator('#gsJapjiAudio').is_visible()
    # small test file decodes; actual uploaded full MP3 remains separate download.
    test_mp3='/mnt/data/gs_audio_v12/.test_short.mp3'
    subprocess.run(['ffmpeg','-v','error','-y','-i','/mnt/data/Gurbani_Saanjh_Japji_Sahib_Bhai_Jarnail_Singh_Cleaned.mp3','-t','2','-c:a','libmp3lame','-b:a','96k',test_mp3],check=True)
    page.locator('#gsAudioFileInput').set_input_files(test_mp3)
    page.wait_for_timeout(700)
    assert 'Saved offline' in page.locator('#gsAudioStatus').inner_text(),page.locator('#gsAudioStatus').inner_text()
    page.reload(wait_until='networkidle')
    page.wait_for_timeout(900)
    assert page.locator('#gsJapjiAudio').get_attribute('src')
    page.locator('[data-action="nitnem"]').click()
    page.locator('[data-action="nitnem-japji"]').click()
    page.locator('#gsAudioRate').select_option('1.25')
    assert abs(page.locator('#gsJapjiAudio').evaluate('(x)=>x.playbackRate')-1.25)<.01
    page.locator('#gsJapjiAudio').evaluate('(x)=>x.play()')
    page.wait_for_timeout(650)
    print('audio currentTime=',page.locator('#gsJapjiAudio').evaluate('(x)=>x.currentTime'))
    # First word popup remains usable
    page.locator('[data-word]').first.click(force=True)
    assert page.locator('#wordPopup').is_visible()
    page.locator('[data-pop="listen"]').click()
    assert 'word' in page.locator('#wordNote').inner_text().lower()
    page.screenshot(path='/mnt/data/Gurbani_Saanjh_v1.2_Audio_Test_Preview.png',full_page=False)
    print('PASS: Home language toggle, Nitnem navigation, audio player, offline IndexedDB persistence, speed, word guidance.')
    print('Errors:',errors)
    assert not errors,errors
    browser.close()
server.shutdown()
