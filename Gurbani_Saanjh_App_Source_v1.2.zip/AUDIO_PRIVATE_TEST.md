# Gurbani Saanjh v1.2 — Private Japji Sahib audio test

This public-source ZIP contains **no copyrighted recording**. Do not upload a third-party MP3 into the public GitHub repository unless you have permission to distribute it.

## On your Android phone

1. Save `Gurbani_Saanjh_Japji_Sahib_Bhai_Jarnail_Singh_Cleaned.mp3` to Downloads.
2. Install/update the signed v1.2 APK using the SAME GitHub signing secrets and application ID as v1.1.
3. Open **Nitnem → Japji Sahib**, or the **Read** screen.
4. In the bottom audio player, press **MP3 / ਆਡੀਓ** and select the cleaned file from Downloads.
5. The MP3 is saved privately on your phone using IndexedDB. Play/pause, scrub, 10-second seek and speed controls should work even without internet after import.
6. Close and reopen the app and test that the saved audio still loads offline.
7. After updating the APK, test again without uninstalling; Android must use the same signing key to preserve stored data.

## Limitations

- Full verified Japji Sahib text, word-level audio timing, and AI answers are **not** included in this iteration. Reader contains selected Ang 1 lines only.
- The existing Nitnem catalog now has a Japji Sahib entry with the player; other Banis are marked pending.
- Imported audio is not included in data backup JSON and can be lost if app storage is cleared or the app is uninstalled. Keep the original MP3 separately.
- Playback and storage require actual testing on the Samsung Android device. Code checks are not a device test.
- A private test is not authorization to distribute a recording. Ask the rights holder before distributing publicly.
- Audio was gently filtered and denoised; final listening and text/audio matching checks are outstanding.
