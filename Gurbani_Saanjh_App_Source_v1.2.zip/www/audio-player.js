/* Gurbani Saanjh v1.2: local, authentic recitation player.
   Recording is imported by the user and retained in IndexedDB; never fetched from piracy sites.
   No AI voice and no unverified word-level timing. */
(() => {
 'use strict';
 const dock = document.createElement('section');
 dock.id = 'gs-audio-dock'; dock.className='gs-audio-dock hidden';
 dock.innerHTML = `<div class="gs-audio-heading"><strong>ਜਪੁਜੀ ਸਾਹਿਬ · Japji Sahib</strong><span id="gs-audio-subtitle">Bhai Jarnail Singh Ji</span><button id="gs-audio-close" type="button" aria-label="Hide audio player">×</button></div>
 <audio id="gs-audio" controls preload="metadata" aria-label="Japji Sahib recording"></audio>
 <div class="gs-audio-actions"><button id="gs-audio-back" type="button">−10s</button><button id="gs-audio-forward" type="button">+10s</button>
 <label>Speed <select id="gs-audio-speed"><option value="0.85">0.85×</option><option value="1" selected>1×</option><option value="1.1">1.1×</option></select></label>
 <label class="gs-audio-import">Import MP3<input id="gs-audio-import" type="file" accept="audio/*,.mp3,.m4a" hidden></label></div>
 <p id="gs-audio-state" class="gs-audio-state">Import your copy of Bhai Jarnail Singh Ji's MP3 to play offline.</p>`;
 document.querySelector('#nav').before(dock);
 const $=id=>document.getElementById(id), audio=$('gs-audio');
 let available=false, blobURL=null;
 const note=(pa,en)=>document.documentElement.lang==='pa'?pa:en;
 const info=msg=>{$('gs-audio-state').textContent=msg};
 function reveal(){dock.classList.remove('hidden');dock.scrollIntoView({block:'nearest',behavior:'smooth'})}
 function database(){return new Promise((res,rej)=>{if(!indexedDB)return rej(Error('No indexedDB'));
  const r=indexedDB.open('gs-local-audio-v1',1);r.onupgradeneeded=()=>r.result.createObjectStore('mp3');
  r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
 async function save(file){const db=await database();await new Promise((res,rej)=>{
  const x=db.transaction('mp3','readwrite');x.objectStore('mp3').put(file,'japji');x.oncomplete=res;x.onerror=()=>rej(x.error)});db.close()}
 async function restore(){try{const db=await database();const obj=await new Promise((res,rej)=>{
  const t=db.transaction('mp3','readonly'),r=t.objectStore('mp3').get('japji');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)});
  db.close();if(obj){setAudio(obj);info(note('ਸੰਭਾਲੀ MP3 ਚੱਲਣ ਲਈ ਤਿਆਰ ਹੈ।','Saved offline MP3 is ready to play.'));return}
 }catch(e){console.warn('Audio restore:',e)}
 // Optional private-only embedded file; the public source does not contain this MP3.
 try{const x=await fetch('audio/japji-sahib.mp3',{method:'HEAD'});
  if(x.ok){audio.src='audio/japji-sahib.mp3';available=true;info(note('ਨਿੱਜੀ ਆਡੀਓ ਤਿਆਰ ਹੈ।','Private test audio ready.'))}
 }catch(e){/* expected on public builds */}
 }
 function setAudio(file){if(blobURL)URL.revokeObjectURL(blobURL);blobURL=URL.createObjectURL(file);audio.src=blobURL;audio.load();available=true;}
 async function importFile(file){if(!file)return;
  if(!file.type.startsWith('audio/')&&!/\.(mp3|m4a|aac|ogg|wav)$/i.test(file.name)){
   info(note('ਸਹੀ MP3 ਫਾਈਲ ਚੁਣੋ।','Please select an audio file.'));return;}
  setAudio(file);reveal();try{await save(file);info(note('ਇਹ MP3 ਫੋਨ ’ਤੇ ਆਫਲਾਈਨ ਸੇਵ ਹੋ ਗਈ ਹੈ।','MP3 saved on this phone for offline playback.'))}
  catch(e){console.warn('Audio save:',e);info(note('ਫਾਈਲ ਚੱਲੇਗੀ ਪਰ ਮੁੜ ਇੰਪੋਰਟ ਕਰਨੀ ਪੈ ਸਕਦੀ ਹੈ।','Playback ready; storage failed, so you may need to re-import.'))}
 }
 async function toggle(){reveal();if(!available){$('gs-audio-import').click();return}
  if(audio.paused){try{await audio.play()}catch(e){info(note('ਆਡੀਓ ਚਲਾਉਣ ਵਿੱਚ ਸਮੱਸਿਆ।','Could not play this audio file.'))}}
  else audio.pause();}
 document.addEventListener('click',e=>{
  const b=e.target.closest('[data-action="audio"], [data-pop="listen"]');
  if(!b)return;
  // The existing handler would show an outdated 'audio pending' message.
  e.preventDefault();e.stopImmediatePropagation();toggle();
 },true);
 $('gs-audio-close').onclick=()=>dock.classList.add('hidden');
 $('gs-audio-import').addEventListener('change',e=>{importFile(e.target.files?.[0]);e.target.value=''});
 $('gs-audio-back').onclick=()=>{if(available)audio.currentTime=Math.max(0,audio.currentTime-10)};
 $('gs-audio-forward').onclick=()=>{if(available)audio.currentTime=Math.min(audio.duration||Infinity,audio.currentTime+10)};
 $('gs-audio-speed').onchange=e=>{audio.playbackRate=Number(e.target.value)};
 audio.onended=()=>info(note('ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ ਦਾ ਪਾਠ ਪੂਰਾ ਹੋਇਆ।','Japji Sahib recording finished.'));
 window.GS_AUDIO={toggle,reveal,importFile,get available(){return available}};
 restore();
})();
