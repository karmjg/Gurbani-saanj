window.GS_BUILD={"version":"1.2.0","repo":"karmjg/Gurbani-saanj"};
