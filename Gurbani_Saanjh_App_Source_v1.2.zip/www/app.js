/* Gurbani Saanjh v1.2 — offline-first personal trial. No synthetic paath audio.
   Plain HTML/CSS/JS by design, so GitHub source stays easy to update.
*/
(()=>{
'use strict';
const CONTENT=window.GS_DATA;
const CATALOG=window.GS_CATALOG||[];
let catalogFilter='';
let catalogSelected=null;
const APP_VERSION=(window.GS_BUILD?.version||'1.2.0');
let isApplyingUpdate=false;
let installPrompt=null;
const KEY='gurbani-saanjh-trial-v1'; // Keep unchanged: older v0.2 reading progress migrates.
const BASE={lang:'pa',meaningLang:'pa',readingScript:'gurmukhi',meanings:false,theme:'light',mode:'scroll',font:24,uiScale:1.12,raisedHeadings:true,spacing:1.82,fontStyle:'serif',margin:'normal',
  view:'home',readView:'sggs',verse:0,verseOffset:0,page:0,hasProgress:false,kirtanId:'kirtan-lakh',
  favorites:[],homeOrder:['reader','nitnem','catalog','kirtan','ask','daily'],filter:'all',depth:'detail',questions:[],
  daily:{source:'sggs',order:'sequential',amount:2,time:'08:00',enabled:false,startDate:''}};
let stored={};try{stored=JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch{}
const state={...BASE,...stored,daily:{...BASE.daily,...(stored.daily||{})},favorites:Array.isArray(stored.favorites)?stored.favorites:[],questions:Array.isArray(stored.questions)?stored.questions.slice(-12):[]};
state.font=Math.min(40,Math.max(18,Number(state.font)||24));
state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));
state.raisedHeadings=state.raisedHeadings!==false;
state.spacing=Math.min(2.35,Math.max(1.45,Number(state.spacing)||1.82));
state.meaningLang=state.meaningLang==='en'?'en':'pa';
state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';
state.lang=state.lang==='en'?'en':'pa';
const HOME_IDS=['reader','nitnem','catalog','kirtan','ask','daily'];
function normalizeHomeOrder(value){const good=Array.isArray(value)?value.filter((id,i)=>HOME_IDS.includes(id)&&value.indexOf(id)===i):[];return [...good,...HOME_IDS.filter(id=>!good.includes(id))]}
state.homeOrder=normalizeHomeOrder(state.homeOrder);
let homeEditing=false;
let homePending=null;
let homeDrag=null;
let homeDragCleanup=null;
let lastHomeDragEnded=0;
state.view='home';
state.fontStyle=['serif','sans'].includes(state.fontStyle)?state.fontStyle:'serif';
state.margin=['narrow','normal','wide'].includes(state.margin)?state.margin:'normal';
state.theme=['light','sepia','dark','charcoal'].includes(state.theme)?state.theme:'light';
const $=id=>document.getElementById(id);
const words=CONTENT.words;
const lines=CONTENT.reader.sections[0].lines;
const PAGE_GROUPS=[[0,1,2,3],[4,5,6],[7,8,9]]; // Visual pagination of ONE trial Ang, not separate Angs.
const txt={
pa:{home:'ਮੁੱਖ',read:'ਪਾਠ',search:'ਖੋਜ',ask:'ਸਵਾਲ',settings:'ਸੈਟਿੰਗਾਂ',menu:'ਮੀਨੂ',readerSettings:'ਪੜ੍ਹਨ ਦੀ ਸੈਟਿੰਗ',appearance:'ਦਿੱਖ',fontStyleLabel:'ਫੌਂਟ',serif:'ਕਿਤਾਬੀ',sans:'ਸਾਫ਼',margins:'ਪਾਸਿਆਂ ਦੀ ਜਗ੍ਹਾ',narrow:'ਘੱਟ',normal:'ਦਰਮਿਆਨੀ',wide:'ਵੱਧ',sepia:'ਸੇਪੀਆ',charcoal:'ਚਾਰਕੋਲ',smallText:'ਛੋਟੇ ਅੱਖਰ',largeText:'ਵੱਡੇ ਅੱਖਰ',updateCenter:'ਐਪ ਅੱਪਡੇਟ',currentVersion:'ਮੌਜੂਦਾ ਵਰਜ਼ਨ',updating:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੱਭ ਰਹੇ ਹਾਂ…',upToDate:'ਇਹ ਵਰਜ਼ਨ ਅੱਪਡੇਟ ਹੈ।',updateAvailable:'ਨਵਾਂ ਵਰਜ਼ਨ ਮਿਲਿਆ ਹੈ। ਅੱਪਡੇਟ ਕਰਨ ਲਈ ਦਬਾਓ।',updateRequiresWeb:'Android APK ਅੱਪਡੇਟ ਲਈ GitHub Releases ਵਰਤੋ।',updateFailed:'ਅੱਪਡੇਟ ਚੈੱਕ ਨਹੀਂ ਹੋ ਸਕੀ। ਇੰਟਰਨੈੱਟ ਚੈੱਕ ਕਰੋ।',updateReady:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ…',install:'ਹੋਮ ਸਕਰੀਨ ਉੱਤੇ ਜੋੜੋ',installHint:'ਇਹ ਪਹਿਲਾਂ ਤੋਂ Android ਐਪ ਵਜੋਂ ਇੰਸਟਾਲ ਹੈ।',menuIntro:'ਇੱਕੋ ਐਪ ਰੱਖੋ — ਨਵੇਂ ਵਰਜ਼ਨ ਸਿੱਧੇ ਅੱਪਡੇਟ ਕਰੋ।',menuBackups:'ਤੁਹਾਡਾ ਡਾਟਾ',backupHint:'ਸਹਿਜ ਪਾਠ ਦੀ ਜਗ੍ਹਾ, ਪਸੰਦੀਦਾ ਸ਼ਬਦ ਅਤੇ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿੰਦੀਆਂ ਹਨ। ਬੈਕਅੱਪ ਵੱਖਰਾ ਸੰਭਾਲੋ।',
  hero:'ਗੁਰਬਾਣੀ ਨਾਲ ਜੁੜਨ ਦੀ ਇੱਕ ਸਾਦੀ ਥਾਂ',welcome:'ਜਿੱਥੇ ਛੱਡਿਆ ਸੀ, ਉੱਥੋਂ ਪੜ੍ਹੋ',continue:'ਸਹਿਜ ਪਾਠ ਜਾਰੀ ਰੱਖੋ',
  sample:'ਨਿੱਜੀ ਟਰਾਇਲ: ਇਸ ਵੇਲੇ ਅੰਗ ੧ ਦੀਆਂ ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ ਹਨ, ਪੂਰਾ ਅੰਗ ਨਹੀਂ।',
  readerTitle:'ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ', ang:'ਅੰਗ', excerpt:'ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ',
  meanings:'ਅਰਥ',on:'ਚਾਲੂ',off:'ਬੰਦ',listen:'ਸੁਣੋ',meaning:'ਅਰਥ',
  audioPending:'ਪਲੇਅਰ ਵਿੱਚ ਅਸਲੀ ਮਨੁੱਖੀ ਰਿਕਾਰਡਿੰਗ ਸੁਣ ਸਕਦੇ ਹੋ। ਸ਼ਬਦ-ਵਾਰ ਸਮਾਂ ਹਾਲੇ ਨਹੀਂ ਮਿਲਾਇਆ।',
  wordPending:'ਇਸ ਸ਼ਬਦ ਦੇ ਪ੍ਰਮਾਣਿਤ ਅਰਥ ਹਾਲੇ ਜੋੜਣੇ ਹਨ।',
  start:'ਪੜ੍ਹੋ',next:'ਅਗਲਾ',prev:'ਪਿਛਲਾ',last:'ਅਗਲਾ ਅੰਗ ਅਜੇ ਟਰਾਇਲ ਵਿੱਚ ਨਹੀਂ ਹੈ।',
  library:'ਗੁਰਬਾਣੀ ਸੰਗ੍ਰਹਿ',catalog:'ਅਨੇਕ ਬਾਣੀਆਂ',catalogSearch:'ਬਾਣੀ ਦਾ ਨਾਮ ਖੋਜੋ...',catalogNotice:'ਇਹ ਤੁਹਾਡੀ ਵੀਡੀਓ ਵਾਲੀ ਸੂਚੀ ਹੈ। ਪ੍ਰਮਾਣਿਤ ਪੂਰੇ ਪਾਠ ਅਜੇ ਨਹੀਂ ਜੋੜੇ ਗਏ।',catalogPending:'ਇਸ ਬਾਣੀ ਦਾ ਪ੍ਰਮਾਣਿਤ ਪੂਰਾ ਪਾਠ ਅਜੇ ਜੋੜਿਆ ਜਾਣਾ ਹੈ।',catalogSection1:'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੀਆਂ ਬਾਣੀਆਂ',catalogSection2:'ਦਸਮ ਗ੍ਰੰਥ ਸੰਬੰਧੀ ਬਾਣੀਆਂ',catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਵੱਖਰੇ ਰੂਪ',catalogSection4:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',catalogResults:'ਬਾਣੀਆਂ',collection:'ਹੋਰ ਬਾਣੀਆਂ',kirtan:'ਕੀਰਤਨ ਸ਼ਬਦ',
  kirtanDesc:'ਵਾਰ-ਵਾਰ ਪੜ੍ਹਨ ਲਈ ਪਸੰਦੀਦਾ ਸ਼ਬਦ',kirtanNote:'ਇਸ ਟਰਾਇਲ ਵਿੱਚ ਸ਼ਬਦਾਂ ਦੀਆਂ ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ ਹਨ; ਪੂਰੇ ਸ਼ਬਦ ਬਾਅਦ ਵਿੱਚ ਜੋੜੇ ਜਾਣਗੇ।',
  fav:'ਪਸੰਦੀਦਾ',all:'ਸਾਰੇ',onlyFav:'ਸਿਰਫ਼ ਪਸੰਦੀਦਾ',noFav:'ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੇਵ ਨਹੀਂ ਕੀਤਾ।',
  nitnem:'ਨਿਤਨੇਮ',dasam:'ਦਸਮ ਗ੍ਰੰਥ ਸਾਹਿਬ',bhai:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',pending:'ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਅਤੇ ਵਰਤੋਂ ਦੀ ਇਜਾਜ਼ਤ ਤੋਂ ਬਾਅਦ ਪੂਰੀ ਸਮੱਗਰੀ ਜੋੜੀ ਜਾਵੇਗੀ।',
  searchTitle:'ਗੁਰਬਾਣੀ ਖੋਜੋ',searchHint:'ਪੰਗਤੀ ਜਾਂ ਸ਼ਬਦ ਲਿਖੋ ਜਾਂ ਬੋਲੋ...',voicePending:'ਆਵਾਜ਼ ਨਾਲ ਖੋਜ ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਉਪਲਬਧ ਨਹੀਂ ਜਾਂ ਇੰਟਰਨੈੱਟ ਚਾਹੀਦਾ ਹੈ।',
  noResults:'ਟਰਾਇਲ ਦੀਆਂ ਪੰਗਤੀਆਂ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ।',results:'ਨਤੀਜੇ',
  askTitle:'ਗੁਰਬਾਣੀ ਤੋਂ ਪੁੱਛੋ',askHint:'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ...',askButton:'ਪੁੱਛੋ',short:'ਸੰਖੇਪ',detail:'ਵਿਸਥਾਰ',deep:'ਡੂੰਘਾਈ',
  askNotLive:'AI ਹਾਲੇ ਕਨੈਕਟ ਨਹੀਂ ਹੈ। ਇਹ ਸਿਰਫ਼ ਗੱਲਬਾਤ ਦੇ ਡਿਜ਼ਾਈਨ ਦਾ ਟਰਾਇਲ ਹੈ। ਅਸਲ ਜਵਾਬ ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਹਵਾਲਿਆਂ ਨਾਲ ਤਿਆਰ ਹੋਣਗੇ; ਦਸਮ ਗ੍ਰੰਥ ਅਤੇ ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਸਹਾਇਕ ਸਰੋਤ ਹੋਣਗੇ।',
  askRules:'AI ਸਵਾਲਾਂ ਦੇ ਅਸਲੀ ਜਵਾਬ ਇਸ ਵਰਜ਼ਨ ਵਿੱਚ ਹਾਲੇ ਉਪਲਬਧ ਨਹੀਂ ਹਨ।',
  language:'ਐਪ ਦੀ ਭਾਸ਼ਾ',meanLang:'ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ',viewMeaning:'ਪੰਗਤੀ ਹੇਠਾਂ ਅਰਥ',mode:'ਪੰਨਾ ਬਦਲਣ ਦਾ ਤਰੀਕਾ',scroll:'ਸਕ੍ਰੋਲ',page:'ਕਿਤਾਬ ਵਾਂਗ',font:'ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',spacing:'ਲਾਈਨਾਂ ਵਿਚਕਾਰ ਜਗ੍ਹਾ',theme:'ਰੰਗ',light:'ਹਲਕਾ',dark:'ਗੂੜ੍ਹਾ',
  reading:'ਪੜ੍ਹਨ ਦਾ ਤਰੀਕਾ',preferences:'ਤੁਹਾਡੀਆਂ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿਣਗੀਆਂ।',
  update:'ਅੱਪਡੇਟ ਚੈੱਕ ਕਰੋ',backup:'ਬੈਕਅੱਪ',restore:'ਬੈਕਅੱਪ ਲਿਆਓ',
  daily:'ਰੋਜ਼ਾਨਾ ਗੁਰਬਾਣੀ',dailyTitle:'ਅੱਜ ਲਈ ਗੁਰਬਾਣੀ',dailyDesc:'ਤੁਹਾਡੀ ਆਪਣੀ ਰਫ਼ਤਾਰ ਨਾਲ ਪੜ੍ਹਨ ਲਈ',dailySetup:'ਰੋਜ਼ਾਨਾ ਪਾਠ ਸੈੱਟ ਕਰੋ',dailyPreview:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦਾ ਨਮੂਨਾ',dailyOpen:'ਅੱਜ ਦਾ ਪਾਠ ਖੋਲ੍ਹੋ',
  amount:'ਰੋਜ਼ ਕਿੰਨੇ ਅੰਗ?',order:'ਚੋਣ ਦਾ ਤਰੀਕਾ',sequential:'ਲੜੀਵਾਰ',random:'ਰੈਂਡਮ',source:'ਕਿਹੜਾ ਸਰੋਤ?',time:'ਸਮਾਂ',
  enable:'ਰੋਜ਼ਾਨਾ ਯਾਦ ਦਿਵਾਉਣਾ',savePlan:'ਪਲਾਨ ਸੇਵ ਕਰੋ',sendTest:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ',
  dailyLimit:'ਹੁਣ ਇਹ ਪਲਾਨ ਅਤੇ ਐਪ ਅੰਦਰਲਾ ਨਮੂਨਾ ਕੰਮ ਕਰਦੇ ਹਨ। ਐਪ ਬੰਦ ਹੋਣ ’ਤੇ ਹਰ ਰੋਜ਼ ਭਰੋਸੇਯੋਗ ਨੋਟੀਫਿਕੇਸ਼ਨ ਲਈ ਅਗਲੇ ਵਰਜ਼ਨ ਵਿੱਚ Android reminder ਜਾਂ push service ਜੋੜਨੀ ਪਵੇਗੀ।',
  notificationsUnsupported:'ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਨੋਟੀਫਿਕੇਸ਼ਨ ਉਪਲਬਧ ਨਹੀਂ।',notificationDenied:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਮਿਲੀ।',notificationSent:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ ਭੇਜੀ ਗਈ।',
  planSaved:'ਤੁਹਾਡਾ ਪਲਾਨ ਸੇਵ ਹੋ ਗਿਆ।',preview:'ਨਮੂਨਾ · ਅਸਲ ਪਾਠ ਨਹੀਂ',
  pageHint:'ਸਵਾਈਪ ਕਰਕੇ ਪੰਨਾ ਬਦਲੋ',transNote:'ਅਰਥ ਸੌਖੀ ਵਿਆਖਿਆ ਦੇ ਨਮੂਨੇ ਹਨ; ਹਾਲੇ ਵਿਦਵਾਨਾਂ ਤੋਂ ਸਮੀਖਿਆ ਅਤੇ ਅਧਿਕਾਰਾਂ ਦੀ ਪੁਸ਼ਟੀ ਬਾਕੀ ਹੈ।',saved:'ਆਖ਼ਰੀ ਪੜ੍ਹੀ ਜਗ੍ਹਾ ਆਪਣੇ ਆਪ ਸੇਵ ਹੁੰਦੀ ਹੈ।'},
en:{home:'Home',read:'Read',search:'Search',ask:'Ask',settings:'Settings',menu:'Menu',readerSettings:'Reading settings',appearance:'Appearance',fontStyleLabel:'Font',serif:'Book',sans:'Clean',margins:'Page margins',narrow:'Narrow',normal:'Comfort',wide:'Wide',sepia:'Sepia',charcoal:'Charcoal',smallText:'Smaller text',largeText:'Larger text',updateCenter:'App updates',currentVersion:'Current version',updating:'Checking for a newer version…',upToDate:'You are using the latest published version.',updateAvailable:'A newer version is ready. Tap to update.',updateRequiresWeb:'Android APK updates are delivered through GitHub Releases.',updateFailed:'Could not check for updates. Check your connection.',updateReady:'Loading the updated app…',install:'Add to home screen',installHint:'You already have the Android app installed.',menuIntro:'Keep the same installed app and receive new versions without reinstalling.',menuBackups:'Your data',backupHint:'Your Sahaj Paath position, favourites and settings stay saved on this phone. Keep a backup for extra safety.',
  hero:'A calm place to reconnect with Gurbani',welcome:'Continue from where you left off',continue:'Continue Sehaj Paath',
  sample:'Private trial: only selected lines from Ang 1 are included, not the complete Ang.',
  readerTitle:'Japji Sahib Ji',ang:'Ang',excerpt:'Selected lines',meanings:'Meanings',on:'On',off:'Off',listen:'Listen',meaning:'Meaning',
  audioPending:'Original human audio available in the player. Word timing is not yet verified.',wordPending:'Reviewed word meaning is not yet available.',
  start:'Read',next:'Next',prev:'Back',last:'The next Ang is not available in this trial.',
  library:'Scripture library',catalog:'Anek Baaniyaan',catalogSearch:'Search a Bani by name...',catalogNotice:'This is the list from your video. Verified full texts have not been added yet.',catalogPending:'The verified full text for this Bani has not been added yet.',catalogSection1:'Baaniyaan from Sri Guru Granth Sahib Ji',catalogSection2:'Dasam Granth related compositions',catalogSection3:'Other recitations and variations',catalogSection4:'Bhai Gurdas Ji',catalogResults:'Baaniyaan',collection:'Other Banis',kirtan:'Kirtan Shabads',kirtanDesc:'Favourite Shabads to read again',
  kirtanNote:'This trial contains selected lines only; full Shabads will be included after content review.',
  fav:'Favourites',all:'All',onlyFav:'Favourites only',noFav:'No saved Shabads yet.',
  nitnem:'Nitnem',dasam:'Sri Dasam Granth Sahib',bhai:'Bhai Gurdas Ji',pending:'Full content will be added after text verification and the necessary permissions.',
  searchTitle:'Search Gurbani',searchHint:'Type or speak a word or line...',voicePending:'Voice search is unavailable here or needs an online speech service.',
  noResults:'Not found in the trial excerpts.',results:'Results',
  askTitle:'Ask Gurbani',askHint:'Ask any question...',askButton:'Ask',short:'Brief',detail:'Detailed',deep:'In depth',
  askNotLive:'Live AI is not connected yet. This is a conversation-design trial. Future answers will cite Sri Guru Granth Sahib Ji first, with Sri Dasam Granth and Bhai Gurdas Ji as relevant supporting sources.',askRules:'Real AI responses are not available in this version yet.',
  language:'App language',meanLang:'Meaning language',viewMeaning:'Meanings under each line',mode:'Page navigation',scroll:'Scroll',page:'Book-style',font:'Font size',spacing:'Line spacing',theme:'Theme',light:'Light',dark:'Dark',
  reading:'Reading preferences',preferences:'Preferences are saved on this device.',update:'Check for updates',backup:'Export backup',restore:'Import backup',
  daily:'Daily Gurbani',dailyTitle:'Your Gurbani for today',dailyDesc:'A reading rhythm that feels right for you',dailySetup:'Set daily reading',dailyPreview:'Notification preview',dailyOpen:'Open today’s reading',
  amount:'Daily Ang goal',order:'Selection',sequential:'In order',random:'Random',source:'Starting collection',time:'Time',
  enable:'Daily reminder preference',savePlan:'Save reading plan',sendTest:'Test notification',
  dailyLimit:'Your plan and the in-app preview work now. Reliable daily delivery while the app is closed requires a future Android reminder feature or push service.',
  notificationsUnsupported:'Notifications are unavailable in this browser.',notificationDenied:'Notification permission was not granted.',notificationSent:'Test notification sent.',
  planSaved:'Your plan is saved.',preview:'Preview · not full scripture',pageHint:'Swipe to turn pages',transNote:'Meanings are illustrative paraphrases, not yet scholarly reviewed or licensed for release.',saved:'Your last reading position is saved automatically.'}}
txt.pa.readingScript='ਗੁਰਬਾਣੀ ਦੀ ਲਿਪੀ';txt.en.readingScript='Gurbani script';
txt.pa.roman='ਅੰਗਰੇਜ਼ੀ ਅੱਖਰ';txt.en.roman='English letters';
txt.pa.nitnemNote='ਨਿਤਨੇਮ — ਜਪੁਜੀ ਸਾਹਿਬ ਦੀ ਅਸਲੀ ਮਨੁੱਖੀ ਰਿਕਾਰਡਿੰਗ ਟੈਸਟ ਕਰੋ।';txt.en.nitnemNote='Nitnem — test the authentic Japji Sahib recitation.';
const t=k=>(txt[state.lang]||txt.pa)[k]||k;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const age=(k,en)=>state.lang==='pa'?k:en;
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch{}}
function toast(msg){let x=$('toast');x.textContent=msg;x.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>x.classList.remove('show'),3400)}
function theme(){
 const html=document.documentElement;
 html.classList.toggle('dark',state.theme==='dark'||state.theme==='charcoal');
 html.dataset.tone=state.theme;html.dataset.font=state.fontStyle;html.dataset.margin=state.margin;html.dataset.raisedText=state.raisedHeadings?'on':'off';
 html.style.setProperty('--font',state.font+'px');
 html.style.setProperty('--ui-scale',state.uiScale);
 html.style.setProperty('--leading',state.spacing);html.lang=state.lang;
 document.querySelector('meta[name=theme-color]')?.setAttribute('content',state.theme==='dark'||state.theme==='charcoal'?'#19221f':state.theme==='sepia'?'#f4eddf':'#fbfaf7');
}
function go(view,opts={}){if(view!=='home')homeEditing=false;if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();closeWord();state.view=view;if(view==='reader'&&opts.reader)state.readView=opts.reader;persist();render();if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});}
function navReader(){state.readView='sggs';go('reader')}
function labelSource(src){return ({sggs:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),japji:age('ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ','Japji Sahib Ji'),dasam:t('dasam'),bhai:t('bhai')})[src]||src}
/* Consistent daily sample: a deterministic date-based excerpt, not a fake five-Ang pack. */
function dailyExcerpt(){
 if(!['sggs','japji'].includes(state.daily.source))return null;
 const now=new Date();const dayKey=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
 const origin=state.daily.startDate||dayKey;
 const days=Math.max(0,Math.floor((Date.parse(dayKey+'T12:00:00')-Date.parse(origin+'T12:00:00'))/86400000));
 let idx=days%lines.length;
 if(state.daily.order==='random'){
  let hash=0;for(const c of dayKey+state.daily.source)hash=(hash*31+c.charCodeAt(0))>>>0;
  idx=hash%lines.length;
 }
 return lines[idx];
}
function dailyQuote(){const l=dailyExcerpt();if(!l)return `<p class="fine">${t('pending')}</p>`;
 return `<div class="daily-quote" lang="pa">${esc(l.g)}</div><p class="daily-meaning">${esc(l[state.meaningLang])}</p>`}
function render(){theme();document.documentElement.classList.toggle('home-open',state.view==='home');$('brand').textContent='ਗੁਰਬਾਣੀ ਸਾਂਝ';$('labelHome').textContent=t('home');$('labelRead').textContent=t('read');$('labelSearch').textContent=t('search');$('labelBookmarks').textContent=age('ਸੰਭਾਲੇ','Saved');$('labelMenu').textContent=t('settings');$('settingsBtn').title=t('readerSettings');$('settingsBtn').style.visibility=state.view==='reader'?'visible':'hidden';$('backBtn').style.visibility=state.view==='home'?'hidden':'visible';
for(const v of ['home','reader','search','bookmarks','menu'])$('nav-'+v).classList.toggle('active',state.view===v);
const views={home:homeScreen,nitnem:nitnemScreen,reader:readerScreen,library:libraryScreen,catalog:catalogScreen,catalogItem:catalogEntryScreen,kirtan:kirtanScreen,search:searchScreen,ask:askScreen,bookmarks:bookmarksScreen,daily:dailyScreen,coming:comingScreen,menu:menuScreen};
$('main').innerHTML=(views[state.view]||homeScreen)();attach();
if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll'&&state.hasProgress){requestAnimationFrame(()=>{const node=document.querySelector(`[data-line="${Math.min(lines.length-1,state.verse)}"]`);if(node){const y=window.scrollY+node.getBoundingClientRect().top-73+state.verseOffset;window.scrollTo({top:Math.max(0,y),behavior:'instant'})}})}}
function homeCard(id){
 const icons={
 reader:'<path d="M12 6.5C9.6 4.6 6.7 4.1 3 4v15c3.7.1 6.6.8 9 2.3 2.4-1.5 5.3-2.2 9-2.3V4c-3.7.1-6.6.6-9 2.5Z"/><path d="M12 6.5v14.8"/>',
 nitnem:'<path d="M5 4.5h14v15H5z"/><path d="M9 2v5m6-5v5M5 10h14"/><path d="M9 14h2m2 0h2m-6 3h2"/>',
 catalog:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
 kirtan:'<path d="M4 6a4 4 0 0 1 4-3h12v16H8a4 4 0 0 0-4 2Z"/><path d="M4 6v15M10 8h7M10 12h7"/>',
 ask:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 daily:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/>'
 };
 const titles={reader:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),nitnem:t('nitnem'),catalog:t('catalog'),kirtan:t('kirtan'),ask:t('askTitle'),daily:t('daily')};
 const descriptions={reader:age('ਪੜ੍ਹਨ ਲਈ','For reading'),nitnem:age('ਨਿਤਨੇਮ ਪਾਠ','Daily prayers'),catalog:age('ਹੋਰ ਬਾਣੀਆਂ','Other Banis'),kirtan:age('ਕੇਵਲ ਪੜ੍ਹਨ ਲਈ','For reading only'),ask:age('ਸਵਾਲ ਅਤੇ ਵਿਆਖਿਆ','Questions & meaning'),daily:age('ਅੱਜ ਦਾ ਪਾਠ','Today’s reading')};
 return `<button type="button" class="feature home-tile tile-3d ${id==='ask'||id==='daily'?'tile-wide':''} ${id==='daily'?'tile-daily':''}" data-action="${id}" data-home-id="${id}" aria-label="${esc(titles[id])}" aria-grabbed="${homeEditing}"><span class="drag-handle" aria-hidden="true">⠿</span><span class="tile-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round">${icons[id]}</svg></span><strong>${titles[id]}</strong><span class="tile-foot"><small>${descriptions[id]}</small><span aria-hidden="true">›</span></span></button>`;
}
function homeScreen(){return `<div class="home home-v6 home-v7 home-v10 ${homeEditing?'home-editing':''}">
  <section class="premium-hero" aria-label="Gurbani Saanjh">
    <div class="hero-brand"><img src="icons/icon-192.png" alt="" class="hero-mark"><h1>ਗੁਰਬਾਣੀ ਸਾਂਝ</h1></div>
    <div class="hero-temple" role="img" aria-label="Sri Harmandir Sahib illustration"></div>
    <div class="home-lang-switch" role="group" aria-label="App language"><button data-action="lang-pa" class="${state.lang==='pa'?'sel':''}">ਪੰਜਾਬੀ</button><button data-action="lang-en" class="${state.lang==='en'?'sel':''}">English</button></div>
  </section>
  <button class="continue-card" data-action="continue"><span class="continue-icon" aria-hidden="true">↗</span><span class="continue-copy"><strong>${t('continue')}</strong><small>${age('ਸਹਿਜ ਪਾਠ · ਅੰਗ ੧ (ਨਮੂਨਾ)','Sahaj Paath · Ang 1 (sample)')}</small></span><span class="go" aria-hidden="true">›</span></button>
  <div class="section-head home-label"><span>${t('library')}</span><button class="text-link reorder-trigger" data-action="${homeEditing?'done-layout':'edit-layout'}">${homeEditing?age('ਹੋ ਗਿਆ','Done'):age('ਤਰਤੀਬ ਬਦਲੋ','Rearrange')}</button></div>
  ${homeEditing?`<div class="layout-edit-banner"><span>${age('ਕਿਸੇ ਕਾਰਡ ਨੂੰ ਫੜ ਕੇ ਨਵੀਂ ਜਗ੍ਹਾ ਲੈ ਜਾਓ।','Hold a card and move it to a new position.')}</span><button data-action="reset-layout">${age('ਮੂਲ ਤਰਤੀਬ','Reset')}</button></div>`:''}
  <div class="feature-grid home-grid home-drag-grid" id="homeDragGrid" aria-label="${age('ਘਰ ਦੇ ਕਾਰਡ','Home cards')}">${state.homeOrder.map(homeCard).join('')}</div>
  <p class="home-trial-label">${age('ਨਿੱਜੀ ਟਰਾਇਲ · ਪੂਰਾ ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਹਾਲੇ ਜੋੜਿਆ ਜਾਣਾ ਹੈ','Private trial · Complete verified texts not yet included')}</p>
 </div>`} 
function moveHomeCard(id,delta){const order=normalizeHomeOrder(state.homeOrder),from=order.indexOf(id),to=Math.max(0,Math.min(order.length-1,from+delta));if(to===from)return;order.splice(from,1);order.splice(to,0,id);state.homeOrder=order;persist();render();const node=document.querySelector(`[data-home-id="${id}"]`);node?.focus();}
function setupHomeDrag(){
 if(homeDragCleanup)homeDragCleanup();
 const grid=$('homeDragGrid');if(!grid)return;
 function stopPending(){if(homePending){clearTimeout(homePending.timer);homePending=null}}
 function beginDrag(info){
  if(!info)return;
  if(!homeEditing){homeEditing=true;render();}
  const list=$('homeDragGrid'),tile=[...list.querySelectorAll('[data-home-id]')].find(x=>x.dataset.homeId===info.id);
  if(!tile)return;
  const r=tile.getBoundingClientRect();
  const ghost=tile.cloneNode(true);ghost.classList.add('tile-drag-ghost');ghost.removeAttribute('id');
  ghost.style.width=r.width+'px';ghost.style.height=r.height+'px';
  ghost.style.left=r.left+'px';ghost.style.top=r.top+'px';
  document.body.appendChild(ghost);tile.classList.add('tile-placeholder');
  homeDrag={pointerId:info.pointerId,ghost,tile,list,dx:info.x-r.left,dy:info.y-r.top};
  lastHomeDragEnded=Date.now();
  if(navigator.vibrate)try{navigator.vibrate(18)}catch{}
 }
 grid.addEventListener('pointerdown',e=>{
  const tile=e.target.closest('[data-home-id]');if(!tile||e.button!==0)return;
  stopPending();homePending={id:tile.dataset.homeId,pointerId:e.pointerId,x:e.clientX,y:e.clientY};
  if(homeEditing){beginDrag(homePending);homePending=null;return}
  homePending.timer=setTimeout(()=>{const p=homePending;homePending=null;beginDrag(p)},460);
 });
 const onMove=e=>{
  if(homePending&&homePending.pointerId===e.pointerId){
   if(Math.hypot(e.clientX-homePending.x,e.clientY-homePending.y)>11)stopPending();
  }
  const d=homeDrag;if(!d||d.pointerId!==e.pointerId)return;
  if(e.cancelable)e.preventDefault();
  d.ghost.style.left=(e.clientX-d.dx)+'px';d.ghost.style.top=(e.clientY-d.dy)+'px';
  const el=document.elementFromPoint(e.clientX,e.clientY);
  const over=el?.closest?.('[data-home-id]');
  if(!over||over===d.tile||!d.list.contains(over))return;
  const from=[...d.list.children].indexOf(d.tile),to=[...d.list.children].indexOf(over);
  if(from<to)d.list.insertBefore(d.tile,over.nextSibling);else d.list.insertBefore(d.tile,over);
 };
 document.addEventListener('pointermove',onMove,{passive:false});
 function finishDrag(e){
  if(homePending&&(!e||homePending.pointerId===e.pointerId))stopPending();
  const d=homeDrag;if(!d||e&&d.pointerId!==e.pointerId)return;
  d.ghost.remove();d.tile.classList.remove('tile-placeholder');homeDrag=null;
  state.homeOrder=[...d.list.querySelectorAll('[data-home-id]')].map(n=>n.dataset.homeId);persist();
  lastHomeDragEnded=Date.now();render();
 }
 document.addEventListener('pointerup',finishDrag);
 document.addEventListener('pointercancel',finishDrag);
 grid.addEventListener('contextmenu',e=>{if(e.target.closest('[data-home-id]'))e.preventDefault()});
 homeDragCleanup=()=>{document.removeEventListener('pointermove',onMove);document.removeEventListener('pointerup',finishDrag);document.removeEventListener('pointercancel',finishDrag);stopPending();if(homeDrag){homeDrag.ghost.remove();homeDrag=null}};
}
const NITNEM_LIST=[['ਜਪੁਜੀ ਸਾਹਿਬ','Japji Sahib',true],['ਜਾਪੁ ਸਾਹਿਬ','Jaap Sahib',false],['ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ','Tav-Prasad Savaiye',false],['ਚੌਪਈ ਸਾਹਿਬ','Chaupai Sahib',false],['ਅਨੰਦੁ ਸਾਹਿਬ','Anand Sahib',false],['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',false],['ਕੀਰਤਨ ਸੋਹਿਲਾ','Kirtan Sohila',false]];
function nitnemScreen(){return `<section class="page nitnem-page"><h1>${t('nitnem')}</h1><p class="muted fine">${t('nitnemNote')}</p>${NITNEM_LIST.map(([pa,en,ready])=>`<button class="catalog-row" data-action="${ready?'open-japji':'bani-pending'}"><span>${state.lang==='pa'?pa:en}<small class="nitnem-state">${ready?(state.lang==='pa'?'ਪਾਠ + MP3 ਟੈਸਟ':'Reading + MP3 test'):(state.lang==='pa'?'ਅਜੇ ਟੈਸਟ ਵਿੱਚ ਨਹੀਂ':'Not in this test yet')}</small></span><span aria-hidden="true">›</span></button>`).join('')}</section>`}
function lineHTML(v,idx,kind='sggs'){
 const roman=state.readingScript==='roman'&&v.roman;
 const original=v.g.trim().split(/\s+/),visible=(roman?v.roman:v.g).trim().split(/\s+/);
 const rendered=visible.map((part,i)=>`<button class="word" data-word="${esc(original[i]||part)}" data-kind="${kind}" data-idx="${idx}" aria-label="${esc(part)}">${esc(part)}</button>`).join(' ');
 return `<article class="verse-block" data-line="${idx}"><div class="verse-text ${roman?'roman-text':''}" lang="${roman?'en':'pa'}">${rendered}</div>${state.meanings?`<div class="verse-meaning" lang="${state.meaningLang}">${esc(v[state.meaningLang]||'')}</div>`:''}</article>`;
}
function readerScreen(){if(state.readView==='kirtan'){const item=CONTENT.kirtan.find(x=>x.id===state.kirtanId)||CONTENT.kirtan[0];return `<section class="reading"><div class="reading-head"><div><h1>${esc(item[state.lang==='pa'?'titlePa':'titleEn'])}</h1><div class="sub">${esc(item[state.lang==='pa'?'descriptionPa':'descriptionEn'])} · ${t('ang')} ${item.ang}</div></div><button class="read-action" data-action="toggle-meaning">${t('meanings')} ${state.meanings?t('on'):t('off')}</button></div><div class="ang-label">${t('excerpt')}</div><div class="verse-list">${item.lines.map((v,i)=>lineHTML(v,i,'kirtan')).join('')}</div><p class="notice">${t('kirtanNote')}</p><button class="secondary full" data-action="kirtan">← ${t('kirtan')}</button></section>`}
const indices=state.mode==='page'?PAGE_GROUPS[state.page]||PAGE_GROUPS[0]:lines.map((_,i)=>i);
return `<section class="reading"><div class="reading-head"><div><h1>${t('readerTitle')}</h1><div class="sub">${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji')}</div></div><div><button class="read-action" data-action="audio" title="${t('listen')}">▶ ${t('listen')}</button><button class="read-action" data-action="toggle-meaning">${t('meanings')} ${state.meanings?t('on'):t('off')}</button></div></div>
${state.mode==='scroll'||state.page===0?`<div class="ang-label">${t('ang')} ੧ · ${t('excerpt')}</div>`:''}
<div class="reading-script-shortcut"><button data-action="script-gurmukhi" class="${state.readingScript==='gurmukhi'?'selected':''}">ਗੁਰਮੁਖੀ</button><button data-action="script-roman" class="${state.readingScript==='roman'?'selected':''}">English letters</button></div>
<div class="verse-list" id="verses">${indices.map(i=>lineHTML(lines[i],i)).join('')}</div>
${state.mode==='page'?`<div class="pagebar"><button class="secondary" data-action="prev" ${state.page===0?'disabled':''}>‹ ${t('prev')}</button><span class="small">${state.page+1} / ${PAGE_GROUPS.length}</span><button class="secondary" data-action="next" ${state.page===PAGE_GROUPS.length-1?'disabled':''}>${t('next')} ›</button></div><p class="tiny-status center">${t('pageHint')}</p>`:''}
<div class="reading-bottom"><span class="tiny-status">✓ ${t('saved')}</span><p class="trial-notice">${t('sample')} ${t('transNote')}</p></div></section>`}
function libraryScreen(){return `<section class="page"><h1>${t('library')}</h1>
${[['reader',age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji')],['nitnem',t('nitnem')],['catalog',t('catalog')],['dasam',t('dasam')],['kirtan',t('kirtan')]].map(([a,name])=>`<button class="catalog-row" data-action="${a}"><span>${name}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}
function catalogScreen(){return `<section class="page catalog-page"><h1>${t('catalog')}</h1><p class="muted fine">${t('catalogNotice')}</p>
<label class="catalog-search-box"><span aria-hidden="true">⌕</span><input type="search" id="catalogSearch" autocomplete="off" placeholder="${t('catalogSearch')}" value="${esc(catalogFilter)}" aria-label="${t('catalogSearch')}"></label>
<div id="catalogResults">${catalogRows(catalogFilter)}</div></section>`}
function catalogRows(filter){const q=String(filter||'').trim().toLocaleLowerCase();const groups=[['sggs','catalogSection1'],['dasam','catalogSection2'],['tradition','catalogSection3'],['bhai','catalogSection4']];const count=CATALOG.filter(i=>!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))).length;
return `<div class="catalog-count">${count} ${t('catalogResults')}</div>`+groups.map(([g,header])=>{const items=CATALOG.filter(i=>i.group===g&&(!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))));if(!items.length)return '';return `<section class="catalog-section"><h2>${t(header)}</h2>${items.map(i=>`<button class="catalog-row" data-catalog-id="${i.id}"><span>${esc(i[state.lang==='pa'?'titlePa':'titleEn'])}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}).join('')}
function catalogEntryScreen(){const item=CATALOG.find(i=>i.id===catalogSelected);if(!item)return catalogScreen();return `<section class="page"><p class="eyebrow">${t('catalog')}</p><h1>${esc(item[state.lang==='pa'?'titlePa':'titleEn'])}</h1><p class="notice">${t('catalogPending')}</p><p class="muted fine">${age('ਪ੍ਰਮਾਣਿਤ ਸਰੋਤ, ਅਰਥ ਅਤੇ ਪਾਠ-ਰੂਪ ਦੀ ਜਾਂਚ ਤੋਂ ਬਾਅਦ ਹੀ ਸ਼ਾਮਲ ਕਰਾਂਗੇ।','We will add it only after verifying the source text, variant and use rights.')}</p><button class="secondary full" data-action="catalog">← ${t('catalog')}</button></section>`}
function comingScreen(){return `<section class="page"><h1>${esc(state.comingTitle||t('collection'))}</h1><div class="simple-card"><p>${t('pending')}</p><p class="fine">${t('sample')}</p></div><button class="secondary full" data-action="library">← ${t('library')}</button></section>`}
function kirtanScreen(){const items=CONTENT.kirtan.filter(v=>state.filter!=='favorites'||state.favorites.includes(v.id));return `<section class="page"><h1>${t('kirtan')}</h1><p class="muted fine">${t('kirtanDesc')}</p><div class="answer-pills"><button data-filter="all" class="${state.filter==='all'?'sel':''}">${t('all')}</button><button data-filter="favorites" class="${state.filter==='favorites'?'sel':''}">${t('onlyFav')}</button></div>
${items.map(v=>`<div class="simple-card item-row"><button class="item-main" data-kirtan="${v.id}"><strong>${esc(v[state.lang==='pa'?'titlePa':'titleEn'])}</strong><small>${esc(v[state.lang==='pa'?'descriptionPa':'descriptionEn'])} · ${t('ang')} ${v.ang} · ${t('excerpt')}</small></button><button class="favorite ${state.favorites.includes(v.id)?'selected':''}" data-favorite="${v.id}" aria-label="${t('fav')}" title="${t('fav')}">${state.favorites.includes(v.id)?'♥':'♡'}</button></div>`).join('')||`<p class="empty">${t('noFav')}</p>`}<p class="notice">${t('kirtanNote')}</p></section>`}
function bookmarksScreen(){const saved=CONTENT.kirtan.filter(item=>state.favorites.includes(item.id));return `<section class="page bookmarks-page"><h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1><p class="muted fine">${age('ਤੁਹਾਡੇ ਪਸੰਦੀਦਾ ਕੀਰਤਨ ਸ਼ਬਦ ਪੜ੍ਹਨ ਲਈ।','Your favourite Kirtan Shabads for reading.')}</p>${saved.length?saved.map(item=>`<button class="catalog-row" data-kirtan="${item.id}"><span>${esc(item[state.lang==='pa'?'titlePa':'titleEn'])}</span><span aria-hidden="true">›</span></button>`).join(''):`<p class="empty">${age('ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੰਭਾਲਿਆ ਨਹੀਂ। ਕੀਰਤਨ ਸ਼ਬਦਾਂ ਵਿੱਚੋਂ ♡ ਦਬਾਓ।','No saved Shabads yet. Save one from Kirtan Shabads.')}</p>`}<button class="secondary full" data-action="kirtan" style="margin-top:24px">${t('kirtan')} ›</button></section>`}
function menuScreen(){
 return `<section class="page menu-page"><div class="settings-page-header"><h1>${t('settings')}</h1><p class="muted fine">ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}</p></div>

 <div class="menu-group-label">${t('reading')}</div>
 <button class="menu-item" data-action="menu-settings"><span class="menu-copy"><strong>${t('readerSettings')}</strong><small>${t('font')} · ${t('theme')} · ${t('mode')}</small></span><span class="menu-chevron">›</span></button>

 <button class="menu-item" data-action="daily"><span class="menu-copy"><strong>${t('dailySetup')}</strong><small>${t('dailyDesc')}</small></span><span class="menu-chevron">›</span></button>
 <button class="menu-item" data-action="reset-layout"><span class="menu-copy"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਦੀ ਤਰਤੀਬ ਰੀਸੈੱਟ','Reset home layout')}</strong><small>${age('ਕਾਰਡਾਂ ਨੂੰ ਮੂਲ ਜਗ੍ਹਾ ਵਾਪਸ ਲਿਆਓ','Restore the original card positions')}</small></span><span class="menu-chevron">›</span></button>
 <div class="menu-group-label">${t('updateCenter')}</div>
 <div class="menu-update-card"><div class="version-info"><div><span class="muted fine">${t('currentVersion')}</span><strong>v${APP_VERSION}</strong></div><span class="version-dot" aria-hidden="true"></span></div><p class="fine" id="updateStatus">${t('menuIntro')}</p><button class="primary full" data-action="check-update" id="checkUpdateButton">↻ ${t('update')}</button>${window.GS_NATIVE_UPDATES?.isNative?'':`<button class="secondary full install-button" data-action="install-app">${t('install')} ↗</button><p class="fine muted">${t('installHint')}</p>`}</div>
 <div class="menu-group-label">${t('menuBackups')}</div>
 <p class="fine muted">${t('backupHint')}</p><div class="menu-backup-row"><button class="secondary" data-action="backup-export">${t('backup')} ↓</button><button class="secondary" data-action="backup-import">${t('restore')} ↑</button></div>
 <input id="menuBackupInput" class="hidden" type="file" accept="application/json,.json">
 <p class="fine trial-menu-note">${t('sample')}</p></section>`;
}
function searchScreen(){return `<section class="page"><h1>${t('searchTitle')}</h1><p class="muted fine">${t('sample')}</p><div class="inputrow"><span style="font-size:22px">⌕</span><input id="searchInput" autocomplete="off" aria-label="${t('searchTitle')}" placeholder="${t('searchHint')}"><button id="voiceBtn" aria-label="Voice search">🎙</button></div><div id="searchResults"></div></section>`}
function askScreen(){return `<section class="page ask"><h1>${t('askTitle')}</h1><p class="fine">${age('ਮੁੱਖ ਸਰੋਤ: ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Primary source: Sri Guru Granth Sahib Ji')}</p><textarea id="questionInput" placeholder="${t('askHint')}"></textarea><div class="answer-pills">${[['short','short'],['detail','detail'],['deep','deep']].map(([k,name])=>`<button data-depth="${k}" class="${state.depth===k?'sel':''}">${t(name)}</button>`).join('')}</div><button id="askButton" class="primary full" style="margin-top:14px">${t('askButton')}</button><div id="conversation">${state.questions.map(v=>`<div class="simple-card"><strong>${esc(v.q)}</strong><p>${t('askNotLive')}</p></div>`).join('')}</div><p class="notice">${t('askRules')}</p></section>`}
function dailyScreen(){const c=state.daily;const opts=(val,items,attr)=>`<div class="choice">${items.map(([k,label])=>`<button data-daily="${attr}" data-value="${k}" class="${String(val)===String(k)?'sel':''}">${label}</button>`).join('')}</div>`;
return `<section class="page"><h1>${t('dailySetup')}</h1><p class="muted fine">${t('dailyDesc')}</p><div class="setting-row"><div><strong>${t('source')}</strong></div><select id="dailySource" aria-label="${t('source')}">${['sggs','japji','dasam','bhai'].map(s=>`<option value="${s}" ${s===c.source?'selected':''}>${labelSource(s)}</option>`).join('')}</select></div>
<div class="setting-row"><strong>${t('order')}</strong>${opts(c.order,[['sequential',t('sequential')],['random',t('random')]],'order')}</div>
<div class="setting-row"><strong>${t('amount')}</strong>${opts(c.amount,[[1,'1'],[2,'2'],[5,'5']],'amount')}</div>
<div class="setting-row"><strong>${t('time')}</strong><input id="dailyTime" type="time" value="${esc(c.time)}"></div>
<div class="setting-row"><strong>${t('enable')}</strong>${opts(!!c.enabled,[[false,t('off')],[true,t('on')]],'enabled')}</div>
<button class="primary full" data-action="save-daily" style="margin-top:19px">${t('savePlan')}</button>
<div class="section-head">${t('dailyPreview')}</div><div class="daily-preview"><div class="eyebrow">ਗੁਰਬਾਣੀ ਸਾਂਝ</div><h2>${t('dailyTitle')}</h2><p>${labelSource(c.source)} · ${c.amount} ${age('ਅੰਗ','Ang')} · ${c.order==='random'?t('random'):t('sequential')}</p>${dailyQuote()}<button class="secondary" data-action="daily-open">${t('dailyOpen')} →</button></div>
<button class="secondary full" data-action="test-notification">${t('sendTest')}</button><p class="notice">${t('dailyLimit')} ${t('sample')}</p></section>`}
function settingsHTML(){
 const choice=(key,options)=>`<div class="choice">${options.map(([v,name])=>`<button data-setting="${key}" data-value="${v}" class="${String(state[key])===String(v)?'sel':''}">${name}</button>`).join('')}</div>`;
 const themes=[['light',t('light'),'#ffffff'],['sepia',t('sepia'),'#f4ead6'],['dark',t('dark'),'#1b2822'],['charcoal',t('charcoal'),'#303438']];
 return `<div class="settings-preview"><div class="settings-caption">${t('appearance')}</div><div class="theme-choice">${themes.map(([value,label,color])=>`<button data-setting="theme" data-value="${value}" class="theme-swatch ${state.theme===value?'sel':''}" aria-pressed="${state.theme===value}"><span class="tone-dot" style="background:${color}"></span><span>${label}</span></button>`).join('')}</div></div>
 <div class="setting-section">${t('font')}</div>
 <div class="settings-control-block"><div class="settings-control-head"><strong>${t('font')}</strong>${choice('fontStyle',[['serif',t('serif')],['sans',t('sans')]])}</div>
 <div class="settings-control-head"><strong>${t('font')}</strong><span class="desc" id="fontValue">${state.font}px</span></div>
 <div class="slider-row"><button id="fontMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="18" max="40" step="1" value="${state.font}" id="fontSlider" aria-label="${t('font')}"><button id="fontPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਅਤੇ ਮੀਨੂ ਦੇ ਅੱਖਰ','Home & menu font size')}</strong><span class="desc" id="uiScaleValue">${Math.round(state.uiScale*100)}%</span></div>
 <div class="slider-row"><button id="uiMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="1" max="1.35" step="0.05" value="${state.uiScale}" id="uiSlider" aria-label="${age('ਮੁੱਖ ਪੰਨੇ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ','Home text size')}"><button id="uiPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('3D ਮੀਨੂ ਅੱਖਰ','3D menu text')}</strong>${choice('raisedHeadings',[['true',t('on')],['false',t('off')]])}</div>
 <div class="settings-control-head"><strong>${t('spacing')}</strong><span class="desc" id="spacingValue">${state.spacing.toFixed(2)}</span></div>
 <div class="slider-row"><span class="size-end">≡</span><input type="range" min="1.45" max="2.35" step="0.05" value="${state.spacing}" id="spacingSlider" aria-label="${t('spacing')}"><span class="size-end">☷</span></div>
 <div class="settings-control-head"><strong>${t('margins')}</strong>${choice('margin',[['narrow',t('narrow')],['normal',t('normal')],['wide',t('wide')]])}</div></div>
 <div class="setting-section">${t('reading')}</div>
 <div class="setting-row"><strong>${t('mode')}</strong>${choice('mode',[['scroll',t('scroll')],['page',t('page')]])}</div>
 <div class="setting-row"><strong>${t('viewMeaning')}</strong>${choice('meanings',[['false',t('off')],['true',t('on')]])}</div>
 <div class="setting-row"><strong>${t('readingScript')}</strong>${choice('readingScript',[['gurmukhi','ਗੁਰਮੁਖੀ'],['roman','English letters']])}</div>
 <div class="setting-row"><strong>${t('meanLang')}</strong>${choice('meaningLang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <div class="setting-row"><strong>${t('language')}</strong>${choice('lang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <p class="fine muted settings-footer">${t('preferences')}</p>`;
}
function openSettings(){closeWord();$('settingsTitle').textContent=t('readerSettings');$('sheetBody').innerHTML=settingsHTML();$('sheetOverlay').classList.remove('hidden')}
function closeSettings(){$('sheetOverlay').classList.add('hidden')}
function closeWord(){$('wordPopup').classList.add('hidden')}
let focusedWord='';
function openWord(el){const pop=$('wordPopup');focusedWord=el.dataset.word.replace(/[॥।੧੨੩੪੫੬੭੮੯੦;,]/g,'');const rect=el.getBoundingClientRect();pop.innerHTML=`<div class="popup-title" lang="pa">${esc(focusedWord)}</div><div class="popup-actions"><button data-pop="listen">◖)) ${t('listen')}</button><button data-pop="meaning">▤ ${t('meaning')}</button></div><div class="popup-note hidden" id="wordNote"></div>`;pop.classList.remove('hidden');let left=Math.min(window.innerWidth-324,Math.max(12,rect.left+rect.width/2-156));left=Math.max(12,left);let top=rect.bottom+13;if(top>window.innerHeight-195)top=Math.max(65,rect.top-164);pop.style.left=left+'px';pop.style.top=top+'px';pop.style.setProperty('--arrow-left',Math.max(14,Math.min(290,rect.left+rect.width/2-left))+'px');}
function showWordNote(type){let box=$('wordNote');if(!box)return;box.classList.remove('hidden');box.textContent=type==='listen'?t('audioPending'):(words[focusedWord]?.[state.meaningLang]||t('wordPending'));}
function results(q){let result=$('searchResults');if(!result)return;let text=q.trim().toLowerCase();if(!text){result.innerHTML=`<p class="fine">${age('ਉਦਾਹਰਨ: ਸੋਚੈ, ਹੁਕਮਿ, ਲਖ ਖੁਸੀਆ','Try: ਸੋਚੈ, ਹੁਕਮਿ, ਲਖ ਖੁਸੀਆ')}</p>`;return}let matches=[];lines.forEach((line,i)=>{if([line.g,line.pa,line.en].some(x=>x.toLowerCase().includes(text)))matches.push({line,idx:i,kind:'sggs',ang:1})});CONTENT.kirtan.forEach(item=>item.lines.forEach((line,i)=>{if([line.g,line.pa,line.en].some(x=>x.toLowerCase().includes(text)))matches.push({line,idx:i,kind:item.id,ang:item.ang})}));
result.innerHTML=`<div class="section-head">${t('results')} · ${matches.length}</div>${matches.map(x=>`<button class="result" data-search-kind="${x.kind}" data-search-idx="${x.idx}"><strong lang="pa">${esc(x.line.g)}</strong><small>${t('ang')} ${x.ang} · ${x.kind==='sggs'?t('readerTitle'):t('kirtan')}</small></button>`).join('')||`<p class="empty">${t('noResults')}</p>`}`}
function capture(){if(state.view!=='reader'||state.readView!=='sggs'||state.mode!=='scroll')return;let el=[...document.querySelectorAll('.verse-block')].find(n=>n.getBoundingClientRect().bottom>72);if(el){state.verse=Number(el.dataset.line)||0;state.verseOffset=Math.max(0,Math.round(73-el.getBoundingClientRect().top));state.hasProgress=true;persist()}}
function turn(dir){state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,state.page+dir));state.verse=PAGE_GROUPS[state.page][0];state.verseOffset=0;state.hasProgress=true;persist();render();window.scrollTo({top:0,behavior:'instant'});if(dir>0&&state.page===PAGE_GROUPS.length-1){} }
function readKirtan(id){state.kirtanId=id;state.readView='kirtan';go('reader');window.scrollTo({top:0,behavior:'instant'})}
function toggleMeaning(){if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();state.meanings=!state.meanings;persist();render()}
function action(a){switch(a){case'edit-layout':homeEditing=true;render();break;case'done-layout':homeEditing=false;persist();render();break;case'reset-layout':state.homeOrder=[...HOME_IDS];persist();render();toast(age('ਮੂਲ ਤਰਤੀਬ ਵਾਪਸ ਆ ਗਈ','Default layout restored'));break;case'continue':case'reader':navReader();break;case'library':go('library');break;case'catalog':go('catalog');break;case'kirtan':go('kirtan');break;case'daily':go('daily');break;case'daily-open':state.readView='sggs';go('reader');break;case'toggle-meaning':toggleMeaning();break;case'prev':turn(-1);break;case'next':turn(1);break;case'audio':window.GS_AUDIO?.toggle();break;
case'lang-pa':state.lang='pa';persist();render();break;
case'lang-en':state.lang='en';persist();render();break;
case'script-gurmukhi':state.readingScript='gurmukhi';persist();render();break;
case'script-roman':state.readingScript='roman';persist();render();break;
case'open-japji':state.readView='sggs';go('reader');break;
case'bani-pending':toast(age('ਪੂਰੇ ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਦੀ ਜਾਂਚ ਬਾਕੀ ਹੈ।','Full text is pending verification.'));break;
case'nitnem':go('nitnem');break;case'dasam':case'bhai':state.comingTitle=a==='nitnem'?t('nitnem'):a==='dasam'?t('dasam'):t('bhai');go('coming');break;
case'save-daily':if(!state.daily.startDate)state.daily.startDate=new Date().toISOString().slice(0,10);persist();toast(t('planSaved'));render();break;
case'test-notification':testNotification();break;
case'open-daily':closeSettings();go('daily');break;case'menu-settings':openSettings();break;case'check-update':checkUpdate();break;case'install-app':installApp();break;case'backup-export':exportBackup();break;case'backup-import':$('menuBackupInput')?.click();break;default:break}}
async function testNotification(){if(!('Notification' in window)){toast(t('notificationsUnsupported'));return}let permission=Notification.permission;try{if(permission==='default')permission=await Notification.requestPermission();if(permission!=='granted'){toast(t('notificationDenied'));return}const sample=dailyExcerpt();const body=sample?`${sample.g} · ${sample[state.meaningLang].slice(0,70)}`:`${labelSource(state.daily.source)} · ${state.daily.amount} ${age('ਅੰਗ','Ang')}`;if('serviceWorker' in navigator&&location.protocol.startsWith('http')){const reg=await navigator.serviceWorker.ready;await reg.showNotification('ਗੁਰਬਾਣੀ ਸਾਂਝ',{body,icon:'icons/icon-192.png',tag:'gurbani-saanjh-demo',data:{url:'./'}})}else new Notification('ਗੁਰਬਾਣੀ ਸਾਂਝ',{body});toast(t('notificationSent'))}catch(e){toast(t('notificationsUnsupported'));console.warn(e)}}
function updateStatus(message){const x=$('updateStatus');if(x)x.textContent=message;}
async function checkUpdate(){
 if(window.GS_NATIVE_UPDATES?.isNative){
   await window.GS_NATIVE_UPDATES.check((message)=>updateStatus(message),state.lang);
   return;
 }
 if(!navigator.onLine){updateStatus(age('ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਹੈ','You are offline'));return;}
 if(!/^https?:$/.test(location.protocol)){updateStatus(t('updateRequiresWeb'));return;}
 updateStatus(t('updating'));
 try{
  const res=await fetch('./version.json?check='+Date.now(),{cache:'no-store'});
  if(!res.ok)throw Error('Version manifest not available');
  const incoming=await res.json();
  if(!/^\d+\.\d+\.\d+$/.test(incoming.version))throw Error('Invalid version');
  const [a,b,c]=incoming.version.split('.').map(Number);const [x,y,z]=APP_VERSION.split('.').map(Number);
  const newer=a>x||(a===x&&(b>y||(b===y&&c>z)));
  if(!newer){updateStatus(t('upToDate'));toast(t('upToDate'));return;}
  updateStatus(`${t('updateAvailable')} v${incoming.version}`);
  let btn=$('checkUpdateButton');if(btn)btn.textContent=t('update')+' · v'+incoming.version;
  if(state.view==='reader')capture();
  const reg=await navigator.serviceWorker?.getRegistration();
  if(!reg){updateStatus(t('updateRequiresWeb'));return;}
  isApplyingUpdate=true;
  await reg.update();
  if(reg.waiting)reg.waiting.postMessage({type:'SKIP_WAITING'});
  updateStatus(t('updateReady'));
  // Browser update lifecycle can take a moment. We wait for the new worker to control this page.
  setTimeout(()=>{if(isApplyingUpdate)location.reload()},2000);
 }catch(e){console.warn('Update check:',e);updateStatus(t('updateFailed'))}
}
async function installApp(){
 if(installPrompt){try{installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;}catch(e){console.warn(e)}return;}
 toast(t('installHint'));
}
function exportBackup(){const blob=new Blob([JSON.stringify({app:'Gurbani Saanjh',version:APP_VERSION,exported:new Date().toISOString(),state},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='gurbani-saanjh-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
async function importBackup(file){try{const obj=JSON.parse(await file.text());if(obj.app!=='Gurbani Saanjh'||!obj.state||typeof obj.state!=='object')throw Error('Invalid backup');const permitted=['lang','meaningLang','readingScript','meanings','theme','mode','font','uiScale','raisedHeadings','spacing','fontStyle','margin','readView','verse','verseOffset','page','hasProgress','kirtanId','favorites','homeOrder','depth','daily','questions'];for(const k of permitted)if(k in obj.state)state[k]=obj.state[k];state.daily={...BASE.daily,...state.daily};state.lang=state.lang==='en'?'en':'pa';state.meaningLang=state.meaningLang==='en'?'en':'pa';state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));state.raisedHeadings=state.raisedHeadings!==false;state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,Number(state.page)||0));state.homeOrder=normalizeHomeOrder(state.homeOrder);persist();closeSettings();render();toast(age('ਬੈਕਅੱਪ ਲਿਆ ਗਿਆ','Backup restored'))}catch(e){toast(age('ਬੈਕਅੱਪ ਫਾਈਲ ਸਹੀ ਨਹੀਂ','Invalid backup file'))}}
function attach(){if(state.view==='home')setupHomeDrag();else if(homeDragCleanup){homeDragCleanup();homeDragCleanup=null;}if(state.view==='catalog'){const input=$('catalogSearch');if(input)input.addEventListener('input',()=>{catalogFilter=input.value;$('catalogResults').innerHTML=catalogRows(catalogFilter)});}if(state.view==='search'){const input=$('searchInput');input.addEventListener('input',()=>results(input.value));results('');$('voiceBtn').onclick=()=>{const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){toast(t('voicePending'));return}try{const r=new SR();r.lang=state.lang==='pa'?'pa-IN':'en-CA';r.onresult=e=>{input.value=e.results[0][0].transcript;results(input.value)};r.onerror=()=>toast(t('voicePending'));r.start()}catch{toast(t('voicePending'))}}}
if(state.view==='reader'&&state.mode==='page'&&state.readView==='sggs'){let start=null;const el=$('verses');el.addEventListener('touchstart',e=>{start={x:e.changedTouches[0].clientX,y:e.changedTouches[0].clientY}},{passive:true});el.addEventListener('touchend',e=>{if(!start)return;const dx=e.changedTouches[0].clientX-start.x,dy=e.changedTouches[0].clientY-start.y;if(Math.abs(dx)>65&&Math.abs(dx)>Math.abs(dy)*1.4)turn(dx<0?1:-1);start=null},{passive:true})}}
function bindGlobals(){
$('nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){if(b.dataset.view==='reader')navReader();else go(b.dataset.view)}});
$('backBtn').onclick=()=>{if(state.view==='catalogItem')go('catalog');else if(state.view==='reader'&&state.readView==='kirtan')go('kirtan');else go('home')};$('settingsBtn').onclick=openSettings;$('closeSheet').onclick=closeSettings;
$('sheetOverlay').addEventListener('click',e=>{if(e.target===$('sheetOverlay'))closeSettings()});
$('main').addEventListener('click',e=>{if(e.target.closest('[data-home-id]')&&(homeEditing||Date.now()-lastHomeDragEnded<600)){e.preventDefault();e.stopPropagation();return;}const act=e.target.closest('[data-action]');if(act){action(act.dataset.action);return}const word=e.target.closest('[data-word]');if(word){e.stopPropagation();openWord(word);return}const fav=e.target.closest('[data-favorite]');if(fav){let id=fav.dataset.favorite;state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];persist();render();return}const k=e.target.closest('[data-kirtan]');if(k){readKirtan(k.dataset.kirtan);return}const selectedBani=e.target.closest('[data-catalog-id]');if(selectedBani){catalogSelected=selectedBani.dataset.catalogId;go('catalogItem');return}const filter=e.target.closest('[data-filter]');if(filter){state.filter=filter.dataset.filter;persist();render();return}const result=e.target.closest('[data-search-kind]');if(result){let kind=result.dataset.searchKind;if(kind==='sggs'){state.verse=Number(result.dataset.searchIdx);state.page=PAGE_GROUPS.findIndex(g=>g.includes(state.verse));state.verseOffset=0;state.hasProgress=true;navReader()}else readKirtan(kind);return}const depth=e.target.closest('[data-depth]');if(depth){state.depth=depth.dataset.depth;persist();document.querySelectorAll('[data-depth]').forEach(b=>b.classList.toggle('sel',b.dataset.depth===state.depth));return}const day=e.target.closest('[data-daily]');if(day){let key=day.dataset.daily,v=day.dataset.value;state.daily[key]=key==='amount'?Number(v):key==='enabled'?v==='true':v;persist();render();return}});
$('main').addEventListener('change',e=>{if(e.target.id==='dailySource'){state.daily.source=e.target.value;persist();render()}if(e.target.id==='dailyTime'){state.daily.time=e.target.value;persist()}});
$('main').addEventListener('click',e=>{if(e.target.closest('#askButton')){let input=$('questionInput'),q=input?.value.trim();if(!q){toast(age('ਸਵਾਲ ਲਿਖੋ','Enter a question'));return}state.questions.push({q,depth:state.depth});state.questions=state.questions.slice(-12);persist();render();$('conversation')?.scrollIntoView({block:'nearest'})}});
$('wordPopup').addEventListener('click',e=>{const b=e.target.closest('[data-pop]');if(b)showWordNote(b.dataset.pop)});
document.addEventListener('click',e=>{if(!e.target.closest('[data-word]')&&!e.target.closest('#wordPopup'))closeWord()});
$('sheetBody').addEventListener('click',e=>{let setting=e.target.closest('[data-setting]');if(setting){const prop=setting.dataset.setting,val=setting.dataset.value;if(state.view==='reader'&&state.mode==='scroll')capture();state[prop]=(prop==='meanings'||prop==='raisedHeadings')?val==='true':val;if(prop==='mode'){state.page=PAGE_GROUPS.findIndex(g=>g.includes(state.verse));if(state.page<0)state.page=0;state.verseOffset=0}persist();$('sheetBody').innerHTML=settingsHTML();$('settingsTitle').textContent=t('readerSettings');render();return}let act=e.target.closest('[data-action]');if(act){action(act.dataset.action);return}let button=e.target.closest('[data-settings-action]');if(button){const a=button.dataset.settingsAction;if(a==='export')exportBackup();if(a==='import')$('backupInput').click();if(a==='update')checkUpdate()}});
$('sheetBody').addEventListener('click',e=>{const u=e.target.closest('#uiMinus,#uiPlus');if(!u)return;state.uiScale=Math.min(1.35,Math.max(1,Math.round((state.uiScale+(u.id==='uiPlus'?.05:-.05))*100)/100));$('uiSlider').value=state.uiScale;$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();});
$('sheetBody').addEventListener('click',e=>{const plus=e.target.closest('#fontPlus,#fontMinus');if(!plus)return;state.font=Math.min(40,Math.max(18,state.font+(plus.id==='fontPlus'?1:-1)));$('fontSlider').value=state.font;$('fontValue').textContent=state.font+'px';theme();persist()});
$('sheetBody').addEventListener('input',e=>{if(e.target.id==='uiSlider'){state.uiScale=Number(e.target.value);$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();}if(e.target.id==='fontSlider'){state.font=Number(e.target.value);$('fontValue').textContent=state.font+'px';theme();persist()}if(e.target.id==='spacingSlider'){state.spacing=Number(e.target.value);$('spacingValue').textContent=state.spacing.toFixed(2);theme();persist()}});
$('sheetBody').addEventListener('change',e=>{if(e.target.id==='backupInput'&&e.target.files?.[0])importBackup(e.target.files[0])});
$('main').addEventListener('change',e=>{if(e.target.id==='menuBackupInput'&&e.target.files?.[0])importBackup(e.target.files[0])});
let scrollTimer;window.addEventListener('scroll',()=>{if(!$('wordPopup').classList.contains('hidden'))closeWord();if(state.view!=='reader'||state.mode!=='scroll'||state.readView!=='sggs')return;clearTimeout(scrollTimer);scrollTimer=setTimeout(capture,130)},{passive:true});
window.addEventListener('pagehide',capture);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')capture()});
document.addEventListener('keydown',e=>{const homeCard=e.target.closest?.('[data-home-id]');if(state.view==='home'&&homeCard&&homeEditing&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();moveHomeCard(homeCard.dataset.homeId,['ArrowLeft','ArrowUp'].includes(e.key)?-1:1);return;}if(state.view==='home'&&homeCard&&!homeEditing&&e.key===' '){e.preventDefault();homeEditing=true;render();document.querySelector(`[data-home-id="${homeCard.dataset.homeId}"]`)?.focus();return;}if(e.key==='Escape'){closeWord();closeSettings()}if(state.view==='reader'&&state.mode==='page'&&state.readView==='sggs'&&!e.target.matches('input,textarea')){if(e.key==='ArrowRight')turn(1);if(e.key==='ArrowLeft')turn(-1)}});
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(isApplyingUpdate){isApplyingUpdate=false;location.reload()}})}
bindGlobals();render();
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator&&location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(console.warn));
})();
