window.GS_BUILD={"version":"2.2.69","repo":"","hideAiSettings":false};
