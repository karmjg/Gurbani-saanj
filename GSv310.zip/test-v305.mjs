/* v2.2.85 test - the AI answer (Ask) text is bigger by default: 22px
 * instead of 18px. Karamjit 2026-11-19: "Is it possible to increase
 * the size of the font - in the cloud [AI answer]?" Pinch does not
 * work on his phone and the A-/A+ buttons were tried before and did
 * not work, so the size is now just bigger when the app opens.
 * The font size is set in the APP (state.aiFont, CSS --ai-font), NOT
 * in the cloud worker - the cloud only sends the answer words.
 * Uses the REAL code from www/app.js (not copies), run in a Node vm
 * sandbox, plus static checks. Run: node test-v305.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.85', vj.version === '2.2.85', vj.version);
  ok('version notes mention v2.2.85', vj.notes.includes('v2.2.85:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.85', pj.version === '2.2.85', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.85', nbc.includes('"version":"2.2.85"'));
}

// ---------- static checks: v2.2.85 (AI answer font 22px) ----------
ok('BASE.aiFont is 22', app.includes('aiFont:22,'));
ok('no 18px aiFont default remains', !app.includes('aiFont:18'));
ok('the 18->22 migration is present', app.includes('if(state.aiFont===18)state.aiFont=22;'));
ok('init fallback is 22', app.includes('Number(state.aiFont)||22'));
ok('theme() sets --ai-font from 22 fallback', app.includes("html.style.setProperty('--ai-font',(Number(state.aiFont)||22)+'px')"));
ok('CSS fallback is 22px', css.includes('font-size:var(--ai-font,22px)'));
ok('old CSS 18px fallback is gone', !css.includes('font-size:var(--ai-font,18px)'));
ok('pinchFont fallback is 22', app.includes('(Number(startFont)||22)'));
ok('no A-/A+ buttons added', !app.includes('data-ai-zoom='));
ok('the 14-32 clamp is unchanged', app.includes('Math.min(32,Math.max(14,'));

// ---------- v2.2.84 (highlight stays centered) intact ----------
ok('v2.2.84 comment present', app.includes('v2.2.84: a found line (yellow highlight) stays in the MIDDLE'));
ok('render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
ok('render() still restores the anchor when there is no highlight', app.includes('if(readerAnchor<0)return;'));
// ---------- v2.2.83 (search Gurmukhi + Latin only) intact ----------
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
ok('v2.2.83 fillResultEn still gone', !app.includes('fillResultEn'));
ok('v2.2.83 the Latin line still renders', app.includes('romanHtml'));
// ---------- v2.2.82 (Ask buttons, button decides) intact ----------
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 language pills still present', app.includes('data-ai-lang="${k}"'));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
ok('v2.2.82 askOpenAI still answers in the button language', app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;') && app.includes("let lastOpenedKey='';") && app.includes("let lastOpenedQuery='';"));
ok('v2.2.81 go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('v2.2.81 results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
ok('v2.2.81 opened-row CSS intact', css.includes('.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}'));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 detail output still 1200 tokens', app.includes('max_tokens:1200'));
// ---------- v2.2.79 (mic) intact - mic NOT touched in v2.2.85 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('mic still one session per tap (no restart loop)', !app.includes('for(;;)') || !app.slice(app.indexOf('startVoiceSearch'), app.indexOf('startVoiceSearch') + 6000).includes('for(;;)'));

// ---------- no data changes; styles.css differs ONLY by the font fallback ----------
{
  const rb = '/tmp/v305-rollback/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.84 (${n} files)`, diff === 0, `${diff} differ`);
  const rbCss = fs.readFileSync('/tmp/v305-rollback/www/styles.css', 'utf8');
  const onlyFontFallback = css === rbCss.replace('font-size:var(--ai-font,18px)', 'font-size:var(--ai-font,22px)');
  ok('styles.css differs from v2.2.84 ONLY by the --ai-font fallback', onlyFontFallback);
}

// ---------- runtime: the REAL init line runs in a vm sandbox ----------
// Extract the real aiFont init statement and run it with different
// starting values, the way the app boots with a stored state.
{
  const marker = "state.aiFont=Math.min(32,Math.max(14,Number(state.aiFont)||22));if(state.aiFont===18)state.aiFont=22;";
  ok('the real init statement is found', app.includes(marker));
  const runInit = (start) => {
    const ctx = { state: { aiFont: start } };
    vm.createContext(ctx);
    vm.runInContext(marker, ctx);
    return ctx.state.aiFont;
  };
  // Case A: his phone - stored aiFont is the old default 18. The
  // migration must bump it to 22, otherwise the new default would
  // never show on his phone (stored state overrides BASE).
  ok('stored 18 (old default) becomes 22', runInit(18) === 22, `got ${runInit(18)}`);
  // Case B: fresh install - no stored value. The ||22 fallback gives 22.
  ok('fresh install (undefined) becomes 22', runInit(undefined) === 22, `got ${runInit(undefined)}`);
  // Case C: a deliberately set size is untouched (not 18, not bumped).
  ok('deliberately set 20 stays 20', runInit(20) === 20, `got ${runInit(20)}`);
  ok('deliberately set 26 stays 26', runInit(26) === 26, `got ${runInit(26)}`);
  // Case D: the clamp still holds - a huge stored value is capped at 32,
  // a tiny one is raised to 14.
  ok('stored 40 is clamped to 32', runInit(40) === 32, `got ${runInit(40)}`);
  ok('stored 5 is raised to 14', runInit(5) === 14, `got ${runInit(5)}`);
  // Case E: the migration is idempotent - running it again on 22 stays 22.
  ok('running it again on 22 stays 22', runInit(22) === 22, `got ${runInit(22)}`);
  // Case F: theme() applies the font - the --ai-font property is 22px
  // when state.aiFont is 22. Extract the WHOLE theme() function by
  // brace counting (a fixed slice cuts it off mid-expression).
  {
    const extractFn = (src, startMarker) => {
      const start = src.indexOf(startMarker);
      if (start === -1) return null;
      let depth = 1, i = start + startMarker.length;
      for (; i < src.length; i++) {
        if (src[i] === '{') depth++;
        else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
      }
      return null;
    };
    const themeSrc = extractFn(app, 'function theme(){');
    ok('the real theme() function is found', !!themeSrc);
    const ctx = {
      state: { aiFont: 22, theme: 'light', font: 24, lineLayout: 'compact', fontStyle: 'serif', margin: 'normal', raisedHeadings: false, nightMode: false, baniTextSize: 'normal', fontColor: 'black', tone: 0, layerScale: 0.8 },
      document: { documentElement: { classList: { toggle: () => {} }, dataset: {}, style: { setProperty: function (k, v) { this[k] = v; } } }, querySelector: () => null },
    };
    vm.createContext(ctx);
    vm.runInContext(themeSrc + '\ntheme();', ctx);
    ok('theme() sets --ai-font to 22px', ctx.document.documentElement.style['--ai-font'] === '22px', `got ${ctx.document.documentElement.style['--ai-font']}`);
  }
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
