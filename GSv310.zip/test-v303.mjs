/* v2.2.83 test — search results show Gurmukhi + Latin ONLY, no English
 * meaning. Karamjit 2026-11-19: "I don't want to see the English meaning
 * I just want to see a Gurmukhi line plus the Latin that's it. Because
 * once I click the word then I can go to the setting and ask for
 * translation whatever." Uses the REAL code from www/app.js (not
 * copies), run in a Node vm sandbox, plus static checks.
 * Run: node test-v303.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

function extractFn(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 1, i = start + startMarker.length;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.83', vj.version === '2.2.83', vj.version);
  ok('version notes mention v2.2.83', vj.notes.includes('v2.2.83:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.83', pj.version === '2.2.83', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.83', nbc.includes('"version":"2.2.83"'));
}

// ---------- static checks: v2.2.83 (no English in the result list) ----------
ok('no gs-result-en span is rendered', !app.includes('gs-result-en'));
ok('no data-en-for attribute is rendered', !app.includes('data-en-for'));
ok('fillResultEn is gone', !app.includes('fillResultEn'));
ok('enFor helper is gone', !app.includes('enFor('));
ok('showOfflineResults no longer fills English', !app.includes('fillResultEn($(target))'));
ok('showOfflineResults still awaits the raag fills', app.includes('await fillRaagHeaders($(target));'));
ok('the Latin (roman) line is still rendered', app.includes('romanHtml'));
ok('v2.2.83 comment present', app.includes('v2.2.83: no English meaning in the result list'));
// ---------- v2.2.82 (Ask buttons, button decides) intact ----------
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 language pills still present', app.includes("data-ai-lang=\"${k}\""));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
ok('v2.2.82 askOpenAI still answers in the button language', app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('v2.2.82 click handler still present', app.includes("e.target.closest('[data-ai-lang]')"));
// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;') && app.includes("let lastOpenedKey='';") && app.includes("let lastOpenedQuery='';"));
ok('v2.2.81 go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('v2.2.81 go() saves the search place', app.includes('saveSearchPlace();if(view!==' + "'reader'){readerBarHidden=true;"));
ok('v2.2.81 results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
ok('v2.2.81 opened-row CSS intact', css.includes('.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}'));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 Latin prompt intact', app.includes('then write the same verse in Latin (Roman) letters exactly as given'));
ok('v2.2.80 detail output still 1200 tokens', app.includes('max_tokens:1200'));
// ---------- v2.2.79 (mic) intact — mic NOT touched in v2.2.83 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('mic still one session per tap (no restart loop)', !app.includes('for(;;)') || !app.slice(app.indexOf('startVoiceSearch'), app.indexOf('startVoiceSearch') + 6000).includes('for(;;)'));
// ---------- no data changes / no CSS changes ----------
{
  const rb = '/tmp/v303-rollback/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.82 (${n} files)`, diff === 0, `${diff} differ`);
  const rbCss = fs.readFileSync('/tmp/v303-rollback/www/styles.css', 'utf8');
  ok('styles.css byte-identical to v2.2.82 (no CSS change)', css === rbCss);
}

// ---------- runtime A: a result row shows Gurmukhi + Latin, NO English ----------
// Even when the match CARRIES an English meaning (Bani matches carry `en`,
// SGGS matches get it filled in), the rendered row must not show it.
{
  const fn = extractFn(app, 'function scriptureResultsMarkup(arr,{save=false}={}){');
  ok('scriptureResultsMarkup found', !!fn);
  const ctx = {
    state: { lang: 'pa', savedVerses: [], showTranslit: true },
    lastSearchQuery: 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ', lastOpenedKey: '', lastOpenedQuery: '',
    age: (pa) => pa, esc: s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'),
    t: k => k,
  };
  vm.createContext(ctx);
  vm.runInContext(fn, ctx);
  const rows = [
    // SGGS match: no `en` field here, but the old code rendered an empty
    // data-en-for span and filled it async - that span must be gone.
    { src: 'sggs', ang: 1098, idx: 2, g: 'ਮੈ ਚਾਰੇ ਕੁੰਡਾ ਭਾਲੀਆ ਤੁਧੁ ਜੇਵਡੁ ਨ ਸਾਈਆ ॥', roman: 'mai. chaare kunddaa bhaaleea; tudh jevadd na. saaeea |', en: '' },
    { src: 'sggs', ang: 11, idx: 15, g: 'ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ ਤੁਧੁ ਜੇਵਡੁ ਅਵਰੁ ਨ ਕੋਈ ॥', roman: 'toon aad purakh aparanpar karataa jee; tudh jevadd. avar na koee |', en: '' },
    // Bani match WITH an English meaning carried on it - the old code
    // rendered it inline. It must NOT appear now.
    { src: 'bani', baniId: 116, idx: 18, g: 'ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥', roman: 'satinam. karataa purakh; nirbhau. nirvair; akaal moorat ajoonee saibhan gur prasaad |', en: 'One Universal Creator God. The Name Is Truth. Creative Being Personified. No Fear. No Hatred. Image Of The Undying, Beyond Birth, Self-Existent. By Guru’s Grace.', titlePa: 'ਸਬਦ ਹਜ਼ਾਰੇ', titleEn: 'Shabad Hazare', group: 'gutka' },
  ];
  const html = vm.runInContext(`scriptureResultsMarkup(${JSON.stringify(rows)},{save:true})`, ctx);
  ok('no gs-result-en span in the rendered rows', !html.includes('gs-result-en'));
  ok('no data-en-for attribute in the rendered rows', !html.includes('data-en-for'));
  ok('the Bani English meaning text does NOT appear', !html.includes('One Universal Creator God'));
  ok('the Gurmukhi lines still render', html.includes('ਮੈ ਚਾਰੇ ਕੁੰਡਾ ਭਾਲੀਆ') && html.includes('ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ') && html.includes('ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ'));
  ok('the Latin lines still render', html.includes('mai. chaare kunddaa bhaaleea') && html.includes('toon aad purakh aparanpar') && html.includes('satinam. karataa purakh'));
  ok('the Ang / Bani source labels still render', html.includes('1098') && html.includes('11') && html.includes('ਸਬਦ ਹਜ਼ਾਰੇ'));
  ok('the save (heart) buttons still render', (html.match(/data-save-hit/g) || []).length === 3);
}

// ---------- runtime B: showOfflineResults awaits only the raag fill ----------
// The fills are async (raag comes from Ang files). Prove the raag fill
// still completes before showOfflineResults resolves, and that there is
// no English fill left to await.
{
  const fn = extractFn(app, "async function showOfflineResults(q,target='searchResults',save=false){");
  ok('showOfflineResults found', !!fn);
  const ctx = {
    searchSeq: 0, searchMode: 'auto', lastSearchQuery: '',
    $: (id) => ctx._els[id],
    age: (pa) => pa, t: k => k,
    window: {
      GS_SCRIPTURE_SEARCH: {
        query: async () => [{ src: 'sggs', ang: 11, idx: 15, g: 'ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ ਤੁਧੁ ਜੇਵਡੁ ਅਵਰੁ ਨ ਕੋਈ ॥', roman: 'x', en: '' }],
      },
    },
    scriptureResultsMarkup: () => '<div class="gs-result-row"><span data-raag-for="11:15"></span></div>',
    fillRaagHeaders: async () => { await new Promise(r => setTimeout(r, 5)); ctx._raagDone = true; },
    _els: {}, _raagDone: false,
    setTimeout,
  };
  ctx._els.searchResults = { innerHTML: '', querySelectorAll: () => [] };
  vm.createContext(ctx);
  vm.runInContext(fn, ctx);
  const p = vm.runInContext(`showOfflineResults('ਤੁਧੁ ਜੇਵਡੁ ਨਾ','searchResults',true)`, ctx);
  await p;
  ok('after showOfflineResults resolves, the raag fill has COMPLETED', ctx._raagDone === true);
  ok('showOfflineResults recorded the query', ctx.lastSearchQuery === 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ');
  ok('the rendered markup has no English span', ctx._els.searchResults.innerHTML.includes('gs-result-row') && !ctx._els.searchResults.innerHTML.includes('gs-result-en'));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
