/* v2.2.84 test — the yellow highlighted (found) line stays in the MIDDLE
 * of the screen when coming back from Settings. Karamjit 2026-11-19:
 * "when you search a word, it shows yellow... then suppose I go into
 * Settings, I change Transliteration / Punjabi / any setting, then I
 * come back - the yellow highlighter should be there, and it should
 * stay in the middle of the screen."
 * Uses the REAL code from www/app.js (not copies), run in a Node vm
 * sandbox, plus static checks. Run: node test-v304.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

function extractFn(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 1, i = start + startMarker.length;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
// Extract a whole `if(...) {...}` statement starting at startMarker by
// brace counting. Braces inside template literals / object literals
// balance out, so a naive counter works here.
function extractStatement(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.84', vj.version === '2.2.84', vj.version);
  ok('version notes mention v2.2.84', vj.notes.includes('v2.2.84:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.84', pj.version === '2.2.84', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.84', nbc.includes('"version":"2.2.84"'));
}

// ---------- static checks: v2.2.84 (highlight stays centered) ----------
ok('v2.2.84 comment present', app.includes('v2.2.84: a found line (yellow highlight) stays in the MIDDLE'));
ok('render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
ok('render() still restores the anchor when there is no highlight', app.includes('if(readerAnchor<0)return;'));
ok('render() no longer gates the block on readerAnchor>=0', !app.includes("if(state.view==='reader'&&activeRemote?.lines?.length&&readerAnchor>=0){requestAnimationFrame"));
ok('the highlight check comes before the anchor restore', (() => {
  const h = app.indexOf("if(highlightLine>=0){const idx=Math.max(0,Math.min(highlightLine,activeRemote.lines.length-1));");
  const a = app.indexOf("if(readerAnchor<0)return;");
  return h !== -1 && a !== -1 && h < a;
})());
// ---------- v2.2.83 (search Gurmukhi + Latin only) intact ----------
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
ok('v2.2.83 fillResultEn still gone', !app.includes('fillResultEn'));
ok('v2.2.83 the Latin line still renders', app.includes('romanHtml'));
// ---------- v2.2.82 (Ask buttons, button decides) intact ----------
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 language pills still present', app.includes("data-ai-lang=\"${k}\""));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
ok('v2.2.82 askOpenAI still answers in the button language', app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;') && app.includes("let lastOpenedKey='';") && app.includes("let lastOpenedQuery='';"));
ok('v2.2.81 go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('v2.2.81 go() saves the search place', app.includes('saveSearchPlace();if(view!==' + "'reader'){readerBarHidden=true;"));
ok('v2.2.81 results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
ok('v2.2.81 opened-row CSS intact', css.includes('.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}'));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 detail output still 1200 tokens', app.includes('max_tokens:1200'));
// ---------- v2.2.79 (mic) intact — mic NOT touched in v2.2.84 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('mic still one session per tap (no restart loop)', !app.includes('for(;;)') || !app.slice(app.indexOf('startVoiceSearch'), app.indexOf('startVoiceSearch') + 6000).includes('for(;;)'));
// ---------- no data changes / no CSS changes ----------
{
  const rb = '/tmp/v304-rollback/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.83 (${n} files)`, diff === 0, `${diff} differ`);
  const rbCss = fs.readFileSync('/tmp/v304-rollback/www/styles.css', 'utf8');
  ok('styles.css byte-identical to v2.2.83 (no CSS change)', css === rbCss);
}

// ---------- runtime: render() centers the highlight, else restores anchor ----------
// Extract the REAL re-render scroll block from render() and run it in a
// vm sandbox with a mocked DOM. requestAnimationFrame runs at once.
{
  const block = extractStatement(app, "if(state.view==='reader'&&activeRemote?.lines?.length){requestAnimationFrame(()=>{");
  ok('re-render scroll block found', !!block);
  // A fake verse-block node. scrollIntoView records the block it was
  // called with; getBoundingClientRect gives the anchor its offset.
  const makeNode = (line, top) => ({
    dataset: { line: String(line) },
    getBoundingClientRect: () => ({ top, bottom: top + 60, height: 60 }),
    scrollIntoView: function (opts) { this._centered = opts; },
    _centered: null,
  });
  const makeCtx = (highlightLine, readerAnchor, readerAnchorTop) => {
    const nodes = {};
    // 20 verse lines, each 60px tall, starting at y=0.
    for (let i = 0; i < 20; i++) nodes[i] = makeNode(i, i * 60);
    return {
      state: { view: 'reader' },
      activeRemote: { lines: Array.from({ length: 20 }, (_, i) => ({ g: 'x' + i })) },
      highlightLine, readerAnchor, readerAnchorTop,
      document: {
        querySelector: (sel) => {
          const m = /\[data-line="(\d+)"\]/.exec(sel);
          return m ? nodes[Number(m[1])] || null : null;
        },
        querySelectorAll: () => [],
      },
      window: {
        scrollY: 300,
        scrollTo: function (opts) { this._scrolledTo = opts; },
        _scrolledTo: null,
      },
      requestAnimationFrame: (fn) => fn(),
      _nodes: nodes,
    };
  };
  const run = (ctx) => { vm.createContext(ctx); vm.runInContext(block, ctx); };

  // Case A: a found line is highlighted (line 15). Coming back from
  // Settings must CENTER it, even though the anchor points elsewhere
  // (the layout changed when the setting grew the verses).
  {
    const ctx = makeCtx(15, 3, 100);
    run(ctx);
    const node15 = ctx._nodes[15];
    ok('highlight line 15 is centered (scrollIntoView block:center)', node15._centered && node15._centered.block === 'center', JSON.stringify(node15._centered));
    ok('the anchor scrollTo is NOT called when a highlight exists', ctx.window._scrolledTo === null);
  }
  // Case B: no highlight (normal reading). The anchored line keeps its
  // place as before (v2.2.55) - scrollTo restores it to its old offset.
  {
    const ctx = makeCtx(-1, 3, 100);
    run(ctx);
    ok('with no highlight, the anchor is restored via scrollTo', ctx.window._scrolledTo !== null && typeof ctx.window._scrolledTo.top === 'number', JSON.stringify(ctx.window._scrolledTo));
    // The anchored line (line 3, top 180) is put back at offset 100:
    // scrollY(300) + rect.top(180) - anchorTop(100) = 380.
    ok('the anchor lands at the right scroll position', ctx.window._scrolledTo && ctx.window._scrolledTo.top === 380, `top=${ctx.window._scrolledTo && ctx.window._scrolledTo.top}`);
    const anyCentered = Object.values(ctx._nodes).some(n => n._centered);
    ok('with no highlight, no line is centered', !anyCentered);
  }
  // Case C: no highlight and no anchor (fresh reader). Nothing scrolls.
  {
    const ctx = makeCtx(-1, -1, 0);
    run(ctx);
    ok('with no highlight and no anchor, nothing scrolls', ctx.window._scrolledTo === null && !Object.values(ctx._nodes).some(n => n._centered));
  }
  // Case D: the highlight is at the very first line - still centered,
  // and the index is clamped, not negative.
  {
    const ctx = makeCtx(0, 8, 50);
    run(ctx);
    ok('highlight line 0 is centered', ctx._nodes[0]._centered && ctx._nodes[0]._centered.block === 'center');
  }
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
