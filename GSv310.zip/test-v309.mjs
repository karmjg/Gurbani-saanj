/* v2.2.89 test - Vaaran + Salok Kabir/Farid + centred reading with all
 * toggles OFF + Vaaran kept out of Ask. Karamjit 2026-11-21, "Haan, bana deo";
 * mockup v289-vaaran-mockup.webp approved.
 * (Named test-v309.mjs after the GSv309 zip, per repo convention:
 * test-v289.mjs is already the v2.2.69 test.)
 *
 * Change 1 - Bhai Gurdas Ji's Vaaran (Bani 131): 40 Vaars, 913 pauris,
 * 6,446 verse lines, from the Shabad OS database 4.8.7 (the app's existing
 * bundled scripture source). Vaar 41 excluded. Reader like Nitnem: centred
 * lines, Punjabi + English under each line, Latin in search results.
 * Change 2 - Salok Kabir Ji (Bani 132, 494 lines), from the app's own Angs.
 * Change 3 - Salok Baba Farid Ji (Bani 133, 297 lines), from the app's own Angs.
 * Change 4 - Bani + Kirtan lines stay CENTRED even with transliteration and
 * translations ALL OFF (v2.2.4 left-align rule removed). This SUPERSEDES
 * the v2.2.88 behaviour (everything OFF = left-aligned): test-v308's two
 * "everything OFF stays LEFT" assertions no longer apply and are NOT
 * re-run here - the cascade proof below asserts the NEW centred result,
 * and proves the OLD v2.2.88 CSS gave LEFT for the same element path.
 * Change 5 - Vaaran kept OUT of Ask/AI: the Ask retrieval drops Bani
 * matches from group 'bhai' (main query AND the topic bridge), so the AI
 * only ever receives SGGS + Dasam Granth passages. The Vaaran stays fully
 * searchable in the Search screen - only Ask is filtered.
 *
 * The proofs below run the REAL code: the real scripture search over the
 * real rebuilt index (the quoted line found by its first-letter initials),
 * the real GS_REMOTE reader path for the three new Banis, the real
 * isBaniHeading, the real Ask filter predicate, and a real CSS cascade
 * computation (!important-aware) over the shipped styles.css.
 * Run: node test-v309.mjs
 * (Needs /tmp/v289-rollback = pristine v2.2.88, extracted from GSv308.zip.)
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v289-rollback/www';
const rbApp = fs.readFileSync(path.join(RB, 'app.js'), 'utf8');
const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
const rbRv = fs.readFileSync(path.join(RB, 'render-verses.js'), 'utf8');
const rbCat = fs.readFileSync(path.join(RB, 'catalog.js'), 'utf8');
const rbMan = JSON.parse(fs.readFileSync(path.join(RB, 'offline/manifest.json'), 'utf8'));
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.89', vj.version === '2.2.89', vj.version);
  ok('version notes mention v2.2.89', vj.notes.includes('v2.2.89:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.89', pj.version === '2.2.89', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.89', nbc.includes('"version":"2.2.89"'));
}

// ---------- catalog: 23 entries, right groups and titles ----------
const catalog = (() => {
  const ctx = { window: {} };
  vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8'), ctx);
  return ctx.window.GS_CATALOG;
})();
{
  ok('catalog has 23 entries (was 20)', catalog.length === 23, `count=${catalog.length}`);
  const byId = Object.fromEntries(catalog.map(c => [c.id, c]));
  ok('131 is bhai, titled Vaaran', byId[131]?.group === 'bhai' && byId[131]?.titlePa === 'ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ' && byId[131]?.titleEn === "Bhai Gurdas Ji's Vaaran");
  ok('132 is sggs, titled Salok Kabir Ji', byId[132]?.group === 'sggs' && byId[132]?.titlePa === 'ਸਲੋਕ ਕਬੀਰ ਜੀ' && byId[132]?.titleEn === 'Salok Kabir Ji');
  ok('133 is sggs, titled Salok Baba Farid Ji', byId[133]?.group === 'sggs' && byId[133]?.titlePa === 'ਸਲੋਕ ਬਾਬਾ ਫਰੀਦ ਜੀ' && byId[133]?.titleEn === 'Salok Baba Farid Ji');
  const groups = catalog.reduce((m, c) => { m[c.group] = (m[c.group] || 0) + 1; return m; }, {});
  ok('catalog groups: sggs 15, dasam 4, tradition 3, bhai 1', groups.sggs === 15 && groups.dasam === 4 && groups.tradition === 3 && groups.bhai === 1, JSON.stringify(groups));
  ok('catalog ids are unique', new Set(catalog.map(c => c.id)).size === 23);
}

// ---------- Bani files: counts, fields, structure ----------
const bani = id => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8')).lines;
{
  const v131 = bani(131), v132 = bani(132), v133 = bani(133);
  ok('131 Vaaran has 7,226 lines', v131.length === 7226, `count=${v131.length}`);
  ok('132 Kabir has 494 lines', v132.length === 494, `count=${v132.length}`);
  ok('133 Farid has 297 lines', v133.length === 297, `count=${v133.length}`);
  for (const [id, lines] of [[131, v131], [132, v132], [133, v133]]) {
    ok(`${id}: every line has string g/en/pa/roman`, lines.every(l => ['g', 'en', 'pa', 'roman'].every(k => typeof l[k] === 'string')));
    ok(`${id}: every line has non-empty g + roman`, lines.every(l => l.g && l.roman));
    ok(`${id}: line ids are unique`, new Set(lines.map(l => l.id)).size === lines.length);
    ok(`${id}: Gurmukhi carries no vishraam markers (; , .)`, lines.every(l => !/[;,.]/.test(l.g)));
  }
  ok('all three files share no line id', new Set([...v131, ...v132, ...v133].map(l => l.id)).size === v131.length + v132.length + v133.length);
  ok('131 starts with the mangal, then the title, then Vaar 1', v131[0].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥' && v131[1].g.startsWith('ਵਾਰਾਂ ਗਿਆਨ ਰਤਨਾਵਲੀ') && v131[2].g === 'ਵਾਰ ੧ ॥');
  ok('131 has exactly one mangal line', v131.filter(l => l.g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥').length === 1);
  ok('131 has 40 Vaar headings', v131.filter(l => /^ਵਾਰ [੦-੯]+ ॥$/.test(l.g)).length === 40);
  ok('131 has 738 Pauri headings', v131.filter(l => /^ਪਉੜੀ [੦-੯]+ ॥$/.test(l.g)).length === 738);
  ok('131 pauri-final lines end with double-danda numbers', v131.filter(l => /॥[੦-੯0-9]+॥\s*$/.test(l.g)).length === 879, `count=${v131.filter(l => /॥[੦-੯0-9]+॥\s*$/.test(l.g)).length}`);
  ok('131: no line still ends with single-danda number', !v131.some(l => /।\s*[੦-੯0-9]+\s*।\s*$/.test(l.g)));
  const verse131 = v131.filter(l => !/^ਵਾਰ [੦-੯]+ ॥$/.test(l.g) && !/^ਪਉੜੀ [੦-੯]+ ॥$/.test(l.g) && l.g !== 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥' && !l.g.startsWith('ਵਾਰਾਂ ਗਿਆਨ'));
  ok('131 has 6,446 verse lines', verse131.length === 6446, `count=${verse131.length}`);
  ok('131 verse lines missing English: exactly 9 (DB gaps)', verse131.filter(l => !l.en.trim()).length === 9, `count=${verse131.filter(l => !l.en.trim()).length}`);
  ok('131 verse lines missing Punjabi: exactly 11 (DB gaps)', verse131.filter(l => !l.pa.trim()).length === 11, `count=${verse131.filter(l => !l.pa.trim()).length}`);
  // The user's quoted line: Vaar 10, Pauri 9, 5th verse line - in HIS Gutka
  // wording (corrected 2026-11-21 on his go; the shipped edition differed).
  const qi = v131.findIndex(l => l.g.includes('ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ') && l.g.includes('ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ'));
  ok('quoted line is in 131 (index 1719)', qi === 1719, `index=${qi}`);
  ok('quoted line is his Gutka wording, exactly', v131[1719].g === 'ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ ॥');
  let vaarH = null, pauriH = null, verseNo = 0;
  for (let i = qi; i >= 0; i--) {
    const g = v131[i].g;
    if (/^ਪਉੜੀ [੦-੯]+ ॥$/.test(g) && !pauriH) pauriH = g;
    if (/^ਵਾਰ [੦-੯]+ ॥$/.test(g)) { vaarH = g; break; }
  }
  for (let i = qi; i >= 0; i--) { if (/^ਪਉੜੀ [੦-੯]+ ॥$/.test(v131[i].g)) break; verseNo++; }
  ok('quoted line sits under Vaar 10, Pauri 9', vaarH === 'ਵਾਰ ੧੦ ॥' && pauriH === 'ਪਉੜੀ ੯ ॥', `${vaarH} / ${pauriH}`);
  ok('quoted line is the 5th verse line of its pauri', verseNo === 5, `verseNo=${verseNo}`);
  ok('quoted line carries its English + Punjabi meanings', !!v131[qi].en.trim() && !!v131[qi].pa.trim() && v131[qi].roman.includes('doorahu'));
  ok('132 starts mangal + Kabir heading + first salok', v132[0].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥' && v132[1].g === 'ਸਲੋਕ ਭਗਤ ਕਬੀਰ ਜੀਉ ਕੇ' && v132[2].g === 'ਕਬੀਰ ਮੇਰੀ ਸਿਮਰਨੀ ਰਸਨਾ ਊਪਰਿ ਰਾਮੁ ॥');
  ok('132 ends with salok 243', v132[v132.length - 1].g.endsWith('॥੨੪੩॥'));
  ok('132 title heading English is a string (not the BaniDB dict)', typeof v132[1].en === 'string' && v132[1].en === 'Shaloks Of Devotee Kabeer Jee:');
  ok('133 starts mangal + Farid heading + first salok', v133[0].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥' && v133[1].g === 'ਸਲੋਕ ਸੇਖ ਫਰੀਦ ਕੇ' && v133[2].g === 'ਜਿਤੁ ਦਿਹਾੜੈ ਧਨ ਵਰੀ ਸਾਹੇ ਲਏ ਲਿਖਾਇ ॥');
  ok('133 ends with salok 130', v133[v133.length - 1].g.endsWith('॥੧੩੦॥'));
  ok('133 title heading English is a string (not the BaniDB dict)', typeof v133[1].en === 'string' && v133[1].en === 'Shaloks Of Shaykh Fareed Jee:');
  ok('no Vaar 41 content: no line is Vaar 41', !v131.some(l => l.g === 'ਵਾਰ ੪੧ ॥'));
}

// ---------- manifest ----------
{
  const man = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8'));
  ok('manifest baniCount is 32', man.baniCount === 32, `baniCount=${man.baniCount}`);
  ok('manifest banis list has 32 entries incl. 131/132/133', man.banis.length === 32 && [131, 132, 133].every(id => man.banis.some(b => b.id === id)));
  ok('manifest sources cite the Vaaran (Shabad OS 4.8.7)', JSON.stringify(man.sources).includes('Vaaran Bhai Gurdas Ji'));
  ok('manifest sources cite BaniDB 77/78 for Kabir/Farid boundaries', JSON.stringify(man.sources).includes('BaniDB API v2 (banis 77/78)'));
  ok('manifest Ang count unchanged (1,430)', man.angCount === 1430);
}

// ---------- search index ----------
const index = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
{
  ok('search index has 17,332 entries (was 9,315)', index.length === 17332, `count=${index.length}`);
  const byBani = index.reduce((m, e) => { m[e[0]] = (m[e[0]] || 0) + 1; return m; }, {});
  ok('index has 7,226 Vaaran rows', byBani[131] === 7226, `count=${byBani[131]}`);
  ok('index has 494 Kabir rows', byBani[132] === 494, `count=${byBani[132]}`);
  ok('index has 297 Farid rows', byBani[133] === 297, `count=${byBani[133]}`);
  ok('index Vaaran rows carry group bhai', index.filter(e => e[0] === 131).every(e => e[8] === 'bhai'));
  ok('index Kabir/Farid rows carry group sggs', index.filter(e => e[0] === 132 || e[0] === 133).every(e => e[8] === 'sggs'));
  ok('index rows for the new Banis all carry a Roman line', index.filter(e => [131, 132, 133].includes(e[0])).every(e => String(e[5] || '').trim().length > 0));
  const q = index.filter(e => e[0] === 131 && e[2].startsWith('ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ'));
  ok('quoted line is in the index exactly once (idx 1719)', q.length === 1 && q[0][1] === 1719, `matches=${q.length}`);
  ok('index rows carry the right titles', index.find(e => e[0] === 131)?.[6] === 'ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ' && index.find(e => e[0] === 132)?.[7] === 'Salok Kabir Ji' && index.find(e => e[0] === 133)?.[7] === 'Salok Baba Farid Ji');
}

// ---------- runtime: the REAL search over the REAL index ----------
const searchApi = await (async () => {
  const searchJS = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sandbox = {
    window: {},
    fetch: async url => {
      const file = String(url).includes('bani-search.json')
        ? path.join(ROOT, 'www/offline/bani-search.json')
        : path.join(ROOT, 'www/offline/search.json');
      return { ok: true, json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
    },
  };
  vm.runInNewContext(searchJS, sandbox);
  return sandbox.window.GS_SCRIPTURE_SEARCH;
})();
{
  // First letters are ਦਦਦਕਹਜਸਛਅ: ਦੰਡਉਤ starts with ਦ + bindi, so the
  // iGranth bare-first-letter rule takes ਦ, not ਡ (the old edition's
  // ਡੰਡਉਤਿ took ਡ). Typing ਡ finds nothing - the app takes ਦ.
  const quoted = await searchApi.query('ਦਦਦਕਹਜਸਛਅ', 12, 'first');
  ok('search finds the quoted Vaaran line by first letters', quoted.some(r => r.src === 'bani' && r.baniId === 131 && r.idx === 1719), `top=${quoted.slice(0, 3).map(r => r.src + ':' + (r.baniId || r.ang) + ':' + r.idx).join(', ')}`);
  const kabir = await searchApi.query('ਕਮਸਰਉਰ', 12, 'first');
  ok('search finds the Kabir line by first letters', kabir.some(r => r.src === 'bani' && r.baniId === 132 && r.idx === 2), `top=${kabir.slice(0, 3).map(r => r.src + ':' + (r.baniId || r.ang) + ':' + r.idx).join(', ')}`);
  const farid = await searchApi.query('ਜਦਧਵਸਲਲ', 12, 'first');
  ok('search finds the Farid line by first letters', farid.some(r => r.src === 'bani' && r.baniId === 133 && r.idx === 2), `top=${farid.slice(0, 3).map(r => r.src + ':' + (r.baniId || r.ang) + ':' + r.idx).join(', ')}`);
  const autoQuoted = await searchApi.query('ਦਦਦਕਹਜਸਛਅ', 12);
  ok('search finds the quoted line in auto mode too', autoQuoted.some(r => r.src === 'bani' && r.baniId === 131 && r.idx === 1719));
  const found = quoted.find(r => r.src === 'bani' && r.baniId === 131 && r.idx === 1719);
  ok('found Vaaran row carries group bhai + title + Roman', !!found && found.group === 'bhai' && found.titlePa === 'ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ' && String(found.roman || '').includes('doorahu'));
  const romanHit = await searchApi.query('doorahu dekh', 12, 'roman');
  ok('Roman query finds the quoted line too', romanHit.some(r => r.src === 'bani' && r.baniId === 131 && r.idx === 1719));
  ok('Vaaran rows are openable as Bani (baniId + idx)', quoted.every(r => r.src !== 'bani' || (Number.isInteger(r.baniId) && Number.isInteger(r.idx))));
}

// ---------- runtime: the REAL remote-library reader path ----------
const remoteApi = await (async () => {
  const libJS = fs.readFileSync(path.join(ROOT, 'www/remote-library.js'), 'utf8');
  const sandbox = {
    window: {},
    fetch: async url => {
      const u = String(url);
      const file = u.includes('manifest.json')
        ? path.join(ROOT, 'www/offline/manifest.json')
        : path.join(ROOT, 'www/offline', u.replace(/^offline\//, ''));
      if (!fs.existsSync(file)) return { ok: false };
      return { ok: true, json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
    },
  };
  vm.runInNewContext(libJS, sandbox);
  return sandbox.window.GS_REMOTE;
})();
{
  const list = await remoteApi.list();
  ok('GS_REMOTE.list() includes 131/132/133', [131, 132, 133].every(id => list.some(b => b.id === id)) && list.length === 32, `count=${list.length}`);
  const r131 = await remoteApi.read('bani', 131);
  ok("GS_REMOTE.read('bani', 131) returns the Vaaran (7,226 lines)", r131.lines.length === 7226 && r131.offline === true);
  ok("GS_REMOTE.read('bani', 132) returns Kabir (494 lines)", (await remoteApi.read('bani', 132)).lines.length === 494);
  ok("GS_REMOTE.read('bani', 133) returns Farid (297 lines)", (await remoteApi.read('bani', 133)).lines.length === 297);
  ok('openCatalogBani routes every catalog entry through loadRemote(bani)', app.includes("function openCatalogBani(item){\n const id=Number(item.id);\n if(Number.isInteger(id)&&id>0){openBani(id,") && app.includes("function openBani(id,title,preserveProgress=false){return loadRemote('bani',Number(id),title||'Bani',preserveProgress)}"));
}

// ---------- runtime: the REAL isBaniHeading ----------
const VERSES = await (async () => {
  const rvJS = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
  const sandbox = { window: {}, document: { querySelector: () => null } };
  vm.runInNewContext(rvJS, sandbox);
  return sandbox.window.GS_VERSES;
})();
{
  ok('heading: "ਵਾਰ ੧੦ ॥" is a heading', VERSES.isBaniHeading('ਵਾਰ ੧੦ ॥') === true);
  ok('heading: "ਪਉੜੀ ੯ ॥" is a heading', VERSES.isBaniHeading('ਪਉੜੀ ੯ ॥') === true);
  ok('heading: bare "ਪਉੜੀ ॥" is still a heading', VERSES.isBaniHeading('ਪਉੜੀ ॥') === true);
  ok('heading: "ਸਲੋਕ ਮਹਲਾ ੯ ॥" is still a heading', VERSES.isBaniHeading('ਸਲੋਕ ਮਹਲਾ ੯ ॥') === true);
  ok('verse: the quoted line is NOT a heading', VERSES.isBaniHeading('ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ ॥') === false);
  ok('verse: a Kabir salok is NOT a heading', VERSES.isBaniHeading('ਕਬੀਰ ਮੇਰੀ ਸਿਮਰਨੀ ਰਸਨਾ ਊਪਰਿ ਰਾਮੁ ॥') === false);
  ok('verse: "ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧ ॥" stays a verse (old guard)', VERSES.isBaniHeading('ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧ ॥') === false);
  ok('verse: "ਦੁਰਗਾ ਪਾਠ ਬਣਾਇਆ ਸਭੇ ਪਉੜੀਆਂ ॥" stays a verse', VERSES.isBaniHeading('ਦੁਰਗਾ ਪਾਠ ਬਣਾਇਆ ਸਭੇ ਪਉੜੀਆਂ ॥') === false);
}

// ---------- a small real CSS cascade (!important-aware, id-aware) ----------
// (Helpers copied from test-v308.mjs - same parser, same specificity rules.)
function parseRules(text) {
  const clean = text.replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = [];
  let i = 0;
  while (i < clean.length) {
    const open = clean.indexOf('{', i);
    if (open === -1) break;
    const sel = clean.slice(i, open).trim();
    let depth = 1, j = open + 1;
    while (j < clean.length && depth > 0) {
      if (clean[j] === '{') depth++;
      else if (clean[j] === '}') depth--;
      j++;
    }
    if (sel && !sel.startsWith('@')) {
      for (const s of sel.split(',')) {
        const t = s.trim();
        if (!t.includes('[') && !t.includes(':')) rules.push({ selector: t, decls: clean.slice(open + 1, j - 1), order: rules.length });
      }
    }
    i = j;
  }
  return rules;
}
function specificity(sel) {
  const ids = (sel.match(/#[\w-]+/g) || []).length;
  const classes = (sel.match(/\.[\w-]+/g) || []).length
    + (sel.match(/\[[^\]]+\]/g) || []).length
    + (sel.match(/:(?!:)[\w-]+(\([^)]*\))?/g) || []).length;
  const els = sel.split(/[\s>+~]+/).reduce((n, part) => n + (/^[a-zA-Z][\w-]*/.test(part) ? 1 : 0), 0);
  return [ids, classes, els];
}
const cmpSpec = (a, b) => (a[0] - b[0]) || (a[1] - b[1]) || (a[2] - b[2]);
function matches(sel, path) {
  const parts = sel.split(/\s+/).map(p => p.trim()).filter(Boolean);
  if (!parts.length) return false;
  let pi = 0;
  for (const el of path) {
    if (pi >= parts.length) break;
    const part = parts[pi];
    const tag = (/^[a-zA-Z][\w-]*/.exec(part) || [])[0];
    const id = (/#([\w-]+)/.exec(part) || [])[1];
    const classes = [...part.matchAll(/\.([\w-]+)/g)].map(m => m[1]);
    if ((!tag || tag === el.tag) && (!id || id === el.id) && classes.every(c => el.classes.includes(c))) pi++;
  }
  return pi === parts.length;
}
function winningProp(text, prop, elementPath) {
  const rules = parseRules(text);
  const cands = [];
  for (const r of rules) {
    const m = new RegExp(prop + '\\s*:\\s*([^;}]+)').exec(r.decls);
    if (!m) continue;
    if (matches(r.selector, elementPath)) {
      const raw = m[1].trim();
      cands.push({ selector: r.selector, value: raw.replace(/!important/g, '').trim(), important: /!important/.test(raw), spec: specificity(r.selector), order: r.order });
    }
  }
  cands.sort((a, b) => ((a.important ? 1 : 0) - (b.important ? 1 : 0)) || cmpSpec(a.spec, b.spec) || (a.order - b.order));
  return { cands, winner: cands[cands.length - 1] || null };
}
const HTML = { tag: 'html', classes: ['reading-open'] };
const VERSES_EL = { tag: 'div', classes: ['verse-list'], id: 'verses' };
const sec = extra => ({ tag: 'section', classes: ['reading', 'reading-immersive', 'gs-reader-bani', ...extra] });
const secSggs = { tag: 'section', classes: ['reading', 'reading-immersive', 'gs-reader-sggs'] };
const pankti = cls => ({ tag: 'div', classes: ['verse-block', 'gs-pankti', cls] });
const roman = { tag: 'div', classes: ['verse-layer', 'verse-roman'] };
const enLayer = { tag: 'div', classes: ['verse-layer', 'verse-en'] };
const gurmukhiBlue = { tag: 'div', classes: ['verse-text', 'gs-gurmukhi-blue'] };
{
  // THE new behaviour (change 4): everything OFF still CENTRES.
  const pOff = [HTML, sec([]), VERSES_EL, pankti('gs-bani-pankti')];
  const tOff = winningProp(css, 'text-align', pOff);
  ok('Bani + everything OFF: lines are CENTRED (new in v2.2.89)', !!tOff.winner && tOff.winner.value === 'center', tOff.winner ? `${tOff.winner.selector} => ${tOff.winner.value}` : 'no winner');
  const kOff = [HTML, sec([]), VERSES_EL, pankti('gs-kirtan-pankti')];
  const tkOff = winningProp(css, 'text-align', kOff);
  ok('Kirtan + everything OFF: lines are CENTRED (new in v2.2.89)', !!tkOff.winner && tkOff.winner.value === 'center', tkOff.winner ? `${tkOff.winner.selector} => ${tkOff.winner.value}` : 'no winner');
  // The OLD behaviour, proved on the pristine v2.2.88 CSS: everything OFF was LEFT.
  const tOld = winningProp(rbCss, 'text-align', pOff);
  ok('v2.2.88: Bani + everything OFF was LEFT-aligned (the old behaviour)', !!tOld.winner && tOld.winner.value === 'left', tOld.winner ? `${tOld.winner.selector} => ${tOld.winner.value}` : 'no winner');
  const tkOld = winningProp(rbCss, 'text-align', kOff);
  ok('v2.2.88: Kirtan + everything OFF was LEFT-aligned (the old behaviour)', !!tkOld.winner && tkOld.winner.value === 'left', tkOld.winner ? `${tkOld.winner.selector} => ${tkOld.winner.value}` : 'no winner');
  // Transliteration ON: centred + orange Roman, Bani and Kirtan (unchanged).
  const pOn = [HTML, sec(['gs-translit-on', 'gs-layers-on']), VERSES_EL, pankti('gs-bani-pankti')];
  const tOn = winningProp(css, 'text-align', pOn);
  ok('Bani + translit ON: still CENTRED (unchanged)', !!tOn.winner && tOn.winner.value === 'center', tOn.winner ? `${tOn.winner.selector} => ${tOn.winner.value}` : 'no winner');
  const rOn = winningProp(css, 'color', [...pOn, roman]);
  ok('Bani + translit ON: Roman still ORANGE #f3541d (unchanged)', !!rOn.winner && rOn.winner.value === '#f3541d', rOn.winner ? `${rOn.winner.selector} => ${rOn.winner.value}` : 'no winner');
  const kOn = [HTML, sec(['gs-translit-on', 'gs-layers-on']), VERSES_EL, pankti('gs-kirtan-pankti')];
  const tkOn = winningProp(css, 'text-align', kOn);
  ok('Kirtan + translit ON: still CENTRED (unchanged)', !!tkOn.winner && tkOn.winner.value === 'center', tkOn.winner ? `${tkOn.winner.selector} => ${tkOn.winner.value}` : 'no winner');
  const rkOn = winningProp(css, 'color', [...kOn, roman]);
  ok('Kirtan + translit ON: Roman still ORANGE #f3541d (unchanged)', !!rkOn.winner && rkOn.winner.value === '#f3541d', rkOn.winner ? `${rkOn.winner.selector} => ${rkOn.winner.value}` : 'no winner');
  // English ON, transliteration OFF: lines centre, layers centre (v2.2.49, unchanged).
  const pEn = [HTML, sec(['gs-layers-on']), VERSES_EL, pankti('gs-bani-pankti')];
  const tEn = winningProp(css, 'text-align', pEn);
  ok('Bani + English ON (translit OFF): lines are CENTRED (unchanged)', !!tEn.winner && tEn.winner.value === 'center', tEn.winner ? `${tEn.winner.selector} => ${tEn.winner.value}` : 'no winner');
  const eEn = winningProp(css, 'text-align', [...pEn, enLayer]);
  ok('Bani + English ON: the English layer is CENTRED (unchanged)', !!eEn.winner && eEn.winner.value === 'center', eEn.winner ? `${eEn.winner.selector} => ${eEn.winner.value}` : 'no winner');
  // Ang (SGGS) unchanged: centred, blue Gurmukhi, red Roman.
  const pAng = [HTML, secSggs, VERSES_EL, pankti('gs-sggs-pankti')];
  const tAng = winningProp(css, 'text-align', pAng);
  ok('Ang: still CENTRED (unchanged)', !!tAng.winner && tAng.winner.value === 'center', tAng.winner ? `${tAng.winner.selector} => ${tAng.winner.value}` : 'no winner');
  const rAng = winningProp(css, 'color', [...pAng, roman]);
  ok('Ang: Roman still RED #b3261e (unchanged)', !!rAng.winner && rAng.winner.value === '#b3261e', rAng.winner ? `${rAng.winner.selector} => ${rAng.winner.value}` : 'no winner');
  const gAng = winningProp(css, 'color', [...pAng, gurmukhiBlue]);
  ok('Ang: Gurmukhi still BLUE #1a3fa0 (unchanged)', !!gAng.winner && gAng.winner.value === '#1a3fa0', gAng.winner ? `${gAng.winner.selector} => ${gAng.winner.value}` : 'no winner');
  // Search results are untouched: left-aligned Gurmukhi + Latin lines.
  ok('search results still left-aligned (untouched)', css.includes('.gs-result-en{display:block;font-size:13px;color:var(--muted);font-weight:400;line-height:1.45;margin-top:2px;text-align:left}') && css.includes('.gs-result-roman{display:block;font-size:13px;color:var(--muted);font-weight:400;font-style:italic;line-height:1.45;margin-top:2px;text-align:left}'));
}

// ---------- static checks: the five changes ----------
// Change 4: the v2.2.4 left-align rule is gone.
ok('change 4: v2.2.4 left-align rule is GONE', !css.includes('html.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}'));
ok('change 4: the v2.2.89 centring comment is present', css.includes('v2.2.89: Bani + Kirtan panktis stay CENTRED'));
ok('change 4: the base centre rule is still there', css.includes('html.reading-open #verses .gs-pankti{display:block!important;max-width:100%;margin:0!important;padding:0!important;text-align:center;'));
// Change 1c: the two heading rules.
{
  const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
  ok('change 1: Vaar heading rule present', rv.includes("if(/^ਵਾਰ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;"));
  ok('change 1: numbered Pauri heading rule present', rv.includes("if(/^ਪਉੜੀ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;"));
  ok('change 1: bare Pauri heading rule untouched', rv.includes("if(/^ਪਉੜੀ\\s*॥$/.test(t))return true;"));
}
// Change 5: the Ask filter (both call sites), and only there.
ok('change 5: Ask main query filters out group bhai', app.includes("const mainMatches=(await window.GS_SCRIPTURE_SEARCH.query(q,12)).filter(m=>!(m.src==='bani'&&m.group==='bhai'));"));
ok('change 5: Ask topic bridge filters out group bhai', app.includes("const extra=(await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word')).filter(m=>!(m.src==='bani'&&m.group==='bhai'));"));
ok('change 5: the old unfiltered Ask lines are gone', !app.includes('const mainMatches=await window.GS_SCRIPTURE_SEARCH.query(q,12);') && !app.includes("const extra=await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word');"));
ok('change 5: the bhai filter appears exactly twice (Ask only)', (app.match(/\.filter\(m=>!\(m\.src==='bani'&&m\.group==='bhai'\)\)/g) || []).length === 2);
{
  // The REAL filter predicate, run on sample matches.
  const m = app.match(/\.filter\((m=>!\(m\.src==='bani'&&m\.group==='bhai'\))\)/);
  ok('change 5: filter predicate found in app.js', !!m);
  const pred = vm.runInNewContext(m[1], {});
  const samples = [
    { src: 'bani', group: 'bhai', baniId: 131 },
    { src: 'bani', group: 'sggs', baniId: 132 },
    { src: 'bani', group: 'sggs', baniId: 115 },
    { src: 'bani', group: 'dasam', baniId: 9 },
    { src: 'bani', group: 'tradition', baniId: 107 },
    { src: 'sggs', ang: 261 },
  ];
  const kept = samples.filter(pred);
  ok('change 5: predicate drops ONLY the Vaaran (bhai) match', kept.length === 5 && !kept.some(x => x.group === 'bhai') && kept.some(x => x.group === 'sggs') && kept.some(x => x.group === 'dasam') && kept.some(x => x.src === 'sggs'), `kept=${kept.length}`);
}
// The Search screen itself is NOT filtered: Vaaran stays searchable there.
ok('Search screen still queries without the bhai filter', (app.match(/GS_SCRIPTURE_SEARCH\.query/g) || []).length >= 3);

// ---------- the diffs: each file differs from v2.2.88 ONLY by its intended edits ----------
{
  const newMain = "  // v2.2.89: Vaaran (Bhai Gurdas Ji, group 'bhai') is searchable in Search\n  // but is NEVER sent to Ask/AI - AI answers come only from Sri Guru Granth\n  // Sahib Ji and Dasam Granth Banis.\n  const mainMatches=(await window.GS_SCRIPTURE_SEARCH.query(q,12)).filter(m=>!(m.src==='bani'&&m.group==='bhai'));";
  const oldMain = "  const mainMatches=await window.GS_SCRIPTURE_SEARCH.query(q,12);";
  const newExtra = "  try{const extra=(await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word')).filter(m=>!(m.src==='bani'&&m.group==='bhai'));";
  const oldExtra = "  try{const extra=await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word');";
  const restored = app.replace(newMain, oldMain).replace(newExtra, oldExtra);
  ok('app.js differs from v2.2.88 ONLY by the Ask filter', restored === rbApp);
}
{
  const oldLeft = '/* v2.2.4: Bani panktis left-aligned like Sundar Gutka (was centered). Headings keep center via .gs-verse-heading. */\nhtml.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}';
  const start = css.indexOf('/* v2.2.89: Bani + Kirtan panktis stay CENTRED');
  const end = css.indexOf('*/', start) + 2;
  const restored = css.slice(0, start) + oldLeft + css.slice(end);
  ok('styles.css differs from v2.2.88 ONLY by the v2.2.4 removal', restored === rbCss);
}
{
  const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
  const added = `
// v2.2.89: Vaaran headings - "ਵਾਰ N ॥" (the Vaar heading) and the numbered
// "ਪਉੜੀ N ॥" (the Pauri heading, e.g. "ਪਉੜੀ ੯ ॥") from Bhai Gurdas Ji's
// Vaaran (Bani 131, Shabad OS database 4.8.7). EXACT match only: no verse
// line is ever just "ਵਾਰ N ॥" or "ਪਉੜੀ N ॥". Audit of ALL Bani lines:
// exactly the 40 Vaar headings + 738 Pauri headings match, all in 131.
if(/^ਵਾਰ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;
if(/^ਪਉੜੀ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;`;
  ok('render-verses.js differs from v2.2.88 ONLY by the 2 heading rules', rv.replace(added, '') === rbRv);
}
{
  const cat = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
  const e132 = `  {
    "id": 132,
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਕਬੀਰ ਜੀ",
    "titleEn": "Salok Kabir Ji"
  },
  {
    "id": 133,
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਬਾਬਾ ਫਰੀਦ ਜੀ",
    "titleEn": "Salok Baba Farid Ji"
  },
`;
  const e131 = `,
  {
    "id": 131,
    "group": "bhai",
    "titlePa": "ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ",
    "titleEn": "Bhai Gurdas Ji's Vaaran"
  }`;
  ok('catalog.js differs from v2.2.88 ONLY by the 3 entries', cat.replace(e132, '').replace(e131, '') === rbCat);
}
{
  const man = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8'));
  const sameKeys = Object.keys(man).every(k => ['baniCount', 'banis', 'sources'].includes(k) || JSON.stringify(man[k]) === JSON.stringify(rbMan[k]));
  ok('manifest differs from v2.2.88 ONLY in baniCount/banis/sources', sameKeys && man.baniCount === 32 && rbMan.baniCount === 29);
  ok('manifest banis = v2.2.88 banis + 131/132/133', JSON.stringify(man.banis.slice(0, 29)) === JSON.stringify(rbMan.banis) && JSON.stringify(man.banis.slice(29).map(b => b.id)) === '[131,132,133]');
  ok('manifest sources = v2.2.88 sources + 2', man.sources.length === rbMan.sources.length + 2 && JSON.stringify(man.sources.slice(0, rbMan.sources.length)) === JSON.stringify(rbMan.sources));
}

// ---------- offline files: old files byte-identical, only the index changed + 3 new Banis ----------
{
  const rbOff = path.join(RB, 'offline');
  let diff = 0, n = 0;
  const added = [];
  const changedFiles = [];
  const walk = d => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { walk(p); continue; }
      n++;
      const rel = path.relative(path.join(ROOT, 'www/offline'), p);
      const rp = path.join(rbOff, rel);
      if (!fs.existsSync(rp)) { added.push(rel); continue; }
      if (md5(p) !== md5(rp)) { diff++; changedFiles.push(rel); }
    }
  };
  walk(path.join(ROOT, 'www/offline'));
  ok(`offline: 3 new Bani files added, nothing else added (${added.length})`, added.length === 3 && added.every(a => ['bani/131.json', 'bani/132.json', 'bani/133.json'].includes(a)), added.join(', '));
  // manifest.json is deliberately changed too (baniCount/banis/sources) -
  // the exact scope of that change is proved in the manifest block above.
  ok(`offline: only bani-search.json + manifest.json changed (${n} files checked)`, diff === 2 && changedFiles.length === 2 && changedFiles.includes('bani-search.json') && changedFiles.includes('manifest.json'), changedFiles.join(', '));
  let angDiff = 0;
  for (let a = 1; a <= 1430; a++) {
    const p = path.join(ROOT, 'www/offline/ang', `${a}.json`);
    if (md5(p) !== md5(path.join(rbOff, 'ang', `${a}.json`))) angDiff++;
  }
  ok('all 1,430 Ang files byte-identical to v2.2.88', angDiff === 0, `${angDiff} differ`);
}

// ---------- carry-forwards (v2.2.88 / v2.2.87 / v2.2.86 / v2.2.79 etc.) ----------
// NOTE: test-v308's two "everything OFF stays LEFT-aligned" assertions are
// SUPERSEDED by change 4 (everything OFF is now CENTRED) and are not re-run.
ok('v2.2.88 popstate fix intact', app.includes("state.view=nv;render();if(nv==='reader')showReaderBar();"));
ok('v2.2.88 kirtan classes intact', app.includes("(kind==='bani'||kind==='kirtan')&&state.showTranslit?' gs-translit-on':''"));
ok('v2.2.88 kirtan centre rules intact', css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti{text-align:center!important;}'));
ok('v2.2.87 font selector intact', css.includes('.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'));
ok('v2.2.87 BASE.aiFont still 22', app.includes('aiFont:22,'));
ok('v2.2.87 18->22 migration intact', app.includes('if(state.aiFont===18)state.aiFont=22;'));
ok('v2.2.86 BASE.ggAng intact', app.includes('ang:1,ggAng:0,'));
ok('v2.2.86 loadRemote still writes ggAng', app.includes('if(extra.gg)state.ggAng=Number(id);'));
ok('v2.2.84 render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
ok('v2.2.83 Latin line still rendered under results', app.includes('gs-result-roman'));
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;'));
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError plugin patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('v2.2.75 popstate still stops the mic leaving search/ask', app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('AI system prompt still SGGS + Dasam only', app.includes('which may come from Sri Guru Granth Sahib Ji or from Dasam Granth Banis'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
