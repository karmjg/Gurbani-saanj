/* v2.2.87 test - the AI answer font size now actually shows.
 * Karamjit 2026-11-20, on a screenshot of the Ask screen: "Is this
 * 22?" It was NOT 22px. Measured in his screenshot against the
 * bottom-nav labels (11px): the AI answer renders at about 12px.
 *
 * Root cause: `.simple-card p{font-size:12px}` beats
 * `.ai-answer{font-size:var(--ai-font,22px)}` on CSS specificity -
 * (0,1,1) beats (0,1,0) - because the answer paragraph sits inside
 * a `.simple-card`. So the 22px from v2.2.85, the pinch-to-zoom and
 * the A-/A+ buttons all changed the stored number, but the screen
 * never used it: the answer was always 12px.
 *
 * The fix: the AI-answer rule's selector is now
 * `.simple-card p.ai-answer` (specificity (0,2,1)), so it beats
 * `.simple-card p` (0,1,1) and the answer renders at
 * var(--ai-font,22px). The core proof below computes the REAL CSS
 * cascade from www/styles.css (not a copy of the rule): which
 * font-size rule wins for a `p.ai-answer` inside a `.simple-card`,
 * on the new CSS and on the pristine v2.2.86 CSS.
 * Run: node test-v307.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v307-rollback/www';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// Extract a whole function starting at startMarker by brace counting.
function extractFunction(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}

// ---------- a small real CSS cascade ----------
// Parse top-level rules (selector + declarations); @-rules are skipped
// whole, and the test below asserts no @-rule touches .ai-answer.
function parseRules(text) {
  const clean = text.replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = [];
  let i = 0;
  while (i < clean.length) {
    const open = clean.indexOf('{', i);
    if (open === -1) break;
    const sel = clean.slice(i, open).trim();
    let depth = 1, j = open + 1;
    while (j < clean.length && depth > 0) {
      if (clean[j] === '{') depth++;
      else if (clean[j] === '}') depth--;
      j++;
    }
    if (sel && !sel.startsWith('@')) {
      for (const s of sel.split(',')) {
        rules.push({ selector: s.trim(), decls: clean.slice(open + 1, j - 1), order: rules.length });
      }
    }
    i = j;
  }
  return rules;
}

// Specificity (ids, classes/attrs/pseudo-classes, elements).
function specificity(sel) {
  const ids = (sel.match(/#[\w-]+/g) || []).length;
  const classes = (sel.match(/\.[\w-]+/g) || []).length
    + (sel.match(/\[[^\]]+\]/g) || []).length
    + (sel.match(/:(?!:)[\w-]+(\([^)]*\))?/g) || []).length;
  const els = sel.split(/[\s>+~]+/).reduce((n, part) => n + (/^[a-zA-Z][\w-]*/.test(part) ? 1 : 0), 0);
  return [ids, classes, els];
}
const cmpSpec = (a, b) => (a[0] - b[0]) || (a[1] - b[1]) || (a[2] - b[2]);

// Lenient match for a static element: strip :pseudo and [attr]
// qualifiers (they can only narrow a match, never widen it past the
// tag/class/descendant structure), then match tag + classes along the
// ancestor path with descendant semantics.
function matches(sel, path) {
  const parts = sel.split(/\s+/).map(p => p.replace(/:(?!:)[\w-]+(\([^)]*\))?/g, '').replace(/\[[^\]]+\]/g, '').trim()).filter(Boolean);
  if (!parts.length) return false;
  let pi = 0;
  for (const el of path) {
    if (pi >= parts.length) break;
    const part = parts[pi];
    const tag = (/^[a-zA-Z][\w-]*/.exec(part) || [])[0];
    const classes = [...part.matchAll(/\.([\w-]+)/g)].map(m => m[1]);
    if ((!tag || tag === el.tag) && classes.every(c => el.classes.includes(c))) pi++;
  }
  return pi === parts.length;
}

// The element in question: the answer paragraph inside its card.
const ANSWER_PATH = [
  { tag: 'div', classes: ['simple-card', 'qa-card'] },
  { tag: 'p', classes: ['ai-answer'] },
];

// Which font-size rule wins for that element in the given stylesheet?
function winningFontSize(text) {
  const rules = parseRules(text);
  const cands = [];
  for (const r of rules) {
    const m = /font-size\s*:\s*([^;}]+)/.exec(r.decls);
    if (!m) continue;
    if (matches(r.selector, ANSWER_PATH)) {
      cands.push({ selector: r.selector, value: m[1].trim(), spec: specificity(r.selector), order: r.order });
    }
  }
  cands.sort((a, b) => cmpSpec(a.spec, b.spec) || (a.order - b.order));
  return { cands, winner: cands[cands.length - 1] || null };
}

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.87', vj.version === '2.2.87', vj.version);
  ok('version notes mention v2.2.87', vj.notes.includes('v2.2.87:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.87', pj.version === '2.2.87', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.87', nbc.includes('"version":"2.2.87"'));
}

// ---------- the cascade proof (the core of v2.2.87) ----------
{
  const { cands, winner } = winningFontSize(css);
  ok('exactly two font-size rules match the answer paragraph', cands.length === 2, cands.map(c => `${c.selector}=>${c.value}`).join(' | '));
  ok('the generic card-paragraph rule still sets 12px', cands.some(c => c.selector === '.simple-card p' && c.value === '12px'));
  ok('the AI-answer rule sets var(--ai-font,22px)', cands.some(c => c.selector === '.simple-card p.ai-answer' && c.value === 'var(--ai-font,22px)'));
  ok('the AI-answer rule WINS the cascade (specificity (0,2,1) beats (0,1,1))', !!winner && winner.selector === '.simple-card p.ai-answer' && winner.value === 'var(--ai-font,22px)', winner ? `${winner.selector} spec=${winner.spec} => ${winner.value}` : 'no winner');
  // No hidden .ai-answer rule anywhere (including inside @media blocks).
  ok('ai-answer appears exactly 3 times in styles.css (lines 378, 538, 622)', (css.match(/ai-answer/g) || []).length === 3, `count=${(css.match(/ai-answer/g) || []).length}`);
  ok('the other two .ai-answer rules set no font-size', css.includes('.ai-answer{white-space:pre-wrap}') && css.includes('.ai-answer { line-height: 1.75;'));
}
{
  // The bug, proved on the pristine v2.2.86 CSS: the same cascade
  // there picks 12px - that is what his screenshot showed.
  const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
  const { cands, winner } = winningFontSize(rbCss);
  ok('v2.2.86 cascade: the two competing rules are present', cands.length === 2, cands.map(c => `${c.selector}=>${c.value}`).join(' | '));
  ok('v2.2.86 cascade: 12px WON (the bug his screenshot showed)', !!winner && winner.selector === '.simple-card p' && winner.value === '12px', winner ? `${winner.selector} spec=${winner.spec} => ${winner.value}` : 'no winner');
  ok('v2.2.86 cascade: the plain .ai-answer rule LOST (specificity (0,1,0))', cands.some(c => c.selector === '.ai-answer' && c.value === 'var(--ai-font,22px)'));
}

// ---------- static checks: the fix, nothing else moved ----------
ok('the fixed rule is present', css.includes('.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'));
ok('the generic .simple-card p rule is untouched (still 12px)', css.includes('.simple-card p{font-size:12px;color:var(--muted);margin:3px 0}'));
ok('font-size var(--ai-font,22px) appears exactly once', (css.match(/font-size:var\(--ai-font,22px\)/g) || []).length === 1);
ok('app.js byte-identical to v2.2.86 (no app code changed)', md5(path.join(ROOT, 'www/app.js')) === md5(path.join(RB, 'app.js')));
{
  const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
  const expected = rbCss.replace('.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);', '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);');
  ok('styles.css differs from v2.2.86 ONLY by the selector change', css === expected);
}

// ---------- v2.2.85 (AI answer font 22px) intact ----------
ok('v2.2.85 BASE.aiFont still 22', app.includes('aiFont:22,'));
ok('v2.2.85 18->22 migration intact', app.includes('if(state.aiFont===18)state.aiFont=22;'));
ok('v2.2.85 theme() still sets --ai-font from state.aiFont', app.includes("html.style.setProperty('--ai-font',(Number(state.aiFont)||22)+'px')"));
// ---------- v2.2.86 (Sahaj/GGS two positions) intact ----------
ok('v2.2.86 BASE.ggAng intact', app.includes('ang:1,ggAng:0,'));
ok('v2.2.86 loadRemote still writes ggAng', app.includes('if(extra.gg)state.ggAng=Number(id);'));
ok('v2.2.86 jump box + picker still pass gg only', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,false,true)") && app.includes("openAng($('angPicker')?.value||displayAng(),false,false,true)"));
ok('v2.2.86 Continue still sahaj only', app.includes("openAng(state.ang,true,true)"));
// ---------- v2.2.84 (highlight stays centered) intact ----------
ok('v2.2.84 render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
// ---------- v2.2.83 (search Gurmukhi + Latin only) intact ----------
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
// ---------- v2.2.82 (Ask buttons, button decides) intact ----------
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;'));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
// ---------- v2.2.79 (mic) intact - mic NOT touched in v2.2.87 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));

// ---------- runtime: the REAL aiFont migration + the REAL theme() ----------
// Run the real init statements in a vm sandbox, then the real theme()
// with a mock html/document, and read the --ai-font it actually sets.
{
  const migrate = 'state.aiFont=Math.min(32,Math.max(14,Number(state.aiFont)||22));if(state.aiFont===18)state.aiFont=22;';
  ok('the real aiFont migration statements are found', app.includes(migrate));
  const runMigrate = stored => {
    const ctx = { state: { aiFont: stored } };
    vm.createContext(ctx);
    vm.runInContext(migrate, ctx);
    return ctx.state.aiFont;
  };
  ok('stored 18 (his phone) becomes 22', runMigrate(18) === 22, `got ${runMigrate(18)}`);
  ok('fresh install (undefined) starts at 22', runMigrate(undefined) === 22, `got ${runMigrate(undefined)}`);
  ok('a deliberately set 20 stays 20', runMigrate(20) === 20, `got ${runMigrate(20)}`);
  ok('a deliberately set 26 stays 26', runMigrate(26) === 26, `got ${runMigrate(26)}`);
  ok('clamp holds: 40 becomes 32', runMigrate(40) === 32, `got ${runMigrate(40)}`);
  ok('clamp holds: 5 becomes 14', runMigrate(5) === 14, `got ${runMigrate(5)}`);

  const themeFn = extractFunction(app, 'function theme(){');
  ok('the real theme() is found', !!themeFn);
  const runTheme = aiFont => {
    const styleStore = {};
    const ctx = {
      state: { theme: 'light', lineLayout: 'standard', fontStyle: 'anmol', margin: 'normal', raisedHeadings: false, nightMode: false, baniTextSize: 'normal', fontColor: 'black', font: 25, aiFont, layerScale: 0.8, uiScale: 1.12, tone: 70, lang: 'pa' },
      // theme() reads document.documentElement itself (const html=...).
      document: {
        documentElement: {
          classList: { toggle: () => {} },
          dataset: {},
          style: { setProperty: (k, v) => { styleStore[k] = v; } },
          lang: '',
        },
        querySelector: () => null,
      },
    };
    vm.createContext(ctx);
    // Run the migration, define theme(), then CALL it.
    vm.runInContext(migrate + '\n' + themeFn + '\ntheme();', ctx);
    return styleStore['--ai-font'];
  };
  // His phone: stored 18 -> migration makes it 22 -> theme sets 22px.
  ok('theme() sets --ai-font to 22px for his phone (stored 18)', runTheme(18) === '22px', `got ${runTheme(18)}`);
  ok('theme() sets --ai-font to 26px when set to 26 (pinch/A+ now work)', runTheme(26) === '26px', `got ${runTheme(26)}`);
  ok('theme() sets --ai-font to 14px at the bottom of the clamp', runTheme(5) === '14px', `got ${runTheme(5)}`);
}

// ---------- no data changes; every offline file byte-identical to v2.2.86 ----------
{
  const rb = path.join(RB, 'offline');
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.86 (${n} files)`, diff === 0, `${diff} differ`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
