/* v2.2.86 test - Sahaj Paath and Guru Granth Sahib are now two
 * separate remembered positions. Karamjit 2026-11-20: "I am on page
 * one four one zero [Sahaj Paath]... then I go to Guru Granth Sahib
 * and I want to search something like five hundred page, that my
 * Sahaj Paath also becomes five hundred. My Sahaj Paath should stay
 * the same, one four one zero, and Guru Granth Sahib should be
 * separate."
 * Uses the REAL code from www/app.js (not copies), run in a Node vm
 * sandbox, plus static checks. Run: node test-v306.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// Extract a whole `if(...) {...}` statement starting at startMarker by
// brace counting. Braces inside template literals / object literals
// balance out, so a naive counter works here.
function extractStatement(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.86', vj.version === '2.2.86', vj.version);
  ok('version notes mention v2.2.86', vj.notes.includes('v2.2.86:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.86', pj.version === '2.2.86', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.86', nbc.includes('"version":"2.2.86"'));
}

// ---------- static checks: v2.2.86 (two positions) ----------
ok('BASE has ggAng:0', app.includes('ang:1,ggAng:0,'));
ok('ggAng migration is present', app.includes('state.ggAng=Math.min(1430,Math.max(1,Number(state.ggAng)||state.ang));'));
ok('loadRemote writes ggAng when extra.gg', app.includes('if(extra.gg)state.ggAng=Number(id);'));
ok('openAng has the gg param', app.includes('function openAng(n,preserveProgress=false,sahaj=false,gg=false)'));
ok('openAng passes both flags to loadRemote', app.includes('{sahaj,gg}'));
ok('jump box passes gg only, not sahaj', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,false,true)"));
ok('Library picker passes gg only, not sahaj', app.includes("openAng($('angPicker')?.value||displayAng(),false,false,true)"));
ok('Library picker input shows ggAng', app.includes('value="${state.ggAng||state.ang}"'));
ok('displayAng falls back to ggAng outside the reader', app.includes("return activeRemote?.kind==='ang'?Number(activeRemote.id):(state.ggAng||state.ang)"));
ok('swipe passes gg and sahaj-when-on-Sahaj-Ang', app.includes("openAng(cur+(dx<0?1:-1),false,cur===state.ang,true)"));
ok('Continue (navReader) still passes sahaj only', app.includes("openAng(state.ang,true,true)"));
ok('search/saved opens still pass no flag (detours)', app.includes("openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true)"));
ok('Hukamnama full-Ang open still a detour', app.includes("openAng(state.hukamnama.ang)"));
ok('ggAng is in the backup permitted list', app.includes("'ang','ggAng',"));
ok('Home Continue card still shows the Sahaj position', app.includes("${age('ਸਹਿਜ ਪਾਠ · ਅੰਗ','Sahaj Paath · Ang')} ${state.ang}"));
ok('no caller still passes sahaj=true to the jump box or picker', !app.includes("displayAng())),false,true)") && !app.includes("displayAng(),false,true)"));

// ---------- v2.2.85 (AI answer font 22px) intact ----------
ok('v2.2.85 BASE.aiFont still 22', app.includes('aiFont:22,'));
ok('v2.2.85 18->22 migration intact', app.includes('if(state.aiFont===18)state.aiFont=22;'));
ok('v2.2.85 CSS fallback still 22px', css.includes('font-size:var(--ai-font,22px)'));
// ---------- v2.2.84 (highlight stays centered) intact ----------
ok('v2.2.84 render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
ok('v2.2.84 render() still restores the anchor when there is no highlight', app.includes('if(readerAnchor<0)return;'));
// ---------- v2.2.83 (search Gurmukhi + Latin only) intact ----------
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
ok('v2.2.83 fillResultEn still gone', !app.includes('fillResultEn'));
// ---------- v2.2.82 (Ask buttons, button decides) intact ----------
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;'));
ok('v2.2.81 go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('v2.2.81 results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 detail output still 1200 tokens', app.includes('max_tokens:1200'));
// ---------- v2.2.79 (mic) intact - mic NOT touched in v2.2.86 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('mic still one session per tap (no restart loop)', !app.includes('for(;;)') || !app.slice(app.indexOf('startVoiceSearch'), app.indexOf('startVoiceSearch') + 6000).includes('for(;;)'));

// ---------- no data changes; styles.css byte-identical to v2.2.85 ----------
{
  const rb = '/tmp/v306-rollback/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.85 (${n} files)`, diff === 0, `${diff} differ`);
  const rbCss = fs.readFileSync('/tmp/v306-rollback/www/styles.css', 'utf8');
  ok('styles.css byte-identical to v2.2.85 (no CSS change)', css === rbCss);
}

// ---------- runtime: the REAL loadRemote Ang branch in a vm sandbox ----------
// Extract the real `if(kind==='ang'){...}` state-writing statement from
// loadRemote and run it with different flags, the way each call site
// reaches it. His phone: Sahaj Paath at 1410, verse 5.
{
  const branch = extractStatement(app, "if(kind==='ang'){if(extra.sahaj)");
  ok('the real loadRemote Ang branch is found', !!branch);
  const runBranch = (id, extra, preserveProgress, start) => {
    const ctx = {
      kind: 'ang', id, extra, preserveProgress,
      state: { ang: start.ang, ggAng: start.ggAng, verse: start.verse ?? 5, verseOffset: start.verseOffset ?? 10, hasProgress: false },
      persist: () => {},
    };
    vm.createContext(ctx);
    vm.runInContext(branch, ctx);
    return ctx.state;
  };
  // Case A: his exact report - Sahaj at 1410, jump box to 500 (gg only).
  // Sahaj must stay 1410; Guru Granth Sahib remembers 500.
  {
    const s = runBranch(500, { sahaj: false, gg: true }, false, { ang: 1410, ggAng: 1410 });
    ok('jump to 500 leaves Sahaj at 1410', s.ang === 1410, `ang=${s.ang}`);
    ok('jump to 500 sets the GGS page to 500', s.ggAng === 500, `ggAng=${s.ggAng}`);
    ok('jump does not reset the Sahaj verse position', s.verse === 5 && s.verseOffset === 10, `verse=${s.verse}`);
  }
  // Case B: Continue (navReader) - Sahaj moves to its own Ang, GGS untouched.
  {
    const s = runBranch(1410, { sahaj: true, gg: false }, true, { ang: 1410, ggAng: 500 });
    ok('Continue keeps Sahaj at 1410', s.ang === 1410, `ang=${s.ang}`);
    ok('Continue does not touch the GGS page (stays 500)', s.ggAng === 500, `ggAng=${s.ggAng}`);
  }
  // Case C: a search result open (detour, no flags) - neither position moves.
  {
    const s = runBranch(500, {}, true, { ang: 1410, ggAng: 1366 });
    ok('search open leaves Sahaj at 1410', s.ang === 1410, `ang=${s.ang}`);
    ok('search open leaves the GGS page at 1366', s.ggAng === 1366, `ggAng=${s.ggAng}`);
  }
  // Case D: swipe forward from the Sahaj Ang (1410 -> 1411) - BOTH move,
  // because he is reading forward and the reader is now at 1411.
  {
    const s = runBranch(1411, { sahaj: true, gg: true }, false, { ang: 1410, ggAng: 500 });
    ok('swipe from Sahaj Ang advances Sahaj to 1411', s.ang === 1411, `ang=${s.ang}`);
    ok('swipe from Sahaj Ang moves the GGS page to 1411 too', s.ggAng === 1411, `ggAng=${s.ggAng}`);
  }
  // Case E: swipe forward from a detour Ang (500 -> 501) - only GGS moves.
  {
    const s = runBranch(501, { sahaj: false, gg: true }, false, { ang: 1410, ggAng: 500 });
    ok('swipe from a detour leaves Sahaj at 1410', s.ang === 1410, `ang=${s.ang}`);
    ok('swipe from a detour moves the GGS page to 501', s.ggAng === 501, `ggAng=${s.ggAng}`);
  }
  // Case F: the Nov 5 bug stays fixed - jump to 1366, then the GGS page
  // is 1366 (it no longer reverts to the old page when he comes back).
  {
    const s = runBranch(1366, { sahaj: false, gg: true }, false, { ang: 478, ggAng: 478 });
    ok('jump to 1366 sticks as the GGS page (no revert to 478)', s.ggAng === 1366, `ggAng=${s.ggAng}`);
    ok('and Sahaj still stays at 478', s.ang === 478, `ang=${s.ang}`);
  }
}

// ---------- runtime: the REAL ggAng init migration in a vm sandbox ----------
{
  const marker = 'state.ggAng=Math.min(1430,Math.max(1,Number(state.ggAng)||state.ang));';
  ok('the real ggAng init statement is found', app.includes(marker));
  const runInit = (storedGg, ang) => {
    const ctx = { state: { ggAng: storedGg, ang } };
    vm.createContext(ctx);
    vm.runInContext(marker, ctx);
    return ctx.state.ggAng;
  };
  // His phone on first load after the update: no stored ggAng, Sahaj 1410.
  ok('first load: no stored ggAng starts at the Sahaj position 1410', runInit(undefined, 1410) === 1410, `got ${runInit(undefined, 1410)}`);
  ok('first load: stored ggAng 0 also starts at 1410', runInit(0, 1410) === 1410, `got ${runInit(0, 1410)}`);
  // Once he has jumped, the stored GGS page survives the next load.
  ok('stored ggAng 500 survives the next load', runInit(500, 1410) === 500, `got ${runInit(500, 1410)}`);
  // Clamps still hold.
  ok('stored ggAng 2000 is clamped to 1430', runInit(2000, 1410) === 1430, `got ${runInit(2000, 1410)}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
