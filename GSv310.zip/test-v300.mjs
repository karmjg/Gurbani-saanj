/* Gurbani Saanjh v2.2.80 - Ask AI follows the question's language, and
 * verses show Gurmukhi + Latin (Karamjit 2026-11-19, with two photos).
 *
 * PHOTO 1 (Ask screen): he asked in English - "What is hukam?" - with the
 * English pill selected, but the whole AI answer came back in Punjabi.
 * And each quoted verse was in Gurmukhi ONLY, no Latin form below it.
 * PHOTO 2 (Search screen): a search for "tudh jevad na" - results show
 * the Gurmukhi lines with the English MEANING below. For Ask, he does NOT
 * want the English meaning; he wants the Latin (Roman) form - how the line
 * is pronounced/written in English letters, same as Roman search.
 *
 * His rule: ask in English -> answer in English; ask in Punjabi -> answer
 * in Punjabi. Each Bani line: Gurmukhi + Latin below it. NO English
 * translation/meaning of the line. The explanation is in the question's
 * language.
 *
 * Changes vs v2.2.79 (app) + the worker:
 *  1. NEW aiQuestionLang(q): Gurmukhi script -> 'pa', Latin -> 'en'.
 *     The Ask call now sends language:aiQuestionLang(q) to the cloud
 *     worker (was state.aiLang, the toggle/app language), and askOpenAI
 *     answers in the question's language too.
 *  2. entry.matches now carries roman for Ang AND Bani matches.
 *  3. AI prompts: each quoted verse is Gurmukhi (exact) then the same
 *     verse in Latin (Roman) exactly as given in the 'roman' field; the
 *     verse is NOT translated into English.
 *  4. The AI-language pills (pa/en) are REMOVED from the Ask screen -
 *     they set state.aiLang, which no longer decides the answer language.
 *  5. Worker: verses mapping accepts roman; prompt updated the same way.
 *     The worker MUST be redeployed (paste worker.js into the Cloudflare
 *     dashboard and Deploy) - the app update alone does not change the
 *     live cloud AI.
 * Run: node test-v300.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v300-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.80', vj.version === '2.2.80');
ok('package.json is 2.2.80', pj.version === '2.2.80');
ok('native-build-config.js is 2.2.80', nbc.includes('"version":"2.2.80"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.80 entry',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.80:') &&
  vj.notes.includes('question') && vj.notes.includes('Latin'));
ok('native-build-config.js differs from v2.2.79 ONLY in the version string',
  nbc.replace('2.2.80', '2.2.79') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.79 ONLY in the version string',
  read('package.json').replace('2.2.80', '2.2.79') === readR('package.json'));

const app = read('www/app.js');

// ---- 1. Question-language detector (runtime) ----
const langMatch = app.match(/const aiQuestionLang=q=>[^;]+;/);
ok('aiQuestionLang detector is present in app.js', !!langMatch);
if (langMatch) {
  const sb = {};
  vm.createContext(sb);
  vm.runInContext(langMatch[0] + '\nglobalThis.__lang=aiQuestionLang;', sb);
  const f = sb.__lang;
  ok('English question "What is hukam?" -> en', f('What is hukam?') === 'en');
  ok('Punjabi question "ਹੁਕਮ ਕੀ ਹੈ?" -> pa', f('ਹੁਕਮ ਕੀ ਹੈ?') === 'pa');
  ok('Roman Punjabi "hukam ki hai?" -> en (Latin letters read as English)', f('hukam ki hai?') === 'en');
  ok('empty question -> en (default)', f('') === 'en');
  ok('mixed "What is ਸਤਿ?" -> pa (has Gurmukhi)', f('What is ਸਤਿ?') === 'pa');
  ok('Ang search "ਤੁਧੁ ਜੇਵਡੁ ਨਾ" -> pa', f('ਤੁਧੁ ਜੇਵਡੁ ਨਾ') === 'pa');
}

// ---- 2. The Ask call sends the question language ----
ok('cloud AI call sends language:aiQuestionLang(q)',
  app.includes('language:aiQuestionLang(q)'));
ok('cloud AI call no longer sends state.aiLang',
  !app.includes('language:state.aiLang'));
ok('askOpenAI answers in the question language',
  app.includes("Answer in ${aiQuestionLang(question)==='en'?'English':'Punjabi'}"));
ok('askOpenAI no longer answers in state.aiLang',
  !app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));

// ---- 3. Matches carry roman (Ang + Bani) ----
// Runtime: run a real search and confirm the match objects have roman.
const searchSrc = read('www/scripture-search.js');
{
  const rows = JSON.parse(read('www/offline/search.json'));
  const baniRows = JSON.parse(read('www/offline/bani-search.json'));
  const sb = {
    window: {},
    fetch: async (url) => {
      const text = url.includes('bani-search') ? JSON.stringify(baniRows) : JSON.stringify(rows);
      return { ok: true, json: async () => JSON.parse(text) };
    },
    console,
  };
  vm.createContext(sb);
  vm.runInContext(searchSrc, sb);
  const q = sb.window.GS_SCRIPTURE_SEARCH.query;
  const res = await q('ਹੁਕਮ', 5);
  ok('search returns matches for "ਹੁਕਮ"', Array.isArray(res) && res.length > 0, `got ${res?.length}`);
  const withRoman = res.filter(m => typeof m.roman === 'string' && m.roman.trim().length > 0);
  ok('search matches carry a non-empty roman (Latin) field',
    withRoman.length === res.length, `${withRoman.length}/${res.length}`);
  // The entry.matches mapping in app.js must include roman for both kinds.
  ok('entry.matches mapping includes roman (Ang + Bani)',
    app.includes("roman:m.roman||''") && (app.match(/roman:m\.roman\|\|''/g) || []).length === 2);
  // The exact verse from photo 1 (Ang 1, hukam) has a roman form.
  const ang1 = rows.find(r => r[0] === 1 && String(r[2] || '').includes('ਹੁਕਮੀ ਹੋਵਨਿ ਆਕਾਰ'));
  ok('Ang 1 "ਹੁਕਮੀ ਹੋਵਨਿ ਆਕਾਰ" line has a roman form in the data',
    !!ang1 && typeof ang1[5] === 'string' && ang1[5].length > 0, ang1 ? String(ang1[5]).slice(0, 60) : 'not found');
}

// ---- 4. AI prompts: Gurmukhi + Latin, no English translation ----
ok('AI_SYSTEM_PROMPT quotes Gurmukhi then the Latin form exactly as given',
  app.includes("then write the same verse in Latin (Roman) letters exactly as given in the"));
ok('AI_SYSTEM_PROMPT forbids translating the verse into English',
  app.includes('Do NOT translate the verse into English; the Latin form is how the verse is pronounced, not a translation.'));
ok('askOpenAI context includes the roman form',
  app.includes("head+' '+m.g+(m.roman?'\\n'+m.roman:'')"));

// ---- 5. AI-language pills removed from the Ask screen ----
ok('ai-lang-pills markup is gone from the Ask screen',
  !app.includes('ai-lang-pills'));
ok('AI answer language label is gone',
  !app.includes('AI ਜਵਾਬ ਦੀ ਭਾਸ਼ਾ'));

// ---- 6. Worker (in-repo copy) ----
const worker = read('ai-server/cloudflare-worker.mjs');
ok('worker accepts roman in the verses mapping',
  worker.includes("const roman=String(v.roman||'').slice(0,480);"));
ok('worker verse objects carry roman (bani + sggs)',
  (worker.match(/g,roman\}/g) || []).length === 2);
ok('worker prompt quotes Gurmukhi then the Latin form exactly as given',
  worker.includes("then write the same verse in Latin (Roman) letters exactly as given in the"));
ok('worker prompt forbids translating the verse into English',
  worker.includes('Do NOT translate the verse into English; the Latin form is the pronunciation, not a translation.'));
ok('worker no longer bans pronunciation guidance outright (the supplied Latin IS the pronunciation)',
  worker.includes('Do not add any other pronunciation guidance beyond the supplied Latin form.') &&
  !worker.includes('Do not add audio/pronunciation guidance.'));
ok('worker still answers in body.language (the app now sends the question language)',
  worker.includes("const language=body?.language==='pa'?'Punjabi (Gurmukhi)':'English';"));
ok('worker still requires question + verses',
  worker.includes("if(!question||!verses.length)return reply(400,{error:'Question and verified source verses are required'});"));

// ---- 6b. Ask answers elaborate a little more (Detailed level) ----
ok('worker detail level asks for a fuller explanation of each verse',
  worker.includes("take a little more time on each verse: its meaning, and why it matters in daily life."));
ok('worker detail output room raised 900 -> 1200 tokens',
  worker.includes("depth==='detail'?1200:1500"));
ok('app askOpenAI detail level asks for a fuller explanation of each verse',
  app.includes("take a little more time on each verse: its meaning, and why it matters in daily life."));
ok('app askOpenAI max_tokens raised 900 -> 1200',
  app.includes('max_tokens:1200'));
ok('short and deep levels unchanged (only detail elaborates a little more)',
  worker.includes("depth==='short'?250:") && worker.includes(":1500,temperature:0.3") &&
  app.includes("depth==='short'?'Explain in very simple words") &&
  app.includes("depth==='deep'?'Explain in depth: meaning, context, and what it means for a person\\'s life.'"));

// ---- 7. Mic (v2.2.79) + 30s + mic-stop untouched ----
ok('v2.2.79 segStartedAt still recorded', app.includes('run.segStartedAt=Date.now();'));
ok('v2.2.79 dead-start retry still present', app.includes('let deadStartRetries=0;'));
ok('deadStart condition still exact',
  app.includes('const deadStart=!heard.text.trim()&&(Date.now()-run.segStartedAt)<3000&&!runEnded()&&deadStartRetries<1;'));
ok('app guard still arms at 30000ms', app.includes('armSegGuard(30000);'));
ok('go() still stops the mic when leaving Search/Ask',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('popstate still stops the mic (back button)',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('visibilitychange hidden still stops the mic',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('voiceMeter still in BOTH search and ask screens', (app.match(/id="voiceMeter"/g) || []).length === 2);
const css = read('www/styles.css');
ok('styles.css is byte-identical to v2.2.79 (no CSS changes in this build)',
  fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(path.join(ROLL, 'www/styles.css'))));

// ---- 8. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));

// ---- 9. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.79',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 10. Nothing else changed vs v2.2.79 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js', 'ai-server/cloudflare-worker.mjs'];
const added = ['scripts/fix-v300.py', 'test-v300.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts', 'ai-server']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
for (const f of walk(path.join(ROLL, 'scripts'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.79 (only app.js + worker + version files)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.79 (no files missing)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.79',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
