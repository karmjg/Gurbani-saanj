/* v2.2.90 test - Ask page: mic out, Ask + language pills in the question
 * box, Ask label follows the answer language. Karamjit 2026-11-23,
 * "Build it"; mockup mockup_ask_no_mic.png approved.
 *
 * Change 1 - Mic REMOVED from the Ask page only (button, listening
 * status line, green meter). Search mic untouched.
 * Change 2 - Ask button moves into the question box, FIRST (before
 * Punjabi and English), keeping id="askButton". Big full-width Ask
 * button below is gone.
 * Change 3 - Language pills (Punjabi/English) move into the question
 * box, beside Ask. Their separate row below is gone.
 * Change 4 - Ask button label follows the selected ANSWER language
 * (state.aiLang): Punjabi -> 'ਪੁੱਛੋ', English -> 'Ask'. New helper
 * askButtonLabel(); the data-ai-lang tap handler re-labels the button
 * (guarded while an answer is being fetched); answerQuestion() restores
 * via the helper and its transient text follows the same rule.
 * Change 5 - Intro no longer says "speak": "Type your question" /
 * "ਸਵਾਲ ਲਿਖੋ।".
 * CSS - Ask button + language pills keep their look inside .inputrow
 * (solid primary Ask, outlined pills, selected = solid primary),
 * textarea min-width:0, dark-mode overrides.
 *
 * The proofs below run the REAL askScreen() + askButtonLabel() from the
 * shipped app.js in a VM (with the real t()/age() implementations and
 * the real askButton strings), and a real CSS cascade computation
 * (attribute-selector-aware) over the shipped styles.css.
 * Negative control: the same checks run against /tmp/v290-rollback
 * (pristine v2.2.89, extracted from GSv309.zip) and must show the OLD
 * layout (mic present, big Ask button, language row below, no helper).
 * Run: node test-v310.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v290-rollback/www';
const rbApp = fs.readFileSync(path.join(RB, 'app.js'), 'utf8');
const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: version ----------
{
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json version is 2.2.90', pj.version === '2.2.90', `got ${pj.version}`);
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json is 2.2.90', vj.version === '2.2.90', `got ${vj.version}`);
  ok('version.json notes carry v2.2.90', vj.notes.includes('v2.2.90:'));
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js is 2.2.90', nbc.includes('"version":"2.2.90"') && nbc.match(/2\.2\.90/g).length === 1);
}

// ---------- runtime: the REAL askScreen() + askButtonLabel() ----------
function extractAsk(appSrc) {
  const start = appSrc.indexOf('function askButtonLabel(){');
  if (start === -1) return null;
  const askStart = appSrc.indexOf('function askScreen(){', start);
  const end = appSrc.indexOf('</section>`}', askStart);
  if (askStart === -1 || end === -1) return null;
  return appSrc.slice(start, end + '</section>`}'.length);
}
function makeAskCtx() {
  // Real t()/age() implementations (one-liners, copied verbatim from app.js)
  // and the real askButton strings from the shipped txt dict (verified
  // statically below); the rest of txt is stubbed to the keys askScreen
  // actually reads.
  const txt = {
    pa: { askButton: 'ਪੁੱਛੋ', askTitle: 'ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਤੋਂ ਪੁੱਛੋ', askHint: 'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ...', short: 'ਸੌਖਾ', detail: 'ਵਿਸਥਾਰ', deep: 'ਡੂੰਘਾਈ' },
    en: { askButton: 'Ask', askTitle: 'Ask Guru Granth Sahib', askHint: 'Ask any question...', short: 'Simple', detail: 'Detailed', deep: 'In depth' },
  };
  const state = { lang: 'en', aiLang: 'pa', depth: 'detail', questions: [], aiApiKey: '', aiEndpoint: '' };
  const ctx = {
    txt, state,
    AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev',
    renderQA: () => '',
    esc: s => String(s),
  };
  ctx.t = k => (ctx.txt[ctx.state.lang] || ctx.txt.pa)[k] || k;
  ctx.age = (k, en) => ctx.state.lang === 'pa' ? k : en;
  return ctx;
}
function runAsk(appSrc) {
  const code = extractAsk(appSrc);
  if (!code) return null;
  const ctx = makeAskCtx();
  vm.createContext(ctx);
  vm.runInContext(code, ctx);
  // askScreen() is now defined in the context; call it under two aiLang
  // settings and return both renderings.
  const out = {};
  for (const aiLang of ['pa', 'en']) {
    ctx.state.aiLang = aiLang;
    out[aiLang] = vm.runInContext('askScreen()', ctx);
  }
  // Also render with the APP language flipped, to prove the label follows
  // aiLang and not the app language.
  ctx.state.lang = 'pa'; ctx.state.aiLang = 'en';
  out.langPa_aiEn = vm.runInContext('askScreen()', ctx);
  ctx.state.lang = 'en'; ctx.state.aiLang = 'pa';
  out.langEn_aiPa = vm.runInContext('askScreen()', ctx);
  return out;
}
const rendered = runAsk(app);
ok('askButtonLabel + askScreen extract and run', !!rendered);
{
  // The real txt dict carries the two Ask strings.
  ok("txt.pa.askButton is 'ਪੁੱਛੋ'", /askButton:'ਪੁੱਛੋ'/.test(app));
  ok("txt.en.askButton is 'Ask'", /askButton:'Ask'/.test(app));
}
if (rendered) {
  const pa = rendered.pa, en = rendered.en;
  // --- Change 1: mic gone from the Ask page ---
  ok('Ask page has NO askVoiceBtn', !pa.includes('askVoiceBtn') && !en.includes('askVoiceBtn'));
  ok('Ask page has NO voiceStatus', !pa.includes('voiceStatus') && !en.includes('voiceStatus'));
  ok('Ask page has NO voiceMeter', !pa.includes('voiceMeter') && !en.includes('voiceMeter'));
  ok('Ask page has NO mic emoji', !pa.includes('🎙') && !en.includes('🎙'));
  // --- Change 2+3: Ask + language pills live inside the inputrow ---
  const rowOf = html => {
    const m = html.match(/<div class="inputrow">([\s\S]*?)<\/div>/);
    return m ? m[1] : '';
  };
  const rowPa = rowOf(pa), rowEn = rowOf(en);
  ok('inputrow exists', !!rowPa && !!rowEn);
  ok('Ask button (id=askButton) is inside the inputrow', rowPa.includes('id="askButton"') && rowEn.includes('id="askButton"'));
  ok('language pills are inside the inputrow', rowPa.includes('data-ai-lang') && rowEn.includes('data-ai-lang'));
  ok('Ask button comes BEFORE the language pills in the row',
    rowPa.indexOf('id="askButton"') < rowPa.indexOf('data-ai-lang') &&
    rowEn.indexOf('id="askButton"') < rowEn.indexOf('data-ai-lang'));
  ok('Ask button comes before Punjabi specifically',
    rowPa.indexOf('id="askButton"') < rowPa.indexOf('ਪੰਜਾਬੀ'));
  ok('Ask button is NOT full-width (no "primary full")', !pa.includes('primary full') && !en.includes('primary full'));
  ok('no big Ask button below the box', !pa.includes('margin-top:14px') && !en.includes('margin-top:14px'));
  // Only ONE answer-pills row remains (the depth row); the language row is gone.
  const pills = (pa.match(/<div class="answer-pills">/g) || []).length;
  ok('exactly one answer-pills row remains (depth only)', pills === 1, `got ${pills}`);
  ok('depth pills still present (Simple/Detailed/In depth)', pa.includes('data-depth') && pa.includes('Detailed'));
  // --- Change 4: label follows aiLang, not the app language ---
  ok("Punjabi picked -> Ask button reads 'ਪੁੱਛੋ'", rowPa.includes('>ਪੁੱਛੋ<'));
  ok("English picked -> Ask button reads 'Ask'", rowEn.includes('>Ask<'));
  ok("label follows aiLang, not app language (lang=en, aiLang=pa -> 'ਪੁੱਛੋ')", rowOf(rendered.langEn_aiPa).includes('>ਪੁੱਛੋ<'));
  ok("label follows aiLang, not app language (lang=pa, aiLang=en -> 'Ask')", rowOf(rendered.langPa_aiEn).includes('>Ask<'));
  // The selected language pill carries .sel in the row.
  ok("Punjabi pill is .sel when Punjabi picked", /data-ai-lang="pa" class="sel"/.test(rowPa));
  ok("English pill is .sel when English picked", /data-ai-lang="en" class="sel"/.test(rowEn));
  // --- Change 5: intro no longer says "speak" ---
  ok('intro says "Type your question", not "Type or speak"', pa.includes('Type your question') && !pa.includes('Type or speak'));
  // The Punjabi strings only render when the APP language is Punjabi.
  const paLang = rendered.langPa_aiEn;
  ok('Punjabi intro says "ਸਵਾਲ ਲਿਖੋ।", not "ਜਾਂ ਬੋਲੋ"', paLang.includes('ਸਵਾਲ ਲਿਖੋ।') && !paLang.includes('ਜਾਂ ਬੋਲੋ'));
  // Unchanged: AI status line, conversation, footer note.
  ok('AI online line still present', pa.includes('aiStatusLine') && pa.includes('AI is online'));
  ok('conversation div still present', pa.includes('id="conversation"'));
  ok('footer note still present (English)', pa.includes('AI interpretation is always distinct from original Gurbani.'));
  ok('footer note still present (Punjabi)', paLang.includes('AI ਦੀ ਵਿਆਖਿਆ ਨੂੰ ਮੂਲ ਗੁਰਬਾਣੀ ਤੋਂ ਵੱਖਰਾ ਰੱਖਿਆ ਜਾਂਦਾ ਹੈ।'));
}
// --- Static: the mic wiring cleanup + handler + restore ---
{
  ok('no askVoiceBtn reference anywhere in app.js', !app.includes('askVoiceBtn'));
  ok('ai-lang handler re-labels the Ask button', app.includes("ab.textContent=askButtonLabel()"));
  ok('ai-lang handler guards while fetching (does not overwrite a disabled button)', app.includes("if(ab&&!ab.disabled)ab.textContent=askButtonLabel()"));
  ok('answerQuestion restores via the helper', app.includes("b.textContent=askButtonLabel()"));
  ok('transient searching text follows aiLang', app.includes("state.aiLang==='pa'?'ਖੋਜ ਹੋ ਰਹੀ ਹੈ…'"));
  ok('Search mic button intact', app.includes('id="voiceBtn"'));
  ok('Search voiceStatus intact (exactly one)', (app.match(/id="voiceStatus"/g) || []).length === 1);
  ok('Search voiceMeter intact (exactly one)', (app.match(/id="voiceMeter"/g) || []).length === 1);
  ok('Search mic wiring intact', app.includes("const vb=$('voiceBtn');if(vb)vb.onclick"));
  ok('startVoiceSearch takes only the Search mic', app.includes("const btn=$('voiceBtn');"));
  ok('voice loops cleaned (exactly two, voiceBtn only)', (app.match(/for\(const id of \['voiceBtn'\]\)/g) || []).length === 2);
  ok('delegated Ask click handler still present', app.includes("if(e.target.closest('#askButton'))answerQuestion()"));
  // Carry-forwards.
  ok('v2.2.89 Vaaran-out-of-Ask filter intact', app.includes("!(m.src==='bani'&&m.group==='bhai')"));
  ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1'));
  ok('v2.2.86 ggAng intact', app.includes('if(extra.gg)state.ggAng=Number(id);'));
}

// ---------- a real CSS cascade (attribute-selector-aware) ----------
// (Helpers adapted from test-v309.mjs - same parser/specificity rules,
// extended so [data-ai-lang] attribute selectors are matched.)
function parseRules(text) {
  const clean = text.replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = [];
  let i = 0;
  while (i < clean.length) {
    const open = clean.indexOf('{', i);
    if (open === -1) break;
    const sel = clean.slice(i, open).trim();
    let depth = 1, j = open + 1;
    while (j < clean.length && depth > 0) {
      if (clean[j] === '{') depth++;
      else if (clean[j] === '}') depth--;
      j++;
    }
    if (sel && !sel.startsWith('@')) {
      for (const s of sel.split(',')) {
        const t = s.trim();
        if (!t.includes(':')) rules.push({ selector: t, decls: clean.slice(open + 1, j - 1), order: rules.length });
      }
    }
    i = j;
  }
  return rules;
}
function specificity(sel) {
  const ids = (sel.match(/#[\w-]+/g) || []).length;
  const classes = (sel.match(/\.[\w-]+/g) || []).length
    + (sel.match(/\[[^\]]+\]/g) || []).length
    + (sel.match(/:(?!:)[\w-]+(\([^)]*\))?/g) || []).length;
  const els = sel.split(/[\s>+~]+/).reduce((n, part) => n + (/^[a-zA-Z][\w-]*/.test(part) ? 1 : 0), 0);
  return [ids, classes, els];
}
const cmpSpec = (a, b) => (a[0] - b[0]) || (a[1] - b[1]) || (a[2] - b[2]);
function partMatches(part, el) {
  const tag = (/^[a-zA-Z][\w-]*/.exec(part) || [])[0];
  const id = (/#([\w-]+)/.exec(part) || [])[1];
  const classes = [...part.matchAll(/\.([\w-]+)/g)].map(m => m[1]);
  const attrs = [...part.matchAll(/\[([\w-]+)(?:=["']?([^"'\]]+)["']?)?\]/g)].map(m => ({ name: m[1], value: m[2] }));
  if (tag && tag !== el.tag) return false;
  if (id && id !== el.id) return false;
  if (!classes.every(c => (el.classes || []).includes(c))) return false;
  for (const a of attrs) {
    if (!(el.attrs && a.name in el.attrs)) return false;
    if (a.value !== undefined && el.attrs[a.name] !== a.value) return false;
  }
  return true;
}
function matches(sel, path) {
  const parts = sel.split(/\s+/).map(p => p.trim()).filter(Boolean);
  if (!parts.length) return false;
  let pi = 0;
  for (const el of path) {
    if (pi >= parts.length) break;
    if (partMatches(parts[pi], el)) pi++;
  }
  return pi === parts.length;
}
function winningProp(text, prop, elementPath) {
  const rules = parseRules(text);
  const cands = [];
  for (const r of rules) {
    const m = new RegExp(prop + '\\s*:\\s*([^;}]+)').exec(r.decls);
    if (!m) continue;
    if (matches(r.selector, elementPath)) {
      const raw = m[1].trim();
      cands.push({ selector: r.selector, value: raw.replace(/!important/g, '').trim(), important: /!important/.test(raw), spec: specificity(r.selector), order: r.order });
    }
  }
  cands.sort((a, b) => ((a.important ? 1 : 0) - (b.important ? 1 : 0)) || cmpSpec(a.spec, b.spec) || (a.order - b.order));
  return cands.length ? cands[cands.length - 1] : null;
}
{
  const askBtn = [
    { tag: 'section', classes: ['page', 'ask'] },
    { tag: 'div', classes: ['inputrow'] },
    { tag: 'button', id: 'askButton', classes: ['primary'] },
  ];
  const bg = winningProp(css, 'background', askBtn);
  ok('Ask button in the box wins a solid primary background',
    !!bg && bg.value === 'var(--primary)', bg ? `${bg.selector} -> ${bg.value}` : 'no rule');
  const col = winningProp(css, 'color', askBtn);
  ok('Ask button in the box wins white text',
    !!col && col.value === '#fff', col ? `${col.selector} -> ${col.value}` : 'no rule');
  const pillSel = [
    { tag: 'section', classes: ['page', 'ask'] },
    { tag: 'div', classes: ['inputrow'] },
    { tag: 'button', classes: ['sel'], attrs: { 'data-ai-lang': 'pa' } },
  ];
  const pbg = winningProp(css, 'background', pillSel);
  ok('selected language pill in the box wins a solid primary background',
    !!pbg && pbg.value === 'var(--primary)', pbg ? `${pbg.selector} -> ${pbg.value}` : 'no rule');
  const pill = [
    { tag: 'section', classes: ['page', 'ask'] },
    { tag: 'div', classes: ['inputrow'] },
    { tag: 'button', classes: [], attrs: { 'data-ai-lang': 'en' } },
  ];
  const pbg2 = winningProp(css, 'background', pill);
  ok('unselected language pill in the box wins the surface background',
    !!pbg2 && pbg2.value === 'var(--surface)', pbg2 ? `${pbg2.selector} -> ${pbg2.value}` : 'no rule');
  const prad = winningProp(css, 'border-radius', pill);
  ok('language pill in the box keeps the pill radius (19px)',
    !!prad && prad.value === '19px', prad ? `${prad.selector} -> ${prad.value}` : 'no rule');
  const ta = [
    { tag: 'section', classes: ['page', 'ask'] },
    { tag: 'div', classes: ['inputrow'] },
    { tag: 'textarea', id: 'questionInput', classes: [] },
  ];
  const mw = winningProp(css, 'min-width', ta);
  ok('textarea in the box gets min-width:0 so the row fits',
    !!mw && mw.value === '0', mw ? `${mw.selector} -> ${mw.value}` : 'no rule');
  ok('dark-mode Ask override present', css.includes('.dark .ask .inputrow #askButton{background:#2a5b45}'));
  ok('dark-mode selected-pill override present', css.includes('.dark .ask .inputrow [data-ai-lang].sel{background:#2e6047}'));
  ok('v2.2.87 AI font fix intact', css.includes('.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'));
}

// ---------- negative control: the v2.2.89 rollback must show the OLD layout ----------
{
  const rbRendered = runAsk(rbApp);
  ok('rollback has NO askButtonLabel helper (old code)', rbRendered === null);
  ok('rollback Ask page HAS the mic button', rbApp.includes('id="askVoiceBtn"'));
  ok('rollback Ask page HAS the big full-width Ask button', rbApp.includes('class="primary full"'));
  ok('rollback Ask page HAS the standalone language row (two answer-pills rows)',
    (rbApp.match(/<div class="answer-pills">/g) || []).length === 2);
  ok('rollback intro still says "Type or speak"', rbApp.includes('Type or speak your question'));
  ok('rollback CSS has NO v2.2.90 inputrow Ask rule', !rbCss.includes('.ask .inputrow #askButton'));
  ok('rollback CSS has NO v2.2.90 pill rule', !rbCss.includes('.ask .inputrow [data-ai-lang]'));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
