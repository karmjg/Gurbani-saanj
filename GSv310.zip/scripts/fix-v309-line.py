#!/usr/bin/env python3
"""v2.2.89 line correction (GSv309 rebuilt, same version - not uploaded yet):
Karamjit's Gutka wording for his quoted Vaaran line (Vaar 10, Pauri 9,
5th verse line, 131.json index 1719), on his go 2026-11-21 ('Lets do it').
The shipped Shabad OS edition read:
  'ਦੂਰਹੁ ਦੇਖਿ ਡੰਡਉਤਿ ਕਰਿ ਛਡਿ ਸਿੰਘਾਸਣੁ ਹਰਿ ਜੀ ਆਏ ।'
His Gutka reads (final call):
  'ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ ॥'
Exactly ONE line changes: its Gurmukhi + Roman. English/Punjabi meanings
are unchanged (they fit both wordings). Roman is gurmukhi-utils toEnglish
for the new wording, keeping the ';' vishraam marker after 'kar' exactly
as the stored Roman had it. The search index is rebuilt afterwards with
scripts/build-bani-search.mjs, so the line is found by HIS first letters
(ਦਦਡਕਹਜਸਛਅ). No other file, no other line: the word ਡੰਡਉਤਿ also occurs
in SGGS Ang lines and Bani 120 - those are different lines, untouched."""
import json

P = "/home/hatch/workspace/gurbani/v231/www/offline/bani/131.json"
OLD_G = "ਦੂਰਹੁ ਦੇਖਿ ਡੰਡਉਤਿ ਕਰਿ ਛਡਿ ਸਿੰਘਾਸਣੁ ਹਰਿ ਜੀ ਆਏ ।"
OLD_R = "doorahu dekh ddanddaut kar; chhadd singhaasan har jee aae |"
NEW_G = "ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ ॥"
NEW_R = "doorahu dekh danddaut kar; har jeeo singhaasan chhaadd aaeaa |"

d = json.load(open(P, encoding="utf-8"))
lines = d["lines"]
assert len(lines) == 7226, len(lines)
l = lines[1719]
assert l["g"] == OLD_G, repr(l["g"])
assert l["roman"] == OLD_R, repr(l["roman"])
assert l["en"].strip() and l["pa"].strip(), "meanings must stay"
l["g"] = NEW_G
l["roman"] = NEW_R
# indent=1 round-trips the file byte-identically (verified) - diff is 2 lines.
open(P, "w", encoding="utf-8").write(json.dumps(d, ensure_ascii=False, indent=1))

d2 = json.load(open(P, encoding="utf-8"))
assert d2["lines"][1719]["g"] == NEW_G
assert d2["lines"][1719]["roman"] == NEW_R
assert d2["lines"][1719]["en"].strip() and d2["lines"][1719]["pa"].strip()
assert sum(1 for x in d2["lines"] if x["g"] == NEW_G) == 1
print("OK: 131.json line 1719 now reads his Gutka wording; nothing else changed")
