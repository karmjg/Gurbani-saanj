#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.89 - Bhai Gurdas Ji's Vaaran + Salok Kabir/Farid +
reader centring with all toggles OFF + Vaaran kept out of Ask (Karamjit
2026-11-21, "Haan, bana deo"; mockup v289-vaaran-mockup.webp approved).

Exactly 5 changes vs v2.2.88:
  1. Bhai Gurdas Ji's Vaaran (40 Vaars, 913 pauris, 6,446 verse lines)
     added to the catalog (Section 4 "Bhai Gurdas Ji", group 'bhai',
     Bani file 131.json). Reader exactly like Nitnem/other Banis:
     centred lines, Punjabi + English meaning under EACH line, Latin
     transliteration under the Gurmukhi line in search results.
     Searchable by typing first letters AND by voice, like GGS/Banis.
     Text + meanings from the Shabad OS database 4.8.7 (the app's
     EXISTING bundled scripture source, MIT; Gurmukhi text is Public
     Domain Mark 1.0, printed source Ashok & Chakar, 'Varan Giaan
     Ratnaavli Bhai Gurdaas Ji', SGPC Nov 2011; English by Dr. Jodh
     Singh, Punjabi by Bhai Vir Singh - the DB marks translations as
     subject to their respective source copyrights). Vaar 41 (a
     different, later Gurdas) is EXCLUDED - 40 Vaars only. Latin
     transliteration is deterministic gurmukhi-utils toEnglish, the
     same library the app already uses for its Roman. Gurmukhi is
     marker-free like every other Bani/Ang line (vishraam markers
     ; , . stripped; Roman keeps them). Pauri-final "।N।" -> "॥N॥"
     so the reader's paragraph breaks work at pauri ends.
     The user's quoted line is at Vaar 10, Pauri 9, line 5 - confirmed
     in this text - but NOTE: this edition's wording differs from his
     Gutka ("ਦੂਰਹੁ ਦੇਖਿ ਡੰਡਉਤਿ ਕਰਿ; ਛਡਿ ਸਿੰਘਾਸਣੁ ਹਰਿ ਜੀ ਆਏ ।" vs
     his "ਦੂਰਹੁ ਦੇਖਿ ਦੰਡਉਤ ਕਰਿ ਹਰਿ ਜੀਉ ਸਿੰਘਾਸਣੁ ਛਾਡਿ ਆਇਆ ॥").
     Cross-checked against the searchgurbani backend API: same 913
     pauris in the same order; 90.2% of lines identical after light
     normalisation, the rest single-word spelling variants.
  2. Salok Kabir Ji (Bani file 132.json, 494 lines) added to the
     catalog, Section 1 (SGGS Banis). Text + meanings from the app's
     OWN Ang data (Ang 1364-1377, Shabad OS 4.8.7 corpus); BaniDB
     /v2/banis/77 used only for line selection and section boundaries
     (488 exact matches, 2 joined verses split into their 2 Ang
     lines, 2 spelling variants, 1 page-boundary move, mangal +
     title heading constructed like 115.json).
  3. Salok Baba Farid Ji (Bani file 133.json, 297 lines) added to
     the catalog, Section 1. Same method (Ang 1377-1384, BaniDB
     /v2/banis/78; 293 exact, 1 spelling variant, 1 page-boundary
     move, mangal + title heading constructed).
  4. Bani reader (Nitnem + all Banis, incl. the 3 new ones) AND the
     Kirtan shabad reader now stay CENTRED even when transliteration
     and translations are ALL OFF (Karamjit 2026-11-21, Ang 261
     Kirtan photo: lines were left-aligned with everything OFF, and
     he confirmed "Hanji" - centred even then). The v2.2.4
     left-align rule is REMOVED; the base rule already centres every
     pankti. Colours and layer visibility are UNCHANGED: Gurmukhi
     stays black when OFF, Roman is orange only when
     transliteration is ON, English/Punjabi layers show only when
     their toggles are ON. The SGGS Ang reader ("View full Ang",
     already centred) and search-results layout are untouched.
  5. Vaaran kept OUT of Ask/AI answers: the Ask retrieval now drops
     Bani matches from group 'bhai' (main query AND the topic
     bridge), so the AI is only ever sent SGGS + Dasam Granth
     passages, as its rule requires. The Vaaran stays fully
     searchable in the Search screen - only Ask is filtered. No
     worker change (the system prompt already says SGGS + Dasam
     only); the filter is app-side.
Also (part of change 1): two new isBaniHeading rules for the Vaaran's
section headings - "ਵਾਰ N ॥" (40x) and the numbered "ਪਉੜੀ N ॥"
(738x) - exact-match only, so no existing verse line is affected.
Keeps: Kirtan Aa bar back on back-button return (v2.2.88), AI answer
22px (v2.2.87), Sahaj/GGS two positions (v2.2.86), highlight stays
centered (v2.2.84), search Gurmukhi + Latin only (v2.2.83), Ask
buttons (v2.2.82), search keep-place + highlight (v2.2.81), mic 30s
+ dead-start retry (v2.2.79), no beep, music keeps playing, offline.
The mic is NOT touched in this build.
No audio in this build (Play Store build); no Ang changes, saved
verses unaffected. No worker change.
Supersedes v2.2.88 (GSv308.zip) - do NOT upload GSv308 for this
release, upload GSv309 instead. (GSv308 was uploaded 2026-11-20
and its AAB run succeeded; v2.2.89 replaces it.)
After running this script, regenerate the search index with:
  node scripts/build-bani-search.mjs
then run test-v289.mjs (working copy AND extracted zip).
"""
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_289 = (" v2.2.89: three new Banis, plus centred reading with "
            "everything off. (1) Bhai Gurdas Ji's Vaaran - all 40 Vaars "
            "(913 pauris) in the Sundar Gutka list, under 'Bhai Gurdas "
            "Ji', with Punjabi + English meanings under each line; "
            "searchable by typing first letters and by voice, like the "
            "other Banis. (2) Salok Kabir Ji and (3) Salok Baba Farid Ji "
            "in the Sri Guru Granth Sahib Ji Banis list. (4) Bani and "
            "Kirtan lines now stay centred even when transliteration "
            "and translations are all OFF - before, they went "
            "left-aligned with everything OFF. Colours are unchanged: "
            "Gurmukhi stays black when OFF, Roman is orange only when "
            "transliteration is ON. (5) The Vaaran is kept out of Ask/AI "
            "answers - AI answers still come only from Sri Guru Granth "
            "Sahib Ji and Dasam Granth. Vaaran text from the Shabad OS "
            "database (the app's existing scripture source); Kabir/Farid "
            "text from the app's own Angs. No audio in this build (Play "
            "Store build); no Ang changes, saved verses unaffected. The "
            "mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- Bani files must already exist (built by vaaran-build/) ----
    for bid, want in ((131, 7226), (132, 494), (133, 297)):
        d = load(f'www/offline/bani/{bid}.json')
        assert len(d['lines']) == want, f'bani {bid}: {len(d["lines"])} lines, want {want}'
        assert all(isinstance(l[k], str) for l in d['lines']
                   for k in ('id', 'g', 'en', 'pa', 'roman')), f'bani {bid}: non-string field'
        assert all(l['g'] and l['roman'] for l in d['lines']), f'bani {bid}: empty g/roman'
        assert len({l['id'] for l in d['lines']}) == want, f'bani {bid}: duplicate ids'
    print('Bani files 131/132/133 verified (7226 + 494 + 297 lines)')

    # ---- change 1-3a: catalog entries ----
    cat_path = ROOT / 'www/catalog.js'
    cat = cat_path.read_text(encoding='utf-8')
    assert '"id": 131' not in cat and '"id": 132' not in cat and '"id": 133' not in cat, \
        'catalog already has the new entries'
    assert cat.count('"group": "sggs"') == 13, 'sggs entry count changed unexpectedly'
    anchor_sggs = '''  {
    "id": 127,
    "group": "sggs",
    "titlePa": "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ",
    "titleEn": "Sri Guru Granth Sahib Ji de Paath de Bhog de Salok"
  },'''
    assert cat.count(anchor_sggs) == 1, 'sggs anchor not found exactly once'
    cat = cat.replace(anchor_sggs, anchor_sggs + '''
  {
    "id": 132,
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਕਬੀਰ ਜੀ",
    "titleEn": "Salok Kabir Ji"
  },
  {
    "id": 133,
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਬਾਬਾ ਫਰੀਦ ਜੀ",
    "titleEn": "Salok Baba Farid Ji"
  },''', 1)
    anchor_bhai = '''  {
    "id": 107,
    "group": "tradition",
    "titlePa": "ਰਹਰਾਸਿ ਸਾਹਿਬ (ਸੰਖੇਪ)",
    "titleEn": "Rehras Sahib (Short)"
  }
];'''
    assert cat.count(anchor_bhai) == 1, 'bhai anchor not found exactly once'
    cat = cat.replace(anchor_bhai, '''  {
    "id": 107,
    "group": "tradition",
    "titlePa": "ਰਹਰਾਸਿ ਸਾਹਿਬ (ਸੰਖੇਪ)",
    "titleEn": "Rehras Sahib (Short)"
  },
  {
    "id": 131,
    "group": "bhai",
    "titlePa": "ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ",
    "titleEn": "Bhai Gurdas Ji's Vaaran"
  }
];''', 1)
    cat_path.write_text(cat, encoding='utf-8')
    print('Catalog: 132/133 added to sggs, 131 added to bhai (23 entries)')

    # ---- change 1-3b: manifest (baniCount + banis + sources) ----
    man_path = ROOT / 'www/offline/manifest.json'
    raw = man_path.read_text(encoding='utf-8')
    man = json.loads(raw)
    assert man['baniCount'] == 29, f"manifest baniCount is {man['baniCount']}"
    assert [b['id'] for b in man['banis']] and 131 not in [b['id'] for b in man['banis']]
    man['baniCount'] = 32
    man['banis'] = man['banis'] + [
        {"id": 131, "titlePa": "ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ",
         "titleEn": "Bhai Gurdas Ji's Vaaran"},
        {"id": 132, "titlePa": "ਸਲੋਕ ਕਬੀਰ ਜੀ", "titleEn": "Salok Kabir Ji"},
        {"id": 133, "titlePa": "ਸਲੋਕ ਬਾਬਾ ਫਰੀਦ ਜੀ",
         "titleEn": "Salok Baba Farid Ji"},
    ]
    man['sources'] = man['sources'] + [
        {"name": "Shabad OS database 4.8.7 - Vaaran Bhai Gurdas Ji",
         "url": "https://github.com/shabados/database",
         "license": "Gurmukhi text: Public Domain Mark 1.0; translations "
                    "(Dr. Jodh Singh English, Bhai Vir Singh Punjabi): "
                    "respective source copyrights - see Shabad OS licensing",
         "usedFor": "Bhai Gurdas Ji's Vaaran (40 Vaars, 913 pauris, "
                    "6,446 verse lines) + per-line English/Punjabi "
                    "meanings; Latin transliteration via gurmukhi-utils"},
        {"name": "BaniDB API v2 (banis 77/78) - line selection only",
         "url": "https://api.banidb.com/v2/banis/77",
         "license": "MIT (API codebase)",
         "usedFor": "Salok Kabir Ji / Salok Baba Farid Ji line selection "
                    "and section boundaries; all verse text and meanings "
                    "resolved from the bundled SGGS corpus (Shabad OS 4.8.7)"},
    ]
    out = json.dumps(man, ensure_ascii=False)
    if raw.endswith('\n'):
        out += '\n'
    man_path.write_text(out, encoding='utf-8')
    print('Manifest: baniCount 29 -> 32, 3 banis + 2 sources added')

    # ---- change 1c: Vaaran heading rules ----
    rv_path = ROOT / 'www/render-verses.js'
    rv = rv_path.read_text(encoding='utf-8')
    old_pauri = "if(/^ਪਉੜੀ\\s*॥$/.test(t))return true;"
    assert rv.count(old_pauri) == 1, 'bare pauri heading rule not found exactly once'
    assert "if(/^ਵਾਰ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;" not in rv
    assert "if(/^ਪਉੜੀ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;" not in rv
    rv = rv.replace(old_pauri, old_pauri + '''
// v2.2.89: Vaaran headings - "ਵਾਰ N ॥" (the Vaar heading) and the numbered
// "ਪਉੜੀ N ॥" (the Pauri heading, e.g. "ਪਉੜੀ ੯ ॥") from Bhai Gurdas Ji's
// Vaaran (Bani 131, Shabad OS database 4.8.7). EXACT match only: no verse
// line is ever just "ਵਾਰ N ॥" or "ਪਉੜੀ N ॥". Audit of ALL Bani lines:
// exactly the 40 Vaar headings + 738 Pauri headings match, all in 131.
if(/^ਵਾਰ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;
if(/^ਪਉੜੀ\\s*[੦-੯0-9]+\\s*॥$/.test(t))return true;''', 1)
    rv_path.write_text(rv, encoding='utf-8')
    print('Heading rules: Vaar + numbered Pauri added')

    # ---- change 4: remove the v2.2.4 left-align rule (centring, all OFF) ----
    css_path = ROOT / 'www/styles.css'
    css = css_path.read_text(encoding='utf-8')
    old_left = ('/* v2.2.4: Bani panktis left-aligned like Sundar Gutka (was centered). '
                'Headings keep center via .gs-verse-heading. */\n'
                'html.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}')
    assert css.count(old_left) == 1, 'v2.2.4 left-align rule not found exactly once'
    new_centre = ('/* v2.2.89: Bani + Kirtan panktis stay CENTRED even with transliteration\n'
                  ' * and translations all OFF (Karamjit 2026-11-21, Ang 261 Kirtan photo:\n'
                  ' * the lines were left-aligned with everything OFF). The v2.2.4\n'
                  ' * left-align rule is REMOVED - the base rule above already centres\n'
                  ' * every pankti, so Bani and Kirtan now centre in all toggle states.\n'
                  ' * Colours and layer visibility are unchanged: Gurmukhi stays black\n'
                  ' * when OFF, Roman is orange only under .gs-translit-on, layers show\n'
                  ' * only when their toggles are ON. The SGGS Ang reader and search\n'
                  ' * results are untouched. */')
    css = css.replace(old_left, new_centre, 1)
    css_path.write_text(css, encoding='utf-8')
    print('Centring: v2.2.4 left-align rule removed (base rule centres all panktis)')

    # ---- change 5: Vaaran out of Ask/AI (app.js Ask retrieval) ----
    app_path = ROOT / 'www/app.js'
    app = app_path.read_text(encoding='utf-8')
    old_main = "  const mainMatches=await window.GS_SCRIPTURE_SEARCH.query(q,12);"
    assert app.count(old_main) == 1, 'Ask mainMatches line not found exactly once'
    new_main = ("  // v2.2.89: Vaaran (Bhai Gurdas Ji, group 'bhai') is searchable in Search\n"
                "  // but is NEVER sent to Ask/AI - AI answers come only from Sri Guru Granth\n"
                "  // Sahib Ji and Dasam Granth Banis.\n"
                "  const mainMatches=(await window.GS_SCRIPTURE_SEARCH.query(q,12))"
                ".filter(m=>!(m.src==='bani'&&m.group==='bhai'));")
    app = app.replace(old_main, new_main, 1)
    old_extra = "  try{const extra=await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word');"
    assert app.count(old_extra) == 1, 'Ask topic-bridge line not found exactly once'
    new_extra = ("  try{const extra=(await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word'))"
                 ".filter(m=>!(m.src==='bani'&&m.group==='bhai'));")
    app = app.replace(old_extra, new_extra, 1)
    app_path.write_text(app, encoding='utf-8')
    print('Ask: Vaaran (group bhai) filtered from main + topic-bridge retrieval')

    # ---- asserts: the changes are in place, nothing else moved ----
    cat = cat_path.read_text(encoding='utf-8')
    assert cat.count('"id": 131') == 1 and cat.count('"id": 132') == 1 and cat.count('"id": 133') == 1
    assert '"group": "bhai"' in cat and cat.count('"group": "sggs"') == 15
    assert '"group": "dasam"' in cat and '"group": "tradition"' in cat
    man = load('www/offline/manifest.json')
    assert man['baniCount'] == 32 and len(man['banis']) == 32
    assert [b['id'] for b in man['banis']][-3:] == [131, 132, 133]
    assert 'Shabad OS database 4.8.7 - Vaaran Bhai Gurdas Ji' in json.dumps(man['sources'], ensure_ascii=False)
    assert 'BaniDB API v2 (banis 77/78)' in json.dumps(man['sources'], ensure_ascii=False)
    # Heading rules classify exactly the new Vaaran headings, nothing else.
    vaar_h = pauri_h = 0
    for f in (ROOT / 'www/offline/bani').glob('*.json'):
        for l in load(f'www/offline/bani/{f.name}')['lines']:
            g = l['g']
            if re.fullmatch(r'ਵਾਰ [੦-੯0-9]+ ॥', g):
                vaar_h += 1
                assert f.name == '131.json', f'vaar heading outside 131: {f.name}'
            if re.fullmatch(r'ਪਉੜੀ [੦-੯0-9]+ ॥', g):
                pauri_h += 1
                assert f.name == '131.json', f'pauri heading outside 131: {f.name}'
    assert vaar_h == 40, f'vaar headings: {vaar_h}, want 40'
    assert pauri_h == 738, f'pauri headings: {pauri_h}, want 738'
    # No Bani/Ang line carries vishraam markers in its Gurmukhi.
    for bid in (131, 132, 133):
        for l in load(f'www/offline/bani/{bid}.json')['lines']:
            assert not any(c in l['g'] for c in ';,.') , f'bani {bid}: marker in g: {l["g"][:40]}'
    # CSS: left-align gone, base centre + translit/layers rules untouched.
    css = css_path.read_text(encoding='utf-8')
    assert 'html.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}' not in css, \
        'v2.2.4 left-align rule still present'
    assert 'html.reading-open #verses .gs-pankti{display:block!important;max-width:100%;margin:0!important;padding:0!important;text-align:center;' in css, \
        'base centre rule missing'
    assert 'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;' in css, \
        'orange Roman rule changed'
    assert 'html.reading-open .gs-reader-sggs #verses .gs-pankti{line-height:var(--leading)!important;}' in css, \
        'SGGS rule changed'
    # Ask filter present; the Search screen is NOT filtered (Vaaran stays searchable).
    app = app_path.read_text(encoding='utf-8')
    assert app.count(".filter(m=>!(m.src==='bani'&&m.group==='bhai'))") == 2, 'Ask bhai filter count wrong'
    assert "const mainMatches=await window.GS_SCRIPTURE_SEARCH.query(q,12);" not in app
    assert "const extra=await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word');" not in app
    # Carry-forwards: v2.2.88, v2.2.87, v2.2.86, v2.2.79.
    assert "if(nv==='reader')showReaderBar();" in app, 'v2.2.88 popstate fix missing'
    assert "(kind==='bani'||kind==='kirtan')&&state.showTranslit" in app, 'v2.2.88 kirtan classes missing'
    assert '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}' in css, 'v2.2.87 font fix missing'
    assert 'if(extra.gg)state.ggAng=Number(id);' in app, 'v2.2.86 ggAng missing'
    assert 'deadStartRetries<1' in app, 'v2.2.79 dead-start retry missing'
    assert "onError" in (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8'), 'v2.2.79 plugin patch missing'
    print('v2.2.89 changes verified')

    # ---- version bump 2.2.88 -> 2.2.89 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.88', f"version.json is {vj['version']}"
    assert 'v2.2.88:' in vj['notes'], 'version notes do not contain v2.2.88'
    vj['notes'] = vj['notes'] + NOTE_289
    vj['version'] = '2.2.89'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.88"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.88"', '"version": "2.2.89"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.88"' in nbc, 'native-build-config.js is not 2.2.88'
    assert nbc.count('2.2.88') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.88"', '"version":"2.2.89"'),
        encoding='utf-8')
    print('version bump 2.2.88 -> 2.2.89 done')


if __name__ == '__main__':
    main()
