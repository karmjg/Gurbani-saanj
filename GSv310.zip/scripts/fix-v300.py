#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.80 - Ask AI follows the question's language, and
verses show Gurmukhi + Latin (Karamjit 2026-11-19, with two photos).

PHOTO 1 (Ask screen): he asked in English - "What is hukam?" - with the
English pill selected, but the whole AI answer came back in Punjabi
(intro, "bhaav ate viakhia", explanation). And each quoted verse was in
Gurmukhi ONLY, with no Latin form below it.
PHOTO 2 (Search screen): a search for "tudh jevad na" - results show the
Gurmukhi lines with the English MEANING below. For Ask, he does NOT want
the English meaning; he wants the Latin (Roman) form - how the line is
pronounced/written in English letters, same as Roman search.

His rule: ask in English -> answer in English; ask in Punjabi -> answer
in Punjabi. Each Bani line: Gurmukhi + Latin below it. NO English
translation/meaning of the line. The explanation is in the question's
language.

Exactly these changes vs v2.2.79 (app) + the worker:
  APP (www/app.js):
  1. NEW aiQuestionLang(q): Gurmukhi script in the question -> 'pa',
     Latin letters -> 'en'. (A Roman-Punjabi question reads as English,
     since its letters are English.) The Ask call now sends
     language:aiQuestionLang(q) to the cloud worker (was state.aiLang,
     the toggle/app language), and askOpenAI answers in the question's
     language too. So the answer follows the QUESTION.
  2. entry.matches now carries roman:m.roman||'' for Ang AND Bani
     matches (the search index already has it per line), so the AI
     receives the Latin form of every verse.
  3. AI_SYSTEM_PROMPT + askOpenAI context: each quoted verse is shown
     as Gurmukhi (exact) then the same verse in Latin (Roman) letters
     exactly as given in the 'roman' field; the verse is NOT translated
     into English. The Latin is the pronunciation, not a translation.
  4. The AI-language pills (pa/en) are REMOVED from the Ask screen -
     they set state.aiLang, which no longer decides the answer language,
     so leaving them would lie about what they control. The question
     decides now.
  WORKER (ai-server/cloudflare-worker.mjs + top-level worker.js):
  5. Verses mapping accepts roman (both bani and sggs).
  6. Prompt updated the same way: Gurmukhi + Latin per verse, no
     English translation of the verse, Latin is pronunciation only.
     The worker still answers in body.language, which the app now sets
     from the question. The worker MUST be redeployed (paste worker.js
     into the Cloudflare dashboard and Deploy) - the app update alone
     does not change the live cloud AI.
  Keeps: one session per tap, 30s mic stretches, mic-stop on leaving
  the page, beep muted, music keeps playing, offline. No audio (Play
  Store build). No Bani or Ang changes; no lines added or removed,
  saved verses unaffected. Supersedes v2.2.79 (GSv299.zip) - do NOT
  upload GSv299, upload GSv300 instead.

Run from the repo root (pristine v2.2.79 in /tmp/v300-rollback):
  python3 scripts/fix-v300.py
Then: node test-v300.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_280 = (" v2.2.80: Ask AI follows the question's language, and verses "
            "show Gurmukhi + Latin. Ask in English -> the answer is in "
            "English; ask in Punjabi -> the answer is in Punjabi (before, "
            "the answer followed the app language / toggle, so an English "
            "question got a Punjabi answer). Each quoted verse now shows "
            "in Gurmukhi and, below it, in Latin (Roman) letters - how "
            "the line is pronounced - exactly as given; the verse is NOT "
            "translated into English. The AI-language pills are removed "
            "from the Ask screen (the question decides the language now). "
            "The cloud Worker must also be redeployed with the updated "
            "worker.js (paste into the Cloudflare dashboard and Deploy) - "
            "the app update alone does not change the live cloud AI. Also: "
            "Ask answers elaborate a little more at the Detailed level - "
            "each verse gets a fuller explanation (its meaning and why it "
            "matters in daily life), with more room for it (detail output "
            "900 -> 1200 tokens). No "
            "audio in this build (Play Store build); no Bani or Ang "
            "changes, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.79 -> 2.2.80 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.79', f"version.json is {vj['version']}"
    assert 'v2.2.79:' in vj['notes'], 'version notes do not contain v2.2.79'
    vj['notes'] = vj['notes'] + NOTE_280
    vj['version'] = '2.2.80'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.79"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.79"', '"version": "2.2.80"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.79"' in nbc, 'native-build-config.js is not 2.2.79'
    assert nbc.count('2.2.79') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.79"', '"version":"2.2.80"'),
        encoding='utf-8')
    print('version bump 2.2.79 -> 2.2.80 done')

    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')

    # ---- 1. Question-language detector ----
    assert "const aiQuestionLang=q=>/[\\u0A00-\\u0A7F]/.test(String(q||''))?'pa':'en';" in app, 'aiQuestionLang missing'
    assert 'v2.2.80: the AI answer follows the QUESTION' in app, 'aiQuestionLang comment missing'
    print('aiQuestionLang detector present')

    # ---- 2. Cloud call sends the question language, not the toggle ----
    assert 'language:aiQuestionLang(q)' in app, 'cloud call does not send the question language'
    assert 'language:state.aiLang' not in app, 'cloud call still sends state.aiLang'
    print('cloud AI call sends the question language')

    # ---- 3. matches carry roman (Ang + Bani) ----
    assert "roman:m.roman||''" in app, 'matches do not carry roman'
    assert app.count("roman:m.roman||''") == 2, 'roman must be in BOTH the Bani and the Ang match mapping'
    print('matches carry roman (Ang + Bani)')

    # ---- 4. AI prompts: Gurmukhi + Latin, no English translation ----
    assert "then write the same verse in Latin (Roman) letters exactly as given in the" in app, 'AI_SYSTEM_PROMPT lacks the Latin rule'
    assert 'Do NOT translate the verse into English; the Latin form is how the verse is pronounced, not a translation.' in app, 'AI_SYSTEM_PROMPT lacks the no-translation rule'
    assert "Answer in ${aiQuestionLang(question)==='en'?'English':'Punjabi'}" in app, 'askOpenAI does not answer in the question language'
    assert "head+' '+m.g+(m.roman?'\\n'+m.roman:'')" in app, 'askOpenAI context does not include roman'
    print('AI prompts quote Gurmukhi + Latin, no English translation')

    # ---- 5. AI-language pills removed from the Ask screen ----
    assert 'ai-lang-pills' not in app, 'ai-lang-pills markup still present'
    # data-ai-lang appears only in the (now dead) click handler line - both
    # occurrences are on that one line; no pill markup renders it anymore.
    assert app.count('data-ai-lang') == 2, 'data-ai-lang appears somewhere other than the dead handler'
    assert 'AI ਜਵਾਬ ਦੀ ਭਾਸ਼ਾ' not in app, 'AI answer language label still present'
    print('AI-language pills removed from the Ask screen')

    # ---- 6. Mic (v2.2.79) untouched ----
    assert 'run.segStartedAt=Date.now();' in app, 'v2.2.79 segStartedAt missing'
    assert 'let deadStartRetries=0;' in app, 'v2.2.79 dead-start retry missing'
    assert 'armSegGuard(30000);' in app, 'app guard is not 30s'
    assert "if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();" in app, 'popstate mic-stop missing'
    print('mic v2.2.79 fixes + 30s + mic-stop untouched')

    # ---- 7. Worker (in-repo copy) ----
    worker = (ROOT / 'ai-server/cloudflare-worker.mjs').read_text(encoding='utf-8')
    assert "const roman=String(v.roman||'').slice(0,480);" in worker, 'worker does not accept roman'
    assert 'g,roman}' in worker, 'worker verse objects lack roman'
    assert "then write the same verse in Latin (Roman) letters exactly as given in the" in worker, 'worker prompt lacks the Latin rule'
    assert 'Do NOT translate the verse into English; the Latin form is the pronunciation, not a translation.' in worker, 'worker prompt lacks the no-translation rule'
    assert "Do not add any other pronunciation guidance beyond the supplied Latin form." in worker, 'worker still bans pronunciation guidance outright'
    assert "const language=body?.language==='pa'?'Punjabi (Gurmukhi)':'English';" in worker, 'worker language line changed (must stay - the app now sends the question language)'
    # ---- 6b. Ask answers elaborate a little more (Detailed level) ----
    assert "take a little more time on each verse: its meaning, and why it matters in daily life." in worker, 'worker detail level does not ask for a fuller explanation'
    assert "depth==='detail'?1200:1500" in worker, 'worker detail tokens not raised to 1200'
    assert "take a little more time on each verse: its meaning, and why it matters in daily life." in app, 'askOpenAI detail level does not ask for a fuller explanation'
    assert 'max_tokens:1200' in app, 'askOpenAI max_tokens not raised to 1200'
    print('worker accepts roman + quotes Gurmukhi + Latin')
    print('Ask answers elaborate a little more at the Detailed level')

    # ---- 8. No audio, no player (Play Store build) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')


if __name__ == '__main__':
    main()
