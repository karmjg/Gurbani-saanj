#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.81 - search keeps its place + highlight, reader keeps
its found-line highlight (Karamjit 2026-11-19, after the v2.2.80 mockups).

His words: when we search a word, then go to its meaning, or go into
Settings and change the English/Punjabi translation, then come back, it is
not at the exact same place - it changes. It should be exactly at that
same place, so when we come back we know "this was my word". And: keep
its highlight - when we go to Settings and come back, the highlight on
the searched word gets erased.

Exactly these changes vs v2.2.80:
  1. Search restores itself on return. The last main-search query, its
     scroll place, and the result last opened are remembered (module
     state, not persisted - a fresh app open still starts empty). When
     the search screen re-renders (back from the reader, back from
     Settings, bottom-nav), the query is put back in the box, the
     search re-runs, and the scroll is restored to the exact pixel it
     was at. The scroll is saved on every leave path: go() and the
     back-button (popstate) handler.
  2. The opened result stays highlighted in the search list. The row
     of the result last opened (under the same query) gets the same
     pale-yellow highlight as the reader's found line
     (.gs-result-row.gs-opened), so coming back shows which line it
     was. Clearing the search (X) clears the highlight too.
  3. The reader keeps its found-line highlight across Settings. go()
     used to reset highlightLine on EVERY navigation away from the
     reader - including to Bani View Preferences - so coming back from
     a translation change erased the yellow highlight. Now it is kept
     when the destination is viewprefs (a settings page you return
     from). The reader's scroll anchor is also captured on leaving
     the reader (captureAnchor in go()), so the position restores
     through the existing v2.2.55 anchor.
  4. The raag + English fills are awaited inside showOfflineResults
     (fillRaagHeaders / fillResultEn now return promises), so the
     result rows are at their final height before any scroll restore
     reads the layout. Before, the fills landed after the render and
     grew the rows, shifting the restored place.
Keeps: one session per tap, 30s mic stretches, mic-stop on leaving the
page, beep muted, music keeps playing, offline, Ask language + Latin
(v2.2.80). No audio in this build (Play Store build); no Bani or Ang
changes, saved verses unaffected. Supersedes v2.2.80 (GSv300.zip) - do
NOT upload GSv300, upload GSv301 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_281 = (" v2.2.81: search keeps its place and its highlight. Coming "
            "back to search (from a result's meaning, or from Settings) "
            "restores the same query, the same results, and the exact "
            "scroll place it was at - instead of an empty list at the "
            "top - and the result last opened stays highlighted yellow "
            "in the list, so you know which line it was. The reader "
            "also keeps its found-line highlight when you change the "
            "English/Punjabi translation in Settings and come back "
            "(before, going to Bani View Preferences erased it). No "
            "audio in this build (Play Store build); no Bani or Ang "
            "changes, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def rep(text, old, new, label):
    assert text.count(old) == 1, f"{label}: anchor found {text.count(old)}x (want 1)"
    return text.replace(old, new, 1)


def main():
    # ---- version bump 2.2.80 -> 2.2.81 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.80', f"version.json is {vj['version']}"
    assert 'v2.2.80:' in vj['notes'], 'version notes do not contain v2.2.80'
    vj['notes'] = vj['notes'] + NOTE_281
    vj['version'] = '2.2.81'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.80"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.80"', '"version": "2.2.81"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.80"' in nbc, 'native-build-config.js is not 2.2.80'
    assert nbc.count('2.2.80') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.80"', '"version":"2.2.81"'),
        encoding='utf-8')
    print('version bump 2.2.80 -> 2.2.81 done')

    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')

    # ---- 1. Search state + saveSearchPlace ----
    app = rep(app,
        "let searchSeq=0;",
        "let searchSeq=0;\n"
        "// v2.2.81: remember the last main-search query, its scroll place, and\n"
        "// the result last opened - so coming back to search restores the same\n"
        "// list at the same place, with the opened result still highlighted.\n"
        "// Module-level, not persisted: a fresh app open starts empty, as before.\n"
        "let lastSearchQuery='';\n"
        "let lastSearchScroll=0;\n"
        "let lastOpenedKey='';\n"
        "let lastOpenedQuery='';\n"
        "function saveSearchPlace(){if(state.view==='search')lastSearchScroll=window.scrollY;}",
        'search state')
    print('search state added')

    # ---- 2. showOfflineResults: record query, clear on empty, await fills ----
    app = rep(app,
        " if(!q.trim()){out.innerHTML='';return}",
        " if(!q.trim()){out.innerHTML='';if(target==='searchResults')lastSearchQuery='';return}\n"
        " if(target==='searchResults')lastSearchQuery=q;",
        'showOfflineResults query record')
    app = rep(app,
        "  fillRaagHeaders($(target));fillResultEn($(target));",
        "  // v2.2.81: await the raag + English fills, so the rows are at their\n"
        "  // final height before any scroll restore reads the layout.\n"
        "  await fillRaagHeaders($(target));await fillResultEn($(target));",
        'showOfflineResults await fills')
    print('showOfflineResults records query + awaits fills')

    # ---- 3. fillRaagHeaders / fillResultEn return promises ----
    app = rep(app,
        "function fillRaagHeaders(scope){\n"
        " scope.querySelectorAll('[data-raag-for]').forEach(async el=>{\n"
        "  const [a,i]=String(el.dataset.raagFor).split(':').map(Number);\n"
        "  const raag=await raagFor(a,i);\n"
        "  el.innerHTML=`${raag?`<span class=\"gs-raag\" lang=\"pa\">${esc(raag)}</span><span class=\"gs-raag-sep\"> · </span>`:''}<span>${age('ਅੰਗ','Ang')} ${a}</span>`;\n"
        " });\n"
        "}",
        "function fillRaagHeaders(scope){\n"
        " return Promise.all([...scope.querySelectorAll('[data-raag-for]')].map(async el=>{\n"
        "  const [a,i]=String(el.dataset.raagFor).split(':').map(Number);\n"
        "  const raag=await raagFor(a,i);\n"
        "  el.innerHTML=`${raag?`<span class=\"gs-raag\" lang=\"pa\">${esc(raag)}</span><span class=\"gs-raag-sep\"> · </span>`:''}<span>${age('ਅੰਗ','Ang')} ${a}</span>`;\n"
        " }));\n"
        "}",
        'fillRaagHeaders promise')
    app = rep(app,
        "function fillResultEn(scope){\n"
        " scope.querySelectorAll('[data-en-for]').forEach(async el=>{\n"
        "  const [a,i]=String(el.dataset.enFor).split(':').map(Number);\n"
        "  const en=await enFor(a,i);\n"
        "  if(en)el.textContent=en; else el.remove();\n"
        " });\n"
        "}",
        "function fillResultEn(scope){\n"
        " return Promise.all([...scope.querySelectorAll('[data-en-for]')].map(async el=>{\n"
        "  const [a,i]=String(el.dataset.enFor).split(':').map(Number);\n"
        "  const en=await enFor(a,i);\n"
        "  if(en)el.textContent=en; else el.remove();\n"
        " }));\n"
        "}",
        'fillResultEn promise')
    print('fills return promises')

    # ---- 4. scriptureResultsMarkup: highlight the opened row ----
    app = rep(app,
        "  return `<div class=\"gs-result-row\"><button class=\"result gs-result-open\" ${open}>",
        "  // v2.2.81: the result last opened (under this same query) stays\n"
        "  // highlighted, so coming back to the list shows which line it was.\n"
        "  const opened=lastOpenedKey===saveKey&&lastOpenedQuery&&lastOpenedQuery===lastSearchQuery;\n"
        "  return `<div class=\"gs-result-row${opened?' gs-opened':''}\"><button class=\"result gs-result-open\" ${open}>",
        'results markup highlight')
    print('results markup highlights the opened row')

    # ---- 5. Click handlers record the opened result ----
    app = rep(app,
        " const found=e.target.closest('[data-found-ang],[data-open-saved-ang]');if(found){stopVoiceSearch();highlightLine=Number(found.dataset.foundIdx||found.dataset.openSavedIdx)||0;openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true);return}",
        " const found=e.target.closest('[data-found-ang],[data-open-saved-ang]');if(found){stopVoiceSearch();highlightLine=Number(found.dataset.foundIdx||found.dataset.openSavedIdx)||0;if(found.dataset.foundAng){lastOpenedKey=`${found.dataset.foundAng}:${highlightLine}`;lastOpenedQuery=lastSearchQuery;}openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true);return}",
        'found-ang records opened')
    app = rep(app,
        " const foundBani=e.target.closest('[data-found-bani],[data-open-saved-bani]');if(foundBani){stopVoiceSearch();highlightLine=Number(foundBani.dataset.foundIdx||foundBani.dataset.openSavedIdx)||0;openBani(Number(foundBani.dataset.foundBani||foundBani.dataset.openSavedBani),foundBani.dataset.baniTitle||'Bani',true);return}",
        " const foundBani=e.target.closest('[data-found-bani],[data-open-saved-bani]');if(foundBani){stopVoiceSearch();highlightLine=Number(foundBani.dataset.foundIdx||foundBani.dataset.openSavedIdx)||0;if(foundBani.dataset.foundBani){lastOpenedKey=`bani:${foundBani.dataset.foundBani}:${highlightLine}`;lastOpenedQuery=lastSearchQuery;}openBani(Number(foundBani.dataset.foundBani||foundBani.dataset.openSavedBani),foundBani.dataset.baniTitle||'Bani',true);return}",
        'found-bani records opened')
    print('click handlers record the opened result')

    # ---- 6. go(): save search place, keep highlight for viewprefs, capture anchor ----
    app = rep(app,
        "function go(view,opts={}){if(view!=='home')homeEditing=false;if(view!=='reader'){highlightLine=-1;readerBarHidden=true;}if(state.view==='reader'&&state.readView==='sggs')capture();closeWord();const oldView=state.view;",
        "function go(view,opts={}){if(view!=='home')homeEditing=false;saveSearchPlace();if(view!=='reader'){readerBarHidden=true;if(view!=='viewprefs')highlightLine=-1;}if(state.view==='reader'){if(state.readView==='sggs')capture();captureAnchor();}closeWord();const oldView=state.view;",
        'go() keep-place + keep-highlight')
    print('go() saves search place + keeps highlight for viewprefs')

    # ---- 7. popstate: save search place ----
    app = rep(app,
        "window.addEventListener('popstate',e=>{if(state.view==='reader'&&state.readView==='sggs')capture();closeWord();closeSettings();",
        "window.addEventListener('popstate',e=>{if(state.view==='reader'&&state.readView==='sggs')capture();saveSearchPlace();closeWord();closeSettings();",
        'popstate saves search place')
    print('popstate saves search place')

    # ---- 8. Clear button clears the remembered search ----
    app = rep(app,
        "  const clear=$('searchClear');if(clear)clear.onclick=()=>{resetVoiceNow();input.value='';$('searchResults').innerHTML='';};",
        "  const clear=$('searchClear');if(clear)clear.onclick=()=>{resetVoiceNow();input.value='';$('searchResults').innerHTML='';lastSearchQuery='';lastOpenedKey='';lastOpenedQuery='';lastSearchScroll=0;};",
        'clear button clears remembered search')
    print('clear button clears the remembered search')

    # ---- 9. attach(): restore the search on return ----
    app = rep(app,
        "  const ih=$('iconHistory');if(ih)ih.onclick=()=>{const box=$('searchHistoryBox');if(box){box.classList.toggle('hidden');if(!box.classList.contains('hidden'))box.innerHTML=searchHistoryBoxHTML()}};\n"
        " }",
        "  const ih=$('iconHistory');if(ih)ih.onclick=()=>{const box=$('searchHistoryBox');if(box){box.classList.toggle('hidden');if(!box.classList.contains('hidden'))box.innerHTML=searchHistoryBoxHTML()}};\n"
        "  // v2.2.81: coming back to search restores the last search at its\n"
        "  // exact place - same query, same results, same scroll - instead\n"
        "  // of an empty list at the top. The fills are awaited inside\n"
        "  // showOfflineResults, so the rows are at their final height\n"
        "  // before the scroll is restored.\n"
        "  if(lastSearchQuery&&!input.value){\n"
        "   input.value=lastSearchQuery;\n"
        "   showOfflineResults(lastSearchQuery,'searchResults',true).then(()=>{\n"
        "    if(state.view==='search'&&$('searchInput')?.value===lastSearchQuery)\n"
        "     window.scrollTo({top:lastSearchScroll,behavior:'instant'});\n"
        "   });\n"
        "  }\n"
        " }",
        'attach() restores search')
    print('attach() restores the search on return')

    (ROOT / 'www/app.js').write_text(app, encoding='utf-8')

    # ---- 10. styles.css: opened-row highlight ----
    css = (ROOT / 'www/styles.css').read_text(encoding='utf-8')
    css = rep(css,
        ".gs-result-row { display: flex; align-items: flex-start; gap: 4px; }\n"
        ".gs-result-row .result { flex: 1; }",
        ".gs-result-row { display: flex; align-items: flex-start; gap: 4px; }\n"
        ".gs-result-row .result { flex: 1; }\n"
        "/* v2.2.81: the search result last opened stays highlighted, so coming\n"
        "   back to the list shows which line it was - same pale yellow as the\n"
        "   reader's found-line highlight, with dark text for contrast in every\n"
        "   theme. */\n"
        ".gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}\n"
        ".gs-result-row.gs-opened .result,.gs-result-row.gs-opened .gs-result-ref,.gs-result-row.gs-opened .gs-result-en,.gs-result-row.gs-opened .gs-result-roman{color:#202a26!important;}",
        'opened-row CSS')
    (ROOT / 'www/styles.css').write_text(css, encoding='utf-8')
    print('opened-row CSS added')

    print('v2.2.81 fix applied')


if __name__ == '__main__':
    main()
