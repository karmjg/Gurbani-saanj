#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.83 - search results show Gurmukhi + Latin ONLY,
no English meaning (Karamjit 2026-11-19, after the v2.2.82 mockups).

His words: "I don't want to see the English meaning I just want to see
a Gurmukhi line plus the Latin that's it. Because once I click the word
then I can go to the setting and ask for translation whatever. So I need
the Gurmukhi line plus the Latin."

Exactly these changes vs v2.2.82:
  1. Search results no longer render an English meaning line. The
     `enHtml` span is removed from scriptureResultsMarkup, so every
     result shows only: the source (Ang N / Bani name), the Gurmukhi
     line, and the Latin (Roman) line underneath it (when
     Transliteration is on). The English meaning is NOT shown in the
     list. (This also affects the Ask screen's "related passages"
     list, which shares scriptureResultsMarkup - those verses now
     show Gurmukhi + Latin only too. The AI answer itself is
     untouched, and the reader still shows translations when the
     user turns them on in Bani View Preferences.)
  2. showOfflineResults no longer calls fillResultEn - there is no
     English span left to fill. fillRaagHeaders is still awaited
     (the Ang/Bani source label stays).
  3. The now-dead fillResultEn() + enFor() helpers are removed.
     enFor was only used by fillResultEn; fillResultEn was only
     called from showOfflineResults. The reader's per-line meanings
     use a different path (render-verses.js) and are untouched.
Keeps: Punjabi/English Ask buttons + button decides the answer
language (v2.2.82), search keep-place + highlight (v2.2.81), reader
highlight across Settings (v2.2.81), verses Gurmukhi + Latin +
Detailed elaboration (v2.2.80), mic 30s + dead-start retry (v2.2.79),
no beep, music keeps playing, offline. The mic is NOT touched in
this build. No audio in this build (Play Store build); no Bani or
Ang changes, saved verses unaffected. No worker change needed.
Supersedes v2.2.82 (GSv302.zip) - do NOT upload GSv302, upload
GSv303 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_283 = (" v2.2.83: search results show only the Gurmukhi line and "
            "the Latin (Roman) line underneath it - the English meaning "
            "is no longer shown in the search list. Tap a result to "
            "open it in the reader, and turn on the translation in "
            "Bani View Preferences there if you want it. No audio in "
            "this build (Play Store build); no Bani or Ang changes, "
            "saved verses unaffected. The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def rep(text, old, new, label):
    assert text.count(old) == 1, f"{label}: anchor found {text.count(old)}x (want 1)"
    return text.replace(old, new, 1)


def main():
    # ---- version bump 2.2.82 -> 2.2.83 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.82', f"version.json is {vj['version']}"
    assert 'v2.2.82:' in vj['notes'], 'version notes do not contain v2.2.82'
    vj['notes'] = vj['notes'] + NOTE_283
    vj['version'] = '2.2.83'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.82"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.82"', '"version": "2.2.83"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.82"' in nbc, 'native-build-config.js is not 2.2.82'
    assert nbc.count('2.2.82') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.82"', '"version":"2.2.83"'),
        encoding='utf-8')
    print('version bump 2.2.82 -> 2.2.83 done')

    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')

    # ---- 1. scriptureResultsMarkup: drop the English line ----
    app = rep(app,
        "  const enHtml=isBani\n"
        "   ?(String(v.en||'').trim()?`<span class=\"gs-result-en\" lang=\"en\">${esc(v.en)}</span>`:'')\n"
        "   :`<span class=\"gs-result-en\" lang=\"en\" data-en-for=\"${v.ang}:${v.idx}\"></span>`;\n",
        "  // v2.2.83: no English meaning in the result list - Gurmukhi line\n"
        "  // + Latin line only. The translation is still available in the\n"
        "  // reader (Bani View Preferences) once the line is opened.\n",
        'drop enHtml variable')
    app = rep(app,
        "  return `<div class=\"gs-result-row${opened?' gs-opened':''}\"><button class=\"result gs-result-open\" ${open}>${ref}<strong lang=\"pa\">${esc(v.g)}</strong>${romanHtml}${enHtml}</button>${save?`<button class=\"favorite\" data-save-hit=\"${saveKey}\" aria-label=\"Save Shabad\">${saved?'♥':'♡'}</button>`:''}</div>`;",
        "  return `<div class=\"gs-result-row${opened?' gs-opened':''}\"><button class=\"result gs-result-open\" ${open}>${ref}<strong lang=\"pa\">${esc(v.g)}</strong>${romanHtml}</button>${save?`<button class=\"favorite\" data-save-hit=\"${saveKey}\" aria-label=\"Save Shabad\">${saved?'♥':'♡'}</button>`:''}</div>`;",
        'drop enHtml from the row')
    print('English line removed from the result markup')

    # ---- 2. showOfflineResults: stop filling English (keep raag fills) ----
    app = rep(app,
        "  // v2.2.81: await the raag + English fills, so the rows are at their\n"
        "  // final height before any scroll restore reads the layout.\n"
        "  await fillRaagHeaders($(target));await fillResultEn($(target));",
        "  // v2.2.81: await the raag fills, so the rows are at their final\n"
        "  // height before any scroll restore reads the layout. (v2.2.83:\n"
        "  // no English fill any more - the list shows Gurmukhi + Latin.)\n"
        "  await fillRaagHeaders($(target));",
        'stop the English fill')
    print('English fill removed from showOfflineResults')

    # ---- 3. remove the now-dead enFor + fillResultEn helpers ----
    app = rep(app,
        "async function enFor(ang,idx){\n"
        " try{\n"
        "  const data=await readAngCached(ang);\n"
        "  return String(data?.lines?.[Number(idx)]?.en||'').trim();\n"
        " }catch{return ''}\n"
        "}\n"
        "function fillResultEn(scope){\n"
        " return Promise.all([...scope.querySelectorAll('[data-en-for]')].map(async el=>{\n"
        "  const [a,i]=String(el.dataset.enFor).split(':').map(Number);\n"
        "  const en=await enFor(a,i);\n"
        "  if(en)el.textContent=en; else el.remove();\n"
        " }));\n"
        "}\n",
        "",
        'remove dead enFor + fillResultEn')
    print('dead enFor + fillResultEn removed')

    (ROOT / 'www/app.js').write_text(app, encoding='utf-8')

    # ---- asserts ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'gs-result-en' not in app, 'gs-result-en still rendered'
    assert 'fillResultEn' not in app, 'fillResultEn still present'
    assert 'enFor(' not in app, 'enFor still present'
    assert 'data-en-for' not in app, 'data-en-for still present'
    assert 'fillRaagHeaders($(target));' in app, 'raag fill lost'
    assert 'romanHtml' in app, 'Latin line lost'
    print('v2.2.83 fix applied')


if __name__ == '__main__':
    main()
