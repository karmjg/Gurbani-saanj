#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.85 - the AI answer (Ask) text is bigger by default:
22px instead of 18px (Karamjit 2026-11-19).

His words: "Is it possible to increase the size of the font - in the
cloud [AI answer]?" Then: "Pinch doesn't work" and "A minus A plus we
also tried that it never worked that too."

The font size is set in the APP (state.aiFont, CSS --ai-font), NOT in
the cloud worker - the cloud only sends the answer words. So this is an
app build, not a worker change. No worker change needed.

Exactly these changes vs v2.2.84:
  1. AI answer font default 18px -> 22px. BASE.aiFont is now 22, the
     CSS fallback is 22px, and every `||18` fallback for aiFont is now
     `||22` (init, theme(), pinchFont, touch handlers, ai-zoom handler).
  2. One-time migration: a stored aiFont of exactly 18 (the old
     default) becomes 22 on load. Pinch never worked on his phone and
     the A-/A+ buttons were never rendered, so 18 could never have
     been deliberately set - without this, his phone would keep the
     stored 18 and the new default would never show. A deliberately
     set size (anything other than 18) is untouched. The mic is NOT
     touched. No audio in this build (Play Store build); no Bani or
     Ang changes, saved verses unaffected. No A-/A+ buttons added -
     he tried them before and they did not work, and he is unsure
     whether he wants them.
Supersedes v2.2.84 (GSv304.zip) - do NOT upload GSv304, upload
GSv305 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_285 = (" v2.2.85: the AI answer (Ask) text is bigger by default - "
            "22px instead of 18px. Pinch-to-zoom does not work on "
            "Karamjit's phone and the A-/A+ buttons were tried before "
            "and did not work, so the size is now just bigger when the "
            "app opens - no gesture or button needed. No audio in this "
            "build (Play Store build); no Bani or Ang changes, saved "
            "verses unaffected. The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.84 -> 2.2.85 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.84', f"version.json is {vj['version']}"
    assert 'v2.2.84:' in vj['notes'], 'version notes do not contain v2.2.84'
    vj['notes'] = vj['notes'] + NOTE_285
    vj['version'] = '2.2.85'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.84"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.84"', '"version": "2.2.85"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.84"' in nbc, 'native-build-config.js is not 2.2.84'
    assert nbc.count('2.2.84') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.84"', '"version":"2.2.85"'),
        encoding='utf-8')
    print('version bump 2.2.84 -> 2.2.85 done')

    # ---- asserts: the 22px default + migration are in place ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'aiFont:22' in app, 'BASE.aiFont is not 22'
    assert "if(state.aiFont===18)state.aiFont=22;" in app, 'migration missing'
    assert "(Number(state.aiFont)||22)" in app, 'init/theme fallback not 22'
    assert 'aiFont:18' not in app, 'an 18px aiFont default remains'
    assert '(Number(startFont)||22)' in app, 'pinchFont fallback not 22'
    css = (ROOT / 'www/styles.css').read_text(encoding='utf-8')
    assert 'font-size:var(--ai-font,22px)' in css, 'CSS fallback not 22px'
    assert 'font-size:var(--ai-font,18px)' not in css, 'old CSS fallback remains'
    # No A-/A+ buttons added in this build.
    assert 'data-ai-zoom=' not in app, 'an A-/A+ button was added (not wanted)'
    print('v2.2.85 fix applied')


if __name__ == '__main__':
    main()
