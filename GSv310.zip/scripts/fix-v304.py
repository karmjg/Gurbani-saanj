#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.84 - the yellow highlighted (found) line stays in
the MIDDLE of the screen when coming back from Settings (Karamjit
2026-11-19).

His words: "when you search a word, it shows yellow... then suppose I go
into Settings, I change Transliteration / Punjabi / any setting, then I
come back - the yellow highlighter should be there, and it should stay
in the middle of the screen."

The problem: v2.2.81 keeps the highlight across Settings, but the reader
restores its place with the v2.2.55 anchor - the topmost visible line at
the same pixel offset. Changing a setting (Transliteration, Punjabi
translation) grows or shrinks the verses, so the same scroll position
no longer puts the highlighted line in the middle - it drifts away.

Exactly these changes vs v2.2.83:
  1. In render(), when the reader re-renders with a found line
     highlighted (highlightLine >= 0), the highlighted line is
     scrolled to the CENTER of the screen (scrollIntoView
     block:'center'), instead of restoring the anchor. This covers
     coming back from Bani View Preferences AND toggling a layer in
     the reader itself (refreshReader -> render), since both change
     the layout. With NO highlight (normal reading), the anchored
     line keeps its place exactly as before (v2.2.55) - nothing
     changes for ordinary reading.
Keeps: search Gurmukhi + Latin only (v2.2.83), Ask buttons + button
decides the answer language (v2.2.82), search keep-place + highlight
(v2.2.81), reader highlight across Settings (v2.2.81), verses Gurmukhi
+ Latin + Detailed elaboration (v2.2.80), mic 30s + dead-start retry
(v2.2.79), no beep, music keeps playing, offline. The mic is NOT
touched in this build. No audio in this build (Play Store build); no
Bani or Ang changes, saved verses unaffected. No worker change needed.
Supersedes v2.2.83 (GSv303.zip) - do NOT upload GSv303, upload
GSv304 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_284 = (" v2.2.84: the yellow highlighted (found) line stays in the "
            "middle of the screen when you come back from Settings. "
            "Change Transliteration or the translation in Bani View "
            "Preferences and come back, and the line you searched for "
            "is still highlighted yellow, in the middle - even though "
            "the setting change grows or shrinks the verses. No audio "
            "in this build (Play Store build); no Bani or Ang changes, "
            "saved verses unaffected. The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def rep(text, old, new, label):
    assert text.count(old) == 1, f"{label}: anchor found {text.count(old)}x (want 1)"
    return text.replace(old, new, 1)


def main():
    # ---- version bump 2.2.83 -> 2.2.84 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.83', f"version.json is {vj['version']}"
    assert 'v2.2.83:' in vj['notes'], 'version notes do not contain v2.2.83'
    vj['notes'] = vj['notes'] + NOTE_284
    vj['version'] = '2.2.84'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.83"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.83"', '"version": "2.2.84"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.83"' in nbc, 'native-build-config.js is not 2.2.83'
    assert nbc.count('2.2.83') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.83"', '"version":"2.2.84"'),
        encoding='utf-8')
    print('version bump 2.2.83 -> 2.2.84 done')

    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')

    # ---- 1. render(): center the highlighted line, else restore anchor ----
    old_anchor = (
        "if(state.view==='reader'&&activeRemote?.lines?.length&&readerAnchor>=0)"
        "{requestAnimationFrame(()=>{if(state.view!=='reader'||!activeRemote?.lines?.length||readerAnchor<0)return;"
        "const idx=Math.max(0,Math.min(readerAnchor,activeRemote.lines.length-1));"
        "let node=document.querySelector(`[data-line=\"${idx}\"]`);"
        "if(!node)node=[...document.querySelectorAll('[data-lines]')].find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))||null;"
        "if(node){window.scrollTo({top:Math.max(0,window.scrollY+node.getBoundingClientRect().top-readerAnchorTop),behavior:'instant'})}})}"
    )
    new_anchor = (
        "if(state.view==='reader'&&activeRemote?.lines?.length)"
        "{requestAnimationFrame(()=>{if(state.view!=='reader'||!activeRemote?.lines?.length)return;\n"
        " // v2.2.84: a found line (yellow highlight) stays in the MIDDLE of the\n"
        " // screen across a re-render - e.g. coming back from Bani View\n"
        " // Preferences after changing Transliteration/translation, which grows\n"
        " // or shrinks the verses and would otherwise drift the highlight away\n"
        " // from the middle. With no highlight, the anchored line keeps its\n"
        " // place exactly as before (v2.2.55).\n"
        " if(highlightLine>=0){const idx=Math.max(0,Math.min(highlightLine,activeRemote.lines.length-1));"
        "let node=document.querySelector(`[data-line=\"${idx}\"]`);"
        "if(!node)node=[...document.querySelectorAll('[data-lines]')].find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))||null;"
        "node?.scrollIntoView({block:'center'});return;}\n"
        " if(readerAnchor<0)return;"
        "const idx=Math.max(0,Math.min(readerAnchor,activeRemote.lines.length-1));"
        "let node=document.querySelector(`[data-line=\"${idx}\"]`);"
        "if(!node)node=[...document.querySelectorAll('[data-lines]')].find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))||null;"
        "if(node){window.scrollTo({top:Math.max(0,window.scrollY+node.getBoundingClientRect().top-readerAnchorTop),behavior:'instant'})}})}"
    )
    app = rep(app, old_anchor, new_anchor, 'render() center highlight')
    print('render() centers the highlighted line')

    (ROOT / 'www/app.js').write_text(app, encoding='utf-8')

    # ---- asserts ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'v2.2.84: a found line (yellow highlight) stays in the MIDDLE' in app
    assert "node?.scrollIntoView({block:'center'});return;}" in app
    assert 'if(readerAnchor<0)return;' in app
    print('v2.2.84 fix applied')


if __name__ == '__main__':
    main()
