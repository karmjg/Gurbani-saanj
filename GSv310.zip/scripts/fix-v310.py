#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.90 - Ask page: mic out, Ask + language pills in the
question box (Karamjit 2026-11-23; mockup mockup_ask_no_mic.png approved,
"Build it").

His ask, in his words: no mic in Ask Guru Granth Sahib in AI; put the
Ask button where the mic is. Then, clarified: the Ask button sits at
the right end of the question box, FIRST, then Punjabi, then English
beside it (not in a row at the bottom); when Punjabi is picked the
word Ask becomes Punjabi (ਪੁੱਛੋ), when English it stays Ask.

Exactly 5 changes vs v2.2.89:
  1. Mic REMOVED from the Ask page only: the 🎙 button in the question
     box is gone, and its listening status line + green meter go with
     it. The Search page mic (voiceBtn + its status/meter) is NOT
     touched. The mic JS is cleaned up: the Ask mic wiring in
     attach() is removed, 'askVoiceBtn' leaves the setListeningUI /
     syncVoiceStopUI loops, and startVoiceSearch now only ever takes
     the Search mic (its only remaining caller).
  2. The Ask button MOVES into the question box, FIRST in the row
     (before Punjabi and English), keeping id="askButton" so
     answerQuestion() and the delegated click handler still work.
     The big full-width Ask button below is gone.
  3. The language pills (ਪੰਜਾਬੀ / English) MOVE into the question
     box, beside the Ask button. Their separate row below the depth
     pills is gone.
  4. The Ask button label follows the selected ANSWER language
     (state.aiLang), not the app language: Punjabi picked -> 'ਪੁੱਛੋ',
     English picked -> 'Ask'. New helper askButtonLabel(), used in
     askScreen(), in the data-ai-lang tap handler (guarded: it does
     not overwrite the button while an answer is being fetched), and
     when answerQuestion() restores the label. The transient
     "Searching…" text follows the same rule, so the button never
     flips language mid-search.
  5. The intro line no longer says "speak": "Type or speak your
     question" -> "Type your question" (EN), "ਸਵਾਲ ਲਿਖੋ ਜਾਂ ਬੋਲੋ।" ->
     "ਸਵਾਲ ਲਿਖੋ।" (PA) - there is no mic to speak into any more.
     (This wording is exactly what the approved mockup shows.)

CSS (so the moved buttons look like the mockup): the Ask button
inside .inputrow keeps a solid primary background with white text
(the generic .inputrow button rule would wash it out to light
green); the language pills inside .inputrow keep the outlined pill
look, selected = solid primary; the textarea gets min-width:0 so
the row fits with three buttons; dark-mode overrides match the
existing dark primary / selected-pill colours.

Keeps: depth pills (Simple/Detailed/In depth) unchanged in their
own row; AI online line unchanged; answer card unchanged; the
Search mic untouched; AI answer 22px (v2.2.87); Sahaj/GGS two
positions (v2.2.86); Vaaran/Kabir/Farid + centred reading (v2.2.89);
mic 30s + dead-start retry on Search (v2.2.79). No audio in this
build (Play Store build); no Bani or Ang changes, saved verses
unaffected. No worker change.
Supersedes v2.2.89 (GSv309.zip) - do NOT upload GSv309, upload
GSv310 instead. (GSv309 was delivered but never uploaded.)
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_290 = (" v2.2.90: Ask page - mic removed from Ask Guru Granth Sahib "
            "(Search mic untouched). The Ask button now sits inside the "
            "question box, FIRST, then Punjabi, then English beside it; "
            "the big Ask button below and the language row below are "
            "gone. The Ask button reads in the picked answer language - "
            "ਪੁੱਛੋ when Punjabi is picked, Ask when English is picked. "
            "Intro now says 'Type your question' (no mic to speak into). "
            "No audio in this build (Play Store build); no Bani or Ang "
            "changes, saved verses unaffected. The mic is not touched "
            "on the Search page.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def rep(app, old, new, label):
    assert old in app, f'{label}: old text not found'
    assert app.count(old) == 1, f'{label}: old text appears more than once'
    return app.replace(old, new, 1)


def main():
    app_path = ROOT / 'www/app.js'
    app = app_path.read_text(encoding='utf-8')

    # ---- 1+2+3: the Ask page layout (inputrow + status/meter + pills + big button) ----
    # (a) Intro: no more "speak".
    old_intro = ("<p class=\"fine\">${age('ਸਵਾਲ ਲਿਖੋ ਜਾਂ ਬੋਲੋ। AI ਪਹਿਲਾਂ ਬਾਣੀ ਦੀ ਪੰਕਤੀ ਦੱਸੇਗਾ, ਫਿਰ ਉਸਦਾ ਅਰਥ ਸਮਝਾਵੇਗਾ — ਪੰਜਾਬੀ ਜਾਂ English ਵਿੱਚ। ਸੌਖਾ ਚੁਣੋ ਤਾਂ ਬੱਚਿਆਂ ਲਈ ਸੌਖੇ ਸ਼ਬਦਾਂ ਵਿੱਚ।','Type or speak your question. The AI first quotes the Bani verse, then explains its meaning — in Punjabi or English. Simple explains it in easy words, like to a child.')}</p>")
    new_intro = ("<p class=\"fine\">${age('ਸਵਾਲ ਲਿਖੋ। AI ਪਹਿਲਾਂ ਬਾਣੀ ਦੀ ਪੰਕਤੀ ਦੱਸੇਗਾ, ਫਿਰ ਉਸਦਾ ਅਰਥ ਸਮਝਾਵੇਗਾ — ਪੰਜਾਬੀ ਜਾਂ English ਵਿੱਚ। ਸੌਖਾ ਚੁਣੋ ਤਾਂ ਬੱਚਿਆਂ ਲਈ ਸੌਖੇ ਸ਼ਬਦਾਂ ਵਿੱਚ।','Type your question. The AI first quotes the Bani verse, then explains its meaning — in Punjabi or English. Simple explains it in easy words, like to a child.')}</p>")
    app = rep(app, old_intro, new_intro, 'intro')

    # (b) inputrow: mic out; Ask button FIRST, then the language pills.
    old_row = (" <div class=\"inputrow\"><textarea id=\"questionInput\" placeholder=\"${t('askHint')}\" aria-label=\"${t('askHint')}\"></textarea><button type=\"button\" id=\"askVoiceBtn\" aria-label=\"${age('ਬੋਲ ਕੇ ਸਵਾਲ','Ask by voice')}\" title=\"${age('ਬੋਲ ਕੇ ਸਵਾਲ','Ask by voice')}\">🎙</button></div>")
    new_row = (" <div class=\"inputrow\"><textarea id=\"questionInput\" placeholder=\"${t('askHint')}\" aria-label=\"${t('askHint')}\"></textarea><button id=\"askButton\" class=\"primary\" type=\"button\">${askButtonLabel()}</button>${[['pa','ਪੰਜਾਬੀ'],['en','English']].map(([k,label])=>`<button data-ai-lang=\"${k}\" class=\"${state.aiLang===k?'sel':''}\">${label}</button>`).join('')}</div>")
    app = rep(app, old_row, new_row, 'inputrow')

    # (c) The Ask page's voice status + meter lines (they follow the new
    # inputrow, so this match is the Ask page's pair, not Search's).
    old_vm = (new_row + "\n <p id=\"voiceStatus\" role=\"status\" class=\"fine muted\"></p>\n <div id=\"voiceMeter\" class=\"gs-voice-meter\" hidden><div id=\"voiceMeterFill\" class=\"gs-voice-meter-fill\"></div></div>")
    app = rep(app, old_vm, new_row, 'ask voice status+meter')

    # (d) The standalone language-pills row below the depth pills.
    old_lang = (" <div class=\"answer-pills\">${[['pa','ਪੰਜਾਬੀ'],['en','English']].map(([k,label])=>`<button data-ai-lang=\"${k}\" class=\"${state.aiLang===k?'sel':''}\">${label}</button>`).join('')}</div>\n")
    assert old_lang in app, 'language pills row not found'
    assert app.count(old_lang) == 1, 'language pills row appears more than once'
    app = app.replace(old_lang, '', 1)
    print('Ask layout applied: mic out, Ask first + language pills in the box')

    # (e) The big full-width Ask button below.
    old_big = (" <button id=\"askButton\" class=\"primary full\" style=\"margin-top:14px\">${t('askButton')}</button><div id=\"conversation\">")
    new_big = (" <div id=\"conversation\">")
    app = rep(app, old_big, new_big, 'big Ask button')

    # ---- 4: the Ask label follows the answer language ----
    # (f) Helper, right before askScreen().
    old_fn = "function askScreen(){return `<section class=\"page ask\">"
    new_fn = ("// v2.2.90: the Ask button label follows the selected ANSWER language\n"
              "// (state.aiLang), not the app language: Punjabi -> 'ਪੁੱਛੋ', English -> 'Ask'.\n"
              "function askButtonLabel(){return (txt[state.aiLang]||txt.pa).askButton}\n"
              "function askScreen(){return `<section class=\"page ask\">")
    app = rep(app, old_fn, new_fn, 'askButtonLabel helper')

    # (g) The data-ai-lang tap handler also re-labels the Ask button
    # (guarded: never overwrite it while an answer is being fetched).
    old_h = ("const aiLang=e.target.closest('[data-ai-lang]');if(aiLang){state.aiLang=aiLang.dataset.aiLang;state.aiLangManual=true;persist();document.querySelectorAll('[data-ai-lang]').forEach(b=>b.classList.toggle('sel',b.dataset.aiLang===state.aiLang));return}")
    new_h = ("const aiLang=e.target.closest('[data-ai-lang]');if(aiLang){state.aiLang=aiLang.dataset.aiLang;state.aiLangManual=true;persist();document.querySelectorAll('[data-ai-lang]').forEach(b=>b.classList.toggle('sel',b.dataset.aiLang===state.aiLang));const ab=$('askButton');if(ab&&!ab.disabled)ab.textContent=askButtonLabel();return}")
    app = rep(app, old_h, new_h, 'ai-lang handler')

    # (h) answerQuestion(): the transient text follows the same rule,
    # and the restore uses the helper (not the app-language t()).
    old_s = ("const btn=$('askButton');if(btn){btn.disabled=true;btn.textContent=age('ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching…')}")
    new_s = ("const btn=$('askButton');if(btn){btn.disabled=true;btn.textContent=state.aiLang==='pa'?'ਖੋਜ ਹੋ ਰਹੀ ਹੈ…':'Searching…'}")
    app = rep(app, old_s, new_s, 'searching text')
    old_f = ("finally{const b=$('askButton');if(b){b.disabled=false;b.textContent=t('askButton')}}")
    new_f = ("finally{const b=$('askButton');if(b){b.disabled=false;b.textContent=askButtonLabel()}}")
    app = rep(app, old_f, new_f, 'restore label')
    print('Ask label follows the answer language (helper + handler + restore)')

    # ---- 1 (cleanup): the mic wiring that belonged to the Ask page ----
    # setListeningUI + syncVoiceStopUI no longer touch askVoiceBtn.
    old_set = ("for(const id of ['voiceBtn','askVoiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',on);b.textContent=on?'⏹':'🎙';}}")
    new_set = ("for(const id of ['voiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',on);b.textContent=on?'⏹':'🎙';}}")
    app = rep(app, old_set, new_set, 'setListeningUI')
    old_sync = ("for(const id of ['voiceBtn','askVoiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',voiceListeningOn);b.textContent=voiceListeningOn?'⏹':'🎙';}}")
    new_sync = ("for(const id of ['voiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',voiceListeningOn);b.textContent=voiceListeningOn?'⏹':'🎙';}}")
    app = rep(app, old_sync, new_sync, 'syncVoiceStopUI')
    # startVoiceSearch: only the Search mic can ever call it now.
    old_btn = ("const btn=input.id==='questionInput'?$('askVoiceBtn'):$('voiceBtn');")
    new_btn = ("const btn=$('voiceBtn');")
    app = rep(app, old_btn, new_btn, 'startVoiceSearch btn')
    # attach(): the Ask mic wiring line is gone.
    old_attach = (" if(state.view==='ask'){const av=$('askVoiceBtn');if(av)av.onclick=()=>{const qi=$('questionInput');if(!qi)return;if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(qi)};}\n")
    assert old_attach in app, 'attach Ask mic wiring not found'
    assert app.count(old_attach) == 1, 'attach Ask mic wiring appears more than once'
    app = app.replace(old_attach, '', 1)
    print('Ask mic wiring removed (Search mic untouched)')
    app_path.write_text(app, encoding='utf-8')

    # ---- CSS: the moved buttons keep their look inside .inputrow ----
    css_path = ROOT / 'www/styles.css'
    css = css_path.read_text(encoding='utf-8')
    anchor = ".ask .inputrow textarea { flex: 1; border: 0; background: transparent; outline: 0; color: var(--ink); min-height: 64px; resize: vertical; }"
    assert anchor in css, 'inputrow textarea rule not found'
    assert css.count(anchor) == 1, 'inputrow textarea rule appears more than once'
    rules = ("\n/* v2.2.90: Ask button + language pills live inside the question box.\n"
             "   The generic .inputrow button rule would wash the Ask button out to\n"
             "   light green and the pills out of their outlined pill look. */\n"
             ".ask .inputrow #askButton{background:var(--primary);color:#fff}\n"
             ".ask .inputrow [data-ai-lang]{border:1px solid var(--line);border-radius:19px;background:var(--surface);padding:8px 12px;color:var(--ink);font-size:12px}\n"
             ".ask .inputrow [data-ai-lang].sel{background:var(--primary);color:#fff}\n"
             ".ask .inputrow textarea{min-width:0}\n"
             ".dark .ask .inputrow #askButton{background:#2a5b45}\n"
             ".dark .ask .inputrow [data-ai-lang].sel{background:#2e6047}")
    assert '.ask .inputrow #askButton' not in css, 'v2.2.90 Ask CSS already present'
    css = css.replace(anchor, anchor + rules, 1)
    css_path.write_text(css, encoding='utf-8')
    print('CSS applied: Ask button + language pills inside the inputrow')

    # ---- asserts: the changes are in place, nothing else moved ----
    app = app_path.read_text(encoding='utf-8')
    assert 'askVoiceBtn' not in app, 'askVoiceBtn still referenced'
    assert app.count('id="askButton"') == 1, 'Ask button id count changed'
    assert 'class="primary full"' not in app, 'big full-width Ask button still present'
    assert app.count('data-ai-lang') == 3, 'data-ai-lang count changed (inputrow 2 + handler 1)'
    assert app.count('answer-pills') == 1, 'answer-pills row count changed (only depth row should remain)'
    assert "Type or speak your question" not in app, 'old intro still present'
    assert 'ਸਵਾਲ ਲਿਖੋ ਜਾਂ ਬੋਲੋ' not in app, 'old Punjabi intro still present'
    assert 'Type your question' in app and 'ਸਵਾਲ ਲਿਖੋ।' in app, 'new intro missing'
    assert 'function askButtonLabel()' in app, 'askButtonLabel helper missing'
    assert "ab.textContent=askButtonLabel()" in app, 'ai-lang handler relabel missing'
    assert "b.textContent=askButtonLabel()" in app, 'restore relabel missing'
    # The Search mic is intact: button, status, meter, wiring.
    assert "id=\"voiceBtn\"" in app, 'Search mic button gone'
    assert app.count('id="voiceStatus"') == 1, 'Search voiceStatus count changed'
    assert app.count('id="voiceMeter"') == 1, 'Search voiceMeter count changed'
    assert "const vb=$('voiceBtn');if(vb)vb.onclick" in app, 'Search mic wiring gone'
    assert "const btn=$('voiceBtn');" in app, 'startVoiceSearch btn not simplified'
    assert "for(const id of ['voiceBtn'])" in app, 'voice loops not cleaned'
    assert app.count("for(const id of ['voiceBtn'])") == 2, 'voice loop count changed'
    # The depth pills, AI status line, conversation and footer are untouched.
    assert "data-depth" in app and "id=\"aiStatusLine\"" in app
    assert "id=\"conversation\"" in app
    assert 'AI ਦੀ ਵਿਆਖਿਆ ਨੂੰ ਮੂਲ ਗੁਰਬਾਣੀ ਤੋਂ ਵੱਖਰਾ ਰੱਖਿਆ ਜਾਂਦਾ ਹੈ।' in app
    css = css_path.read_text(encoding='utf-8')
    assert css.count('.ask .inputrow #askButton') == 2, 'Ask button CSS rules missing (light + dark)'
    assert css.count('.ask .inputrow [data-ai-lang]') == 3, 'language pill CSS rules missing'
    assert '.ask .inputrow [data-ai-lang].sel{background:var(--primary);color:#fff}' in css
    assert '.dark .ask .inputrow [data-ai-lang].sel{background:#2e6047}' in css
    assert '.ask .inputrow textarea{min-width:0}' in css
    # Carry-forwards: v2.2.89 Vaaran/Kabir/Farid + centred reading, v2.2.87
    # font fix, v2.2.86 positions, v2.2.79 mic (Search).
    assert "!(m.src==='bani'&&m.group==='bhai')" in app, 'v2.2.89 Vaaran-out-of-Ask filter missing'
    assert '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}' in css, 'v2.2.87 font fix missing'
    assert 'if(extra.gg)state.ggAng=Number(id);' in app, 'v2.2.86 ggAng missing'
    assert 'deadStartRetries<1' in app, 'v2.2.79 dead-start retry missing'
    print('v2.2.90 changes verified')

    # ---- version bump 2.2.89 -> 2.2.90 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.89', f"version.json is {vj['version']}"
    assert 'v2.2.89:' in vj['notes'], 'version notes do not contain v2.2.89'
    vj['notes'] = vj['notes'] + NOTE_290
    vj['version'] = '2.2.90'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.89"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.89"', '"version": "2.2.90"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.89"' in nbc, 'native-build-config.js is not 2.2.89'
    assert nbc.count('2.2.89') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.89"', '"version":"2.2.90"'),
        encoding='utf-8')
    print('version bump 2.2.89 -> 2.2.90 done')


if __name__ == '__main__':
    main()
