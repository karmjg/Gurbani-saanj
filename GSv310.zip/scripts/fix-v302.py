#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.82 - keep the Punjabi/English buttons on the Ask
screen; the SELECTED button decides the answer language (Karamjit
2026-11-19, after the v2.2.80 mockups + his Ask screenshot).

His words: "we have to keep those buttons... if I am typing in English
but I want the answer in Punjabi it should give me in a Punjabi answer...
like let's say 'Hukam ki hai' it's English alphabet but I'm trying to
ask in Punjabi right so it's gonna give me a Punjabi answer because I
select Punjabi but if I'm gonna ask 'what is hukam' ... but I'm
selecting the English it should give me the answer in English."

Exactly these changes vs v2.2.81:
  1. The Punjabi/English buttons are RESTORED on the Ask screen
     (v2.2.80 removed them). They sit under the Simple/Detailed/
     In depth pills, same style, with the selected one highlighted.
     The existing [data-ai-lang] click handler (line ~1813) already
     sets state.aiLang + aiLangManual and persists it - it just had
     no buttons to click.
  2. The answer language now comes from the SELECTED button
     (state.aiLang), not from automatic script detection. The cloud
     call sends language:state.aiLang (was language:aiQuestionLang(q))
     and askOpenAI answers in state.aiLang (was aiQuestionLang).
     The aiQuestionLang detector is REMOVED - it was wrong for Roman
     Punjabi: "Hukam ki hai?" is Punjabi written in Roman letters,
     but the detector read it as English because its letters are
     Latin. Only the user's explicit button choice can tell Roman
     Punjabi from Roman English.
Keeps: search keep-place + highlight (v2.2.81), reader highlight
across Settings (v2.2.81), verses Gurmukhi + Latin + Detailed
elaboration (v2.2.80), mic 30s + dead-start retry (v2.2.79), no beep,
music keeps playing, offline. The mic is NOT touched in this build
(he confirmed 2026-11-19 it is working fine - test it 2-3 days, fix
only if something comes up). No audio in this build (Play Store
build); no Bani or Ang changes, saved verses unaffected. No worker
change needed - the cloud Worker already answers in body.language
(deployed 2026-11-19 14:10 CST, verified byte-identical).
Supersedes v2.2.81 (GSv301.zip) - do NOT upload GSv301, upload
GSv302 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_282 = (" v2.2.82: the Punjabi/English buttons are back on the Ask "
            "screen, and the SELECTED button decides the answer "
            "language. Type in Roman letters and pick Punjabi, and the "
            "answer is in Punjabi; pick English, and it is in English. "
            "Automatic script detection is removed - Roman letters can "
            "be Punjabi or English, so only the button can tell. No "
            "audio in this build (Play Store build); no Bani or Ang "
            "changes, saved verses unaffected. The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.81 -> 2.2.82 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.81', f"version.json is {vj['version']}"
    assert 'v2.2.81:' in vj['notes'], 'version notes do not contain v2.2.81'
    vj['notes'] = vj['notes'] + NOTE_282
    vj['version'] = '2.2.82'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.81"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.81"', '"version": "2.2.82"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.81"' in nbc, 'native-build-config.js is not 2.2.81'
    assert nbc.count('2.2.81') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.81"', '"version":"2.2.82"'),
        encoding='utf-8')
    print('version bump 2.2.81 -> 2.2.82 done')

    # ---- assert the app.js changes (already applied by hand) ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'aiQuestionLang' not in app, 'aiQuestionLang still present'
    assert 'data-ai-lang' in app, 'language pills missing'
    assert 'language:state.aiLang' in app, 'cloud call does not send state.aiLang'
    assert "Answer in ${state.aiLang==='en'?'English':'Punjabi'}" in app, \
        'askOpenAI does not answer in state.aiLang'
    assert 'v2.2.82: the AI answer follows the SELECTED' in app, \
        'v2.2.82 comment missing'
    # the pills row sits right after the depth pills row in askScreen
    assert app.count('data-ai-lang') == 3, \
        f"data-ai-lang appears {app.count('data-ai-lang')}x (want 3: pills template + handler closest + handler querySelectorAll)"
    print('app.js changes verified (pills restored, button decides language)')

    print('v2.2.82 fix applied')


if __name__ == '__main__':
    main()
