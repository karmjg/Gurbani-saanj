#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.88 - Kirtan shabad reader fixes (Karamjit
2026-11-20, video + voice message).

He opened a Kirtan shabad, tapped Aa to open Bani View Preferences,
changed Transliteration, came back - and the Aa button was gone for
good: "it doesn't click again, that one doesn't show at all". And
second: the shabad lines are left-aligned, while the Nitnem/Bani
paaths are centred - "in the middle" - with the Latin and the
translations laid out the same as Nitnem.

Root causes, both verified in code:
  1. The reader top bar (title + Aa) is hidden with display:none
     whenever readerBarHidden is true. go('viewprefs') sets it true.
     Coming back uses the back button (popstate -> render()), which
     never shows the bar again. The ONLY way back is scrolling up
     5px - but a short shabad fits on one screen, so there is no
     scroll at all and the Aa button can never come back.
  2. The iGranth-style rules (centred lines, orange Roman) and the
     centred-layers rules only ever applied to kind==='bani': the
     section only got .gs-translit-on / .gs-layers-on for Banis, and
     the CSS only matched .gs-bani-pankti. A Kirtan shabad
     (kind==='kirtan', .gs-kirtan-pankti) never got either class, so
     it stayed left-aligned with red Roman - even with
     Transliteration ON.

Exactly 2 changes vs v2.2.87:
  1. popstate: after render(), if the back button lands back on the
     reader, showReaderBar() runs at once - the top bar (title + Aa)
     is back immediately, no scroll needed.
  2. The Kirtan reader gets the same treatment as the Bani reader:
     the section gains .gs-translit-on / .gs-layers-on for kirtan
     too, and the four centring rules gain .gs-kirtan-pankti
     companions. With Transliteration ON the shabad lines centre
     and the Roman is orange and centred; with English/Punjabi ON
     those layers centre too - exactly like Nitnem. With everything
     OFF it stays left-aligned black, like Nitnem with everything
     OFF. The Gurmukhi stays black (v2.2.41 rule); the font and
     size are untouched.
Keeps: AI answer 22px (v2.2.87), Sahaj/GGS two positions (v2.2.86),
highlight stays centered (v2.2.84), search Gurmukhi + Latin only
(v2.2.83), Ask buttons (v2.2.82), search keep-place + highlight
(v2.2.81), mic 30s + dead-start retry (v2.2.79), no beep, music
keeps playing, offline. The mic is NOT touched in this build.
No audio in this build (Play Store build); no Bani or Ang changes,
saved verses unaffected. No worker change.
The "View full Ang" reader is unchanged (blue, centred, as now).
Supersedes v2.2.87 (GSv307.zip) - do NOT upload GSv307, upload
GSv308 instead. (GSv307 was delivered but never uploaded.)
NOTE: v2.2.88 was briefly used for a cancelled "22 everything"
change the same morning (reverted, never built, no zip). This
v2.2.88 is the Kirtan fix only.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_288 = (" v2.2.88: Kirtan shabad reader fixes. (1) After coming "
            "back from Bani View Preferences the top bar with the Aa "
            "button shows again at once - before, it stayed hidden "
            "and a short shabad has no scroll to bring it back. "
            "(2) A Kirtan shabad now looks like Nitnem: with "
            "Transliteration ON the lines are centred and the Latin "
            "is orange and centred; English/Punjabi layers centre "
            "too. With everything OFF it stays left-aligned black, "
            "like Nitnem. No audio in this build (Play Store build); "
            "no Bani or Ang changes, saved verses unaffected. The "
            "mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- fix 1: back button landing on the reader shows the bar ----
    app_path = ROOT / 'www/app.js'
    app = app_path.read_text(encoding='utf-8')
    old_pop = "state.view=nv;render();if(state.view!=='reader')window.scrollTo(0,0)});"
    new_pop = "state.view=nv;render();if(nv==='reader')showReaderBar();if(state.view!=='reader')window.scrollTo(0,0)});"
    assert old_pop in app, 'popstate handler not found as expected'
    assert app.count(old_pop) == 1, 'popstate handler appears more than once'
    app = app.replace(old_pop, new_pop, 1)
    print('Fix 1 applied: popstate shows the reader bar on return')

    # ---- fix 2a: the kirtan section gains the translit/layers classes ----
    old_cls = ("${kind==='bani'&&state.showTranslit?' gs-translit-on':''}"
               "${kind==='bani'&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}")
    new_cls = ("${(kind==='bani'||kind==='kirtan')&&state.showTranslit?' gs-translit-on':''}"
               "${(kind==='bani'||kind==='kirtan')&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}")
    assert old_cls in app, 'reader section class expression not found'
    assert app.count(old_cls) == 1, 'class expression appears more than once'
    app = app.replace(old_cls, new_cls, 1)
    app_path.write_text(app, encoding='utf-8')
    print('Fix 2a applied: kirtan section gains gs-translit-on / gs-layers-on')

    # ---- fix 2b: the centring rules gain .gs-kirtan-pankti companions ----
    css_path = ROOT / 'www/styles.css'
    css = css_path.read_text(encoding='utf-8')
    pairs = [
        ('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}',
         'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti{text-align:center!important;}'),
        ('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}',
         'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'),
        ('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti{text-align:center!important;}',
         'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti{text-align:center!important;}'),
        ('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}',
         'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}'),
    ]
    for old, new in pairs:
        assert old in css, f'rule not found: {old[:60]}...'
        assert css.count(old) == 1, f'rule appears more than once: {old[:60]}...'
        assert new not in css, f'kirtan rule already present: {new[:60]}...'
        css = css.replace(old, old + '\n' + new, 1)
    css_path.write_text(css, encoding='utf-8')
    print('Fix 2b applied: 4 kirtan centring rules added')

    # ---- asserts: the fixes are in place, nothing else moved ----
    app = app_path.read_text(encoding='utf-8')
    assert "if(nv==='reader')showReaderBar();" in app, 'popstate fix missing'
    assert app.count("showReaderBar();") == 2, 'showReaderBar call count changed unexpectedly'
    assert new_cls in app, 'kirtan class expression missing'
    assert "kind==='bani'&&state.showTranslit" not in app, 'old bani-only class expression still present'
    css = css_path.read_text(encoding='utf-8')
    assert css.count('.gs-kirtan-pankti{') == 2, 'kirtan pankti centre rules missing'
    assert css.count('.gs-kirtan-pankti .verse-roman') == 1, 'kirtan roman rule missing'
    assert css.count('.gs-kirtan-pankti .verse-layer') == 1, 'kirtan layer rule missing'
    # The Bani rules are untouched, byte for byte.
    assert 'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti{text-align:center!important;}' in css
    assert 'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}' in css
    # The left-align default (line 405) is untouched - it still governs
    # Bani and Kirtan when no layers are on.
    assert 'html.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}' in css, 'default left-align rule changed'
    # The Ang reader is untouched: still blue, still never gets the classes.
    assert 'gs-gurmukhi-blue' in css and 'isSggs' in app
    # Carry-forwards: v2.2.87 font fix, v2.2.86 positions, v2.2.79 mic.
    assert '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}' in css, 'v2.2.87 font fix missing'
    assert 'if(extra.gg)state.ggAng=Number(id);' in app, 'v2.2.86 ggAng missing'
    assert 'deadStartRetries<1' in app, 'v2.2.79 dead-start retry missing'
    assert "onError" in (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8'), 'v2.2.79 plugin patch script missing'
    print('v2.2.88 fixes verified')

    # ---- version bump 2.2.87 -> 2.2.88 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.87', f"version.json is {vj['version']}"
    assert 'v2.2.87:' in vj['notes'], 'version notes do not contain v2.2.87'
    vj['notes'] = vj['notes'] + NOTE_288
    vj['version'] = '2.2.88'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.87"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.87"', '"version": "2.2.88"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.87"' in nbc, 'native-build-config.js is not 2.2.87'
    assert nbc.count('2.2.87') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.87"', '"version":"2.2.88"'),
        encoding='utf-8')
    print('version bump 2.2.87 -> 2.2.88 done')


if __name__ == '__main__':
    main()
