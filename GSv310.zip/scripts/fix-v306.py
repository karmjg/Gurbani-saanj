#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.86 - Sahaj Paath and Guru Granth Sahib are now two
separate remembered positions (Karamjit 2026-11-20).

His words: "I am on page one four one zero [Sahaj Paath]... then I go to
Guru Granth Sahib and I want to search something like five hundred page,
that my Sahaj Paath also becomes five hundred. My Sahaj Paath should stay
the same, one four one zero, and Guru Granth Sahib should be separate."

Root cause: the reader Ang-jump box and the Library Ang picker both
passed sahaj=true, so a jump to Ang 500 overwrote state.ang (the Sahaj
Paath position, 1410). That sahaj=true came from v2.2.12, which fixed his
Nov 5 bug (typed 1366, went back, it reverted to 478) - but its side
effect is exactly this bug.

Exactly these changes vs v2.2.85:
  1. NEW state.ggAng - Guru Granth Sahib's own last page. BASE ggAng:0;
     init migrates it to the Sahaj position on first load
     (state.ggAng = stored ggAng || state.ang), so the picker shows
     1410 until he jumps somewhere else. loadRemote writes ggAng when
     extra.gg is set; openAng gains a 4th param gg.
  2. The reader Ang-jump box and the Library Ang picker now pass gg
     only (sahaj=false) - jumping to 500 moves ggAng to 500 and leaves
     state.ang at 1410. The Library picker input shows ggAng.
  3. Swipes move ggAng too (and still move Sahaj only when swiping
     forward from the Sahaj Ang itself).
  4. Continue (navReader) still opens state.ang with sahaj only - it
     does not touch ggAng. Search results, saved verses and Hukamnama
     opens stay detours that move neither position. displayAng() falls
     back to ggAng (not state.ang) outside the reader. ggAng is added
     to the backup import list so a backup restores it.
Keeps: AI answer font 22px (v2.2.85), highlight stays centered
(v2.2.84), search Gurmukhi + Latin only (v2.2.83), Ask buttons
(v2.2.82), search keep-place + highlight (v2.2.81), mic 30s +
dead-start retry (v2.2.79), no beep, music keeps playing, offline.
The mic is NOT touched in this build. No audio in this build (Play
Store build); no Bani or Ang changes, saved verses unaffected.
Supersedes v2.2.85 (GSv305.zip) - do NOT upload GSv305, upload
GSv306 instead.
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_286 = (" v2.2.86: Sahaj Paath and Guru Granth Sahib are now two "
            "separate remembered positions. Jumping to another Ang in "
            "Guru Granth Sahib (reader jump box or Library Ang picker) "
            "no longer moves your Sahaj Paath - Sahaj Paath stays at "
            "1410 while Guru Granth Sahib remembers 500 on its own. "
            "Sahaj Paath moves only with Continue or by swiping forward "
            "from the Sahaj Ang. No audio in this build (Play Store "
            "build); no Bani or Ang changes, saved verses unaffected. "
            "The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.85 -> 2.2.86 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.85', f"version.json is {vj['version']}"
    assert 'v2.2.85:' in vj['notes'], 'version notes do not contain v2.2.85'
    vj['notes'] = vj['notes'] + NOTE_286
    vj['version'] = '2.2.86'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.85"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.85"', '"version": "2.2.86"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.85"' in nbc, 'native-build-config.js is not 2.2.85'
    assert nbc.count('2.2.85') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.85"', '"version":"2.2.86"'),
        encoding='utf-8')
    print('version bump 2.2.85 -> 2.2.86 done')

    # ---- asserts: the two-position split is in place ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'ang:1,ggAng:0,' in app, 'BASE.ggAng missing'
    assert 'state.ggAng=Math.min(1430,Math.max(1,Number(state.ggAng)||state.ang));' in app, 'ggAng migration missing'
    assert 'if(extra.gg)state.ggAng=Number(id);' in app, 'loadRemote does not write ggAng'
    assert 'function openAng(n,preserveProgress=false,sahaj=false,gg=false)' in app, 'openAng has no gg param'
    assert '{sahaj,gg}' in app, 'openAng does not pass gg to loadRemote'
    # The jump box and the picker must NOT pass sahaj=true any more.
    assert "openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,false,true)" in app, 'jump box still passes sahaj'
    assert "openAng($('angPicker')?.value||displayAng(),false,false,true)" in app, 'picker still passes sahaj'
    assert 'value="${state.ggAng||state.ang}"' in app, 'picker input does not show ggAng'
    assert "return activeRemote?.kind==='ang'?Number(activeRemote.id):(state.ggAng||state.ang)" in app, 'displayAng fallback is not ggAng'
    # Continue still moves Sahaj only; search/saved opens stay detours.
    assert "openAng(state.ang,true,true)" in app, 'navReader changed'
    assert "openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true)" in app, 'search/saved opens changed'
    assert "'ggAng'" in app and "'ang','ggAng'," in app, 'ggAng not in backup permitted list'
    print('v2.2.86 fix applied')


if __name__ == '__main__':
    main()
