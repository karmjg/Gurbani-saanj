#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.87 - the AI answer font size now actually shows
(Karamjit 2026-11-20).

His question, on a screenshot of the Ask screen: "Is this 22?" - the
answer he was looking at. It was NOT 22px. I measured the text in his
screenshot against the bottom-nav labels (11px): the AI answer renders
at about 12px.

Root cause (a real bug, and it also explains his old reports): the
rule `.simple-card p{font-size:12px}` beats `.ai-answer{font-size:
var(--ai-font,22px)}` on CSS specificity - (0,1,1) beats (0,1,0) -
because the answer paragraph sits inside a `.simple-card`. So the
22px from v2.2.85, the pinch-to-zoom and the A-/A+ buttons all changed
the stored number, but the screen never used it: the answer was
always 12px. That is why he said "we tried it multiple times to
increase the font it never worked".

Exactly 1 change vs v2.2.86:
  1. The AI-answer rule's selector becomes `.simple-card p.ai-answer`
     (specificity (0,2,1)), so it now beats `.simple-card p` (0,1,1)
     and the answer renders at var(--ai-font,22px). The generic
     `.simple-card p` rule is untouched, so every other paragraph in
     a card stays 12px. The 22px default and the stored-18 -> 22
     migration from v2.2.85 are unchanged and now take effect.
Side effect (named, good one): pinch-to-zoom and the A-/A+ buttons
now work too, because they change the same --ai-font value that the
answer finally reads.
Keeps: Sahaj/GGS two positions (v2.2.86), AI font 22px default
(v2.2.85), highlight stays centered (v2.2.84), search Gurmukhi +
Latin only (v2.2.83), Ask buttons (v2.2.82), search keep-place +
highlight (v2.2.81), mic 30s + dead-start retry (v2.2.79), no beep,
music keeps playing, offline. The mic is NOT touched in this build.
No audio in this build (Play Store build); no Bani or Ang changes,
saved verses unaffected. No worker change (the cloud only sends the
answer words; the size lives in the app).
Supersedes v2.2.86 (GSv306.zip) - do NOT upload GSv306, upload
GSv307 instead. (GSv306 was uploaded to GitHub at 06:54 today and
its AAB run 85 succeeded, but the font in it is still 12px.)
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_287 = (" v2.2.87: the AI answer font size now actually shows. "
            "The answer was rendering at 12px even though the size "
            "was set to 22px, because another rule (.simple-card p) "
            "was winning over the AI answer rule. The AI answer rule "
            "is now more specific, so the answer shows at 22px. "
            "Pinch-to-zoom and the A-/A+ buttons work now too, for "
            "the same reason. No audio in this build (Play Store "
            "build); no Bani or Ang changes, saved verses unaffected. "
            "The mic is not touched.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- the fix: make the AI-answer font-size rule win ----
    css_path = ROOT / 'www/styles.css'
    css = css_path.read_text(encoding='utf-8')
    old = '.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'
    new = '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'
    assert old in css, 'line 378 .ai-answer rule not found as expected'
    assert css.count(old) == 1, 'the .ai-answer rule appears more than once'
    css = css.replace(old, new, 1)
    css_path.write_text(css, encoding='utf-8')
    print('CSS fix applied: .ai-answer -> .simple-card p.ai-answer')

    # ---- asserts: the fix is in place, nothing else moved ----
    css = css_path.read_text(encoding='utf-8')
    assert '.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}' in css, 'fixed rule missing'
    assert css.count('font-size:var(--ai-font,22px)') == 1, 'font-size var appears more than once'
    assert '.simple-card p{font-size:12px;color:var(--muted);margin:3px 0}' in css, 'generic .simple-card p rule changed - it must stay 12px'
    # No other .ai-answer rule may set a font-size: the only
    # '.ai-answer{' occurrences are the fixed rule and line 538
    # (white-space only); line 622 is '.ai-answer {' with a space.
    assert css.count('.ai-answer{') == 2, 'unexpected .ai-answer rule count'
    assert '.ai-answer { line-height: 1.75; color: var(--ink); white-space: pre-wrap; }' in css, 'line 622 .ai-answer rule changed'
    # The 22px default and migration from v2.2.85 are still there.
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'aiFont:22,' in app, 'BASE aiFont is not 22'
    assert 'if(state.aiFont===18)state.aiFont=22;' in app, 'stored-18 -> 22 migration missing'
    assert '--ai-font' in app, 'theme() does not set --ai-font'
    # Carry-forward: Sahaj/GGS split from v2.2.86 is intact.
    assert 'ang:1,ggAng:0,' in app, 'BASE.ggAng missing'
    assert 'if(extra.gg)state.ggAng=Number(id);' in app, 'loadRemote does not write ggAng'
    print('v2.2.87 fix verified')

    # ---- version bump 2.2.86 -> 2.2.87 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.86', f"version.json is {vj['version']}"
    assert 'v2.2.86:' in vj['notes'], 'version notes do not contain v2.2.86'
    vj['notes'] = vj['notes'] + NOTE_287
    vj['version'] = '2.2.87'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.86"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.86"', '"version": "2.2.87"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.86"' in nbc, 'native-build-config.js is not 2.2.86'
    assert nbc.count('2.2.86') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.86"', '"version":"2.2.87"'),
        encoding='utf-8')
    print('version bump 2.2.86 -> 2.2.87 done')


if __name__ == '__main__':
    main()
