/* v2.2.88 test - Kirtan shabad reader fixes. Karamjit 2026-11-20,
 * video + voice message, on the Kirtan shabad Ang 1106.
 *
 * Issue 1 - the Aa button is gone after Settings: open a Kirtan
 * shabad, tap Aa, change Transliteration, come back - the top bar
 * (title + Aa) never comes back. "It doesn't click again, that one
 * doesn't show at all." Cause: go('viewprefs') sets
 * readerBarHidden=true; the back button (popstate -> render())
 * never shows the bar again; the ONLY way back is scrolling up 5px
 * - and a short shabad fits on one screen, so there is no scroll.
 * Fix: popstate shows the bar at once when it lands on the reader.
 *
 * Issue 2 - the shabad is left-aligned: the iGranth-style rules
 * (centred lines, orange Roman) and the centred-layers rules only
 * ever applied to kind==='bani' - the section only got
 * .gs-translit-on / .gs-layers-on for Banis, and the CSS only
 * matched .gs-bani-pankti. A Kirtan shabad (kind==='kirtan',
 * .gs-kirtan-pankti) never got either class, so it stayed
 * left-aligned with red Roman even with Transliteration ON.
 * Fix: the kirtan section gains the same two classes, and the four
 * centring rules gain .gs-kirtan-pankti companions.
 *
 * The proofs below run the REAL code: the real popstate handler +
 * the real showReaderBar in a vm sandbox (bar back, and still
 * hidden on the pristine v2.2.87 code), the real readerScreen
 * class expression evaluated for every kind, and a real CSS
 * cascade computation (!important-aware) over the shipped
 * styles.css for the kirtan lines.
 * Run: node test-v308.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v308-rollback/www';
const rbApp = fs.readFileSync(path.join(RB, 'app.js'), 'utf8');
const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// Extract a whole function starting at startMarker by brace counting.
function extractFunction(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.88', vj.version === '2.2.88', vj.version);
  ok('version notes mention v2.2.88', vj.notes.includes('v2.2.88:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.88', pj.version === '2.2.88', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.88', nbc.includes('"version":"2.2.88"'));
}

// ---------- static checks: the two fixes ----------
ok('fix 1: popstate shows the bar when landing on the reader', app.includes("state.view=nv;render();if(nv==='reader')showReaderBar();"));
ok('fix 1: the old popstate line is gone', !app.includes("state.view=nv;render();if(state.view!=='reader')window.scrollTo(0,0)});"));
ok('fix 2a: kirtan gains the translit/layers classes', app.includes("(kind==='bani'||kind==='kirtan')&&state.showTranslit?' gs-translit-on':''") && app.includes("(kind==='bani'||kind==='kirtan')&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''"));
ok('fix 2a: the old bani-only class expression is gone', !app.includes("kind==='bani'&&state.showTranslit?' gs-translit-on':''"));
ok('fix 2b: kirtan translit-on centre rule present', css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti{text-align:center!important;}'));
ok('fix 2b: kirtan translit-on orange Roman rule present', css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('fix 2b: kirtan layers-on centre rule present', css.includes('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti{text-align:center!important;}'));
ok('fix 2b: kirtan layers-on layer-centre rule present', css.includes('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('fix 2b: .gs-kirtan-pankti appears exactly 4 times (the 4 new rules)', (css.match(/\.gs-kirtan-pankti/g) || []).length === 4, `count=${(css.match(/\.gs-kirtan-pankti/g) || []).length}`);
// The Bani rules are untouched, byte for byte.
ok('Bani translit-on centre rule untouched', css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}'));
ok('Bani translit-on orange Roman rule untouched', css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('Bani layers-on centre rule untouched', css.includes('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti{text-align:center!important;}'));
ok('Bani layers-on layer-centre rule untouched', css.includes('html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('default left-align rule untouched (still governs when no layers are on)', css.includes('html.reading-open .gs-reader-bani #verses .gs-pankti{text-align:left!important;}'));
ok('Ang blue rule untouched', css.includes('.gs-gurmukhi-blue { color: #1a3fa0; font-weight: 700; }'));
ok('Roman default red rule untouched', css.includes('.verse-roman { color: #b3261e; }'));

// ---------- the diffs: app.js differs ONLY by the two edits, styles.css ONLY by the 4 rules ----------
{
  const newPop = "state.view=nv;render();if(nv==='reader')showReaderBar();if(state.view!=='reader')window.scrollTo(0,0)});";
  const oldPop = "state.view=nv;render();if(state.view!=='reader')window.scrollTo(0,0)});";
  const newCls = "${(kind==='bani'||kind==='kirtan')&&state.showTranslit?' gs-translit-on':''}${(kind==='bani'||kind==='kirtan')&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}";
  const oldCls = "${kind==='bani'&&state.showTranslit?' gs-translit-on':''}${kind==='bani'&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}";
  const restored = app.replace(newPop, oldPop).replace(newCls, oldCls);
  ok('app.js differs from v2.2.87 ONLY by the two edits', restored === rbApp);
}
{
  const pairs = [
    'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}',
    'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}',
    'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti{text-align:center!important;}',
    'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-bani-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}',
  ];
  const kirtan = [
    'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti{text-align:center!important;}',
    'html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-kirtan-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}',
    'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti{text-align:center!important;}',
    'html.reading-open .gs-reader-bani.gs-layers-on #verses .gs-kirtan-pankti .verse-layer{text-align:center;border-left:0;padding-left:0;margin-left:0;}',
  ];
  let restored = css;
  for (let i = 0; i < 4; i++) restored = restored.replace(pairs[i] + '\n' + kirtan[i], pairs[i]);
  ok('styles.css differs from v2.2.87 ONLY by the 4 added kirtan rules', restored === rbCss);
}

// ---------- a small real CSS cascade (!important-aware, id-aware) ----------
// Parse top-level rules; @-rules are skipped whole. Rules whose selector
// carries [attr] or :pseudo qualifiers are skipped for these properties:
// a static element has none of those attributes/states, so such a rule
// can only narrow a match, never widen it - counting it would be a
// false positive (e.g. the night-mode .verse-roman green).
function parseRules(text) {
  const clean = text.replace(/\/\*[\s\S]*?\*\//g, '');
  const rules = [];
  let i = 0;
  while (i < clean.length) {
    const open = clean.indexOf('{', i);
    if (open === -1) break;
    const sel = clean.slice(i, open).trim();
    let depth = 1, j = open + 1;
    while (j < clean.length && depth > 0) {
      if (clean[j] === '{') depth++;
      else if (clean[j] === '}') depth--;
      j++;
    }
    if (sel && !sel.startsWith('@')) {
      for (const s of sel.split(',')) {
        const t = s.trim();
        if (!t.includes('[') && !t.includes(':')) rules.push({ selector: t, decls: clean.slice(open + 1, j - 1), order: rules.length });
      }
    }
    i = j;
  }
  return rules;
}
function specificity(sel) {
  const ids = (sel.match(/#[\w-]+/g) || []).length;
  const classes = (sel.match(/\.[\w-]+/g) || []).length
    + (sel.match(/\[[^\]]+\]/g) || []).length
    + (sel.match(/:(?!:)[\w-]+(\([^)]*\))?/g) || []).length;
  const els = sel.split(/[\s>+~]+/).reduce((n, part) => n + (/^[a-zA-Z][\w-]*/.test(part) ? 1 : 0), 0);
  return [ids, classes, els];
}
const cmpSpec = (a, b) => (a[0] - b[0]) || (a[1] - b[1]) || (a[2] - b[2]);
function matches(sel, path) {
  const parts = sel.split(/\s+/).map(p => p.trim()).filter(Boolean);
  if (!parts.length) return false;
  let pi = 0;
  for (const el of path) {
    if (pi >= parts.length) break;
    const part = parts[pi];
    const tag = (/^[a-zA-Z][\w-]*/.exec(part) || [])[0];
    const id = (/#([\w-]+)/.exec(part) || [])[1];
    const classes = [...part.matchAll(/\.([\w-]+)/g)].map(m => m[1]);
    if ((!tag || tag === el.tag) && (!id || id === el.id) && classes.every(c => el.classes.includes(c))) pi++;
  }
  return pi === parts.length;
}
// Which value wins for one property on one element path?
function winningProp(text, prop, elementPath) {
  const rules = parseRules(text);
  const cands = [];
  for (const r of rules) {
    const m = new RegExp(prop + '\\s*:\\s*([^;}]+)').exec(r.decls);
    if (!m) continue;
    if (matches(r.selector, elementPath)) {
      const raw = m[1].trim();
      cands.push({ selector: r.selector, value: raw.replace(/!important/g, '').trim(), important: /!important/.test(raw), spec: specificity(r.selector), order: r.order });
    }
  }
  cands.sort((a, b) => ((a.important ? 1 : 0) - (b.important ? 1 : 0)) || cmpSpec(a.spec, b.spec) || (a.order - b.order));
  return { cands, winner: cands[cands.length - 1] || null };
}
const HTML = { tag: 'html', classes: ['reading-open'] };
const VERSES = { tag: 'div', classes: ['verse-list'], id: 'verses' };
const sec = extra => ({ tag: 'section', classes: ['reading', 'reading-immersive', 'gs-reader-bani', ...extra] });
const secSggs = { tag: 'section', classes: ['reading', 'reading-immersive', 'gs-reader-sggs'] };
const pankti = cls => ({ tag: 'div', classes: ['verse-block', 'gs-pankti', cls] });
const roman = { tag: 'div', classes: ['verse-layer', 'verse-roman'] };
const enLayer = { tag: 'div', classes: ['verse-layer', 'verse-en'] };
const gurmukhiBlue = { tag: 'div', classes: ['verse-text', 'gs-gurmukhi-blue'] };

// ---------- cascade proof: kirtan lines ----------
{
  // Transliteration ON (his setting): centred + orange Roman.
  const p = [HTML, sec(['gs-translit-on', 'gs-layers-on']), VERSES, pankti('gs-kirtan-pankti')];
  const t = winningProp(css, 'text-align', p);
  ok('kirtan + translit ON: lines are CENTRED', !!t.winner && t.winner.value === 'center', t.winner ? `${t.winner.selector} => ${t.winner.value}` : 'no winner');
  const r = winningProp(css, 'color', [...p, roman]);
  ok('kirtan + translit ON: Roman is ORANGE #f3541d', !!r.winner && r.winner.value === '#f3541d', r.winner ? `${r.winner.selector} => ${r.winner.value}` : 'no winner');
  // English ON, transliteration OFF: lines centre, layers centre (v2.2.49 behaviour).
  const p2 = [HTML, sec(['gs-layers-on']), VERSES, pankti('gs-kirtan-pankti')];
  const t2 = winningProp(css, 'text-align', p2);
  ok('kirtan + English ON (translit OFF): lines are CENTRED', !!t2.winner && t2.winner.value === 'center', t2.winner ? `${t2.winner.selector} => ${t2.winner.value}` : 'no winner');
  const e2 = winningProp(css, 'text-align', [...p2, enLayer]);
  ok('kirtan + English ON: the English layer is CENTRED', !!e2.winner && e2.winner.value === 'center', e2.winner ? `${e2.winner.selector} => ${e2.winner.value}` : 'no winner');
  // Everything OFF: left-aligned black, like Nitnem with everything OFF.
  const p3 = [HTML, sec([]), VERSES, pankti('gs-kirtan-pankti')];
  const t3 = winningProp(css, 'text-align', p3);
  ok('kirtan + everything OFF: lines stay LEFT-aligned', !!t3.winner && t3.winner.value === 'left', t3.winner ? `${t3.winner.selector} => ${t3.winner.value}` : 'no winner');
}
{
  // The bug, proved on the pristine v2.2.87 CSS: with Transliteration
  // ON the kirtan lines were still LEFT and the Roman still RED.
  const p = [HTML, sec(['gs-translit-on', 'gs-layers-on']), VERSES, pankti('gs-kirtan-pankti')];
  const t = winningProp(rbCss, 'text-align', p);
  ok('v2.2.87: kirtan + translit ON was LEFT-aligned (the bug)', !!t.winner && t.winner.value === 'left', t.winner ? `${t.winner.selector} => ${t.winner.value}` : 'no winner');
  const r = winningProp(rbCss, 'color', [...p, roman]);
  ok('v2.2.87: kirtan + translit ON Roman was RED #b3261e (the bug)', !!r.winner && r.winner.value === '#b3261e', r.winner ? `${r.winner.selector} => ${r.winner.value}` : 'no winner');
}
{
  // Bani unchanged: same centred + orange result on the new CSS.
  const p = [HTML, sec(['gs-translit-on', 'gs-layers-on']), VERSES, pankti('gs-bani-pankti')];
  const t = winningProp(css, 'text-align', p);
  ok('Bani + translit ON: still CENTRED (unchanged)', !!t.winner && t.winner.value === 'center', t.winner ? `${t.winner.selector} => ${t.winner.value}` : 'no winner');
  const r = winningProp(css, 'color', [...p, roman]);
  ok('Bani + translit ON: Roman still ORANGE #f3541d (unchanged)', !!r.winner && r.winner.value === '#f3541d', r.winner ? `${r.winner.selector} => ${r.winner.value}` : 'no winner');
  const p3 = [HTML, sec([]), VERSES, pankti('gs-bani-pankti')];
  const t3 = winningProp(css, 'text-align', p3);
  ok('Bani + everything OFF: still LEFT-aligned (unchanged)', !!t3.winner && t3.winner.value === 'left', t3.winner ? `${t3.winner.selector} => ${t3.winner.value}` : 'no winner');
}
{
  // Ang (SGGS) unchanged: centred, blue Gurmukhi, red Roman.
  const p = [HTML, secSggs, VERSES, pankti('gs-sggs-pankti')];
  const t = winningProp(css, 'text-align', p);
  ok('Ang: still CENTRED (unchanged)', !!t.winner && t.winner.value === 'center', t.winner ? `${t.winner.selector} => ${t.winner.value}` : 'no winner');
  const r = winningProp(css, 'color', [...p, roman]);
  ok('Ang: Roman still RED #b3261e (unchanged)', !!r.winner && r.winner.value === '#b3261e', r.winner ? `${r.winner.selector} => ${r.winner.value}` : 'no winner');
  const g = winningProp(css, 'color', [...p, gurmukhiBlue]);
  ok('Ang: Gurmukhi still BLUE #1a3fa0 (unchanged)', !!g.winner && g.winner.value === '#1a3fa0', g.winner ? `${g.winner.selector} => ${g.winner.value}` : 'no winner');
}

// ---------- runtime: the REAL popstate handler + the REAL showReaderBar ----------
// A fake top bar whose class list the real functions manipulate.
function makeBar(hidden) {
  const set = new Set(['gs-reading-topbar']);
  if (hidden) set.add('gs-topbar-hidden');
  return {
    _set: set,
    classList: { add: c => set.add(c), remove: c => set.delete(c), contains: c => set.has(c) },
    rebuild: hide => { set.clear(); set.add('gs-reading-topbar'); if (hide) set.add('gs-topbar-hidden'); },
  };
}
function runPopstate(srcApp, fromView, toView, startHidden) {
  const bar = makeBar(startHidden);
  const showBarFn = extractFunction(srcApp, 'function showReaderBar(){');
  const popLine = srcApp.split('\n').find(l => l.includes("addEventListener('popstate'"));
  const ctx = {
    state: { view: fromView, readView: 'kirtan' },
    bar,
    document: { querySelector: sel => (sel === '.gs-reading-topbar' ? bar : null) },
    window: { scrollY: 0, scrollTo: () => {}, addEventListener: (type, fn) => { ctx._handlers[type] = fn; } },
    _handlers: {},
    capture: () => {}, saveSearchPlace: () => {}, closeWord: () => {}, closeSettings: () => {},
    stopVoiceSearch: () => { ctx.calls.stop++; }, calls: { stop: 0 },
  };
  vm.createContext(ctx);
  const script = `let readerBarHidden=${startHidden};\n${showBarFn}\nfunction render(){ bar.rebuild(readerBarHidden); }\n${popLine}\n_handlers.popstate({state:{gsView:'${toView}'}});\nglobalThis.__result={view:state.view, hidden:readerBarHidden, barHidden:bar.classList.contains('gs-topbar-hidden'), stopCalls:calls.stop};`;
  vm.runInContext(script, ctx);
  return ctx.__result;
}
{
  ok('the real showReaderBar is found', !!extractFunction(app, 'function showReaderBar(){'));
  // THE fix: back button from Bani View Preferences to the reader.
  const r = runPopstate(app, 'viewprefs', 'reader', true);
  ok('back button viewprefs -> reader: view becomes reader', r.view === 'reader', `view=${r.view}`);
  ok('back button viewprefs -> reader: the bar is SHOWN again', r.hidden === false && r.barHidden === false, `hidden=${r.hidden} barHidden=${r.barHidden}`);
  ok('back button viewprefs -> reader: mic not touched', r.stopCalls === 0, `stopCalls=${r.stopCalls}`);
  // The bug, on pristine v2.2.87 code: the same back button leaves it hidden.
  const rb = runPopstate(rbApp, 'viewprefs', 'reader', true);
  ok('v2.2.87: the same back button LEFT the bar hidden (the bug)', rb.hidden === true && rb.barHidden === true, `hidden=${rb.hidden} barHidden=${rb.barHidden}`);
  // Negative: back button to Home does NOT show the bar.
  const h = runPopstate(app, 'viewprefs', 'home', true);
  ok('back button viewprefs -> home: the bar stays hidden', h.hidden === true && h.barHidden === true && h.view === 'home', `hidden=${h.hidden} view=${h.view}`);
  // Already shown: stays shown, no crash.
  const s = runPopstate(app, 'viewprefs', 'reader', false);
  ok('back button to reader when the bar is already shown: stays shown', s.hidden === false && s.barHidden === false, `hidden=${s.hidden} barHidden=${s.barHidden}`);
}

// ---------- runtime: the REAL readerScreen class expression ----------
// Evaluate the shipped template literal for every kind / layer combo.
{
  const line = app.split('\n').find(l => l.includes('gs-translit-on'));
  ok('readerScreen class line found', !!line);
  const lit = line.slice(line.indexOf('`') + 1, line.lastIndexOf('`'));
  const evalSection = (kind, translit, en, pa) => {
    const ctx = {
      isSggs: kind === 'ang', kind,
      state: { showTranslit: translit, showEn: en, showPa: pa },
      drawer: '', head: '', versesHTML: '',
    };
    vm.createContext(ctx);
    return vm.runInContext('`' + lit + '`', ctx);
  };
  const has = (html, cls) => html.includes(cls);
  ok('kirtan + translit ON: section gains BOTH classes', has(evalSection('kirtan', true, false, false), 'gs-translit-on') && has(evalSection('kirtan', true, false, false), 'gs-layers-on'));
  ok('kirtan + English ON (translit OFF): section gains layers-on only', !has(evalSection('kirtan', false, true, false), 'gs-translit-on') && has(evalSection('kirtan', false, true, false), 'gs-layers-on'));
  ok('kirtan + everything OFF: section gains NEITHER class', !has(evalSection('kirtan', false, false, false), 'gs-translit-on') && !has(evalSection('kirtan', false, false, false), 'gs-layers-on'));
  ok('bani + translit ON: section gains BOTH classes (unchanged)', has(evalSection('bani', true, false, false), 'gs-translit-on') && has(evalSection('bani', true, false, false), 'gs-layers-on'));
  ok('ang + translit ON: section gains NEITHER class (Ang unchanged)', !has(evalSection('ang', true, false, false), 'gs-translit-on') && !has(evalSection('ang', true, false, false), 'gs-layers-on'));
}

// ---------- carry-forwards ----------
// v2.2.87 (AI answer font 22px) intact
ok('v2.2.87 font selector intact', css.includes('.simple-card p.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,22px);color:var(--ink);touch-action:pan-y;}'));
ok('v2.2.87 BASE.aiFont still 22', app.includes('aiFont:22,'));
ok('v2.2.87 18->22 migration intact', app.includes('if(state.aiFont===18)state.aiFont=22;'));
// v2.2.86 (Sahaj/GGS two positions) intact
ok('v2.2.86 BASE.ggAng intact', app.includes('ang:1,ggAng:0,'));
ok('v2.2.86 loadRemote still writes ggAng', app.includes('if(extra.gg)state.ggAng=Number(id);'));
// v2.2.84 (highlight stays centered) intact
ok('v2.2.84 render() centers the highlighted line', app.includes("node?.scrollIntoView({block:'center'});return;}"));
// v2.2.83 (search Gurmukhi + Latin only) intact
ok('v2.2.83 no English in the result list', !app.includes('gs-result-en') && !app.includes('data-en-for'));
// v2.2.82 (Ask buttons, button decides) intact
ok('v2.2.82 aiQuestionLang still gone', !app.includes('aiQuestionLang'));
ok('v2.2.82 cloud call still sends the button language', app.includes('language:state.aiLang'));
// v2.2.81 (search keep-place + highlight) intact
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;'));
// v2.2.80 (Latin verses + elaboration) intact
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
// v2.2.79 (mic) intact - mic NOT touched in v2.2.88
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError plugin patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes("v2.2.79: tell the app the recognizer died"));
// v2.2.75 (back-button mic-stop) intact - the popstate handler still stops the mic leaving search/ask
ok('v2.2.75 popstate still stops the mic leaving search/ask', app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));

// ---------- no data changes; every offline file byte-identical to v2.2.87 ----------
{
  const rb = path.join(RB, 'offline');
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.87 (${n} files)`, diff === 0, `${diff} differ`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
