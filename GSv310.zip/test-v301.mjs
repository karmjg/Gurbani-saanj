/* v2.2.81 test — search keeps its place + highlight, reader keeps its
 * found-line highlight. Karamjit 2026-11-19, after the v2.2.80 mockups:
 * "when we search a word, then go to its meaning, or go into Settings
 * and change the English/Punjabi translation, then come back, it is not
 * at the exact same place - it changes. It should be exactly at that
 * same place, so when we come back we know 'this was my word'. And keep
 * its highlight - when we go to Settings and come back, the highlight
 * on the searched word gets erased."
 * Uses the REAL code from www/app.js (not copies), run in a Node vm
 * sandbox, plus static checks. Run: node test-v301.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

function extractFn(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 1, i = start + startMarker.length;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.81', vj.version === '2.2.81', vj.version);
  ok('version notes mention v2.2.81', vj.notes.includes('v2.2.81:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.81', pj.version === '2.2.81', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.81', nbc.includes('"version":"2.2.81"'));
}
ok('search state vars present', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;') && app.includes("let lastOpenedKey='';") && app.includes("let lastOpenedQuery='';"));
ok('saveSearchPlace defined', app.includes('function saveSearchPlace(){if(state.view===' + "'search')lastSearchScroll=window.scrollY;}"));
ok('showOfflineResults records the query', app.includes("if(target==='searchResults')lastSearchQuery=q;"));
ok('showOfflineResults clears the query on empty', app.includes("if(!q.trim()){out.innerHTML='';if(target==='searchResults')lastSearchQuery='';return}"));
ok('showOfflineResults awaits the fills', app.includes('await fillRaagHeaders($(target));await fillResultEn($(target));'));
ok('fillRaagHeaders returns a promise', app.includes('return Promise.all([...scope.querySelectorAll(' + "'[data-raag-for]')].map(async el=>{"));
ok('fillResultEn returns a promise', app.includes('return Promise.all([...scope.querySelectorAll(' + "'[data-en-for]')].map(async el=>{"));
ok('results markup computes opened', app.includes('const opened=lastOpenedKey===saveKey&&lastOpenedQuery&&lastOpenedQuery===lastSearchQuery;'));
ok('results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
ok('found-ang records the opened result', app.includes('lastOpenedKey=`${found.dataset.foundAng}:${highlightLine}`;lastOpenedQuery=lastSearchQuery;'));
ok('found-bani records the opened result', app.includes('lastOpenedKey=`bani:${foundBani.dataset.foundBani}:${highlightLine}`;lastOpenedQuery=lastSearchQuery;'));
ok('go() saves the search place', app.includes('saveSearchPlace();if(view!==' + "'reader'){readerBarHidden=true;"));
ok('go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('go() still resets highlightLine for other views', app.includes("if(view!=='reader'){readerBarHidden=true;if(view!=='viewprefs')highlightLine=-1;}"));
ok('go() captures the reader anchor on leaving', app.includes('if(state.view===' + "'reader'){if(state.readView==='sggs')capture();captureAnchor();}"));
ok('popstate saves the search place', app.includes('capture();saveSearchPlace();closeWord();closeSettings();'));
ok('clear button clears the remembered search', app.includes("lastSearchQuery='';lastOpenedKey='';lastOpenedQuery='';lastSearchScroll=0;"));
ok('attach() restores the search on return', app.includes("if(lastSearchQuery&&!input.value){"));
ok('attach() restores the exact scroll', app.includes("window.scrollTo({top:lastSearchScroll,behavior:'instant'});"));
ok('attach() guards the restore on the live query', app.includes("$('searchInput')?.value===lastSearchQuery"));
ok('opened-row CSS present', css.includes('.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}'));
ok('opened-row dark-text CSS present', css.includes('.gs-result-row.gs-opened .result,.gs-result-row.gs-opened .gs-result-ref,.gs-result-row.gs-opened .gs-result-en,.gs-result-row.gs-opened .gs-result-roman{color:#202a26!important;}'));
// v2.2.80 (Ask) intact
ok('v2.2.80 aiQuestionLang intact', app.includes("const aiQuestionLang=q=>/[\\u0A00-\\u0A7F]/.test(String(q||''))?'pa':'en';"));
ok('v2.2.80 cloud call still sends the question language', app.includes('language:aiQuestionLang(q)'));
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 AI pills still removed', !app.includes('data-ai-lang') || app.split('data-ai-lang').length <= 3);
// v2.2.79 (mic) intact
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
// no data changes: every offline file byte-identical to v2.2.80 rollback
{
  const rb = '/tmp/v301-rollback/v231/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.80 (${n} files)`, diff === 0, `${diff} differ`);
}
// styles.css differs ONLY by the opened-row rules (inserted mid-file)
{
  const rbCss = fs.readFileSync('/tmp/v301-rollback/v231/www/styles.css', 'utf8');
  const block = "\n/* v2.2.81: the search result last opened stays highlighted, so coming\n   back to the list shows which line it was - same pale yellow as the\n   reader's found-line highlight, with dark text for contrast in every\n   theme. */\n.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}\n.gs-result-row.gs-opened .result,.gs-result-row.gs-opened .gs-result-ref,.gs-result-row.gs-opened .gs-result-en,.gs-result-row.gs-opened .gs-result-roman{color:#202a26!important;}";
  ok('styles.css adds only the opened-row rules', css.includes(block) && css.replace(block, '') === rbCss, 'block not found or other diffs');
}

// ---------- runtime A: go() keeps highlight for viewprefs, saves scroll ----------
{
  const goFn = extractFn(app, 'function go(view,opts={}){');
  ok('go() function found', !!goFn);
  const saveFn = extractFn(app, 'function saveSearchPlace(){');
  ok('saveSearchPlace() found', !!saveFn);
  const ctx = {
    state: { view: 'search', readView: 'sggs', baniDrawer: false },
    homeEditing: false, highlightLine: 15, readerBarHidden: false,
    lastSearchQuery: '', lastSearchScroll: 0, lastOpenedKey: '', lastOpenedQuery: '',
    stopVoiceSearch: () => {}, capture: () => {}, captureAnchor: () => { ctx._anchorCalls++; },
    closeWord: () => {}, persist: () => {}, render: () => {},
    history: { pushState: () => {} },
    window: { scrollY: 1200, scrollTo: () => {} },
    _anchorCalls: 0,
  };
  vm.createContext(ctx);
  vm.runInContext(saveFn, ctx);
  vm.runInContext(goFn, ctx);
  // reader -> viewprefs : highlight KEPT, anchor captured
  ctx.state.view = 'reader'; ctx.highlightLine = 15; ctx._anchorCalls = 0;
  vm.runInContext(`go('viewprefs')`, ctx);
  ok("go('viewprefs') from Reader KEEPS the highlight", ctx.highlightLine === 15, `highlightLine=${ctx.highlightLine}`);
  ok("go('viewprefs') captures the reader anchor", ctx._anchorCalls === 1, `anchorCalls=${ctx._anchorCalls}`);
  // reader -> home : highlight RESET
  ctx.state.view = 'reader'; ctx.highlightLine = 15;
  vm.runInContext(`go('home')`, ctx);
  ok("go('home') from Reader RESETS the highlight", ctx.highlightLine === -1, `highlightLine=${ctx.highlightLine}`);
  // reader -> search : highlight RESET
  ctx.state.view = 'reader'; ctx.highlightLine = 15;
  vm.runInContext(`go('search')`, ctx);
  ok("go('search') from Reader RESETS the highlight", ctx.highlightLine === -1, `highlightLine=${ctx.highlightLine}`);
  // search -> home : scroll place SAVED
  ctx.state.view = 'search'; ctx.window.scrollY = 1200; ctx.lastSearchScroll = 0;
  vm.runInContext(`go('home')`, ctx);
  ok("go('home') from Search SAVES the scroll place", ctx.lastSearchScroll === 1200, `lastSearchScroll=${ctx.lastSearchScroll}`);
  // search -> reader : scroll place SAVED (tapping a result)
  ctx.state.view = 'search'; ctx.window.scrollY = 800; ctx.lastSearchScroll = 0;
  vm.runInContext(`go('reader')`, ctx);
  ok("go('reader') from Search SAVES the scroll place", ctx.lastSearchScroll === 800, `lastSearchScroll=${ctx.lastSearchScroll}`);
  // home -> search : scroll NOT overwritten (not leaving search)
  ctx.state.view = 'home'; ctx.window.scrollY = 0; ctx.lastSearchScroll = 1200;
  vm.runInContext(`go('search')`, ctx);
  ok("go('search') from Home does NOT overwrite the saved place", ctx.lastSearchScroll === 1200, `lastSearchScroll=${ctx.lastSearchScroll}`);
}

// ---------- runtime B: popstate (back button) saves the search place ----------
{
  const popLine = app.split('\n').find(l => l.includes("addEventListener('popstate'"));
  ok('popstate handler found', !!popLine);
  const saveFn = extractFn(app, 'function saveSearchPlace(){');
  const ctx = {
    state: { view: 'search', readView: 'sggs' },
    lastSearchScroll: 0,
    stopVoiceSearch: () => {}, capture: () => {}, closeWord: () => {}, closeSettings: () => {},
    render: () => {},
    window: { scrollY: 800, scrollTo: () => {}, addEventListener: (t, fn) => { ctx._h[t] = fn; } },
    _h: {},
  };
  vm.createContext(ctx);
  vm.runInContext(saveFn, ctx);
  vm.runInContext(popLine, ctx);
  const handler = ctx._h.popstate;
  ok('popstate handler registered', typeof handler === 'function');
  ctx.state.view = 'search'; ctx.window.scrollY = 800; ctx.lastSearchScroll = 0;
  handler({ state: { gsView: 'home' } });
  ok('back button Search -> Home SAVES the scroll place', ctx.lastSearchScroll === 800, `lastSearchScroll=${ctx.lastSearchScroll}`);
  ctx.state.view = 'search'; ctx.window.scrollY = 450; ctx.lastSearchScroll = 0;
  handler({ state: { gsView: 'reader' } });
  ok('back button Search -> Reader SAVES the scroll place', ctx.lastSearchScroll === 450, `lastSearchScroll=${ctx.lastSearchScroll}`);
}

// ---------- runtime C: markup highlights exactly the opened row ----------
{
  const fn = extractFn(app, 'function scriptureResultsMarkup(arr,{save=false}={}){');
  ok('scriptureResultsMarkup found', !!fn);
  const ctx = {
    state: { lang: 'pa', savedVerses: [] },
    lastSearchQuery: 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ', lastOpenedKey: '11:15', lastOpenedQuery: 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ',
    age: (pa) => pa, esc: s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'),
    t: k => k, showTranslit: true,
  };
  // scriptureResultsMarkup reads state.showTranslit via `state.showTranslit`
  ctx.state.showTranslit = true;
  vm.createContext(ctx);
  vm.runInContext(fn, ctx);
  const rows = [
    { src: 'sggs', ang: 1098, idx: 2, g: 'ਮੈ ਚਾਰੇ ਕੁੰਡਾ ਭਾਲੀਆ ਤੁਧੁ ਜੇਵਡੁ ਨ ਸਾਈਆ ॥', roman: 'mai. chaare kunddaa bhaaleea; tudh jevadd na. saaeea |', en: '' },
    { src: 'sggs', ang: 11, idx: 15, g: 'ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ ਤੁਧੁ ਜੇਵਡੁ ਅਵਰੁ ਨ ਕੋਈ ॥', roman: 'toon aad purakh aparanpar karataa jee; tudh jevadd. avar na koee |', en: '' },
    { src: 'sggs', ang: 74, idx: 15, g: 'ਤੁਧੁ ਜੇਵਡੁ ਅਵਰੁ ਨ ਭਾਲਿਆ ॥', roman: 'tudh jevadd; avar. na bhaaliaa |', en: '' },
  ];
  const html = vm.runInContext(`scriptureResultsMarkup(${JSON.stringify(rows)},{save:true})`, ctx);
  const openedCount = (html.match(/gs-result-row gs-opened/g) || []).length;
  ok('exactly ONE row is highlighted', openedCount === 1, `opened=${openedCount}`);
  // the highlighted row is the Ang 11 one: its data-raag-for is 11:15 and
  // its Gurmukhi line follows the gs-opened marker (age() stub returns
  // Punjabi, so the ref reads 'ਅੰਗ 11', not 'Ang 11').
  const seg = html.split('gs-result-row gs-opened')[1] || '';
  ok('the highlighted row is Ang 11 (the opened one)', seg.includes('data-raag-for="11:15"') && seg.includes('ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ'), `seg head: ${seg.slice(0, 120)}`);
  ok('Ang 1098 row is NOT highlighted', !html.split('data-raag-for="1098:2"')[0].includes('gs-opened') || html.indexOf('gs-opened') > html.indexOf('data-raag-for="1098:2"'));
  // different query: no highlight at all
  ctx.lastOpenedQuery = 'ਸਹਗ';
  const html2 = vm.runInContext(`scriptureResultsMarkup(${JSON.stringify(rows)},{save:true})`, ctx);
  ok('no highlight when the query differs', !html2.includes('gs-opened'));
  // nothing opened: no highlight
  ctx.lastOpenedKey = ''; ctx.lastOpenedQuery = 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ';
  const html3 = vm.runInContext(`scriptureResultsMarkup(${JSON.stringify(rows)},{save:true})`, ctx);
  ok('no highlight when nothing was opened', !html3.includes('gs-opened'));
}

// ---------- runtime D: showOfflineResults awaits the fills ----------
// The fills are async (raag + English come from Ang files). If the search
// did not await them, the rows would still be growing when the caller
// restores the scroll - the restored place would drift. Prove the await:
// after `await showOfflineResults(...)` both fills have COMPLETED.
{
  const fn = extractFn(app, "async function showOfflineResults(q,target='searchResults',save=false){");
  ok('showOfflineResults found', !!fn);
  const ctx = {
    searchSeq: 0, searchMode: 'auto', lastSearchQuery: '',
    $: (id) => ctx._els[id],
    age: (pa) => pa, t: k => k,
    window: {
      GS_SCRIPTURE_SEARCH: {
        query: async () => [{ src: 'sggs', ang: 11, idx: 15, g: 'ਤੂੰ ਆਦਿ ਪੁਰਖੁ ਅਪਰੰਪਰੁ ਕਰਤਾ ਜੀ ਤੁਧੁ ਜੇਵਡੁ ਅਵਰੁ ਨ ਕੋਈ ॥', roman: 'x', en: '' }],
      },
    },
    scriptureResultsMarkup: () => '<div class="gs-result-row"><span data-raag-for="11:15"></span><span data-en-for="11:15"></span></div>',
    fillRaagHeaders: async () => { await new Promise(r => setTimeout(r, 5)); ctx._raagDone = true; },
    fillResultEn: async () => { await new Promise(r => setTimeout(r, 5)); ctx._enDone = true; },
    _els: {}, _raagDone: false, _enDone: false,
    setTimeout,
  };
  ctx._els.searchResults = { innerHTML: '', querySelectorAll: () => [] };
  vm.createContext(ctx);
  vm.runInContext(fn, ctx);
  const p = vm.runInContext(`showOfflineResults('ਤੁਧੁ ਜੇਵਡੁ ਨਾ','searchResults',true)`, ctx);
  await p;
  ok('after showOfflineResults resolves, the raag fill has COMPLETED', ctx._raagDone === true);
  ok('after showOfflineResults resolves, the English fill has COMPLETED', ctx._enDone === true);
  ok('showOfflineResults recorded the query', ctx.lastSearchQuery === 'ਤੁਧੁ ਜੇਵਡੁ ਨਾ');
  // empty query clears the remembered query
  const p2 = vm.runInContext(`showOfflineResults('','searchResults',true)`, ctx);
  await p2;
  ok('empty query clears the remembered query', ctx.lastSearchQuery === '');
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
