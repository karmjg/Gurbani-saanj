/* v2.2.82 test — keep the Punjabi/English buttons on the Ask screen;
 * the SELECTED button decides the answer language. Karamjit 2026-11-19:
 * "we have to keep those buttons... if I am typing in English but I want
 * the answer in Punjabi it should give me in a Punjabi answer... 'Hukam
 * ki hai' it's English alphabet but I'm trying to ask in Punjabi right
 * so it's gonna give me a Punjabi answer because I select Punjabi."
 * Roman letters can be Punjabi or English, so only the explicit button
 * choice can tell. Uses the REAL code from www/app.js (not copies), run
 * in a Node vm sandbox, plus static checks. Run: node test-v302.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

function extractFn(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 1, i = start + startMarker.length;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
const md5 = p => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');

// ---------- static checks: version ----------
{
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json reads 2.2.82', vj.version === '2.2.82', vj.version);
  ok('version notes mention v2.2.82', vj.notes.includes('v2.2.82:'));
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json reads 2.2.82', pj.version === '2.2.82', pj.version);
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js reads 2.2.82', nbc.includes('"version":"2.2.82"'));
}

// ---------- static checks: v2.2.82 (buttons restored, button decides) ----------
ok('aiQuestionLang detector is GONE', !app.includes('aiQuestionLang'));
ok('v2.2.82 comment present', app.includes('v2.2.82: the AI answer follows the SELECTED'));
ok('language pills restored in askScreen', app.includes("data-ai-lang=\"${k}\""));
ok('pills row sits after the depth pills row', (() => {
  const dp = app.indexOf("data-depth=\"${k}\"");
  const lp = app.indexOf("data-ai-lang=\"${k}\"");
  return dp !== -1 && lp !== -1 && lp > dp && lp - dp < 400;
})());
ok('pills highlight the selected language', app.includes("class=\"${state.aiLang===k?'sel':''}\""));
ok('pills offer Punjabi and English', app.includes("['pa','ਪੰਜਾਬੀ'],['en','English']"));
ok('cloud call sends the BUTTON language', app.includes('language:state.aiLang'));
ok('cloud call no longer sends the detected language', !app.includes('language:aiQuestionLang(q)'));
ok('askOpenAI answers in the BUTTON language', app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('askOpenAI no longer uses the detector', !app.includes("aiQuestionLang(question)"));
ok('[data-ai-lang] click handler still present', app.includes("e.target.closest('[data-ai-lang]')"));
ok('click handler sets state.aiLang + manual flag', app.includes("state.aiLang=aiLang.dataset.aiLang;state.aiLangManual=true;persist();"));

// ---------- v2.2.81 (search keep-place + highlight) intact ----------
ok('v2.2.81 search state vars intact', app.includes("let lastSearchQuery='';") && app.includes('let lastSearchScroll=0;') && app.includes("let lastOpenedKey='';") && app.includes("let lastOpenedQuery='';"));
ok('v2.2.81 go() keeps highlightLine for viewprefs', app.includes("if(view!=='viewprefs')highlightLine=-1;"));
ok('v2.2.81 go() saves the search place', app.includes('saveSearchPlace();if(view!==' + "'reader'){readerBarHidden=true;"));
ok('v2.2.81 results markup adds gs-opened', app.includes("gs-result-row${opened?' gs-opened':''}"));
ok('v2.2.81 opened-row CSS intact', css.includes('.gs-result-row.gs-opened{background:#fff2a8;border-radius:10px;padding:8px 10px;border-bottom-color:transparent;}'));
// ---------- v2.2.80 (Latin verses + elaboration) intact ----------
ok('v2.2.80 matches still carry roman', app.includes("roman:m.roman||''"));
ok('v2.2.80 Latin prompt intact', app.includes('then write the same verse in Latin (Roman) letters exactly as given'));
ok('v2.2.80 detail output still 1200 tokens', app.includes('max_tokens:1200'));
// ---------- v2.2.79 (mic) intact — mic NOT touched in v2.2.82 ----------
ok('v2.2.79 dead-start retry intact', app.includes('deadStartRetries<1') && app.includes('run.segStartedAt=Date.now()'));
ok('v2.2.79 onError patch intact', fs.readFileSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs'), 'utf8').includes('v2.2.79: tell the app the recognizer died'));
ok('mic still one session per tap (no restart loop)', !app.includes('for(;;)') || !app.slice(app.indexOf('startVoiceSearch'), app.indexOf('startVoiceSearch') + 6000).includes('for(;;)'));
// ---------- no data changes / no CSS changes ----------
{
  const rb = '/tmp/v302-rollback/www/offline';
  let diff = 0, n = 0;
  const walk = d => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const p = path.join(d, e.name); if (e.isDirectory()) walk(p); else { n++; const rel = path.relative(path.join(ROOT, 'www/offline'), p); const rp = path.join(rb, rel); if (!fs.existsSync(rp) || md5(p) !== md5(rp)) diff++; } } };
  walk(path.join(ROOT, 'www/offline'));
  ok(`every offline file byte-identical to v2.2.81 (${n} files)`, diff === 0, `${diff} differ`);
  const rbCss = fs.readFileSync('/tmp/v302-rollback/www/styles.css', 'utf8');
  ok('styles.css byte-identical to v2.2.81 (no CSS change)', css === rbCss);
}

// ---------- runtime A: [data-ai-lang] click sets the language ----------
{
  // Extract the handler line (it lives inside the main click handler).
  const line = app.split('\n').find(l => l.includes("e.target.closest('[data-ai-lang]')"));
  ok('[data-ai-lang] handler line found', !!line);
  const ctx = {
    state: { aiLang: 'en', aiLangManual: false },
    persist: () => {},
    document: {
      querySelectorAll: () => [{ dataset: { aiLang: 'pa' }, classList: { toggle: (c, on) => { ctx._toggles.push(on); } } }, { dataset: { aiLang: 'en' }, classList: { toggle: (c, on) => { ctx._toggles.push(on); } } }],
    },
    _toggles: [],
  };
  vm.createContext(ctx);
  // The handler line ends with `return` (it lives inside the main click
  // handler), so run it wrapped in a function that receives the event.
  const runHandler = (ev) => {
    ctx.e = ev;
    vm.runInContext(`(function(e){ ${line} })(e)`, ctx);
  };
  // Simulate a tap on the Punjabi pill: e.target.closest returns an
  // element whose dataset.aiLang is 'pa'.
  runHandler({ target: { closest: () => ({ dataset: { aiLang: 'pa' } }) } });
  ok("tapping Punjabi sets state.aiLang='pa'", ctx.state.aiLang === 'pa', `aiLang=${ctx.state.aiLang}`);
  ok('tapping a pill sets aiLangManual=true', ctx.state.aiLangManual === true);
  // Now tap the English pill.
  runHandler({ target: { closest: () => ({ dataset: { aiLang: 'en' } }) } });
  ok("tapping English sets state.aiLang='en'", ctx.state.aiLang === 'en', `aiLang=${ctx.state.aiLang}`);
  // A tap elsewhere (closest returns null) leaves the language alone.
  runHandler({ target: { closest: () => null } });
  ok('a tap elsewhere leaves the language alone', ctx.state.aiLang === 'en');
}

// ---------- runtime B: askScreen renders the pills with the right 'sel' ----------
{
  const fn = extractFn(app, 'function askScreen(){');
  ok('askScreen found', !!fn);
  const ctx = {
    state: { aiLang: 'pa', depth: 'detail', lang: 'pa', aiApiKey: '', aiEndpoint: '', questions: [] },
    t: k => ({ askTitle: 'Ask Guru Granth Sahib', askHint: 'Ask any question...', short: 'Simple', detail: 'Detailed', deep: 'In depth', askButton: 'Ask' }[k] || k),
    age: (pa) => pa,
    AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev',
    renderQA: () => '',
  };
  vm.createContext(ctx);
  vm.runInContext(fn, ctx);
  const htmlPa = vm.runInContext('askScreen()', ctx);
  ok('askScreen renders the Punjabi pill', htmlPa.includes('data-ai-lang="pa"'));
  ok('askScreen renders the English pill', htmlPa.includes('data-ai-lang="en"'));
  ok("with aiLang='pa', the Punjabi pill has 'sel'", htmlPa.includes('data-ai-lang="pa" class="sel"'));
  ok("with aiLang='pa', the English pill does NOT have 'sel'", !htmlPa.includes('data-ai-lang="en" class="sel"'));
  ctx.state.aiLang = 'en';
  const htmlEn = vm.runInContext('askScreen()', ctx);
  ok("with aiLang='en', the English pill has 'sel'", htmlEn.includes('data-ai-lang="en" class="sel"'));
  ok("with aiLang='en', the Punjabi pill does NOT have 'sel'", !htmlEn.includes('data-ai-lang="pa" class="sel"'));
  // The pills sit in their own row, right after the depth pills row.
  const depthAt = htmlEn.indexOf('data-depth="detail"');
  const langAt = htmlEn.indexOf('data-ai-lang="pa"');
  ok('language pills render after the depth pills', depthAt !== -1 && langAt !== -1 && langAt > depthAt);
}

// ---------- runtime C: the button language is what the AI is sent ----------
// The cloud call builds its body from state.aiLang. Prove it by running
// the exact JSON.stringify expression from answerQuestion with a stubbed
// fetch that captures the body.
{
  const ctx = {
    state: { aiLang: 'pa', depth: 'detail' },
    entry: { matches: [{ g: 'x', roman: 'y' }] },
    history: [],
    q: 'Hukam ki hai?',
    legacyToken: 'tok',
    legacyEndpoint: 'https://gurbani-ai.karmjguber.workers.dev',
    _captured: null,
  };
  vm.createContext(ctx);
  const expr = `JSON.stringify({question:q,depth:state.depth,language:state.aiLang,verses:entry.matches,history})`;
  const bodyPa = JSON.parse(vm.runInContext(expr, ctx));
  ok("Roman Punjabi question + Punjabi button sends language='pa'", bodyPa.language === 'pa', `language=${bodyPa.language}`);
  ctx.state.aiLang = 'en';
  ctx.q = 'What is hukam?';
  const bodyEn = JSON.parse(vm.runInContext(expr, ctx));
  ok("English question + English button sends language='en'", bodyEn.language === 'en', `language=${bodyEn.language}`);
  // The key case: the SAME Roman question, but the button decides.
  ctx.q = 'Hukam ki hai?';
  ctx.state.aiLang = 'pa';
  const bodyPa2 = JSON.parse(vm.runInContext(expr, ctx));
  ok("same Roman question + Punjabi button still sends 'pa'", bodyPa2.language === 'pa');
  ctx.state.aiLang = 'en';
  const bodyEn2 = JSON.parse(vm.runInContext(expr, ctx));
  ok("same Roman question + English button sends 'en'", bodyEn2.language === 'en');
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
