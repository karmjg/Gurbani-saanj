/* Gurbani Saanj v2.2.33 — ONE change (includes ALL of v2.2.32).
 * Voice search now listens CONTINUOUSLY: the native recognizer stops on its
 * own after a pause, so each stop only ends the current segment — the app
 * restarts it and accumulates every word spoken (at least 5-6 words, up to
 * the 15s safety cap), instead of stopping after the first ~3 words.
 * Tapping X stops the mic for real (it no longer restarts listening after
 * clearing — tap the mic to speak again). Everything else is unchanged.
 * The Web Speech fallback gets the same accumulate + restart behavior.
 * Run: node test-v253.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.33', vj.version === '2.2.33');
ok('package.json is 2.2.33', pj.version === '2.2.33');
ok('version notes mention v2.2.33 + continuous listening + X stops mic',
  vj.notes.includes('v2.2.33:') && vj.notes.includes('listens continuously') && vj.notes.includes('stops the mic for real'),
  vj.notes.slice(-200));

// ---- 1. Static wiring for the fix ----
ok('voiceStopRequested flag exists', app.includes('let voiceStopRequested=false;'));
ok('partial listener accumulates into heard.seg/parts',
  app.includes('run.heard.seg') && app.includes('run.heard.parts') && app.includes('run.heard.text=[...run.heard.parts,run.heard.seg]'));
ok('listener ends a SEGMENT on stop (no run.finish)', app.includes('run.endSegment()') && !app.includes('run.finish()'));
ok('beginSegment + auto-restart loop present',
  app.includes('const beginSegment=async()=>') && app.includes('if(!(await beginSegment()))break;'));
ok('resetVoiceNow flags manual stop', app.includes('voiceStopRequested=true;') && app.includes('if(run)run.manualStopped=true;'));
ok('runEnded guard checks safety+manual+flag+current',
  app.includes('const runEnded=()=>run.safetyStopped||run.manualStopped||voiceStopRequested||voiceRun!==run;'));
ok('15s safety cap still 15000', app.includes('},15000);'));
ok('4s no-heard timer still present', app.includes('noHeardTimer') && app.includes('},4000);'));
ok('pa-IN -> en-US fallback still present', app.includes("native.start(opts('pa-IN'))") && app.includes("native.start(opts('en-US'))"));
ok('maxResults:5 + partialResults:true unchanged', app.includes('maxResults:5') && app.includes('partialResults:true'));
ok('X handler no longer restarts the mic', (() => {
  const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick'));
  return !!l && !l.includes('startVoiceSearch');
})());
ok('web fallback restarts on onend + accumulates',
  app.includes('rec.onend=()=>{') && app.includes("try{rec.start();}catch(e){finish(best);}"));
ok('web fallback respects manual stop', app.includes('if(finished||voiceStopRequested)return;'));

// ---- 2. Voice VM harness (fake clock + stubbed recognizers) ----
const _voiceLines = app.split('\n');
const _voiceStart = _voiceLines.findIndex(l => l.startsWith('let searchVoiceBusy=false;'));
const _voiceEnd = _voiceLines.findIndex((l, i) => i > _voiceStart && l.startsWith('// Settings "Test microphone"'));
const voiceSlice = _voiceLines.slice(_voiceStart, _voiceEnd).join('\n');
ok('voice slice extracted (searchVoiceBusy..startVoiceSearch)',
  voiceSlice.includes('async function startVoiceSearch') && voiceSlice.includes('function resetVoiceNow'));

function makeClock() {
  let now = 0, next = 1; const timers = new Map();
  const setTimeout = (fn, ms, ...args) => { const id = next++; timers.set(id, { fn, at: now + Math.max(0, ms || 0), args }); return id; };
  const clearTimeout = id => { timers.delete(id); };
  const advance = ms => {
    const end = now + ms; let guard = 0;
    while (guard++ < 20000) {
      let best = null, bestAt = Infinity;
      for (const [id, t] of timers) { if (t.at <= end && t.at < bestAt) { best = id; bestAt = t.at; } }
      if (best === null) break;
      now = bestAt; const t = timers.get(best); timers.delete(best); t.fn(...t.args);
    }
    now = end;
  };
  return { setTimeout, clearTimeout, advance, pending: () => timers.size, get now() { return now; } };
}
async function drive(clock, ms, step = 15) {
  const target = clock.now + ms;
  while (clock.now < target) {
    clock.advance(Math.min(step, target - clock.now));
    await new Promise(r => setImmediate(r));
    await new Promise(r => setImmediate(r));
  }
}
function fakeEl() { return { disabled: false, textContent: '', value: '', classList: { toggle() {}, add() {}, remove() {} }, dispatchEvent() {} }; }

// Stub native recognizer. script: array of utterances; each is an array of
// growing partial strings, or {delay, partials} for a late utterance.
// A start() with no scripted utterance emits 'started' and stays listening.
function makeStubNative(clock, script, opts = {}) {
  const listeners = {};
  const calls = { start: [], stop: 0 };
  let startCount = 0;
  const emit = (ev, data) => { (listeners[ev] || []).forEach(cb => { try { cb(data); } catch (e) { console.error('listener error', e); } }); };
  const stub = {
    available: async () => ({ available: true }),
    checkPermissions: async () => ({ speechRecognition: opts.perm || 'granted' }),
    requestPermissions: async () => ({ speechRecognition: opts.requestPerm || 'granted' }),
    addListener: (ev, cb) => { (listeners[ev] = listeners[ev] || []).push(cb); return Promise.resolve(); },
    start: async (o) => {
      calls.start.push(o && o.language);
      const idx = startCount++;
      if (opts.failPaIN && o && o.language === 'pa-IN') throw new Error('pa-IN unavailable');
      const raw = script[idx] || [];
      const delay = Array.isArray(raw) ? 0 : (raw.delay || 0);
      const utt = Array.isArray(raw) ? raw : (raw.partials || []);
      clock.setTimeout(() => emit('listeningState', { status: 'started' }), 5);
      utt.forEach((p, i) => { clock.setTimeout(() => emit('partialResults', { matches: [p] }), delay + 10 + i * 15); });
      if (utt.length) clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), delay + 10 + utt.length * 15 + 10);
      return;
    },
    stop: () => { calls.stop++; emit('listeningState', { status: 'stopped' }); return Promise.resolve(); },
    _calls: calls,
  };
  return stub;
}

function makeNativeCtx(script, opts = {}) {
  const clock = makeClock();
  const stub = makeStubNative(clock, script, opts);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl() };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { GS_SPEECH: stub, GS_NATIVE_UPDATES: { isNative: true } },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, stub, input, els, state, sandbox };
}
function readRun(ctx) {
  vm.runInContext('this.__r={run:voiceRun,busy:searchVoiceBusy,stopReq:voiceStopRequested};', ctx);
  return ctx.__r;
}

// Fake Web SpeechRecognition (for the fallback path). One instance; start()
// is called repeatedly on it, each call playing script[idx].
function makeFakeSR(clock, script) {
  const shared = { instances: [] };
  class FakeSR {
    constructor() { this.lang = ''; this.interimResults = false; this.maxAlternatives = 0; this.onresult = null; this.onerror = null; this.onend = null; this._n = 0; shared.instances.push(this); }
    start() {
      const idx = this._n++;
      const utt = script[idx] || [];
      utt.forEach((p, i) => { clock.setTimeout(() => { if (this.onresult) this.onresult({ results: [[{ transcript: p }]] }); }, 10 + i * 15); });
      if (utt.length) clock.setTimeout(() => { if (this.onend) this.onend(); }, 10 + utt.length * 15 + 10);
    }
    stop() { clock.setTimeout(() => { if (this.onend) this.onend(); }, 5); }
  }
  return { FakeSR, shared };
}
function makeWebCtx(script) {
  const clock = makeClock();
  const sr = makeFakeSR(clock, script);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl() };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { SpeechRecognition: sr.FakeSR },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, sr, input, els, state, sandbox };
}

// ---- 3. Behavioral voice tests (async, fake clock) ----
let p;
// (a) Auto-restart accumulates ALL words across segments (the reported bug)
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(a) auto-restart: all 6 words in the input after 2 segments',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(a) auto-restart: recognizer started 3 times (initial + 2 restarts)',
    t.stub._calls.start.length === 3, JSON.stringify(t.stub._calls.start));
  await drive(t.clock, 17000);
  ok('(a) run ends at the 15s safety cap with the 6 words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ' && t.stub._calls.start.length === 3,
    `settled=${settled} value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(a) run cleaned up after safety (voiceRun null, not busy)',
    r.run === null && r.busy === false, JSON.stringify(r));
}
// (b) Manual stop (X / resetVoiceNow) — no restart after it
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(b) before stop: 3 words heard, recognizer restarted once',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ' && t.stub._calls.start.length === 2,
    `value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  vm.runInContext('resetVoiceNow()', t.ctx);
  const startsAtStop = t.stub._calls.start.length;
  await drive(t.clock, 3000);
  ok('(b) manual stop: no restart after X (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(b) manual stop: the 3 words stay in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(b) run resolves after manual stop (safety ends the wait)',
    settled === true, `settled=${settled}`);
}
// (c) 15s safety cap ends the run
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1000);
  const r1 = readRun(t.ctx);
  ok('(c) run still listening before the cap (voiceRun set, busy)',
    r1.run !== null && r1.busy === true, JSON.stringify({ run: !!r1.run, busy: r1.busy }));
  await drive(t.clock, 17000);
  ok('(c) run ends at the 15s safety cap',
    settled === true, `settled=${settled}`);
  const r2 = readRun(t.ctx);
  ok('(c) run cleaned up after cap (voiceRun null, not busy)',
    r2.run === null && r2.busy === false, JSON.stringify(r2));
  ok('(c) no restart after the cap (start count stays 2)',
    t.stub._calls.start.length === 2, `starts=${t.stub._calls.start.length}`);
  ok('(c) status is Done after the cap',
    t.els.voiceStatus.textContent.includes('Done.'), JSON.stringify(t.els.voiceStatus.textContent));
}
// (d) 4s no-heard notice, then recovery when words arrive
{
  const t = makeNativeCtx([
    { delay: 5000, partials: ['ਸਤਿਨਾਮੁ'] },
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 4500);
  ok('(d) 4s no-heard notice fires when nothing is heard',
    t.els.voiceStatus.textContent.includes('not hearing'),
    JSON.stringify(t.els.voiceStatus.textContent));
  await drive(t.clock, 1500);
  ok('(d) status returns to Listening when words arrive',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(d) the word is captured after the notice',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (e) Permission denied + pa-IN -> en-US fallback
{
  const t = makeNativeCtx([], { perm: 'denied', requestPerm: 'denied' });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 500);
  ok('(e1) permission denied: status explains it',
    t.els.voiceStatus.textContent.includes('permission was denied'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(e1) permission denied: recognizer never started',
    t.stub._calls.start.length === 0, `starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(e1) permission denied: mic button re-enabled, not busy',
    r.busy === false && t.els.voiceBtn.disabled === false, JSON.stringify({ busy: r.busy, disabled: t.els.voiceBtn.disabled }));
}
{
  const t = makeNativeCtx([[], ['ਸਤਿਨਾਮੁ']], { failPaIN: true });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 800);
  ok('(e2) pa-IN fails -> en-US fallback is tried',
    t.stub._calls.start[0] === 'pa-IN' && t.stub._calls.start[1] === 'en-US',
    JSON.stringify(t.stub._calls.start));
  ok('(e2) fallback run hears words on the en-US start',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) Web Speech fallback accumulates across onend restarts
{
  const t = makeWebCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(f) web fallback: all 6 words after 2 onend restarts',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(f) web fallback: recognizer started 3 times',
    t.sr.shared.instances[0]._n === 3, `starts=${t.sr.shared.instances[0]._n}`);
  await drive(t.clock, 17000);
  ok('(f) web fallback: run ends at the 15s cap with the 6 words',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// ---- 4. v2.2.32 regressions (static — the full suite also runs in test-v252) ----
ok('regression v2.2.32: AI language follows app language (aiLangManual sync)',
  app.includes('aiLangManual') && app.includes("if(!state.aiLangManual)state.aiLang=state.lang;"));
ok('regression v2.2.32: transliteration in search results',
  app.includes('gs-result-roman') && ss.includes("roman:String(roman||'')"));
ok('regression v2.2.32: cloud AI by default',
  app.includes("AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev'"));
ok('regression v2.2.31: elaborate prompt + Dasam Granth in worker',
  worker.includes('Dasam Granth') && worker.includes('1500') && worker.includes('total essence'));
ok('regression v2.2.30: Hindi absent, English in search results, font slider',
  !app.includes('showHi') && app.includes('gs-result-en') && app.includes('fontSlider'));
ok('regression v2.2.28: search source labels',
  app.includes('gs-result-bani-tag') && app.includes('Dasam Granth'));
ok('regression v2.2.27: reader top bar hide/show',
  app.includes('barScrollDecision') && app.includes('readerBarHidden'));
ok('regression v2.2.26: centered Bani headings, pinch Ask-only',
  css.includes('text-align:center') && app.includes('pinchFont') && app.includes('pinchDist'));
ok('regression: voice permission flow (fast path + listeners once)',
  app.includes('voicePermGranted') && app.includes('ensureVoiceListeners'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
