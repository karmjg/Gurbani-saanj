# Gurbani Saanjh v1.6.1 — Offline Text Edition (private, non-profit trial)

This package is **the Android app source**, not an APK and not a populated scripture dataset. The GitHub Actions build downloads and bundles **all 1,430 Angs of Sri Guru Granth Sahib Ji** and the **complete available BaniDB Sundar Gutka Bani catalogue** into the APK. The text is then read locally; a phone needs **no internet**, even on first launch.

**Build integrity:** the GitHub Action fails rather than releasing an APK if any Ang, listed Bani or one of the seven Nitnem entries has missing text. Only a successfully completed GitHub Actions artifact should be installed.

**Scope:** Your 75+ additional Anek Baaniyaan names remain listed, but entries not available within the BaniDB Sundar Gutka corpus are labelled unavailable rather than filled with made-up or partial text. The Damdami Taksal Rehras wording is NOT independently verified. Work on that edition, accurate Vishraam and scholarly translations remains.

- Settings → Reading → Line spacing → Compact / Standard / Spacious.
- Reading view: Gurbani only, no app toolbar or bottom menu.
- Audio and MP3 import: removed for now, as requested.
- English-letter transliteration and Punjabi/English meanings: shown when present in the source data; unverified entries remain blank, not invented.
- AI Q&A is currently a prototype, not a live service.
- Source/licensing details in `SOURCE_AND_LICENSE.md`. BaniDB's NPOSL licence is for non-profit use; do not commercially launch this dataset without legal review/permission.

**How to build:** Upload this ZIP to the repo root on `main`. In `.github/workflows/android-apk.yml` replace ZIP filename with `Gurbani_Saanjh_App_Source_v1.6.1.zip`. The existing workflow can stay otherwise unchanged: `npm run build:web` now generates the offline library automatically. An improved workflow is also included inside this ZIP with a separate validation step. Commit; GitHub Actions generates the signed APK with the existing four signing secrets.
