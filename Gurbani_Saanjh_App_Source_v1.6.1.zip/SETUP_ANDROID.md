# v1.6.1 GitHub build — simple steps
1. Upload `Gurbani_Saanjh_App_Source_v1.6.1.zip` to the root of `https://github.com/karmjg/Gurbani-saanj` on branch `main`.
2. Edit the existing `.github/workflows/android-apk.yml` line to `zip='Gurbani_Saanjh_App_Source_v1.6.1.zip'`. No other workflow edits are needed because `npm run build:web` automatically downloads scripture at build time. You may optionally use the updated workflow inside the ZIP for a dedicated download/validation step.
3. Commit to `main`. In Actions → Build Gurbani Saanjh Android APK → Run workflow on `main`.
4. The `Build complete offline Gurbani library` step must succeed and print `SUCCESS: 1430 / 1430 Angs` and the number of available Banis. If it fails, DO NOT install an older APK assuming it contains full text.
5. Download the signed APK from the `Gurbani-Saanjh-Android-APK` artifact of the GREEN successful workflow. Install without uninstalling your current app (same signing key and app id).
6. Put phone in Airplane mode and test Japji Sahib, other Nitnem, Ang 1, Ang 1430 and Anek Baaniyaan.

No MP3 is included. Keep your signing keystore secrets private. The app build requires access to the BaniDB website on the GitHub Actions runner, but the installed APK requires no network for scripture reading.
