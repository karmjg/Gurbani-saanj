/* Gurbani Saanjh v2.2.7 — offline Sikh scripture reading (Capacitor/WebView).
   Bani layout + iGranth-style GGS search.
   Plain HTML/CSS/JS by design, so GitHub source stays easy to update.
   Data contract: www/offline/{ang,bani}/*.json lines {id,g,roman,en,pa},
   vishraam.json marks, kosh.json, kosh-stems.json, kirtan-shabads.json.
*/
(()=>{
'use strict';
const CONTENT=window.GS_DATA;
const CATALOG=window.GS_CATALOG||[];
const VERSES=window.GS_VERSES;
const esc=VERSES.esc;
let catalogFilter='';
let activeRemote=null;
let remoteBusy=false;
let onlineCatalog=[];
const APP_VERSION=(window.GS_BUILD?.version||'2.2.0');
let isApplyingUpdate=false;
let installPrompt=null;
const KEY='gurbani-saanjh-trial-v1'; // Keep unchanged: older reading progress migrates.
const AI_DEFAULT_ENDPOINT='https://api.openai.com/v1/chat/completions';
const AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev';
const AI_CLOUD_TOKEN='jq6agiOlBkJygw7bqRWr9t6JLfJ-pRvyXXLcDkBQfO4';
const AI_SYSTEM_PROMPT='You are answering questions about Sikh scripture. Answer ONLY from the provided passages, which may come from Sri Guru Granth Sahib Ji or from Dasam Granth Banis. Quote 2-3 relevant verses, one at a time: quote the first verse exactly as given, in Gurmukhi, then explain that verse fully, in plain simple words — say what the verse teaches, why it matters, how it answers the user\'s question, and how it applies to a person\'s life. Then quote the next verse and explain it the same full way. Never quote all the verses first and explain them afterwards. After the last verse and its explanation, give the total essence (ਸਾਰ) of what the passages say on this topic — a full synthesis in your own clear words, as if explaining to a friend: direct, step by step, no flowery language, no jargon. A short real-world example is allowed ONLY to illustrate what a quoted verse means — the example must flow from that verse itself, never from outside knowledge. Never explain a verse before quoting it. Cite every verse with its source: a Guru Granth Sahib verse as [Sri Guru Granth Sahib Ji, Ang N], a Dasam Granth verse as [Dasam Granth — Bani name] (for example [Dasam Granth — Jaap Sahib]); never cite a Guru Granth Sahib verse as Dasam Granth, and never cite a Dasam Granth verse as Guru Granth Sahib. Answer ONLY from these passages: never from any other scripture, author, book, or your own general knowledge. Never fabricate a verse, an Ang number, or a Bani name. Cite the source for every claim you make. If the passages do not contain the answer, say so plainly in one sentence and do not guess. Match the requested explanation level (simple for a child, or in depth).';
const BASE={bookCursors:{},pageTurnSpeed:'slow',savedVerses:[],aiEndpoint:'',aiAccessToken:'',lineLayout:'compact',ang:1,vishraams:false,lang:'pa',meaningLang:'pa',kbLang:'pa',readingScript:'gurmukhi',meanings:false,theme:'light',mode:'scroll',font:24,uiScale:1.12,raisedHeadings:true,spacing:1.82,fontStyle:'serif',margin:'normal',
  view:'home',readView:'sggs',verse:0,verseOffset:0,page:0,hasProgress:false,kirtanId:'kirtan-lakh',
  favorites:[],homeOrder:['reader','nitnem','catalog','kirtan','ask'],filter:'all',depth:'detail',questions:[],
  nightMode:false,showTranslit:true,showEn:false,showPa:false,showArth:false,baniTextSize:'normal',fontColor:'black',layerScale:0.8,tone:0,
  aiApiKey:'',aiApiEndpoint:'',aiModel:'gpt-4o-mini',aiLang:'pa',aiLangManual:false,aiFont:18,searchHistory:[],keyboardOn:true,baniDrawer:false,
  daily:{source:'sggs',order:'sequential',amount:2,time:'08:00',enabled:false,startDate:''},hukamnama:null};
let stored={};try{stored=JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch{}
const state={...BASE,...stored,daily:{...BASE.daily,...(stored.daily||{})},favorites:Array.isArray(stored.favorites)?stored.favorites:[],questions:Array.isArray(stored.questions)?stored.questions.slice(-12):[],savedVerses:Array.isArray(stored.savedVerses)?stored.savedVerses:[],searchHistory:Array.isArray(stored.searchHistory)?stored.searchHistory.slice(0,12):[]};
// One-time migration from the v2.1 meaning model to per-layer toggles.
if(stored.showPa===undefined&&stored.meanings===true){state.showPa=stored.meaningLang!=='en';state.showEn=stored.meaningLang==='en';}
state.font=Math.min(40,Math.max(18,Number(state.font)||24));
state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));
state.raisedHeadings=state.raisedHeadings!==false;
state.spacing=Math.min(2.35,Math.max(1.45,Number(state.spacing)||1.82));
state.lineLayout=['compact','standard','spacious'].includes(state.lineLayout)?state.lineLayout:'compact';
state.ang=Math.min(1430,Math.max(1,Number(state.ang)||1));
state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';
state.pageTurnSpeed=['slow','normal','fast'].includes(state.pageTurnSpeed)?state.pageTurnSpeed:'slow';
state.vishraams=false;
state.lang=state.lang==='en'?'en':'pa';
state.meaningLang=state.meaningLang==='en'?'en':'pa';
state.aiLang=state.aiLang==='en'?'en':'pa';state.aiFont=Math.min(32,Math.max(14,Number(state.aiFont)||18));
state.aiLangManual=state.aiLangManual===true||(stored.aiLangManual===undefined&&stored.aiLang==='en');if(!state.aiLangManual)state.aiLang=state.lang;
state.nightMode=state.nightMode===true;
state.showTranslit=state.showTranslit!==false;
for(const k of ['showEn','showPa','showArth','keyboardOn'])state[k]=state[k]===true;
if(stored.kbLang===undefined)state.kbLang=state.keyboardOn===false?'en':'pa';
state.baniTextSize=['normal','large','xlarge'].includes(state.baniTextSize)?state.baniTextSize:'normal';
state.fontColor=state.fontColor==='blue'?'blue':'black';
state.layerScale=Math.min(1,Math.max(0.7,Number(state.layerScale)||0.8));
state.tone=Math.min(100,Math.max(0,Number(state.tone)||0));
state.bookCursors=(state.bookCursors&&typeof state.bookCursors==='object'&&!Array.isArray(state.bookCursors))?state.bookCursors:{};
let bookReader=null;
const HOME_IDS=['reader','nitnem','catalog','kirtan','ask'];
function normalizeHomeOrder(value){const good=Array.isArray(value)?value.filter((id,i)=>HOME_IDS.includes(id)&&value.indexOf(id)===i):[];return [...good,...HOME_IDS.filter(id=>!good.includes(id))]}
if(!state.hukamnama||typeof state.hukamnama!=='object'||!Array.isArray(state.hukamnama.lines))state.hukamnama=null;
state.homeOrder=normalizeHomeOrder(state.homeOrder);
let homeEditing=false;
let homePending=null;
let homeDrag=null;
let homeDragCleanup=null;
let lastHomeDragEnded=0;
state.view='home';
try{window.history.replaceState({gsView:'home'},'',window.location.pathname+window.location.search+'#home')}catch{}
state.fontStyle=['serif','sans','system'].includes(state.fontStyle)?state.fontStyle:'serif';
state.margin=['narrow','normal','wide'].includes(state.margin)?state.margin:'normal';
state.theme=['light','sepia','dark','charcoal'].includes(state.theme)?state.theme:'light';
const $=id=>document.getElementById(id);
const words=CONTENT.words;
const lines=CONTENT.reader.sections[0].lines;
const PAGE_GROUPS=[[0,1,2,3],[4,5,6],[7,8,9]];
const txt={
pa:{home:'ਮੁੱਖ',read:'ਪਾਠ',search:'ਖੋਜ',ask:'ਸਵਾਲ',settings:'ਸੈਟਿੰਗਾਂ',menu:'ਮੀਨੂ',readerSettings:'ਪੜ੍ਹਨ ਦੀ ਸੈਟਿੰਗ',appearance:'ਦਿੱਖ',tone:'ਟੋਨ',fontStyleLabel:'ਫੌਂਟ',serif:'ਕਿਤਾਬੀ',sans:'ਸਾਫ਼',sysFont:'ਸਿਸਟਮ',margins:'ਪਾਸਿਆਂ ਦੀ ਜਗ੍ਹਾ',narrow:'ਘੱਟ',normal:'ਦਰਮਿਆਨੀ',wide:'ਵੱਧ',sepia:'ਸੇਪੀਆ',charcoal:'ਚਾਰਕੋਲ',smallText:'ਛੋਟੇ ਅੱਖਰ',largeText:'ਵੱਡੇ ਅੱਖਰ',updateCenter:'ਐਪ ਅੱਪਡੇਟ',currentVersion:'ਮੌਜੂਦਾ ਵਰਜ਼ਨ',updating:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੱਭ ਰਹੇ ਹਾਂ…',upToDate:'ਇਹ ਵਰਜ਼ਨ ਅੱਪਡੇਟ ਹੈ।',updateAvailable:'ਨਵਾਂ ਵਰਜ਼ਨ ਮਿਲਿਆ ਹੈ। ਅੱਪਡੇਟ ਕਰਨ ਲਈ ਦਬਾਓ।',updateRequiresWeb:'Android APK ਅੱਪਡੇਟ ਲਈ GitHub Releases ਵਰਤੋ।',updateFailed:'ਅੱਪਡੇਟ ਚੈੱਕ ਨਹੀਂ ਹੋ ਸਕੀ। ਇੰਟਰਨੈੱਟ ਚੈੱਕ ਕਰੋ।',updateReady:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ…',install:'ਹੋਮ ਸਕਰੀਨ ਉੱਤੇ ਜੋੜੋ',installHint:'ਇਹ ਪਹਿਲਾਂ ਤੋਂ Android ਐਪ ਵਜੋਂ ਇੰਸਟਾਲ ਹੈ।',menuIntro:'ਇੱਕੋ ਐਪ ਰੱਖੋ — ਨਵੇਂ ਵਰਜ਼ਨ ਸਿੱਧੇ ਅੱਪਡੇਟ ਕਰੋ।',menuBackups:'ਤੁਹਾਡਾ ਡਾਟਾ',backupHint:'ਸਹਿਜ ਪਾਠ ਦੀ ਜਗ੍ਹਾ, ਪਸੰਦੀਦਾ ਸ਼ਬਦ ਅਤੇ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿੰਦੀਆਂ ਹਨ। ਬੈਕਅੱਪ ਵੱਖਰਾ ਸੰਭਾਲੋ।',
  hero:'ਗੁਰਬਾਣੀ ਨਾਲ ਜੁੜਨ ਦੀ ਇੱਕ ਸਾਦੀ ਥਾਂ',welcome:'ਜਿੱਥੇ ਛੱਡਿਆ ਸੀ, ਉੱਥੋਂ ਪੜ੍ਹੋ',continue:'ਸਹਿਜ ਪਾਠ ਜਾਰੀ ਰੱਖੋ',
  sample:'ਪਾਠ ਐਪ ਨਾਲ ਹੀ ਆਉਂਦਾ ਹੈ; ਇੰਟਰਨੈੱਟ ਦੀ ਲੋੜ ਨਹੀਂ।',
  readerTitle:'ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ',ang:'ਅੰਗ',excerpt:'ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ',
  meanings:'ਅਰਥ',on:'ਚਾਲੂ',off:'ਬੰਦ',meaning:'ਅਰਥ',
  wordPending:'ਇਸ ਸ਼ਬਦ ਦੇ ਪ੍ਰਮਾਣਿਤ ਅਰਥ ਹਾਲੇ ਜੋੜਣੇ ਹਨ।',
  start:'ਪੜ੍ਹੋ',next:'ਅਗਲਾ',prev:'ਪਿਛਲਾ',last:'ਅਗਲਾ ਅੰਗ ਅਜੇ ਟਰਾਇਲ ਵਿੱਚ ਨਹੀਂ ਹੈ।',
  library:'ਗੁਰਬਾਣੀ ਸੰਗ੍ਰਹਿ',catalog:'ਅਨੇਕ ਬਾਣੀਆਂ',catalogSearch:'ਬਾਣੀ ਦਾ ਨਾਮ ਖੋਜੋ...',catalogNotice:'ਬਾਣੀਆਂ ਦੀ ਸੂਚੀ। ਸਾਰੇ ਪਾਠ ਐਪ ਵਿੱਚ ਆਫਲਾਈਨ ਹਨ।',catalogPending:'ਇਸ ਬਾਣੀ ਦਾ ਪ੍ਰਮਾਣਿਤ ਪੂਰਾ ਪਾਠ ਅਜੇ ਜੋੜਿਆ ਜਾਣਾ ਹੈ।',catalogSection1:'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੀਆਂ ਬਾਣੀਆਂ',catalogSection2:'ਦਸਮ ਗ੍ਰੰਥ ਸੰਬੰਧੀ ਬਾਣੀਆਂ',catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਵੱਖਰੇ ਰੂਪ',catalogSection4:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',catalogResults:'ਬਾਣੀਆਂ',collection:'ਹੋਰ ਬਾਣੀਆਂ',kirtan:'ਕੀਰਤਨ ਸ਼ਬਦ',
  kirtanDesc:'ਕੀਰਤਨੀਆਂ ਲਈ ਸ਼ਬਦਾਂ ਦੀ ਕਿਤਾਬ',kirtanNote:'ਪੂਰੇ ਸ਼ਬਦ — ਪੜ੍ਹਨ ਅਤੇ ਗਾਉਣ ਲਈ।',
  fav:'ਪਸੰਦੀਦਾ',all:'ਸਾਰੇ',onlyFav:'ਸਿਰਫ਼ ਪਸੰਦੀਦਾ',noFav:'ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੇਵ ਨਹੀਂ ਕੀਤਾ।',
  nitnem:'ਨਿਤਨੇਮ',dasam:'ਦਸਮ ਗ੍ਰੰਥ ਸਾਹਿਬ',bhai:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',pending:'ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਅਤੇ ਵਰਤੋਂ ਦੀ ਇਜਾਜ਼ਤ ਤੋਂ ਬਾਅਦ ਪੂਰੀ ਸਮੱਗਰੀ ਜੋੜੀ ਜਾਵੇਗੀ।',
  searchTitle:'ਗੁਰਬਾਣੀ ਖੋਜੋ',searchHint:'ਪੰਗਤੀ ਜਾਂ ਸ਼ਬਦ ਲਿਖੋ ਜਾਂ ਬੋਲੋ...',voicePending:'ਆਵਾਜ਼ ਨਾਲ ਖੋਜ ਇਸ ਡਿਵਾਈਸ ਉੱਤੇ ਉਪਲਬਧ ਨਹੀਂ; ਲਿਖ ਕੇ ਖੋਜੋ।',
  noResults:'ਇਸ ਖੋਜ ਨਾਲ ਮੇਲ ਖਾਂਦੀ ਪੰਗਤੀ ਨਹੀਂ ਮਿਲੀ।',results:'ਨਤੀਜੇ',
  askTitle:'ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਤੋਂ ਪੁੱਛੋ',askHint:'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ...',askButton:'ਪੁੱਛੋ',short:'ਸੌਖਾ',detail:'ਵਿਸਥਾਰ',deep:'ਡੂੰਘਾਈ',
  askNotLive:'AI ਹਾਲੇ ਕਨੈਕਟ ਨਹੀਂ ਹੈ।',
  language:'ਐਪ ਦੀ ਭਾਸ਼ਾ',meanLang:'ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ',viewMeaning:'ਪੰਗਤੀ ਹੇਠਾਂ ਅਰਥ',mode:'ਪੰਨਾ ਬਦਲਣ ਦਾ ਤਰੀਕਾ',scroll:'ਸਕ੍ਰੋਲ',page:'ਪੰਨਾ ਪਲਟੋ',font:'ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',spacing:'ਲਾਈਨਾਂ ਵਿਚਕਾਰ ਜਗ੍ਹਾ',theme:'ਰੰਗ',light:'ਹਲਕਾ',dark:'ਗੂੜ੍ਹਾ',
  reading:'ਪੜ੍ਹਨ ਦਾ ਤਰੀਕਾ',preferences:'ਤੁਹਾਡੀਆਂ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿਣਗੀਆਂ।',
  update:'ਅੱਪਡੇਟ ਚੈੱਕ ਕਰੋ',backup:'ਬੈਕਅੱਪ',restore:'ਬੈਕਅੱਪ ਲਿਆਓ',
  daily:'ਰੋਜ਼ਾਨਾ ਗੁਰਬਾਣੀ',hukamnama:'ਰੋਜ਼ਾਨਾ ਹੁਕਮਨਾਮਾ',hukamLoading:'ਅੱਜ ਦਾ ਹੁਕਮਨਾਮਾ ਖੋਲ੍ਹ ਰਿਹਾ ਹੈ…',hukamUnavailable:'ਅੱਜ ਦਾ ਹੁਕਮਨਾਮਾ ਨਹੀਂ ਮਿਲਿਆ। ਇੰਟਰਨੈੱਟ ਚੈੱਕ ਕਰੋ, ਫਿਰ ਦੁਬਾਰਾ ਖੋਲ੍ਹੋ।',hukamCached:'ਪਿਛਲਾ ਸੇਵ ਕੀਤਾ ਹੁਕਮਨਾਮਾ',hukamReadFullAng:'ਪੂਰਾ ਅੰਗ ਪੜ੍ਹੋ',hukamFrom:'ਸ੍ਰੀ ਦਰਬਾਰ ਸਾਹਿਬ, ਅੰਮ੍ਰਿਤਸਰ',dailyTitle:'ਅੱਜ ਲਈ ਗੁਰਬਾਣੀ',dailyDesc:'ਤੁਹਾਡੀ ਆਪਣੀ ਰਫ਼ਤਾਰ ਨਾਲ ਪੜ੍ਹਨ ਲਈ',dailySetup:'ਰੋਜ਼ਾਨਾ ਪਾਠ ਸੈੱਟ ਕਰੋ',dailyPreview:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦਾ ਨਮੂਨਾ',dailyOpen:'ਅੱਜ ਦਾ ਪਾਠ ਖੋਲ੍ਹੋ',
  amount:'ਰੋਜ਼ ਕਿੰਨੇ ਅੰਗ?',order:'ਚੋਣ ਦਾ ਤਰੀਕਾ',sequential:'ਲੜੀਵਾਰ',random:'ਰੈਂਡਮ',source:'ਕਿਹੜਾ ਸਰੋਤ?',time:'ਸਮਾਂ',
  enable:'ਰੋਜ਼ਾਨਾ ਯਾਦ ਦਿਵਾਉਣਾ',savePlan:'ਪਲਾਨ ਸੇਵ ਕਰੋ',sendTest:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ',
  dailyLimit:'ਹੁਣ ਇਹ ਪਲਾਨ ਅਤੇ ਐਪ ਅੰਦਰਲਾ ਨਮੂਨਾ ਕੰਮ ਕਰਦੇ ਹਨ। ਐਪ ਬੰਦ ਹੋਣ ’ਤੇ ਹਰ ਰੋਜ਼ ਭਰੋਸੇਯੋਗ ਨੋਟੀਫਿਕੇਸ਼ਨ ਲਈ ਅਗਲੇ ਵਰਜ਼ਨ ਵਿੱਚ Android reminder ਜਾਂ push service ਜੋੜਨੀ ਪਵੇਗੀ।',
  notificationsUnsupported:'ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਨੋਟੀਫਿਕੇਸ਼ਨ ਉਪਲਬਧ ਨਹੀਂ।',notificationDenied:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਮਿਲੀ।',notificationSent:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ ਭੇਜੀ ਗਈ।',
  planSaved:'ਤੁਹਾਡਾ ਪਲਾਨ ਸੇਵ ਹੋ ਗਿਆ।',preview:'ਨਮੂਨਾ · ਅਸਲ ਪਾਠ ਨਹੀਂ',
  pageHint:'ਸਵਾਈਪ ਕਰਕੇ ਪੰਨਾ ਬਦਲੋ',saved:'ਆਖ਼ਰੀ ਪੜ੍ਹੀ ਜਗ੍ਹਾ ਆਪਣੇ ਆਪ ਸੇਵ ਹੁੰਦੀ ਹੈ।',
  viewPrefs:'Bani View Preferences',nightMode:'Night Mode',translit:'Transliteration',enTrans:'English Translation',paTrans:'Punjabi Translation',shabadArth:'Shabad Arth',baniTextSize:'Bani Text Size',tSizeNormal:'Normal',tSizeLarge:'Large',tSizeXLarge:'Extra-large',fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ',fontBlack:'ਕਾਲਾ',fontBlue:'ਨੀਲਾ',layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ',
  share:'ਸਾਂਝਾ ਕਰੋ',viewFullAng:'ਪੂਰਾ ਅੰਗ ਵੇਖੋ',kirtanBook:'ਕੀਰਤਨ ਸ਼ਬਦ ਕਿਤਾਬ',kirtanSearchHint:'ਪਹਿਲੀ ਪੰਗਤੀ ਨਾਲ ਸ਼ਬਦ ਲੱਭੋ...',
  aiKey:'AI API key',aiEndpoint:'AI endpoint',aiModel:'AI model',micTest:'Test microphone',
  relatedOffline:'Related Shabads (offline)',aiAnswerLabel:'AI answer',aiNeedsKey:'AI ਜਵਾਬ ਲਈ Settings ਵਿੱਚ API key ਪਾਓ — ਹੇਠਾਂ ਸਬੰਧਤ ਸ਼ਬਦ ਦਿਖਾਏ ਗਏ ਹਨ।',
  clear:'ਸਾਫ਼ ਕਰੋ',options:'ਵਿਕਲਪ',history:'ਖੋਜ ਇਤਿਹਾਸ',noHistory:'ਹਾਲੇ ਕੋਈ ਖੋਜ ਨਹੀਂ।'},
en:{home:'Home',read:'Read',search:'Search',ask:'Ask',settings:'Settings',menu:'Menu',readerSettings:'Reading settings',appearance:'Appearance',tone:'Tone',fontStyleLabel:'Font',serif:'Book',sans:'Clean',sysFont:'System',margins:'Page margins',narrow:'Narrow',normal:'Comfort',wide:'Wide',sepia:'Sepia',charcoal:'Charcoal',smallText:'Smaller text',largeText:'Larger text',updateCenter:'App updates',currentVersion:'Current version',updating:'Checking for a newer version…',upToDate:'You are using the latest published version.',updateAvailable:'A newer version is ready. Tap to update.',updateRequiresWeb:'Android APK updates are delivered through GitHub Releases.',updateFailed:'Could not check for updates. Check your connection.',updateReady:'Loading the updated app…',install:'Add to home screen',installHint:'You already have the Android app installed.',menuIntro:'Keep the same installed app and receive new versions without reinstalling.',menuBackups:'Your data',backupHint:'Your Sahaj Paath position, favourites and settings stay saved on this phone. Keep a backup for extra safety.',
  hero:'A calm place to reconnect with Gurbani',welcome:'Continue from where you left off',continue:'Continue Sehaj Paath',
  sample:'Scripture is bundled inside the app; no internet needed.',
  readerTitle:'Japji Sahib Ji',ang:'Ang',excerpt:'Selected lines',meanings:'Meanings',on:'On',off:'Off',meaning:'Meaning',
  wordPending:'Reviewed word meaning is not yet available.',
  start:'Read',next:'Next',prev:'Back',last:'The next Ang is not available in this trial.',
  library:'Scripture library',catalog:'Anek Baaniyaan',catalogSearch:'Search a Bani by name...',catalogNotice:'Full Bani texts are bundled offline in the app.',catalogPending:'The verified full text for this Bani has not been added yet.',catalogSection1:'Baaniyaan from Sri Guru Granth Sahib Ji',catalogSection2:'Dasam Granth related compositions',catalogSection3:'Other recitations and variations',catalogSection4:'Bhai Gurdas Ji',catalogResults:'Baaniyaan',collection:'Other Banis',kirtan:'Kirtan Shabads',kirtanDesc:'Shabad book for kirtanis',kirtanNote:'Full Shabads — for reading and singing.',
  fav:'Favourites',all:'All',onlyFav:'Favourites only',noFav:'No saved Shabads yet.',
  nitnem:'Nitnem',dasam:'Sri Dasam Granth Sahib',bhai:'Bhai Gurdas Ji',pending:'Full content will be added after text verification and the necessary permissions.',
  searchTitle:'Search Gurbani',searchHint:'Type or speak a word or line...',voicePending:'Voice search is unavailable on this device; type to search.',
  noResults:'No matching Gurbani line was found.',results:'Results',
  askTitle:'Ask Guru Granth Sahib',askHint:'Ask any question...',askButton:'Ask',short:'Simple',detail:'Detailed',deep:'In depth',
  askNotLive:'AI is not connected yet.',
  language:'App language',meanLang:'Meaning language',viewMeaning:'Meanings under each line',mode:'Page navigation',scroll:'Scroll',page:'Page Turn',font:'Font size',spacing:'Line spacing',theme:'Theme',light:'Light',dark:'Dark',
  reading:'Reading preferences',preferences:'Preferences are saved on this device.',update:'Check for updates',backup:'Export backup',restore:'Import backup',
  daily:'Daily Gurbani',hukamnama:'Daily Hukamnama',hukamLoading:'Loading today’s Hukamnama…',hukamUnavailable:'Today’s Hukamnama could not be loaded. Check the internet, then open it again.',hukamCached:'Last saved Hukamnama',hukamReadFullAng:'Read the full Ang',hukamFrom:'Sri Darbar Sahib, Amritsar',dailyTitle:'Your Gurbani for today',dailyDesc:'A reading rhythm that feels right for you',dailySetup:'Set daily reading',dailyPreview:'Notification preview',dailyOpen:'Open today’s reading',
  amount:'Daily Ang goal',order:'Selection',sequential:'In order',random:'Random',source:'Starting collection',time:'Time',
  enable:'Daily reminder preference',savePlan:'Save reading plan',sendTest:'Test notification',
  dailyLimit:'Your plan and the in-app preview work now. Reliable daily delivery while the app is closed requires a future Android reminder feature or push service.',
  notificationsUnsupported:'Notifications are unavailable in this browser.',notificationDenied:'Notification permission was not granted.',notificationSent:'Test notification sent.',
  planSaved:'Your plan is saved.',preview:'Preview · not full scripture',pageHint:'Swipe to turn pages',saved:'Your last reading position is saved automatically.',
  viewPrefs:'Bani View Preferences',nightMode:'Night Mode',translit:'Transliteration',enTrans:'English Translation',paTrans:'Punjabi Translation',shabadArth:'Shabad Arth',baniTextSize:'Bani Text Size',tSizeNormal:'Normal',tSizeLarge:'Large',tSizeXLarge:'Extra-large',fontColor:'Text colour',fontBlack:'Black',fontBlue:'Blue',layerSize:'Roman + translation size',
  share:'Share',viewFullAng:'View full Ang',kirtanBook:'Kirtan Shabad Book',kirtanSearchHint:'Find a Shabad by its first line...',
  aiKey:'AI API key',aiEndpoint:'AI endpoint',aiModel:'AI model',micTest:'Test microphone',
  relatedOffline:'Related Shabads (offline)',aiAnswerLabel:'AI answer',aiNeedsKey:'Add an API key in Settings for AI answers — related Shabads are shown below.',
  clear:'Clear',options:'Options',history:'Search history',noHistory:'No searches yet.'}};
const t=k=>(txt[state.lang]||txt.pa)[k]||k;
const age=(k,en)=>state.lang==='pa'?k:en;
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch{}}
function toast(msg){let x=$('toast');x.textContent=msg;x.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>x.classList.remove('show'),3400)}
function theme(){
 const html=document.documentElement;
 html.classList.toggle('dark',state.theme==='dark'||state.theme==='charcoal');
 html.dataset.tone=state.theme;html.dataset.lineLayout=state.lineLayout;html.dataset.font=state.fontStyle;html.dataset.margin=state.margin;html.dataset.raisedText=state.raisedHeadings?'on':'off';
 html.dataset.nightmode=state.nightMode?'on':'off';
 html.dataset.banisize=state.baniTextSize;
 html.dataset.gurmukhiColor=state.fontColor==='blue'?'blue':'black';
 html.style.setProperty('--font',state.font+'px');html.style.setProperty('--ai-font',(Number(state.aiFont)||18)+'px');
 html.style.setProperty('--layer-scale',String(state.layerScale));
 html.style.setProperty('--ui-scale',state.uiScale);
 html.style.setProperty('--tone-opacity',(state.tone/100*0.5).toFixed(3));
 const ls={compact:[1.35,'0px'],standard:[1.5,'0px'],spacious:[1.65,'0px']}[state.lineLayout];
 html.style.setProperty('--leading',ls[0]);html.style.setProperty('--verse-gap',ls[1]);html.lang=state.lang;
 document.querySelector('meta[name=theme-color]')?.setAttribute('content',state.nightMode?'#0b0e0c':state.theme==='dark'||state.theme==='charcoal'?'#19221f':state.theme==='sepia'?'#f4eddf':'#ffffff');
}
// ---- Offline data boot: kosh (tap meanings, no highlight) and vishraam (data kept, no UI) ----
let koshReady=false,vishraamReady=false;
function bootData(){
 window.GS_KOSH?.ready().then(()=>{koshReady=true;if(state.view==='reader'||state.view==='search')render()}).catch(()=>{});
 window.GS_VISHRAAM?.load().then(()=>{vishraamReady=true}).catch(()=>{});
}
/* ---- Navigation ---- */
function go(view,opts={}){if(view!=='home')homeEditing=false;if(view!=='reader'){highlightLine=-1;readerBarHidden=true;}if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();closeWord();const oldView=state.view;state.view=view;if(view==='reader'&&opts.reader)state.readView=opts.reader;state.baniDrawer=false;if(oldView!==view&&!opts.noHistory){try{history.pushState({gsView:view},'',`#${view}`)}catch{}}persist();render();if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});}
function navReader(){state.readView='sggs';openAng(state.ang,true,true)}
function labelSource(src){return ({sggs:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),japji:age('ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ','Japji Sahib Ji'),dasam:t('dasam'),bhai:t('bhai')})[src]||src}
function dailyAngNumber(){
 const now=new Date(),key=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
 const origin=state.daily.startDate||key;
 const days=Math.max(0,Math.floor((Date.parse(key+'T12:00:00')-Date.parse(origin+'T12:00:00'))/86400000));
 if(state.daily.order==='random'){let n=0;for(const c of key)n=(n*31+c.charCodeAt(0))>>>0;return n%1430+1}
 return (days*Math.max(1,state.daily.amount)%1430)+1;
}
function dailyExcerpt(){return null}
function dailyQuote(){return `<div id="dailyQuoteActual" class="daily-quote fine">${age('ਆਫਲਾਈਨ ਪਾਠ ਖੋਲ੍ਹ ਰਹੇ ਹਾਂ…','Loading the offline Ang…')}</div>`}

/* ---- Daily Hukamnama (v2.2.14) ----
 * Replaces the Daily Gurbani reading plan. No settings: every morning the
 * app fetches today's Hukamnama from BaniDB (free, no key) and saves it on
 * the phone, so it still shows offline. If the fetch fails, the last saved
 * Hukamnama is shown (marked stale) instead of an empty screen. */
function hukamTodayKey(d){const n=d||new Date();return `${n.getFullYear()}-${String(n.getMonth()+1).padStart(2,'0')}-${String(n.getDate()).padStart(2,'0')}`}
function hukamMapVerse(v){
 const tr=v.translation||{};
 const en=String(tr.en?.bdb||tr.en?.ms||'').trim();
 const pu=tr.pu||{};
 const pa=String(pu.ss?.unicode||pu.bdb?.unicode||pu.ms?.unicode||'').trim();
 const roman=String(v.transliteration?.english||'').trim();
 return {g:String(v.verse?.unicode||'').trim(),roman,en,pa};
}
let hukamFetching=false;
async function fetchHukamnama(force=false){
 const key=hukamTodayKey();
 if(!force&&state.hukamnama&&state.hukamnama.date===key&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return state.hukamnama;
 if(hukamFetching)return state.hukamnama;
 hukamFetching=true;
 try{
  const n=new Date();
  const res=await fetch(`https://api.banidb.com/v2/hukamnamas/${n.getFullYear()}/${n.getMonth()+1}/${n.getDate()}`,{headers:{Accept:'application/json'}});
  if(!res.ok)throw new Error('Hukamnama unavailable ('+res.status+')');
  const data=await res.json();
  const shabad=(data.shabads||[])[0];
  if(!shabad||!Array.isArray(shabad.verses)||!shabad.verses.length)throw new Error('Hukamnama empty');
  const info=shabad.shabadInfo||{};
  const lines=shabad.verses.map(hukamMapVerse).filter(l=>l.g);
  if(!lines.length)throw new Error('Hukamnama empty');
  const enriched=await enrichLines(lines,'hukamnama',null);
  state.hukamnama={date:key,ang:Number(info.pageNo)||0,raag:String(info.raag?.unicode||''),raagEn:String(info.raag?.english||''),writer:String(info.writer?.english||''),shabadId:Number(info.shabadId)||0,lines:enriched,fetchedAt:Date.now(),stale:false};
  persist();
 }catch(e){
  console.warn('Hukamnama fetch failed',e);
  if(state.hukamnama&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)state.hukamnama.stale=true;
  else state.hukamnama=null;
 }finally{hukamFetching=false;}
 return state.hukamnama;
}
function ensureHukamnama(){
 const key=hukamTodayKey();
 if(state.hukamnama&&state.hukamnama.date===key&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return;
 fetchHukamnama().then(()=>{if(state.view==='home'||state.view==='hukamnama')render();});
}
let hukamNotifScheduled=false;
async function scheduleHukamNotification(){
 if(hukamNotifScheduled)return;
 const N=window.GS_NOTIFY;if(!N||!N.isNative)return;
 hukamNotifScheduled=true;
 try{await N.scheduleDaily();}catch(e){console.warn('Hukamnama notification',e);}
}
/* ---- Layered verse rendering ----
 * Enrichment (vishraam marks + shabad arth) is precomputed in loadRemote so
 * render() stays synchronous. */
async function enrichLines(lines,kind,ref){
 let marksByLine={};
 try{
  if(kind==='ang')marksByLine=await window.GS_VISHRAAM.marksForText('a',ref);
  else if(kind==='bani')marksByLine=await window.GS_VISHRAAM.marksForText('b',ref);
  else if(kind==='kirtan'&&ref&&ref.ang)marksByLine=await window.GS_VISHRAAM.marksForText('a',ref.ang);
 }catch{}
 const wantArth=state.showArth;
 const lang=state.lang;
 const lineOffset=(kind==='kirtan'&&ref&&typeof ref.lineStart==='number')?ref.lineStart:0;
 for(let i=0;i<lines.length;i++){
  const line=lines[i];
  line._marks=marksByLine[lineOffset+i]||null;
  line._legacyVishraam=line.vishraam||null;
  line._arth=null;
  if(wantArth){
   try{line._arth=await window.GS_KOSH.arthFor(line,lang)}catch{}
  }
 }
 return lines;
}
function layerOpts(){
 return {translit:state.showTranslit,en:state.showEn,pa:state.showPa,arth:state.showArth};
}
function koshHas(word){return koshReady&&window.GS_KOSH.hasEntrySync(word)}
function verseBlock(line,idx,kind,extra={}){
 return VERSES.verseHTML(line,{
  idx,kind,found:idx===highlightLine,
  vishraamOn:state.vishraams,
  marks:line._marks||null,
  legacyVishraam:line._legacyVishraam||null,
  koshHas,
  arth:line._arth||null,
  show:extra.show||layerOpts(),
  heading:!!extra.heading,
  gurmukhiClass:kind==='ang'?'gs-gurmukhi-blue':'',
 });
}
function render(){if(bookReader){bookReader.destroy();bookReader=null;}theme();document.documentElement.classList.toggle('home-open',state.view==='home');document.documentElement.classList.toggle('reading-open',state.view==='reader');$('brand').textContent=age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh');$('labelHome').textContent=t('home');$('labelSearch').textContent=t('search');$('labelBookmarks').textContent=age('ਸੰਭਾਲੇ','Saved');$('labelMenu').textContent=t('settings');$('settingsBtn').title=t('readerSettings');$('settingsBtn').style.visibility=state.view==='reader'?'visible':'hidden';$('backBtn').style.visibility=state.view==='home'?'hidden':'visible';
for(const v of ['home','search','bookmarks','menu'])$('nav-'+v).classList.toggle('active',state.view===v);
const views={home:homeScreen,reader:readerScreen,library:libraryScreen,catalog:catalogScreen,nitnem:nitnemScreen,kirtan:kirtanScreen,search:searchScreen,ask:askScreen,bookmarks:bookmarksScreen,hukamnama:hukamnamaScreen,daily:hukamnamaScreen,coming:comingScreen,menu:menuScreen,viewprefs:viewprefsScreen};
$('main').innerHTML=(views[state.view]||homeScreen)();attach();
if(state.view==='reader'&&!activeRemote&&state.readView==='sggs'&&state.mode==='scroll'&&state.hasProgress){requestAnimationFrame(()=>{const node=document.querySelector(`[data-line="${Math.min(lines.length-1,state.verse)}"]`);if(node){const r=node.getBoundingClientRect();const y=window.scrollY+r.top+r.height/2-window.innerHeight/2+state.verseOffset;window.scrollTo({top:Math.max(0,y),behavior:'instant'})}})}}
/* ---- Home ---- */
function homeCard(id){
 const icons={
 reader:'<path d="M12 6.5C9.6 4.6 6.7 4.1 3 4v15c3.7.1 6.6.8 9 2.3 2.4-1.5 5.3-2.2 9-2.3V4c-3.7.1-6.6.6-9 2.5Z"/><path d="M12 6.5v14.8"/>',
 nitnem:'<path d="M5 4.5h14v15H5z"/><path d="M9 2v5m6-5v5M5 10h14"/><path d="M9 14h2m2 0h2m-6 3h2"/>',
 catalog:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
 kirtan:'<path d="M4 6a4 4 0 0 1 4-3h12v16H8a4 4 0 0 0-4 2Z"/><path d="M4 6v15M10 8h7M10 12h7"/>',
 ask:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 daily:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/>'
 };
 const titles={reader:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),nitnem:t('nitnem'),catalog:t('catalog'),kirtan:t('kirtan'),ask:t('askTitle')};
 const descriptions={reader:age('ਪੜ੍ਹਨ ਲਈ','For reading'),nitnem:age('ਨਿਤਨੇਮ ਪਾਠ','Daily prayers'),catalog:age('ਹੋਰ ਬਾਣੀਆਂ','Other Banis'),kirtan:age('ਕੀਰਤਨੀਆਂ ਲਈ','For kirtanis'),ask:age('ਸਵਾਲ ਅਤੇ ਵਿਆਖਿਆ','Questions & meaning')};
 return `<button type="button" class="feature home-tile tile-3d ${id==='ask'||id==='daily'?'tile-wide':''} ${id==='daily'?'tile-daily':''}" data-action="${id}" data-home-id="${id}" aria-label="${esc(titles[id])}" aria-grabbed="${homeEditing}"><span class="drag-handle" aria-hidden="true">⠿</span><span class="tile-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round">${icons[id]}</svg></span><strong>${titles[id]}</strong><span class="tile-foot"><small>${descriptions[id]}</small><span aria-hidden="true">›</span></span></button>`;
}
function homeScreen(){return `<div class="home home-v6 home-v7 home-v10 ${homeEditing?'home-editing':''}">
  <section class="premium-hero" aria-label="Gurbani Saanjh">
    <div class="hero-brand"><img src="icons/icon-192.png" alt="" class="hero-mark"><h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1></div>
    <div class="hero-temple" role="img" aria-label="Sri Harmandir Sahib illustration"></div>
    <div class="home-lang-switch" role="group" aria-label="App language"><button data-action="lang-pa" class="${state.lang==='pa'?'sel':''}">ਪੰਜਾਬੀ</button><button data-action="lang-en" class="${state.lang==='en'?'sel':''}">English</button></div>
  </section>
  ${hukamHeroHTML()}
  <button class="continue-card" data-action="continue"><span class="continue-icon" aria-hidden="true">↗</span><span class="continue-copy"><strong>${t('continue')}</strong><small>${age('ਸਹਿਜ ਪਾਠ · ਅੰਗ','Sahaj Paath · Ang')} ${state.ang}</small></span><span class="go" aria-hidden="true">›</span></button>
  <div class="section-head home-label"><span>${t('library')}</span><button class="text-link reorder-trigger" data-action="${homeEditing?'done-layout':'edit-layout'}">${homeEditing?age('ਹੋ ਗਿਆ','Done'):age('ਤਰਤੀਬ ਬਦਲੋ','Rearrange')}</button></div>
  ${homeEditing?`<div class="layout-edit-banner"><span>${age('ਕਿਸੇ ਕਾਰਡ ਨੂੰ ਫੜ ਕੇ ਨਵੀਂ ਜਗ੍ਹਾ ਲੈ ਜਾਓ।','Hold a card and move it to a new position.')}</span><button data-action="reset-layout">${age('ਮੂਲ ਤਰਤੀਬ','Reset')}</button></div>`:''}
  <div class="feature-grid home-grid home-drag-grid" id="homeDragGrid" aria-label="${age('ਘਰ ਦੇ ਕਾਰਡ','Home cards')}">${state.homeOrder.map(homeCard).join('')}</div>
  <p class="home-trial-label">${age('ਗੁਰਬਾਣੀ ਪੜ੍ਹਨਾ ਆਫਲਾਈਨ · AI ਲਈ ਇੰਟਰਨੈੱਟ ਲੋੜੀਂਦਾ ਹੋ ਸਕਦਾ ਹੈ','Offline Gurbani reading · Live AI may require internet')}</p>
 </div>`}
function moveHomeCard(id,delta){const order=normalizeHomeOrder(state.homeOrder),from=order.indexOf(id),to=Math.max(0,Math.min(order.length-1,from+delta));if(to===from)return;order.splice(from,1);order.splice(to,0,id);state.homeOrder=order;persist();render();const node=document.querySelector(`[data-home-id="${id}"]`);node?.focus();}
function setupHomeDrag(){
 if(homeDragCleanup)homeDragCleanup();
 const grid=$('homeDragGrid');if(!grid)return;
 function stopPending(){if(homePending){clearTimeout(homePending.timer);homePending=null}}
 function beginDrag(info){
  if(!info)return;
  if(!homeEditing){homeEditing=true;render();}
  const list=$('homeDragGrid'),tile=[...list.querySelectorAll('[data-home-id]')].find(x=>x.dataset.homeId===info.id);
  if(!tile)return;
  const r=tile.getBoundingClientRect();
  const ghost=tile.cloneNode(true);ghost.classList.add('tile-drag-ghost');ghost.removeAttribute('id');
  ghost.style.width=r.width+'px';ghost.style.height=r.height+'px';
  ghost.style.left=r.left+'px';ghost.style.top=r.top+'px';
  document.body.appendChild(ghost);tile.classList.add('tile-placeholder');
  homeDrag={pointerId:info.pointerId,ghost,tile,list,dx:info.x-r.left,dy:info.y-r.top};
  lastHomeDragEnded=Date.now();
  if(navigator.vibrate)try{navigator.vibrate(18)}catch{}
 }
 grid.addEventListener('pointerdown',e=>{
  const tile=e.target.closest('[data-home-id]');if(!tile||e.button!==0)return;
  stopPending();homePending={id:tile.dataset.homeId,pointerId:e.pointerId,x:e.clientX,y:e.clientY};
  if(homeEditing){beginDrag(homePending);homePending=null;return}
  homePending.timer=setTimeout(()=>{const p=homePending;homePending=null;beginDrag(p)},460);
 });
 const onMove=e=>{
  if(homePending&&homePending.pointerId===e.pointerId){
   if(Math.hypot(e.clientX-homePending.x,e.clientY-homePending.y)>11)stopPending();
  }
  const d=homeDrag;if(!d||d.pointerId!==e.pointerId)return;
  if(e.cancelable)e.preventDefault();
  d.ghost.style.left=(e.clientX-d.dx)+'px';d.ghost.style.top=(e.clientY-d.dy)+'px';
  const el=document.elementFromPoint(e.clientX,e.clientY);
  const over=el?.closest?.('[data-home-id]');
  if(!over||over===d.tile||!d.list.contains(over))return;
  const from=[...d.list.children].indexOf(d.tile),to=[...d.list.children].indexOf(over);
  if(from<to)d.list.insertBefore(d.tile,over.nextSibling);else d.list.insertBefore(d.tile,over);
 };
 document.addEventListener('pointermove',onMove,{passive:false});
 function finishDrag(e){
  if(homePending&&(!e||homePending.pointerId===e.pointerId))stopPending();
  const d=homeDrag;if(!d||e&&d.pointerId!==e.pointerId)return;
  d.ghost.remove();d.tile.classList.remove('tile-placeholder');homeDrag=null;
  state.homeOrder=[...d.list.querySelectorAll('[data-home-id]')].map(n=>n.dataset.homeId);persist();
  lastHomeDragEnded=Date.now();render();
 }
 document.addEventListener('pointerup',finishDrag);
 document.addEventListener('pointercancel',finishDrag);
 grid.addEventListener('contextmenu',e=>{if(e.target.closest('[data-home-id]'))e.preventDefault()});
 homeDragCleanup=()=>{document.removeEventListener('pointermove',onMove);document.removeEventListener('pointerup',finishDrag);document.removeEventListener('pointercancel',finishDrag);stopPending();if(homeDrag){homeDrag.ghost.remove();homeDrag=null}};
}

/* ---- Daily Hukamnama hero (top of Home) + full screen ---- */
function hukamHeroHTML(){
 const h=state.hukamnama;
 const dateStr=new Date().toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'});
 const first=h&&Array.isArray(h.lines)&&h.lines.length?(h.lines[1]||h.lines[0]).g:'';
 const meta=h&&h.ang?`${age('ਅੰਗ','Ang')} ${h.ang}${h.raag?` · ${state.lang==='pa'?h.raag:(h.raagEn||h.raag)}`:''}`:'';
 return `<button type="button" class="hukam-hero" data-action="hukamnama" aria-label="${esc(t('hukamnama'))}">
  <span class="hukam-hero-kicker">॥ ${age('ਵਾਹਿਗੁਰੂ ਜੀ ਕਾ ਖਾਲਸਾ','Waheguru Ji Ka Khalsa')} ॥</span>
  <strong class="hukam-hero-title">${t('hukamnama')}</strong>
  <span class="hukam-hero-date">${esc(dateStr)}</span>
  ${meta?`<span class="hukam-hero-meta">${esc(meta)}</span>`:''}
  ${first?`<span class="hukam-hero-preview" lang="pa">${esc(first)}</span>`:`<span class="hukam-hero-sub">${t('hukamLoading')}</span>`}
  <span class="hukam-hero-go" aria-hidden="true">›</span>
 </button>`;
}
function hukamnamaScreen(){
 const h=state.hukamnama;
 const dateStr=new Date().toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'});
 const head=`<div class="hukam-head"><div class="hukam-kicker">॥ ${age('ਵਾਹਿਗੁਰੂ ਜੀ ਕਾ ਖਾਲਸਾ','Waheguru Ji Ka Khalsa')} ॥</div><h1 class="hukam-title">${t('hukamnama')}</h1><p class="hukam-date">${esc(dateStr)}</p><p class="hukam-source">${t('hukamFrom')}</p></div>`;
 if(!h||!Array.isArray(h.lines)||!h.lines.length){
  return `<section class="page hukam-page">${head}<p class="fine hukam-empty">${t('hukamUnavailable')}</p><button class="secondary" data-action="hukam-retry">${age('ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ','Try again')}</button></section>`;
 }
 // v2.2.15: translations follow the user's settings (Bani View Preferences),
 // exactly like the SGGS reader and Banis — never forced on here. Tap any
 // line for its meaning, the same as everywhere else.
 const verses=h.lines.map((line,idx)=>verseBlock(line,idx,'hukamnama')).join('');
 const metaParts=[];
 if(h.ang)metaParts.push(`${age('ਅੰਗ','Ang')} ${h.ang}`);
 if(h.raag)metaParts.push(state.lang==='pa'?h.raag:(h.raagEn||h.raag));
 if(h.writer)metaParts.push(h.writer);
 return `<section class="page hukam-page">${head}
  <div class="hukam-frame">
   ${metaParts.length?`<p class="hukam-meta">${esc(metaParts.join('  |  '))}</p>`:''}
   ${h.stale?`<p class="fine hukam-stale">${t('hukamCached')}</p>`:''}
   <div class="hukam-verses">${verses}</div>
  </div>
  ${h.ang?`<button class="primary full hukam-full-ang" data-action="hukam-full-ang">${t('hukamReadFullAng')} · ${age('ਅੰਗ','Ang')} ${h.ang}</button>`:''}
 </section>`;
}
/* ---- Nitnem ---- */
const NITNEM_LIST=[['ਜਪੁਜੀ ਸਾਹਿਬ','Japji Sahib',2],['ਜਾਪੁ ਸਾਹਿਬ','Jaap Sahib',4],['ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ','Tav-Prasad Savaiye',6],['ਚੌਪਈ ਸਾਹਿਬ','Chaupai Sahib',9],['ਅਨੰਦੁ ਸਾਹਿਬ','Anand Sahib',10],['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',21],['ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ','Rakhia De Shabad',130],['ਕੀਰਤਨ ਸੋਹਿਲਾ','Kirtan Sohila',23]];
function nitnemScreen(){return `<section class="page nitnem-page"><h1>${t('nitnem')}</h1><p class="muted fine">${age('ਨਿਤਨੇਮ ਦਾ ਪਾਠ ਐਪ ਵਿੱਚ ਆਫਲਾਈਨ ਹੈ।','Nitnem texts are included for offline reading.')}</p>${NITNEM_LIST.map(([pa,en,id])=>`<button class="catalog-row" data-remote-bani="${id}" data-bani-title="${esc(state.lang==='pa'?pa:en)}"><span>${state.lang==='pa'?pa:en}</span><span aria-hidden="true">›</span></button>`).join('')}<p class="fine muted">${age('ਨੋਟ: ਰਹਰਾਸਿ ਸਾਹਿਬ ਦਾ ਵੱਖਰਾ ਪ੍ਰਮਾਣਿਤ ਰੂਪ ਬਾਅਦ ਵਿੱਚ ਜੋੜਿਆ ਜਾਵੇਗਾ।','Note: a separate verified Rehras Sahib edition will be added later.')}</p></section>`}
/* ---- Loading texts ---- */
async function loadRemote(kind,id,title,preserveProgress=false,extra={}){
  if(remoteBusy)return;
  remoteBusy=true;readerBarHidden=true;
  activeRemote={kind,id,title,loading:true,lines:[]};
  if(state.view!=='reader')go('reader');else render();
  try{
    const result=await window.GS_REMOTE.read(kind,id);
    if(!result.lines.length)throw new Error('Empty Bani text');
    const lines=await enrichLines(result.lines,kind,id);
    activeRemote={kind,id,title,loading:false,lines,offline:result.offline,meta:extra.meta||null};
    if(kind==='ang'){if(extra.sahaj){state.ang=Number(id);if(!preserveProgress){state.verse=0;state.verseOffset=0}}state.hasProgress=true;persist()}
  }catch(e){
    activeRemote={kind,id,title,loading:false,lines:[],error:String(e.message||e)};
  }finally{remoteBusy=false;readerOpenedAt=Date.now();if(state.view==='reader'){render();if(preserveProgress&&activeRemote?.lines?.length){const target=highlightLine>=0?highlightLine:state.verse;const idx=Math.max(0,Math.min(target,activeRemote.lines.length-1));let node=document.querySelector(`[data-line="${idx}"]`);if(!node)node=[...document.querySelectorAll('[data-lines]')].find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))||null;node?.scrollIntoView({block:'center'});}else window.scrollTo({top:0,behavior:'instant'})}}
}
// v2.2.8: the Ang on screen (activeRemote) vs the Sahaj Paath position (state.ang).
// Search, jumps and detours change only the screen; Sahaj Paath moves only
// via Continue (navReader) or sequential swipe/page-turn from the Sahaj Ang.
function displayAng(){return activeRemote?.kind==='ang'?Number(activeRemote.id):state.ang}
function openAng(n,preserveProgress=false,sahaj=false){let num=Math.max(1,Math.min(1430,Number(n)||1));return loadRemote('ang',num,`${age('ਅੰਗ','Ang')} ${num}`,preserveProgress,{sahaj})}
function openBani(id,title,preserveProgress=false){return loadRemote('bani',Number(id),title||'Bani',preserveProgress)}
async function openKirtanShabad(id){
 if(remoteBusy)return;
 remoteBusy=true;readerBarHidden=true;
 activeRemote={kind:'kirtan',id,loading:true,lines:[],title:''};
 if(state.view!=='reader')go('reader');else render();
 try{
  const {meta,lines}=await window.GS_KIRTAN.shabad(id);
  const enriched=await enrichLines(lines,'kirtan',{ang:meta.ang,lineStart:meta.lineStart});
  activeRemote={kind:'kirtan',id,loading:false,lines:enriched,meta,offline:true,title:meta.firstLine||'Shabad'};
 }catch(e){
  activeRemote={kind:'kirtan',id,loading:false,lines:[],error:String(e.message||e)};
 }finally{
  remoteBusy=false;readerOpenedAt=Date.now();
  if(state.view==='reader'){render();window.scrollTo({top:0,behavior:'instant'})}
 }
}
function normalizeBaniName(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu,'').replace(/sahib|ji|ਸਾਹਿਬ/gu,'')}
function openCatalogBani(item){
 const id=Number(item.id);
 if(Number.isInteger(id)&&id>0){openBani(id,item[state.lang==='pa'?'titlePa':'titleEn']);return}
 toast(age('ਇਸ ਬਾਣੀ ਦਾ ਪੂਰਾ ਪਾਠ ਇਸ ਸਰੋਤ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ।','A complete Bani text was not found in this source.'));
}
/* ---- Reader ---- */
function baniHeaderBlock(lines,title){
 if(!VERSES.baniHeaderNeeded(lines))return '';
 return `<div class="bani-header" aria-label="${esc(title)}">
  <div class="bani-manglacharan"><span class="bani-ik-oankar">ੴ</span> <span>ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥</span></div>
 </div>`;
}
/* v2.2.7: drawer groups Banis like the reference Gutka app's menu (Mool Mantar,
   Nitnem, Bani collection, Kirtan) using our own labels. */
function baniDrawerHTML(){
 const byId={};for(const v of (onlineCatalog.length?onlineCatalog:[]))byId[v.id]=v;
 const name=v=>state.lang==='pa'?(v.titlePa||v.titleEn):(v.titleEn||v.titlePa);
 const row=(id,title)=>`<button class="drawer-row" data-remote-bani="${id}" data-bani-title="${esc(title)}"><span lang="pa">${esc(title)}</span><span aria-hidden="true">›</span></button>`;
 const ghead=t=>`<div class="drawer-group-head">${esc(t)}</div>`;
 const nitnemIds=[2,4,6,9,10,21,130,23];
 const catalogIds=(window.GS_CATALOG||[]).map(x=>x.id);
 let html='';
 html+=ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))+row(2,age('ਮੂਲ ਮੰਤਰ','Mool Mantar'));
 const nitnemRows=nitnemIds.filter(id=>byId[id]).map(id=>row(id,name(byId[id]))).join('');
 if(nitnemRows)html+=ghead(age('ਨਿਤਨੇਮ','Nitnem'))+nitnemRows;
 const catRows=catalogIds.filter(id=>byId[id]).map(id=>row(id,name(byId[id]))).join('');
 if(catRows)html+=ghead(age('ਬਾਣੀਆਂ','Banis'))+catRows;
 html+=ghead(age('ਕੀਰਤਨ','Kirtan'))+`<button class="drawer-row" data-action="kirtan"><span>${age('ਕੀਰਤਨ ਸ਼ਬਦ','Kirtan Shabads')}</span><span aria-hidden="true">›</span></button>`;
 if(!onlineCatalog.length)html=`<p class="fine">${age('ਸੂਚੀ ਖੁੱਲ੍ਹ ਰਹੀ ਹੈ…','Opening the list…')}</p>`;
 return `<div class="gs-drawer-scrim" data-drawer-close="1"></div>
 <aside class="gs-drawer" aria-label="${age('ਬਾਣੀਆਂ','Banis')}">
  <div class="gs-drawer-head"><strong>${age('ਬਾਣੀਆਂ','Banis')}</strong><button class="icon-button" data-drawer-close="1" aria-label="${age('ਬੰਦ ਕਰੋ','Close')}">×</button></div>
  <div class="gs-drawer-list">${html}</div>
 </aside>`;
}
function shareCurrent(){
 const title=activeRemote?(activeRemote.kind==='ang'?`SGGS, Ang ${activeRemote.id}`:activeRemote.title):'Gurbani Saanjh';
 const firstLine=activeRemote?.lines?.[0]?.g||'';
 const text=`${title}\n${firstLine}`;
 if(navigator.share){navigator.share({title,text}).catch(()=>{})}
 else if(navigator.clipboard){navigator.clipboard.writeText(text).then(()=>toast(age('ਕਾਪੀ ਹੋ ਗਿਆ','Copied'))).catch(()=>toast(title))}
 else toast(title);
}
function readerScreen(){
 if(activeRemote){
  if(activeRemote.loading)return `<section class="reading reading-immersive"><p class="remote-state">${age('ਪਾਠ ਖੋਲ੍ਹ ਰਹੇ ਹਾਂ…','Loading scripture…')}</p></section>`;
  if(activeRemote.error)return `<section class="reading reading-immersive remote-error"><p>${age('ਇਹ ਪਾਠ ਐਪ ਦੀ ਆਫਲਾਈਨ ਲਾਇਬ੍ਰੇਰੀ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ। ਬਿਲਡ ਦੀ ਜਾਂਚ ਕਰੋ।','This text is not in the installed offline library. Check the build report.')}</p><button data-retry-remote="1" class="secondary">${age('ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼','Retry')}</button></section>`;
  const kind=activeRemote.kind;
  const isSggs=kind==='ang';
  const sgAng=isSggs?Number(activeRemote.id):null;
  // v2.2.9: the top bar is never hidden in page mode (no scroll to reveal it); scroll mode keeps the full-screen-on-open behaviour.
  const barHidden=readerBarHidden&&state.mode==='scroll';
  const head=isSggs
   ?`<div class="gs-reading-topbar gs-ang-jump${barHidden?' gs-topbar-hidden':''}"><label class="gs-ang-jump-label">${age('ਅੰਗ','Ang')}<input id="angJumpInput" type="number" min="1" max="1430" value="${sgAng}" inputmode="numeric" aria-label="${age('ਅੰਗ ਨੰਬਰ','Ang number')}"></label><button type="button" id="angJumpGo" class="primary gs-ang-jump-go">${age('ਜਾਓ','Go')} ›</button><span class="gs-reading-actions"><button type="button" class="icon-button" data-action="open-viewprefs" aria-label="${t('readerSettings')}" title="${t('readerSettings')}">Aa</button></span></div>`
   :kind==='bani'
   ?`<div class="gs-reading-topbar${barHidden?' gs-topbar-hidden':''}"><button type="button" class="icon-button" data-action="toggle-drawer" aria-label="${age('ਬਾਣੀਆਂ','Banis')}">☰</button><strong class="gs-bani-topbar-title" lang="pa">${esc(activeRemote.title)}</strong><span class="gs-reading-actions"><button type="button" class="icon-button" data-action="open-viewprefs" aria-label="${t('readerSettings')}" title="${t('readerSettings')}">Aa</button></span></div>${baniHeaderBlock(activeRemote.lines,activeRemote.title)}`
   :`<div class="gs-reading-topbar${barHidden?' gs-topbar-hidden':''}"><strong lang="pa">${esc(activeRemote.meta?.firstLine||activeRemote.title||'')}</strong><span class="gs-reading-actions"><button type="button" class="icon-button" data-action="open-viewprefs" aria-label="${t('readerSettings')}">Aa</button></span></div>
     ${activeRemote.meta?`<div class="kirtan-shabad-ref"><span lang="pa">${esc([activeRemote.meta.raag,activeRemote.meta.mahla].filter(Boolean).join(' '))}</span><span>${t('ang')} ${activeRemote.meta.ang}</span> <button class="text-link" data-action="view-full-ang" data-ang="${activeRemote.meta.ang}">${t('viewFullAng')} ›</button></div>`:''}`;
  const versesHTML=(kind==='bani')
   ?VERSES.baniFlowHTML(activeRemote.lines,{vishraamOn:state.vishraams,koshHas,show:layerOpts(),foundIdx:highlightLine})
   :activeRemote.lines.map((l,i)=>{
   const heading=kind==='bani'&&VERSES.isBaniHeading(l.g);
   return verseBlock(l,i,kind,{heading});
  }).join('');
  const drawer=(kind==='bani'&&state.baniDrawer)?baniDrawerHTML():'';
  if(state.mode==='page'&&(isSggs||kind==='bani')){
   return `<section class="reading reading-immersive gs-book-reading gs-has-topbar ${isSggs?'gs-reader-sggs':'gs-reader-bani'}">${drawer}${head}<div class="gs-book-reference" aria-label="${esc(isSggs?`SGGS, Ang ${sgAng}`:activeRemote.title)}">${esc(isSggs?`SGGS, ${age('ਅੰਗ','Ang')} ${sgAng}`:activeRemote.title)}</div><div class="gs-book-stage" id="bookStage" aria-label="${age('ਕਿਤਾਬ ਵਾਂਗ ਪਾਠ','Book-style scripture reading')}"></div></section>`;
  }
  return `<section class="reading reading-immersive ${isSggs?'gs-reader-sggs':'gs-reader-bani'}${kind==='bani'&&state.showTranslit?' gs-translit-on':''}">${drawer}${head}<div class="verse-list" id="verses">${versesHTML}</div></section>`;
 }
 if(state.readView==='kirtan'){
  const item=CONTENT.kirtan.find(x=>x.id===state.kirtanId)||CONTENT.kirtan[0];
  return state.mode==='page'?`<section class="reading reading-immersive gs-book-reading gs-has-topbar"><div class="gs-reading-topbar"><strong lang="pa">${esc(item.lines[0]?.g||'')}</strong><span class="gs-reading-actions"><button type="button" class="icon-button" data-action="open-viewprefs" aria-label="${t('readerSettings')}" title="${t('readerSettings')}">Aa</button></span></div><div class="gs-book-stage" id="bookStage" aria-label="${age('ਕਿਤਾਬ ਵਾਂਗ ਪਾਠ','Book-style scripture reading')}"></div></section>`:`<section class="reading reading-immersive"><div class="verse-list">${item.lines.map((v,i)=>verseBlock(v,i,'kirtan')).join('')}</div></section>`;
 }
 return `<section class="reading reading-immersive remote-error"><p>${age('ਅੰਗ ਖੋਲ੍ਹਣ ਲਈ ਵਾਪਸ ਜਾਓ।','Go back to select an Ang.')}</p></section>`;
}
/* ---- Library / catalog / coming ---- */
function libraryScreen(){return `<section class="page"><h1>${t('library')}</h1><div class="ang-picker"><strong>${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ — ਅੰਗ ੧–੧੪੩੦','Sri Guru Granth Sahib Ji — Ang 1–1430')}</strong><div class="ang-picker-controls"><input type="number" id="angPicker" min="1" max="1430" value="${state.ang}" aria-label="Ang number"><button data-open-ang="1" class="primary">${age('ਅੰਗ ਖੋਲ੍ਹੋ','Read Ang')}</button></div><p class="fine muted">${age('ਸਾਰੇ ੧੪੩੦ ਅੰਗ ਐਪ ਦੇ ਅੰਦਰ ਹਨ। ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਚਾਹੀਦਾ।','All 1,430 Angs are bundled inside the APK and work offline.')}</p></div>
${[['nitnem',t('nitnem')],['catalog',t('catalog')],['kirtan',t('kirtan')]].map(([a,name])=>`<button class="catalog-row" data-action="${a}"><span>${name}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}
function catalogScreen(){return `<section class="page catalog-page"><h1>${t('catalog')}</h1><p class="muted fine">${t('catalogNotice')}</p>
<label class="catalog-search-box"><span aria-hidden="true">⌕</span><input type="search" id="catalogSearch" autocomplete="off" placeholder="${t('catalogSearch')}" value="${esc(catalogFilter)}" aria-label="${t('catalogSearch')}"></label>
<div id="catalogResults">${catalogRows(catalogFilter)}</div></section>`}
function catalogRows(filter){const q=String(filter||'').trim().toLocaleLowerCase();const groups=[['sggs','catalogSection1'],['dasam','catalogSection2'],['tradition','catalogSection3'],['bhai','catalogSection4']];const count=CATALOG.filter(i=>!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))).length;
return `<div class="catalog-count">${count} ${t('catalogResults')}</div>`+groups.map(([g,header])=>{const items=CATALOG.filter(i=>i.group===g&&(!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))));if(!items.length)return '';return `<section class="catalog-section"><h2>${t(header)}</h2>${items.map(i=>`<button class="catalog-row" data-catalog-id="${i.id}"><span>${esc(i[state.lang==='pa'?'titlePa':'titleEn'])}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}).join('')}
function comingScreen(){return `<section class="page"><h1>${esc(state.comingTitle||t('collection'))}</h1><div class="simple-card"><p>${t('pending')}</p><p class="fine">${t('sample')}</p></div><button class="secondary full" data-action="library">← ${t('library')}</button></section>`}
/* ---- Kirtan Shabad book ---- */
let kirtanBookList=null,kirtanBookFilter='',kirtanAlphaIndex=null;
async function ensureKirtanBook(){
 if(kirtanBookList!==null)return kirtanBookList;
 try{kirtanBookList=await window.GS_KIRTAN.list()}catch{kirtanBookList=[]}
 for(const s of kirtanBookList){s._initial=kirtanInitials(s.firstLine);s._romanInitial=kirtanRomanInitials(s.firstLine)}
 return kirtanBookList;
}
// v2.2.12: first-letter helpers for the Kirtan book — same bare-first-letter rule
// as GGS search (ਮਾਧੋ→ਮ, ਐਸੇ→ਅ, ਤੂ→ਤ). Roman initials come from a first-letter map.
const kirtanWords=s=>String(s||'').normalize('NFC').toLocaleLowerCase().replace(/[\u200c\u200d]/gu,'').trim().split(/[\s,;?!.।॥:()"'\[\]{}\-।੦-੯\d|]+/u).map(w=>w.replace(/^[^\p{L}\p{N}ੴ]+|[^\p{L}\p{N}\p{M}]+$/gu,'')).filter(Boolean);
const kirtanFoldFirst=ch=>({'ਆ':'ਅ','ਈ':'ਇ','ਊ':'ਉ','ਏ':'ਅ','ਐ':'ਅ','ਓ':'ਅ','ਔ':'ਅ'})[ch]||ch;
const kirtanInitials=s=>kirtanWords(s).filter(w=>w!=='ੴ').map(w=>kirtanFoldFirst(Array.from(w)[0]||'')).join('');
const KIRTAN_ROMAN_FIRST={'ੳ':'u','ਅ':'a','ਆ':'a','ਇ':'i','ਈ':'e','ਉ':'u','ਊ':'o','ਏ':'e','ਐ':'a','ਓ':'o','ਔ':'a','ਕ':'k','ਖ':'k','ਗ':'g','ਘ':'g','ਙ':'n','ਚ':'c','ਛ':'c','ਜ':'j','ਝ':'j','ਞ':'n','ਟ':'t','ਠ':'t','ਡ':'d','ਢ':'d','ਣ':'n','ਤ':'t','ਥ':'t','ਦ':'d','ਧ':'d','ਨ':'n','ਪ':'p','ਫ':'p','ਬ':'b','ਭ':'b','ਮ':'m','ਯ':'y','ਰ':'r','ਲ':'l','ਵ':'v','ੜ':'r','ਸ':'s','ਹ':'h','ਖ਼':'k','ਗ਼':'g','ਜ਼':'z','ਫ਼':'f','ਸ਼':'s'};
const kirtanRomanInitials=s=>kirtanWords(s).map(w=>KIRTAN_ROMAN_FIRST[Array.from(w)[0]]||'').join('');
// v2.2.8: Kirtan Shabads A-Z in traditional Gurmukhi order (ਅ … ੜ).
// Plain code-point sort would put ਸ near the end; this rank map keeps ਅ, ੲ, ਸ, ਹ first.
// v2.2.12: ਇ/ਉ sit in their traditional spots after ਅ, and vowel variants fold to
// their base (ਆ/ਏ/ਐ/ਓ/ਔ→ਅ, ਈ→ਇ, ਊ→ਉ) so they sort with their letter, not at the end.
const GS_ALPHA='ੳਅਇਉੲਸਹਕਖਗਘਙਚਛਜਝਞਟਠਡਢਣਤਥਦਧਨਪਫਬਭਮਯਰਲਵੜਖ਼ਗ਼ਜ਼ਫ਼';
const gsAlphaKey=s=>String(s||'').split('').map(ch=>{const f=kirtanFoldFirst(ch);const i=GS_ALPHA.indexOf(f);return i>=0?String.fromCharCode(256+i):ch}).join('');
function kirtanBookRows(){
 const qRaw=kirtanBookFilter.trim(),q=qRaw.toLocaleLowerCase();
 const items=(kirtanBookList||[]).filter(s=>{
  if(!q)return true;
  const fl=(s.firstLine||'').toLocaleLowerCase(),rg=(s.raag||'').toLocaleLowerCase();
  // v2.2.12: a single bare letter behaves like tapping that letter in the
  // A-Z index — initials only, never a substring flood of the whole book.
  if(qRaw.length===1&&!/[\p{M}]/u.test(qRaw)){
   const ch=kirtanFoldFirst(Array.from(q)[0]||'');
   if((s._initial||'').startsWith(ch))return true;
   if(/[a-z]/.test(q)&&(s._romanInitial||'').startsWith(q))return true;
   return false;
  }
  if(fl.includes(q)||rg.includes(q))return true;
  // v2.2.12: first-letter search (same rule as GGS) — bare-letter queries only.
  // A query with a matra (ਸਤਿਗੁਰ, ਜਪੁ) is a full word, not initials, so it stays
  // substring-only and never floods the list with every Shabad of that letter.
  if(!/[\p{M}]/u.test(qRaw)){
   const sig=Array.from(q.replace(/[^\p{L}]/gu,'')).map(kirtanFoldFirst).join('');
   if(sig.length>=1&&(s._initial||'').startsWith(sig))return true;
   if(/[a-z]/.test(q)){
    const rsig=q.replace(/[^a-z]/g,'');
    if(rsig.length>=1&&(s._romanInitial||'').startsWith(rsig))return true;
   }
  }
  return false;
 });
 items.sort((a,b)=>{const ka=gsAlphaKey(a.firstLine),kb=gsAlphaKey(b.firstLine);return ka<kb?-1:ka>kb?1:0});
 // v2.2.12: A-Z index — first row index per letter, in the list's own order.
 kirtanAlphaIndex=null;
 if(!q){
  kirtanAlphaIndex={};
  items.forEach((s,i)=>{
   const first=Array.from(String(s.firstLine||'').trim())[0]||'';
   const pa=kirtanFoldFirst(first),en=KIRTAN_ROMAN_FIRST[first]||'';
   if(pa&&!(pa in kirtanAlphaIndex))kirtanAlphaIndex[pa]=i;
   if(en){const k='en:'+en.toUpperCase();if(!(k in kirtanAlphaIndex))kirtanAlphaIndex[k]=i;}
  });
 }
 if(!items.length)return `<p class="fine muted">${q?age('ਕੋਈ ਸ਼ਬਦ ਨਹੀਂ ਮਿਲਿਆ।','No Shabad found.'):age('ਕਿਤਾਬ ਖਾਲੀ ਹੈ।','The book is empty.')}</p>`;
 return items.map(s=>`<button class="catalog-row kirtan-book-row" data-kirtan-shabad="${esc(s.id)}"><span lang="pa"><strong>${esc(s.firstLine)}</strong><small class="gutka-sub">${esc([s.raag,s.mahla].filter(Boolean).join(' '))} · ${t('ang')} ${s.ang}</small></span><span aria-hidden="true">›</span></button>`).join('');
}
// v2.2.12: A-Z side strip for the Kirtan book — tap or drag a letter to jump to
// the first Shabad starting with it. Punjabi shows Gurmukhi letters, English A-Z.
function renderKirtanAlpha(){
 const strip=$('kirtanAlpha');if(!strip)return;
 let letters=[];
 if(kirtanAlphaIndex){
  const keys=Object.keys(kirtanAlphaIndex);
  letters=state.lang==='pa'?keys.filter(k=>!k.startsWith('en:')):keys.filter(k=>k.startsWith('en:')).map(k=>k.slice(3)).sort();
 }
 if(kirtanBookFilter.trim()||!letters.length){strip.innerHTML='';strip.style.display='none';return;}
 strip.style.display='flex';
 strip.innerHTML=letters.map(l=>`<span class="kirtan-alpha-letter" data-alpha="${esc(l)}">${esc(l)}</span>`).join('');
}
function kirtanAlphaJump(letter){
 if(!kirtanAlphaIndex)return;
 const key=state.lang==='pa'?letter:'en:'+letter;
 const idx=kirtanAlphaIndex[key];if(idx==null)return;
 const rows=[...document.querySelectorAll('.kirtan-book-row')];
 const row=rows[idx];if(!row)return;
 row.scrollIntoView({block:'start'});
 row.classList.add('kirtan-alpha-flash');
 setTimeout(()=>row.classList.remove('kirtan-alpha-flash'),1200);
}
function kirtanScreen(){
 const saved=state.savedVerses||[];
 const hasQuery=kirtanQuery.trim().length>0;
 return `<section class="page"><h1>${t('kirtan')}</h1><p class="muted fine">${t('kirtanNote')}</p>
 <div class="section-head">${t('kirtanBook')}</div>
 <div class="inputrow"><span aria-hidden="true">⌕</span><input type="search" id="kirtanBookSearch" autocomplete="off" placeholder="${t('kirtanSearchHint')}" value="${esc(kirtanBookFilter)}" aria-label="${t('kirtanSearchHint')}"></div>
 <div class="kirtan-book-wrap"><div id="kirtanBookResults"><p class="fine muted">${age('ਕਿਤਾਬ ਖੁੱਲ੍ਹ ਰਹੀ ਹੈ…','Opening the book…')}</p></div><div class="kirtan-alpha" id="kirtanAlpha" aria-hidden="true"></div></div>
 <div class="section-head">${age('ਪਾਠ ਵਿੱਚ ਖੋਜ','Search the scripture')}</div>
 <div class="inputrow"><span aria-hidden="true">⌕</span><input type="search" id="kirtanSearch" lang="pa" enterkeyhint="search" placeholder="${age('ਸ਼ਬਦ ਜਾਂ ਪਹਿਲੀ ਪੰਗਤੀ ਖੋਜੋ','Search a word or first line')}" value="${esc(kirtanQuery)}"></div>
 <div id="kirtanResults">${hasQuery?`<p class="fine">${age('ਪਾਠ ਵਿੱਚ ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching the offline text…')}</p>`:''}</div>
 <div class="section-head">${age('ਸੰਭਾਲੇ ਹੋਏ ਸ਼ਬਦ','Saved Shabads')} (${saved.length})</div>
 ${saved.length?saved.map(v=>v.src==='bani'?`<div class="simple-card item-row"><button class="item-main" data-open-saved-bani="${v.baniId}" data-open-saved-idx="${Number(v.idx)}" data-bani-title="${esc(v.baniTitle||v.titlePa||'')}"><strong lang="pa">${esc(v.g)}</strong><small>${v.group==='dasam'?'Dasam Granth — ':''}${esc(v.baniTitle||v.titlePa||'')}</small></button><button data-remove-saved="bani:${v.baniId}:${Number(v.idx)}" class="favorite selected" aria-label="Remove bookmark">♥</button></div>`:`<div class="simple-card item-row"><button class="item-main" data-open-saved-ang="${Number(v.ang)}" data-open-saved-idx="${Number(v.idx)}"><strong lang="pa">${esc(v.g)}</strong><small>${t('ang')} ${Number(v.ang)}</small></button><button data-remove-saved="${Number(v.ang)}:${Number(v.idx)}" class="favorite selected" aria-label="Remove bookmark">♥</button></div>`).join(''):`<p class="fine muted">${age('ਖੋਜ ਨਤੀਜੇ ਵਿੱਚੋਂ ♡ ਦਬਾ ਕੇ ਸ਼ਬਦ ਸੰਭਾਲੋ।','Tap ♡ beside a search result to save it.')}</p>`}
 </section>`;
}
function bookmarksScreen(){return `<section class="page bookmarks-page"><h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1>${(state.savedVerses||[]).length?state.savedVerses.map(v=>v.src==='bani'?`<button class="catalog-row" data-open-saved-bani="${v.baniId}" data-open-saved-idx="${Number(v.idx)}" data-bani-title="${esc(v.baniTitle||v.titlePa||'')}"><span lang="pa">${esc(v.g)}</span><span>${v.group==='dasam'?'Dasam Granth — ':''}${esc(v.baniTitle||v.titlePa||'')} ›</span></button>`:`<button class="catalog-row" data-open-saved-ang="${v.ang}" data-open-saved-idx="${v.idx}"><span lang="pa">${esc(v.g)}</span><span>${age('ਅੰਗ','Ang')} ${v.ang} ›</span></button>`).join(''):`<p class="fine">${age('ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੰਭਾਲਿਆ ਨਹੀਂ।','Nothing saved yet.')}</p>`}<button class="secondary full" data-action="kirtan">${t('kirtan')} ›</button></section>`}
/* ---- Search (iGranth behavior) ---- */
const GS_KEYS=[
 ['ੳ/ਓ','ਅ','ੲ','ਸ','ਹ'],
 ['ਕ','ਖ','ਗ','ਘ','ਙ'],
 ['ਚ','ਛ','ਜ','ਝ','ਞ'],
 ['ਟ','ਠ','ਡ','ਢ','ਣ'],
 ['ਤ','ਥ','ਦ','ਧ','ਨ'],
 ['ਪ','ਫ','ਬ','ਭ','ਮ'],
 ['ਯ','ਰ','ਲ','ਵ','ੜ'],
];
const GS_KEY_VALUE={'ੳ/ਓ':'ੳ'};
function gsKeyboardHTML(){
 return `<div class="gs-keyboard" id="gsKeyboard" role="group" aria-label="${age('ਗੁਰਮੁਖੀ ਅੱਖਰ','Gurmukhi letters')}">${GS_KEYS.map(row=>`<div class="gs-key-row">${row.map(k=>`<button type="button" class="gs-key" data-gs-key="${esc(k)}">${esc(k)}</button>`).join('')}<button type="button" class="gs-key gs-key-back" data-gs-key="⌫" aria-label="${age('ਮਿਟਾਓ','Delete')}">⌫</button></div>`).join('')}</div>`;
}
function searchScreen(){
 const modes=[['auto',age('ਸਭ','All')],['first',age('ਪਹਿਲੇ ਅੱਖਰ','First letters')],['any-first',age('ਵਿਚਕਾਰਲੇ ਅੱਖਰ','Letters anywhere')],['word',age('ਪੂਰਾ ਸ਼ਬਦ','Full word')],['roman',age('English ਅੱਖਰ','Romanised')],['ang',age('ਅੰਗ','Ang')]];
 return `<section class="page search-page">
 <div class="search-darkhead"><h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1><p>${t('searchTitle')}</p></div>
 <div class="inputrow gs-search-box"><span aria-hidden="true">⌕</span><input id="searchInput" type="search" autocomplete="off" lang="pa" enterkeyhint="search" placeholder="${t('searchHint')}" aria-label="${t('searchHint')}"><button type="button" id="searchClear" aria-label="${t('clear')}" title="${t('clear')}">✕</button><button type="button" id="voiceBtn" aria-label="${age('ਬੋਲ ਕੇ ਖੋਜ','Voice search')}" title="${age('ਬੋਲ ਕੇ ਖੋਜ','Voice search')}">🎙</button><button type="button" id="kbToggle" class="gs-kb-toggle" aria-label="${age('ਕੀਬੋਰਡ ਭਾਸ਼ਾ','Keyboard language')}" title="${age('ਕੀਬੋਰਡ ਭਾਸ਼ਾ','Keyboard language')}">${state.kbLang==='pa'?'ਪੁ':'EN'}</button></div>
 <div class="gs-icon-row" role="group" aria-label="${t('options')}">
  <button type="button" id="iconSearch" aria-label="${t('search')}">🔍<small>${t('search')}</small></button>
  <button type="button" id="iconBookmarks" aria-label="${age('ਸੰਭਾਲੇ','Saved')}">🔖<small>${age('ਸੰਭਾਲੇ','Saved')}</small></button>
  <button type="button" id="iconHistory" aria-label="${t('history')}">☰<small>${t('history')}</small></button>
 </div>
 <div class="gs-search-modes" id="gsSearchModes" role="group" aria-label="Search method">${modes.map(([v,label])=>`<button type="button" data-search-mode="${v}" class="${v===searchMode?'sel':''}">${label}</button>`).join('')}</div>
 ${state.kbLang==='pa'?gsKeyboardHTML():''}
 <p id="voiceStatus" role="status" class="fine muted"></p>
 <div id="searchResults"></div>
 <div id="searchHistoryBox" class="hidden">${searchHistoryBoxHTML()}</div>
 </section>`;
}
// v2.2.44: the history box (heading + Clear-all button + list) in one place,
// so every re-render — open, clear-all, single delete — shows the button
// exactly when history is non-empty.
function searchHistoryBoxHTML(){
 return `<div class="section-head">${t('history')}${state.searchHistory.length?`<button type="button" class="text-link" data-clear-history>${age('ਸਭ ਸਾਫ਼ ਕਰੋ','Clear all')}</button>`:''}</div><div id="searchHistoryList">${searchHistoryHTML()}</div>`;
}
function searchHistoryHTML(){
 if(!state.searchHistory.length)return `<p class="fine muted">${t('noHistory')}</p>`;
 // v2.2.44: each row is a container — the query button re-runs the search
 // (as before) and the × deletes just that one item.
 return state.searchHistory.map(q=>`<div class="history-row"><button class="catalog-row" data-history-q="${esc(q)}"><span lang="pa">${esc(q)}</span><span aria-hidden="true">›</span></button><button type="button" class="history-del" data-remove-history="${esc(q)}" aria-label="${age('ਇਤਿਹਾਸ ਵਿੱਚੋਂ ਹਟਾਓ','Remove from history')}">×</button></div>`).join('');
}
function pushSearchHistory(q){
 q=String(q||'').trim();if(!q||q.length<2)return;
 state.searchHistory=[q,...state.searchHistory.filter(x=>x!==q)].slice(0,12);persist();
}
// Ang file cache for raag/mahla derivation (from bundled data only).
const angFileCache=new Map();
async function readAngCached(n){
 if(angFileCache.has(n))return angFileCache.get(n);
 const p=window.GS_REMOTE.read('ang',n).then(d=>d).catch(()=>null);
 angFileCache.set(n,p);
 if(angFileCache.size>12){const k=angFileCache.keys().next().value;angFileCache.delete(k)}
 return p;
}
const RAAG_LINE_RE=/ਮਹਲਾ|ਮਹਲੁ|ਰਾਗੁ/;
async function raagFor(ang,idx){
 try{
  const data=await readAngCached(ang);
  const arr=data?.lines||[];
  for(let i=Math.min(idx,arr.length-1);i>=0;i--){
   const g=String(arr[i]?.g||'').trim();
   if(g&&RAAG_LINE_RE.test(g)&&g.split(/\s+/).length<=12)return g;
  }
 }catch{}
 return '';
}
function fillRaagHeaders(scope){
 scope.querySelectorAll('[data-raag-for]').forEach(async el=>{
  const [a,i]=String(el.dataset.raagFor).split(':').map(Number);
  const raag=await raagFor(a,i);
  el.innerHTML=`${raag?`<span class="gs-raag" lang="pa">${esc(raag)}</span><span class="gs-raag-sep"> · </span>`:''}<span>${age('ਅੰਗ','Ang')} ${a}</span>`;
 });
}
// v2.2.30: fill the English translation under each SGGS search result.
// The SGGS index carries no en — it comes from the Ang file, same async
// enrichment pattern as fillRaagHeaders. A line with no English translation
// leaves no trace (the empty span is removed, no placeholder text).
async function enFor(ang,idx){
 try{
  const data=await readAngCached(ang);
  return String(data?.lines?.[Number(idx)]?.en||'').trim();
 }catch{return ''}
}
function fillResultEn(scope){
 scope.querySelectorAll('[data-en-for]').forEach(async el=>{
  const [a,i]=String(el.dataset.enFor).split(':').map(Number);
  const en=await enFor(a,i);
  if(en)el.textContent=en; else el.remove();
 });
}
// v2.2.28: every result shows its source CLEARLY on the result itself —
// SGGS shows Ang N (as before); Bani shows the Bani name, bold with a Bani
// tag, so the source is obvious at a glance. Tapping a Bani result opens
// that Bani at the line; tapping an SGGS result opens that Ang, as before.
function scriptureResultsMarkup(arr,{save=false}={}){
 return arr.map(v=>{
  const isBani=v.src==='bani';
  const isDasam=isBani&&v.group==='dasam';
  const tPa=v.titlePa||v.baniTitle||'',tEn=v.titleEn||'';
  const primary=state.lang==='pa'?(tPa||tEn):(tEn||tPa);
  const secondary=state.lang==='pa'?tEn:tPa;
  const ref=isBani
   ?`<span class="gs-result-ref gs-result-bani"><span class="gs-result-bani-tag${isDasam?' gs-result-dasam-tag':''}">${isDasam?'Dasam Granth':age('ਬਾਣੀ','Bani')}</span><strong class="gs-result-bani-name" lang="pa">${esc(primary)}</strong>${secondary&&secondary!==primary?` <span class="gs-result-bani-en">${esc(secondary)}</span>`:''}</span>`
   :`<span class="gs-result-ref" data-raag-for="${v.ang}:${v.idx}"><span>${age('ਅੰਗ','Ang')} ${v.ang}</span></span>`;
  const open=isBani
   ?`data-found-bani="${v.baniId}" data-found-idx="${v.idx}" data-bani-title="${esc(primary||'Bani')}"`
   :`data-found-ang="${v.ang}" data-found-idx="${v.idx}"`;
  const saveKey=isBani?`bani:${v.baniId}:${v.idx}`:`${v.ang}:${v.idx}`;
  const saved=isBani
   ?state.savedVerses.some(x=>x.src==='bani'&&x.baniId===v.baniId&&x.idx===v.idx)
   :state.savedVerses.some(x=>x.src!=='bani'&&x.ang===v.ang&&x.idx===v.idx);
  const enHtml=isBani
   ?(String(v.en||'').trim()?`<span class="gs-result-en" lang="en">${esc(v.en)}</span>`:'')
   :`<span class="gs-result-en" lang="en" data-en-for="${v.ang}:${v.idx}"></span>`;
  // v2.2.32: Roman transliteration under the Gurmukhi pangti (above the
  // English translation), shown only when Transliteration is on in Bani
  // View Preferences (default ON). A Roman query finds the pangti, and the
  // transliteration under it is what the user reads to confirm the match.
  const romanHtml=state.showTranslit&&String(v.roman||'').trim()
   ?`<span class="gs-result-roman" lang="en-Latn">${esc(v.roman)}</span>`:'';
  return `<div class="gs-result-row"><button class="result gs-result-open" ${open}>${ref}<strong lang="pa">${esc(v.g)}</strong>${romanHtml}${enHtml}</button>${save?`<button class="favorite" data-save-hit="${saveKey}" aria-label="Save Shabad">${saved?'♥':'♡'}</button>`:''}</div>`;
 }).join('');
}
/* ---- Ask Guru Granth Sahib ---- */
// v2.2.24: pinch-to-zoom helpers for the AI answer. Two fingers on the
// answer: pinch out grows the text, pinch in shrinks it. Same 14-32
// clamp as the A+/A- buttons; the size is saved on touchend.
function pinchDist(t){return Math.hypot(t[0].clientX-t[1].clientX,t[0].clientY-t[1].clientY)}
function pinchFont(startFont,startDist,curDist){if(!(startDist>0)||!(curDist>0))return Math.min(32,Math.max(14,Math.round(Number(startFont)||18)));return Math.min(32,Math.max(14,Math.round((Number(startFont)||18)*curDist/startDist)))}
// v2.2.25: pinch-to-zoom, document-level. Attached ONCE at startup so it
// survives re-renders; arms on touchstart OR touchmove with 2 touches.
let pinchState=null,pinchWired=false;
function pinchInAnswer(e){const ts=e.touches||[];for(let i=0;i<ts.length;i++){const t=ts[i]&&ts[i].target;if(t&&t.closest&&(t.closest('.ai-answer')||t.closest('.qa-card')))return true}const t=e.target;return !!(t&&t.closest&&(t.closest('.ai-answer')||t.closest('.qa-card')))}
function setupPinchZoom(){if(pinchWired)return;pinchWired=true;
 document.addEventListener('touchstart',e=>{if(e.touches.length===2&&pinchInAnswer(e))pinchState={d:pinchDist(e.touches),f:(Number(state.aiFont)||18)}},{passive:true});
 document.addEventListener('touchmove',e=>{if(e.touches.length!==2)return;if(!pinchState&&pinchInAnswer(e))pinchState={d:pinchDist(e.touches),f:(Number(state.aiFont)||18)};if(pinchState){e.preventDefault();state.aiFont=pinchFont(pinchState.f,pinchState.d,pinchDist(e.touches));theme()}},{passive:false});
 const endPinch=()=>{if(pinchState){pinchState=null;persist()}};
 document.addEventListener('touchend',endPinch);document.addEventListener('touchcancel',endPinch);}
setupPinchZoom();
function askScreen(){return `<section class="page ask"><h1>${t('askTitle')}</h1><p class="fine">${age('ਸਵਾਲ ਲਿਖੋ ਜਾਂ ਬੋਲੋ। AI ਪਹਿਲਾਂ ਬਾਣੀ ਦੀ ਪੰਕਤੀ ਦੱਸੇਗਾ, ਫਿਰ ਉਸਦਾ ਅਰਥ ਸਮਝਾਵੇਗਾ — ਪੰਜਾਬੀ ਜਾਂ English ਵਿੱਚ। ਸੌਖਾ ਚੁਣੋ ਤਾਂ ਬੱਚਿਆਂ ਲਈ ਸੌਖੇ ਸ਼ਬਦਾਂ ਵਿੱਚ।','Type or speak your question. The AI first quotes the Bani verse, then explains its meaning — in Punjabi or English. Simple explains it in easy words, like to a child.')}</p>
 <div class="inputrow"><textarea id="questionInput" placeholder="${t('askHint')}" aria-label="${t('askHint')}"></textarea><button type="button" id="askVoiceBtn" aria-label="${age('ਬੋਲ ਕੇ ਸਵਾਲ','Ask by voice')}" title="${age('ਬੋਲ ਕੇ ਸਵਾਲ','Ask by voice')}">🎙</button></div>
 <div class="answer-pills">${[['short','short'],['detail','detail'],['deep','deep']].map(([k,name])=>`<button data-depth="${k}" class="${state.depth===k?'sel':''}">${t(name)}</button>`).join('')}</div>
 <div class="answer-pills ai-lang-pills" role="group" aria-label="${age('AI ਜਵਾਬ ਦੀ ਭਾਸ਼ਾ','AI answer language')}">${[['pa','ਪੰਜਾਬੀ'],['en','English']].map(([k,label])=>`<button data-ai-lang="${k}" class="${state.aiLang===k?'sel':''}">${label}</button>`).join('')}</div>
 <p class="fine" id="aiStatusLine">${(String(state.aiApiKey||'').trim()||String(state.aiEndpoint||'').trim()||AI_CLOUD_ENDPOINT)?age('AI ਔਨਲਾਈਨ ਹੈ — ਜਵਾਬ ਗੁਰਬਾਣੀ ਹਵਾਲਿਆਂ ਨਾਲ ਆਵੇਗਾ।','AI is online — answers come with Gurbani references.'):age('AI ਔਫਲਾਈਨ ਹੈ — Bani View Preferences › AI ਵਿੱਚ API key ਜਾਂ ਆਪਣਾ ਸਰਵਰ ਜੋੜੋ।','AI is offline — add an API key or your private server in Bani View Preferences › AI.')}</p>
 <button id="askButton" class="primary full" style="margin-top:14px">${t('askButton')}</button><div id="conversation">${state.questions.length?renderQA(state.questions[state.questions.length-1]):''}</div>
 <p class="fine muted">${age('AI ਦੀ ਵਿਆਖਿਆ ਨੂੰ ਮੂਲ ਗੁਰਬਾਣੀ ਤੋਂ ਵੱਖਰਾ ਰੱਖਿਆ ਜਾਂਦਾ ਹੈ।','AI interpretation is always distinct from original Gurbani.')}</p></section>`}
// v2.2.18: render an AI answer with its quoted Gurmukhi verse lines bold +
// highlighted. A line is a verse line when it carries Gurmukhi AND an Ang
// reference (Ang N) or a verse-number marker. Everything else is the plain
// explanation. Each line is escaped first, then wrapped.
function aiAnswerHTML(answer){
 const isVerse=line=>{
  if(!/[\u0A00-\u0A7F]/.test(line))return false;
  if(/\bAng\s*[0-9]+/i.test(line))return true;
  if(/(?:\u0965|\|\|)\s*[\u0A66-\u0A6F0-9]+\s*(?:\u0965|\|\|)\s*$/.test(line.trim()))return true;
  return false;
 };
 return String(answer||'').split('\n').map(line=>{
  const e=esc(line);
  return isVerse(line)?`<span class="ai-verse">${e}</span>`:e;
 }).join('\n');
}
function renderQA(v){
 return `<div class="simple-card qa-card"><strong>${esc(v.q)}</strong>
 ${v.answer?`<div class="qa-label">${t('aiAnswerLabel')}${v.answerSource?` <small>(${esc(v.answerSource)})</small>`:''}</div><p class="ai-answer">${aiAnswerHTML(v.answer)}</p>`:''}
 ${v.aiPending?`<p class="fine">${age('AI ਜਵਾਬ ਲਿਖ ਰਿਹਾ ਹੈ…','Writing the AI answer…')}</p>`:''}
 ${v.aiError&&!v.answer?`<p class="fine" style="color:#b3261e">${age('AI ਗਲਤੀ: ','AI error: ')}${esc(v.aiError)}</p>`:''}
 ${!v.answer&&!v.aiPending&&!String(state.aiApiKey||'').trim()&&!String(state.aiEndpoint||'').trim()&&!AI_CLOUD_ENDPOINT?`<p class="fine muted">${t('aiNeedsKey')}</p>`:''}
 ${v.matches?.length?`<div class="qa-label">${t('relatedOffline')}</div><div class="ai-sources">${scriptureResultsMarkup(v.matches)}</div>`:`<p class="fine">${age('ਇਸ ਸਵਾਲ ਨਾਲ ਸਬੰਧਤ ਕੋਈ ਹਵਾਲਾ ਨਹੀਂ ਮਿਲਿਆ।','No matching passage was retrieved for this question.')}</p>`}
 </div>`;
}
async function answerQuestion(){
 const field=$('questionInput'),q=field?.value.trim();if(!q){toast(age('ਸਵਾਲ ਲਿਖੋ','Enter a question'));return}
 const btn=$('askButton');if(btn){btn.disabled=true;btn.textContent=age('ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching…')}
 try{
  const matches=await window.GS_SCRIPTURE_SEARCH.query(q,12);
 // v2.2.8: English topic -> Gurmukhi bridge. The offline English translations
 // often say "worry" where the question says "anxiety", so also pull the
 // Gurmukhi verses for the topic and merge them in (deduped, still max 12).
 const TOPIC_BRIDGE={anxiety:'ਚਿੰਤਾ',worry:'ਚਿੰਤਾ',worries:'ਚਿੰਤਾ',worried:'ਚਿੰਤਾ',fear:'ਡਰ',afraid:'ਡਰ',anger:'ਕ੍ਰੋਧ',angry:'ਕ੍ਰੋਧ',ego:'ਹਉਮੈ',pride:'ਹਉਮੈ',peace:'ਸੁਖ',death:'ਮੌਤ',love:'ਪ੍ਰੇਮ',patience:'ਸਬਰ',greed:'ਲੋਭ',sad:'ਦੁਖ',sadness:'ਦੁਖ',hope:'ਆਸ',faith:'ਸਰਧਾ',god:'ਰਬ',stress:'ਚਿੰਤਾ',tension:'ਚਿੰਤਾ',guru:'ਗੁਰੂ',waheguru:'ਵਾਹਿਗੁਰੂ',nanak:'ਨਾਨਕ',simran:'ਸਿਮਰਨ',naam:'ਨਾਮੁ',karma:'ਕਰਮ',maya:'ਮਾਇਆ',sewa:'ਸੇਵਾ',satsang:'ਸਤਸੰਗੁ',mukti:'ਮੁਕਤਿ'};
 const ql=q.toLocaleLowerCase();
 for(const w of Object.keys(TOPIC_BRIDGE).filter(w=>ql.includes(w)).slice(0,3)){
  try{const extra=await window.GS_SCRIPTURE_SEARCH.query(TOPIC_BRIDGE[w],6,'word');
   for(const mm of extra)if(!matches.some(x=>(x.src==='bani'?'bani:'+x.baniId+':'+x.idx:'ang:'+x.ang+':'+x.idx)===(mm.src==='bani'?'bani:'+mm.baniId+':'+mm.idx:'ang:'+mm.ang+':'+mm.idx)))matches.push(mm);
  }catch{}
 }
 matches.splice(12);
  const entry={q,depth:state.depth,answer:'',answerSource:'',aiError:'',aiPending:false,matches:matches.map(m=>m.src==='bani'?{src:'bani',baniId:m.baniId,baniTitle:m.baniTitle||m.titlePa,titlePa:m.titlePa,titleEn:m.titleEn,group:m.group||'sggs',idx:m.idx,g:m.g}:{src:'sggs',ang:m.ang,idx:m.idx,g:m.g})};
  const history=state.questions.slice(-3).map(v=>({q:v.q,a:String(v.answer||'').slice(0,800)}));
  state.questions.push(entry);state.questions=state.questions.slice(-12);persist();render();
  pushSearchHistory(q);
  // Detailed AI answer: user's own API key (OpenAI-compatible) takes priority;
  // otherwise the shared cloud AI server answers (no key needed). A user-set
  // private server (state.aiEndpoint) wins over the cloud default.
  const apiKey=String(state.aiApiKey||'').trim();
  const legacyEndpoint=String(state.aiEndpoint||'').trim()||AI_CLOUD_ENDPOINT;
  const legacyToken=String(state.aiAccessToken||'').trim()||AI_CLOUD_TOKEN;
  if(apiKey&&entry.matches.length){
   entry.aiPending=true;persist();render();
   try{
    entry.answer=await askOpenAI(q,entry.matches,history);
    entry.answerSource=age('ਤੁਹਾਡੀ API key','your API key');
   }catch(e){console.warn('AI answer failed',e);entry.aiError=String(e&&e.message||e);toast(age('AI ਜਵਾਬ ਨਹੀਂ ਮਿਲਿਆ ('+entry.aiError+'); ਸਬੰਧਤ ਸ਼ਬਦ ਥੱਲੇ ਹਨ।','AI answer failed ('+entry.aiError+'); related Shabads are shown below.'))}
   entry.aiPending=false;
  }else if(legacyEndpoint&&/^https:\/\//.test(legacyEndpoint)&&entry.matches.length){
   entry.aiPending=true;persist();render();
   try{
    const res=await fetch(legacyEndpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+legacyToken},body:JSON.stringify({question:q,depth:state.depth,language:state.aiLang,verses:entry.matches,history})});
    if(!res.ok)throw Error('AI service returned '+res.status);
    const data=await res.json();entry.answer=typeof data.answer==='string'?data.answer.slice(0,12000):'';
    entry.answerSource=String(state.aiEndpoint||'').trim()?age('ਤੁਹਾਡਾ ਸਰਵਰ','your server'):age('ਕਲਾਉਡ AI','cloud AI');
   }catch(e){console.warn('AI server failed',e);entry.aiError=String(e&&e.message||e);toast(age('AI ਸਰਵਰ ਨਹੀਂ ਜੁੜ ਸਕਿਆ ('+entry.aiError+'); ਅਸਲੀ ਹਵਾਲੇ ਦਿਖਾਏ ਗਏ ਹਨ।','AI server unavailable ('+entry.aiError+'). Showing original references.'))}
   entry.aiPending=false;
  }
  persist();render();
 }catch(e){toast(age('ਆਫਲਾਈਨ ਡਾਟਾ ਨਹੀਂ ਮਿਲਿਆ','Offline scripture index missing'));console.warn(e)}
 finally{const b=$('askButton');if(b){b.disabled=false;b.textContent=t('askButton')}}
}
async function askOpenAI(question,matches,history=[]){
 const endpoint=String(state.aiApiEndpoint||'').trim()||AI_DEFAULT_ENDPOINT;
 const model=String(state.aiModel||'').trim()||'gpt-4o-mini';
 const level=state.depth==='short'?'Explain in very simple words, as if to a 10-year-old child. Use short sentences.':state.depth==='deep'?'Explain in depth: meaning, context, and what it means for a person\'s life.':'Explain clearly, with context for an adult reader.';
 const context=matches.map(m=>m.src==='bani'?`[${m.group==='dasam'?'Dasam Granth — ':''}${m.baniTitle||m.titlePa||'Bani'}] ${m.g}`:`[Ang ${m.ang}] ${m.g}`).join('\n');
 const historyMsgs=[];
 for(const h of (Array.isArray(history)?history:[]).slice(-3)){if(!h||!h.q)continue;historyMsgs.push({role:'user',content:'Earlier question: '+h.q});if(h.a)historyMsgs.push({role:'assistant',content:h.a})}
 const res=await fetch(endpoint,{method:'POST',
  headers:{'Content-Type':'application/json','Authorization':'Bearer '+String(state.aiApiKey||'').trim()},
  body:JSON.stringify({model,messages:[
   {role:'system',content:AI_SYSTEM_PROMPT},
   ...historyMsgs,
   {role:'user',content:`Question: ${question}\nLevel: ${level}\nAnswer in ${state.aiLang==='en'?'English':'Punjabi'}.\n\nGurbani passages:\n${context}`}
  ],temperature:0.2,max_tokens:900})});
 if(!res.ok)throw Error('AI API returned '+res.status);
 const data=await res.json();
 const text=data?.choices?.[0]?.message?.content;
 if(typeof text!=='string'||!text.trim())throw Error('Empty AI answer');
 return text.trim().slice(0,12000);
}
/* ---- Bani View Preferences ---- */
function viewprefsScreen(){
 const choice=(key,options)=>`<div class="choice">${options.map(([v,name])=>`<button data-setting="${key}" data-value="${v}" class="${String(state[key])===String(v)?'sel':''}">${name}</button>`).join('')}</div>`;
 const toggle=(key,label,note='')=>`<div class="setting-row"><div><strong>${label}</strong>${note?`<span class="desc">${note}</span>`:''}</div>${choice(key,[['true',t('on')],['false',t('off')]])}</div>`;
 // v2.2.43: Play Store build hides the AI settings (build-time flag GS_HIDE_AI_SETTINGS
 // -> window.GS_BUILD.hideAiSettings, set only by the AAB workflow). The AI itself
 // (Ask via cloud) is NOT hidden — only this settings section.
 const hideAI=!!(window.GS_BUILD&&window.GS_BUILD.hideAiSettings);
 const aiSection=hideAI?'':`<div class="menu-group-label">AI</div>
 <div class="setting-row"><div><strong>${t('aiKey')}</strong><span class="desc">${age('ਸਿਰਫ਼ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ — AI ਜਵਾਬ ਲਈ','Stored only on this phone — needed for AI answers')}</span></div><input id="aiKeyInput" type="password" autocomplete="off" placeholder="sk-…" value="${esc(state.aiApiKey||'')}" style="max-width:50%;min-width:130px"></div>
 <div class="setting-row"><div><strong>${t('aiEndpoint')}</strong><span class="desc">${age('ਖਾਲੀ = OpenAI; ਆਪਣਾ OpenAI-ਵਰਗਾ ਸਰਵਰ ਵੀ ਦੇ ਸਕਦੇ ਹੋ','Empty = OpenAI; you may point it at your own OpenAI-compatible server')}</span></div><input id="aiApiEndpointInput" type="url" placeholder="${AI_DEFAULT_ENDPOINT}" value="${esc(state.aiApiEndpoint||'')}" style="max-width:50%;min-width:130px"></div>
 <div class="setting-row"><div><strong>${t('aiModel')}</strong></div><input id="aiModelInput" value="${esc(state.aiModel||'')}" style="max-width:50%;min-width:130px"></div>
 <div class="setting-row"><div><strong>${age('ਨਿੱਜੀ AI ਸਰਵਰ (ਵਿਕਲਪਿਕ)','Private AI server (optional)')}</strong><span class="desc">${age('AI_SERVER_SETUP.md ਵਾਲਾ ਸਰਵਰ; API ਕੁੰਜੀ ਨਹੀਂ','The AI_SERVER_SETUP.md server; never an API key')}</span></div><input type="url" id="aiEndpointInput" placeholder="https://…/ask" value="${esc(state.aiEndpoint||'')}" style="max-width:50%;min-width:130px"></div>
 <div class="setting-row"><div><strong>${age('AI access code','AI access code')}</strong><span class="desc">${age('ਕੇਵਲ ਆਪਣੇ ਨਿੱਜੀ AI ਸਰਵਰ ਲਈ','Only for your private AI server')}</span></div><input id="aiAccessInput" type="password" autocomplete="off" placeholder="Access code" value="${esc(state.aiAccessToken||'')}" style="max-width:50%;min-width:130px"></div>`;
 return `<section class="page"><h1>${t('viewPrefs')}</h1><p class="muted fine">${t('preferences')}</p>
 <div class="menu-group-label">${age('ਪਾਠ ਦੀਆਂ ਪਰਤਾਂ','Verse layers')}</div>
 ${toggle('showTranslit',t('translit'),age('English ਅੱਖਰਾਂ ਵਿੱਚ ਗੁਰਬਾਣੀ','Gurbani in Latin script'))}
 ${toggle('showEn',t('enTrans'))}
 ${toggle('showPa',t('paTrans'))}
 ${toggle('showArth',t('shabadArth'),age('ਸ਼ਬਦ-ਵਾਰ ਅਰਥ ਕੋਸ਼ ਵਿੱਚੋਂ','Word-by-word meanings from the dictionary'))}
 <div class="settings-control-head"><div><strong>${t('font')}</strong><span class="desc">${age('ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ — ਸਾਰੇ ਪਾਠ ਲਈ','Letter size — for all scripture text')}</span></div><span class="desc" id="vpFontValue">${state.font}px</span></div>
 <div class="slider-row"><button type="button" id="vpFontMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="18" max="40" step="1" value="${state.font}" id="vpFontSlider" aria-label="${t('font')}"><button type="button" id="vpFontPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><div><strong>${t('layerSize')}</strong><span class="desc">${age('ਰੋਮਨ + ਅੰਗਰੇਜ਼ੀ + ਪੰਜਾਬੀ — ਇੱਕੋ ਆਕਾਰ','Roman + English + Punjabi — one size')}</span></div><span class="desc" id="vpLayerValue">${Math.round(state.layerScale*100)}%</span></div>
 <div class="slider-row"><button type="button" id="vpLayerMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="0.7" max="1" step="0.05" value="${state.layerScale}" id="vpLayerSlider" aria-label="${t('layerSize')}"><button type="button" id="vpLayerPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="setting-row"><div><strong>${t('baniTextSize')}</strong></div>${choice('baniTextSize',[['normal',t('tSizeNormal')],['large',t('tSizeLarge')],['xlarge',t('tSizeXLarge')]])}</div>
 <div class="setting-row"><div><strong>${t('fontColor')}</strong></div>${choice('fontColor',[['black',t('fontBlack')],['blue',t('fontBlue')]])}</div>
 <div class="menu-group-label">${t('nightMode')}</div>
 ${toggle('nightMode',t('nightMode'),age('ਕਾਲਾ ਪਿਛੋਕੜ, ਸਫੈਦ ਗੁਰਬਾਣੀ','Near-black background, white Gurmukhi'))}
 <div class="menu-group-label">${age('ਆਵਾਜ਼','Voice')}</div>
 <div class="setting-row"><div><strong>${t('micTest')}</strong><span class="desc">${age('ਮਾਈਕ ਦੀ ਜਾਂਚ — ਸਾਫ਼ ਸ਼ਬਦਾਂ ਵਿੱਚ ਨਤੀਜਾ','Checks the microphone and reports plainly')}</span></div><button class="secondary" data-action="mic-test">${t('micTest')}</button></div>
 <p class="fine muted" id="micTestStatus" role="status"></p>
 ${aiSection}
 </section>`;
}
/* ---- Menu / daily ---- */
function menuScreen(){
 return `<section class="page menu-page"><div class="settings-page-header"><h1>${t('settings')}</h1><p class="muted fine">ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}</p></div>
 <div class="menu-group-label">${t('reading')}</div>
 <button class="menu-item" data-action="open-viewprefs"><span class="menu-copy"><strong>${t('viewPrefs')}</strong><small>${t('nightMode')} · ${t('translit')} · ${t('baniTextSize')}</small></span><span class="menu-chevron">›</span></button>
 <button class="menu-item" data-action="menu-settings"><span class="menu-copy"><strong>${t('readerSettings')}</strong><small>${t('font')} · ${t('theme')} · ${t('mode')}</small></span><span class="menu-chevron">›</span></button>
 <button class="menu-item" data-action="reset-layout"><span class="menu-copy"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਦੀ ਤਰਤੀਬ ਰੀਸੈੱਟ','Reset home layout')}</strong><small>${age('ਕਾਰਡਾਂ ਨੂੰ ਮੂਲ ਜਗ੍ਹਾ ਵਾਪਸ ਲਿਆਓ','Restore the original card positions')}</small></span><span class="menu-chevron">›</span></button>
 <div class="menu-group-label">${t('updateCenter')}</div>
 <div class="menu-update-card"><div class="version-info"><div><span class="muted fine">${t('currentVersion')}</span><strong>v${APP_VERSION}</strong></div><span class="version-dot" aria-hidden="true"></span></div><p class="fine" id="updateStatus">${t('menuIntro')}</p><button class="primary full" data-action="check-update" id="checkUpdateButton">↻ ${t('update')}</button>${window.GS_NATIVE_UPDATES?.isNative?'':`<button class="secondary full install-button" data-action="install-app">${t('install')} ↗</button><p class="fine muted">${t('installHint')}</p>`}</div>
 <div class="menu-group-label">${t('menuBackups')}</div>
 <p class="fine muted">${t('backupHint')}</p><div class="menu-backup-row"><button class="secondary" data-action="backup-export">${t('backup')} ↓</button><button class="secondary" data-action="backup-import">${t('restore')} ↑</button></div>
 <input id="menuBackupInput" class="hidden" type="file" accept="application/json,.json">
</section>`;
}
/* ---- Reader settings sheet ---- */
function settingsHTML(){
 const choice=(key,options)=>`<div class="choice">${options.map(([v,name])=>`<button data-setting="${key}" data-value="${v}" class="${String(state[key])===String(v)?'sel':''}">${name}</button>`).join('')}</div>`;
 const themes=[['light',t('light'),'#ffffff'],['sepia',t('sepia'),'#f4ead6'],['dark',t('dark'),'#1b2822'],['charcoal',t('charcoal'),'#303438']];
 return `<div class="setting-section">${t('tone')}</div>
 <div class="slider-row tone-row"><span class="tone-sun dim" aria-hidden="true">☀</span><input type="range" min="0" max="100" step="1" value="${state.tone}" id="toneSlider" class="tone-slider" aria-label="${t('tone')}"><span class="tone-sun" aria-hidden="true">☀</span></div>
 <div class="settings-preview"><div class="settings-caption">${t('appearance')}</div><div class="theme-choice">${themes.map(([value,label,color])=>`<button data-setting="theme" data-value="${value}" class="theme-swatch ${state.theme===value?'sel':''}" aria-pressed="${state.theme===value}"><span class="tone-dot" style="background:${color}"></span><span>${label}</span></button>`).join('')}</div></div>
 <div class="setting-section">${t('font')}</div>
 <div class="settings-control-block"><div class="settings-control-head"><strong>${t('font')}</strong>${choice('fontStyle',[['serif',t('serif')],['sans',t('sans')],['system',t('sysFont')]])}</div>
 <div class="settings-control-head"><strong>${t('font')}</strong><span class="desc" id="fontValue">${state.font}px</span></div>
 <div class="slider-row"><button id="fontMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="18" max="40" step="1" value="${state.font}" id="fontSlider" aria-label="${t('font')}"><button id="fontPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਅਤੇ ਮੀਨੂ ਦੇ ਅੱਖਰ','Home & menu font size')}</strong><span class="desc" id="uiScaleValue">${Math.round(state.uiScale*100)}%</span></div>
 <div class="slider-row"><button id="uiMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="1" max="1.35" step="0.05" value="${state.uiScale}" id="uiSlider" aria-label="${age('ਮੁੱਖ ਪੰਨੇ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ','Home text size')}"><button id="uiPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('3D ਮੀਨੂ ਅੱਖਰ','3D menu text')}</strong>${choice('raisedHeadings',[['true',t('on')],['false',t('off')]])}</div>
 <div class="settings-control-head line-layout-choice"><strong>${t('spacing')}</strong>${choice('lineLayout',[['compact',age('ਘੱਟ','Compact')],['standard',age('ਆਮ','Standard')],['spacious',age('ਵੱਧ','Spacious')]])}</div>
 <div class="settings-control-head"><strong>${t('margins')}</strong>${choice('margin',[['narrow',t('narrow')],['normal',t('normal')],['wide',t('wide')]])}</div></div>
 <div class="setting-section">${t('reading')}</div>
 <div class="setting-row"><strong>${t('mode')}</strong>${choice('mode',[['scroll',t('scroll')],['page',t('page')]])}</div>
 <div class="setting-row"><strong>${age('ਪੰਨਾ ਪਲਟਣ ਦੀ ਰਫ਼ਤਾਰ','Page turning speed')}</strong>${choice('pageTurnSpeed',[['slow',age('ਹੌਲੀ','Slow')],['normal',age('ਆਮ','Normal')],['fast',age('ਤੇਜ਼','Fast')]])}</div>
 <div class="setting-row"><div><strong>${t('viewPrefs')}</strong><span class="desc">${age('ਸਾਰੀਆਂ ਸੈਟਿੰਗਾਂ ਇੱਕ ਥਾਂ','All view settings in one place')}</span></div><button class="secondary" data-action="open-viewprefs">${t('viewPrefs')} ›</button></div>
 <div class="setting-row"><strong>${t('language')}</strong>${choice('lang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <div class="setting-row"><strong>${t('meanLang')}</strong>${choice('meaningLang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <p class="fine muted settings-footer">${t('preferences')}</p>`;
}
function openSettings(){closeWord();$('settingsTitle').textContent=t('readerSettings');$('sheetBody').innerHTML=settingsHTML();$('sheetOverlay').classList.remove('hidden')}
function closeSettings(){$('sheetOverlay').classList.add('hidden')}
/* ---- Tap-a-word ---- */
let wordRequest=0, wordOrigin=null;
function closeWord(){
 wordRequest++;
 const pop=$('wordPopup');pop.classList.add('hidden');pop.innerHTML='';
 if(wordOrigin){wordOrigin.removeAttribute('aria-expanded');wordOrigin=null}
}
// v2.2.8: tap ANY word in a line -> the WHOLE LINE's meaning (Punjabi/English).
// The old tap-a-word kosh popup is gone; the line's bundled translation is shown.
function openLineMeaning(el){
 const kind=el.dataset.kind,idx=Number(el.dataset.idx);
 // v2.2.10: Kirtan taps read the lines actually on screen (activeRemote, enriched
// from the Ang files with en/pa). The old CONTENT.kirtan lookup used the static
// data.js list (only 2 Shabads, 1 line each) and state.kirtanId, which
// openKirtanShabad never sets — so taps found nothing (or the wrong line).
// Fall back to the static list only if no on-screen line exists.
 // v2.2.14: Hukamnama taps read the Hukamnama lines saved on the phone
 // (state.hukamnama), never the reader's activeRemote lines.
 const line=kind==='hukamnama'?(state.hukamnama?.lines||[])[idx]:(activeRemote?.lines?.[idx]) ?? (kind==='kirtan'?(CONTENT.kirtan.find(x=>x.id===state.kirtanId)?.lines||[])[idx]:undefined);
 if(!line||!line.g)return;
 if(wordOrigin===el&&!$('wordPopup').classList.contains('hidden')){closeWord();return}
 closeWord();lineMeaningLine=line;wordOrigin=el;wordOrigin.setAttribute('aria-expanded','true');
 const pop=$('wordPopup');const rect=el.getBoundingClientRect();
 const lang=state.meaningLang==='en'?'en':'pa';
 pop.innerHTML=`<div class="gs-word-popup-head"><button type="button" class="gs-word-close" data-close-word="1" aria-label="${age('ਬੰਦ ਕਰੋ','Close')}">×</button></div><div class="gs-line-meaning-toggle" role="group" aria-label="${age('ਅਰਥ ਦੀ ਭਾਸ਼ਾ','Meaning language')}"><button type="button" data-line-lang="pa" aria-label="Punjabi" class="${lang==='pa'?'sel':''}">ਪ</button><button type="button" data-line-lang="en" aria-label="English" class="${lang==='en'?'sel':''}">EN</button></div><div class="popup-note" id="lineMeaningBody" role="status"></div>`;
 pop.classList.remove('hidden');
 const width=Math.min(342,window.innerWidth-24);
 pop.style.width=width+'px';
 const left=Math.max(12,Math.min(window.innerWidth-width-12,rect.left+rect.width/2-width/2));
 const height=210;
 const top=rect.bottom+12+height>window.innerHeight?Math.max(12,rect.top-height-12):rect.bottom+12;
 pop.style.left=left+'px';pop.style.top=top+'px';
 pop.style.setProperty('--arrow-left',Math.max(14,Math.min(width-20,rect.left+rect.width/2-left))+'px');
 fillLineMeaning(line);
}
function fillLineMeaning(line){
 const box=$('lineMeaningBody');if(!box||!line)return;
 const lang=state.meaningLang==='en'?'en':'pa';
 const text=String(line[lang]||'').trim()||String(line[lang==='en'?'pa':'en']||'').trim();
 box.innerHTML=text?`<p lang="${lang==='en'?'en':'pa'}">${esc(text)}</p>`:`<p>${age('ਇਸ ਲਾਈਨ ਦਾ ਅਰਥ ਹਾਲੇ ਸ਼ਾਮਲ ਨਹੀਂ।','Meaning for this line is not bundled yet.')}</p>`;
}
/* ---- Search wiring ---- */
let searchSeq=0;
let searchMode='auto';
async function showOfflineResults(q,target='searchResults',save=false){
 const id=++searchSeq;const out=$(target);if(!out)return;
 if(!q.trim()){out.innerHTML='';return}
 out.innerHTML=`<p class="fine">${age('ਪਾਠ ਵਿੱਚ ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching the offline library…')}</p>`;
 try{
  const matches=await window.GS_SCRIPTURE_SEARCH.query(q,40,target==='searchResults'?searchMode:'auto');
  if(id!==searchSeq||!$(target))return;
  $(target).innerHTML=matches.length?scriptureResultsMarkup(matches,{save}):`<p class="empty">${t('noResults')}</p>`;
  fillRaagHeaders($(target));fillResultEn($(target));
 }catch(e){if($(target))$(target).innerHTML=`<p class="notice">${age('ਆਫਲਾਈਨ ਖੋਜ ਸੂਚੀ ਨਹੀਂ ਮਿਲੀ। APK ਦਾ ਬਿਲਡ ਜਾਂਚੋ।','Offline search index missing. Verify the APK build.')}</p>`;console.warn(e)}
}
/* ---- Voice search (v2.2.0 rewrite) ----
 * Root causes of the dead mic in v2.1.0, fixed here:
 *  1. getSupportedLanguages() was awaited BEFORE any status text. Its native
 *     side sends an ordered broadcast that may never return, hanging the mic
 *     forever with no feedback. Now: never awaited without a timeout; the app
 *     simply tries pa-IN first and falls back to en-US if start() rejects.
 *  2. The plugin's native onError() never emits listeningState='stopped', so
 *     the old code waited the full 60s on any recognition error. Now: a
 *     2-minute per-segment watchdog (re-armed at every restart) only trips
 *     on a genuinely stuck recognizer; a normal pause never ends the run —
 *     v2.2.37: the mic listens until the user presses Stop.
 *  3. The source ZIP shipped a stale stub www/native-updates.js without
 *     window.GS_SPEECH. The workflow now fail-fasts if the bundle lacks it.
 * Path: native Capacitor plugin (primary) -> Web Speech API fallback
 * (works in Chrome/WebView with internet) -> honest typed-search guidance.
 */
let searchVoiceBusy=false;
// v2.2.15: once the mic permission is granted, remember it — repeat taps
// skip the permission check entirely and go straight to listening.
let voicePermGranted=false;
// v2.2.17: the two native listeners are registered ONCE and stay alive.
// They dispatch to the current run (voiceRun). Re-registering them on every
// tap cost bridge calls (the delay), and a stale 'stopped' from the previous
// run's teardown could kill the next run before it started.
let voiceRun=null;
// v2.2.37: the web fallback recognizer, so Stop (and X) can stop it right
// away too — the native path has native.stop(); the web path needs rec.stop().
let voiceWebRec=null;
// v2.2.37: whether the listening UI is on — re-applied after a re-render so
// the Stop button does not vanish while a run is still listening.
let voiceListeningOn=false;
// v2.2.33: manual stop flag — Stop button / X (clear) / mic-tap-while-busy
// sets this so the continuous-listening loop never restarts the mic after
// the user stopped it.
let voiceStopRequested=false;
// v2.2.33 (stale-event fix): teardown of the previous voice run is serialized.
// resetVoiceNow() returns a promise that resolves when the old run's recognizer
// confirms it stopped, or after ~600ms. startVoiceSearch awaits it before
// starting a new run, so a delayed partial/'stopped' from the old run can never
// leak into the new one. voiceRunSeq invalidates a run that was stopped or
// superseded, so its late fill/status/button cleanup cannot clobber the new run.
let voiceStopPromise=null;
let voiceStoppingRun=null;
let voiceRunSeq=0;
let voiceListenersReady=false,voiceListenersPromise=null;
// v2.2.44: the listeners are registered ONCE at app startup (see the boot call
// below and attach()) so the mic works on the VERY FIRST tap — registering them
// lazily on the first tap raced with native.start() and the first tap heard
// nothing. ensureVoiceListeners() stays as the backstop for the mic-tap path.
async function ensureVoiceListeners(){
 if(voiceListenersReady)return;
 if(voiceListenersPromise)return voiceListenersPromise;
 const native=window.GS_SPEECH;
 if(!native||typeof native.addListener!=='function')return;
 voiceListenersPromise=(async()=>{
 await Promise.all([
  native.addListener('partialResults',data=>{
   const run=voiceRun;if(!run)return;
   // Stale-event guard: only the current, started, not-manually-stopped run
   // may be filled. A delayed partial from a previous run must never fill
   // the new run with the old words.
   if(!run.started||run.manualStopped||voiceStopRequested)return;
   const m=data?.matches?.[0];
   if(typeof m==='string'&&m.trim()){
    // v2.2.22: first words heard — if the "not hearing" status was showing,
    // go back to Listening so the user sees the mic is working now.
    if(!run.heard.gotPartial)setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');
    run.heard.gotPartial=true;
    // v2.2.33: accumulate words — the partial is this segment's transcript.
    // It grows as words arrive, so an extending partial replaces the segment;
    // a shorter one is stale (keep the longer); anything else is the
    // recognizer revising the same utterance (take the latest). Finished
    // segments live in heard.parts, so no words are lost across the
    // auto-restarts below. No dedupe — Gurbani repeats words (ਜਿਉ ਜਿਉ), so a
    // repeated word at a boundary is a real word.
    const seg=run.heard.seg||'';
    if(!seg||m.startsWith(seg))run.heard.seg=m;
    else if(!seg.startsWith(m))run.heard.seg=m;
    run.heard.text=[...run.heard.parts,run.heard.seg].filter(Boolean).join(' ');
    run.fill(run.heard.text);
   }
  }),
  native.addListener('listeningState',data=>{
   if(data?.status==='started'){
    const run=voiceRun;if(!run)return;
    run.sawStarted=true;setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');
   }else if(data?.status==='stopped'){
    const run=voiceRun;
    if(run){run.stopped=true;if(run.sawStarted&&run.started)run.endSegment();}
    else if(voiceStoppingRun){
     // Teardown confirmation: the listener only dispatches to the current
     // run, so a 'stopped' landing after voiceRun was cleared still resolves
     // the resetVoiceNow() waiter for the old run.
     voiceStoppingRun.stopped=true;
     const f=voiceStoppingRun._stopResolve;if(typeof f==='function'){try{f()}catch{}}
    }
   }
  }),
 ]);
  voiceListenersReady=true;
 })().catch(e=>{voiceListenersPromise=null;throw e;});
 return voiceListenersPromise;
}
let highlightLine=-1;
let readerBarHidden=true, readerOpenedAt=0, lastReaderScrollY=0;
// v2.2.27: scroll-direction decision for the reader top bar. Pure — testable.
// Returns 'show' (scrolling back to already-read content), 'hide' (reading
// forward to new content), or null (tiny move under 5px — no change, no flicker).
function barScrollDecision(lastY,curY){const d=curY-lastY;if(d<=-5)return 'show';if(d>=5)return 'hide';return null;}
function showReaderBar(){if(!readerBarHidden)return;readerBarHidden=false;const bar=document.querySelector('.gs-reading-topbar');if(bar){bar.classList.remove('gs-topbar-hidden');bar.classList.add('gs-topbar-in');}}
function hideReaderBar(){if(readerBarHidden)return;readerBarHidden=true;const bar=document.querySelector('.gs-reading-topbar');if(bar){bar.classList.add('gs-topbar-hidden');bar.classList.remove('gs-topbar-in');}}
// v2.2.27: reader top-bar visibility on scroll. Hide completely while reading
// forward; pop out only when scrolling back to already-read content. Called
// by the window scroll handler; updates the baseline on every scroll event.
function onReaderScroll(){if(state.view==='reader'&&state.mode==='scroll'&&Date.now()-readerOpenedAt>800){const dec=barScrollDecision(lastReaderScrollY,window.scrollY);if(dec==='show')showReaderBar();else if(dec==='hide')hideReaderBar();}lastReaderScrollY=window.scrollY;}
let lineMeaningLine=null;
let voiceWatchdog=null,voiceStartTime=0;
// v2.2.7: watchdog — if a voice run gets stuck (native plugin hangs),
// force-reset so the mic button never dies on the 2nd tap.
// v2.2.37: error-only backstop, 2 minutes PER SEGMENT (was 25s per run) —
// the mic now listens until Stop, so a whole run may last minutes; the
// watchdog is re-armed at every segment restart, and only trips when one
// segment hangs with no events for 2 minutes (a genuinely stuck recognizer).
function armVoiceWatchdog(btn){
 clearTimeout(voiceWatchdog);
 voiceStartTime=Date.now();
 voiceWatchdog=setTimeout(()=>{
  searchVoiceBusy=false;
  setListeningUI(false);
  setVoiceStatus('ਮਾਈਕ ਰੀਸੈੱਟ ਹੋ ਗਿਆ — ਦੁਬਾਰਾ ਦਬਾਓ।','Microphone reset — tap again.');
 },120000);
}
function clearVoiceWatchdog(){clearTimeout(voiceWatchdog);voiceWatchdog=null;}
// v2.2.8: instant mic reset — X (clear) and a mic tap while busy.
// v2.2.33 (stale-event fix): returns a promise that resolves when the old
// run's recognizer confirms it stopped, or after ~600ms. startVoiceSearch
// awaits it before starting a new run, so runs never overlap. The button
// still works right away — awaiting happens in startVoiceSearch, not here.
function resetVoiceNow(){
 clearVoiceWatchdog();searchVoiceBusy=false;setListeningUI(false);
 // v2.2.33: a manual stop (X / mic tap while busy) must really stop the mic —
 // flag it so the continuous-listening loop never restarts afterwards.
 // It also invalidates the run's sequence, so its late fill/status/button
 // cleanup cannot clobber a newer run (or the cleared state).
 voiceStopRequested=true;voiceRunSeq++;
 // If a teardown is already pending, return it — a second reset must not
 // start a second waiter for the same stop.
 if(voiceStopPromise)return voiceStopPromise;
 // v2.2.20: only stop the recognizer when one is actually running.
 // A stop() on an already-stopped recognizer (e.g. tapping X after a clean
 // search, then tapping the mic) leaves it in a bad state where the NEXT
 // start() listens but hears nothing - the same redundant-stop bug v2.2.17
 // fixed in finally. The mic-tap-while-busy path still stops a live run.
 const run=voiceRun;
 voiceRun=null;
 if(run)run.manualStopped=true;
 // v2.2.37: wake the run's loop so it sees the stop at once and breaks —
 // without this the loop would wait on the segment promise forever (the
 // old 15s safety timer used to resolve it). Resolving an already-settled
 // segment is a harmless no-op.
 if(run)run.endSegment();
 // Decide BEFORE calling stop(): the 'stopped' confirmation may arrive
 // synchronously, and the listener only records it while voiceStoppingRun
 // is set.
 const needsStop=!!(run&&run.started&&!run.stopped&&!run.safetyStopped);
 if(needsStop)voiceStoppingRun=run;
 if(needsStop){
  try{const n=window.GS_SPEECH;if(n&&typeof n.stop==='function'){const p=n.stop();if(p&&p.catch)p.catch(()=>{});}}catch{}
 }
 // v2.2.37: stop the web fallback recognizer right away too — its onend
 // then finishes the run via dead(). (The native path stops above.)
 if(voiceWebRec){try{voiceWebRec.stop()}catch{}voiceWebRec=null;}
 setVoiceStatus('','');
 // No live recognizer to stop (or it already reported stopped): resolve now.
 if(!needsStop)return Promise.resolve();
 // Live recognizer: wait for its 'stopped' confirmation or 600ms, whichever
 // first. The native onError path may never emit 'stopped', so the timeout
 // is the backstop.
 voiceStopPromise=new Promise(resolve=>{
  let done=false;let to=null;
  const finish=()=>{if(done)return;done=true;if(to!==null)clearTimeout(to);if(voiceStoppingRun===run)voiceStoppingRun=null;voiceStopPromise=null;resolve();};
  run._stopResolve=finish;
  to=setTimeout(finish,600);
  // NOTE: deliberately NOT resolved by stopP — a plugin stop() promise may
  // resolve when the stop command is accepted, not when the recognizer
  // actually stops. Only the 'stopped' event (or the timeout) counts.
 });
 return voiceStopPromise;
}
function voiceStatusEl(){return $('voiceStatus')}
function setVoiceStatus(pa,en){const s=voiceStatusEl();if(s)s.textContent=age(pa,en)}
// v2.2.16: professional listening state — a clean green ring around the mic
// button and a green status line, so it is clear the mic is waiting (no red,
// no pulsing).
// v2.2.40: the mic button ITSELF becomes the Stop sign while listening (like
// the Muse app mic) — no separate Stop button next to it. Tapping the mic
// while it shows ⏹ stops the run (see the attach() handler); when the run
// ends the button goes back to the 🎙 icon.
function setListeningUI(on){
 voiceListeningOn=on;
 for(const id of ['voiceBtn','askVoiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',on);b.textContent=on?'⏹':'🎙';}}
 const s=voiceStatusEl();if(s)s.classList.toggle('gs-listening',on);
}
// v2.2.40: re-apply the mic-as-Stop state to freshly rendered buttons
// (attach() runs after every render; a run in progress must keep its mic
// showing Stop, not revert to the mic icon). Kept the v2.2.37 name — it syncs
// the Stop state, which now lives on the mic button itself.
function syncVoiceStopUI(){
 for(const id of ['voiceBtn','askVoiceBtn']){const b=$(id);if(b){b.classList.toggle('gs-listening',voiceListeningOn);b.textContent=voiceListeningOn?'⏹':'🎙';}}
}
// v2.2.37: dedicated Stop button (Muse-style) — stops the mic RIGHT AWAY.
// The stopped flags are set FIRST (resetVoiceNow does this synchronously),
// so the restart loop cannot restart the recognizer; the search text and
// results are kept — unlike X, which clears them.
function stopVoiceSearch(){resetVoiceNow();}
async function startVoiceSearch(input){
 // v2.2.7: a mic tap ALWAYS works. If a previous run is stuck, kill it first.
 // v2.2.33 (stale-event fix): wait for the old run's recognizer to actually
 // stop before starting a new one — runs never overlap, so a delayed partial
 // or 'stopped' from the old run cannot leak into the new run. The 600ms
 // backstop in resetVoiceNow() bounds the wait.
 if(searchVoiceBusy){await resetVoiceNow();}
 else if(voiceStopPromise){await voiceStopPromise;}
 // A second tap during the teardown wait may already have started a new run.
 if(searchVoiceBusy)return;
 // This run's sequence: a later reset or a newer run invalidates it, so its
 // late fill/status/button cleanup cannot clobber the newer run.
 const mySeq=++voiceRunSeq;
 // v2.2.33: a new run starts fresh — the old run's manual-stop flag is cleared.
 voiceStopRequested=false;
 searchVoiceBusy=true;
 // v2.2.40: the mic button is NEVER disabled while listening — it IS the
 // Stop button (tap it to stop), so it must stay tappable the whole run.
 const btn=input.id==='questionInput'?$('askVoiceBtn'):$('voiceBtn');
 armVoiceWatchdog(btn);
 const fill=spoken=>{spoken=String(spoken||'').trim();if(!spoken)return false;input.value=spoken;input.dispatchEvent(new Event('input',{bubbles:true}));return true};
 const done=(pa,en)=>{if(mySeq!==voiceRunSeq)return;setVoiceStatus(pa,en);setListeningUI(false);searchVoiceBusy=false};
 try{
  const native=window.GS_SPEECH;
  const isNative=!!(window.GS_NATIVE_UPDATES?.isNative&&native);
  setVoiceStatus('ਤਿਆਰੀ ਹੋ ਰਹੀ ਹੈ…','Preparing…');
  if(isNative){
   const heard={text:'',gotPartial:false,parts:[],seg:''};
   // v2.2.17 fast path: once permission is granted, skip BOTH the
   // availability and the permission check — the service already worked.
   // Only the first tap pays for them.
   if(!voicePermGranted){
    const res=await Promise.all([native.available().catch(()=>null),native.checkPermissions().catch(()=>null)]);
    const avail=res[0];let perm=res[1];
    if(!avail||avail.available===false)throw Error('native-unavailable');
    if(!perm||perm.speechRecognition!=='granted'){
     setVoiceStatus('ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਚਾਹੀਦੀ ਹੈ — ਕਿਰਪਾ ਕਰਕੇ Allow ਦਬਾਓ','Microphone permission is needed — please tap Allow');
     try{perm=await native.requestPermissions()}catch{}
     if(!perm||perm.speechRecognition!=='granted')throw Error('permission-denied');
    }
    voicePermGranted=true;
   }
   await ensureVoiceListeners();
   // v2.2.33: continuous listening — the recognizer stops on its own after a
   // pause, so each stop only ends the current SEGMENT. endSegment resolves
   // the current segment's promise; the loop below restarts the recognizer
   // and keeps accumulating words until a manual stop (Stop button / X) or
   // a restart failure ends the run. v2.2.37: no time cap — it listens for
   // as long as the user has not pressed Stop.
   let segResolve=null;let segEnded=null;
   const endSegment=()=>{try{if(segResolve)segResolve()}catch{}};
   const run={heard,fill,endSegment,sawStarted:false,stopped:false,started:false,safetyStopped:false,manualStopped:false,lang:'pa-IN'};
   const commitSegment=()=>{const s=(heard.seg||'').trim();if(s)heard.parts.push(s);heard.seg='';heard.text=heard.parts.join(' ');};
   const runEnded=()=>run.safetyStopped||run.manualStopped||voiceStopRequested||voiceRun!==run;
   let noHeardTimer=null;
   voiceRun=run;
   // v2.2.37: NO time cap — the mic listens until the user presses Stop
   // (or X), however long that takes. The old 15s safety timer is gone: a
   // normal pause must never end the session. The 2-minute per-segment
   // watchdog (re-armed at every restart) is the only backstop, for a
   // genuinely stuck recognizer. A manual stop wakes the loop at once via
   // resetVoiceNow()'s endSegment() call, and a restart failure ends the
   // run via beginSegment() returning false.
   try{
    const opts=lang=>({language:lang,maxResults:5,prompt:age('ਗੁਰਬਾਣੀ ਸ਼ਬਦ ਬੋਲੋ','Say a Gurbani word'),partialResults:true,popup:false});
    const startOnce=async()=>{
     try{await native.start(opts('pa-IN'));run.lang='pa-IN';}
     catch(first){
      // pa-IN missing on device -> English fallback (never hang on language list).
      setVoiceStatus('ਪੰਜਾਬੀ ਪਛਾਣ ਨਹੀਂ ਮਿਲੀ; English ਵਿੱਚ ਸੁਣ ਰਿਹਾ ਹਾਂ…','Punjabi recognition unavailable; listening in English…');
      await native.start(opts('en-US'));run.lang='en-US';
     }
    };
    // Begin one segment: (re)start the recognizer and wait for its stop.
    // Returns false if the run ended instead (manual/safety/restart failure).
    // A failed FIRST start still throws, exactly as before.
    let firstSegment=true;
    const beginSegment=async()=>{
     if(runEnded())return false;
     segEnded=new Promise(r=>{segResolve=r});
     run.stopped=false;run.sawStarted=false;
     // v2.2.37: re-arm the 2-minute error-only watchdog per segment — a
     // long session restarts segments, so only a stuck segment can trip it.
     armVoiceWatchdog(btn);
     try{await startOnce();}
     catch(e){if(firstSegment)throw e;return false;}
     firstSegment=false;
     // A manual stop or the safety deadline may have landed while starting —
     // undo the restart so the mic really stops.
     if(runEnded()){try{native.stop()}catch{}return false;}
     run.started=true;
     // v2.2.44: the recognizer DID start (startOnce() resolved), so mark the
     // segment started here — do not depend on the native 'started' event.
     // On this phone that event does not fire on a restarted segment, so the
     // 'stopped' handler never called endSegment(), the loop hung at
     // `await segEnded`, and the mic sat showing "Listening..." while hearing
     // nothing after the first few words. The 'started' listener still sets
     // this too (harmless).
     run.sawStarted=true;
     setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');
     setListeningUI(true);
     return true;
    };
    if(await beginSegment()){
     // v2.2.33 (stale-event fix): a new voice run starts with a clean results
     // area — stale results from the previous search must not linger and be
     // mistaken for the new search. Voice only; typed input is untouched.
     // The question input has no search-results target, so it is skipped.
     if(input.id==='searchInput'){const out=$('searchResults');if(out)out.innerHTML='';}
     // v2.2.22: if nothing is heard within 4s, say so clearly. The user
     // should know the mic is not picking up, instead of waiting in
     // silence wondering whether it heard. The run keeps listening — he may
     // just need to speak louder or closer.
     noHeardTimer=setTimeout(()=>{
      if(voiceRun===run&&!run.heard.gotPartial){
       setVoiceStatus('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ','Microphone is not hearing — speak louder or tap again');
      }
     },4000);
     for(;;){
      await segEnded;
      if(runEnded()){commitSegment();break;}
      commitSegment();
      if(!(await beginSegment()))break;
     }
    }
    // Only a run that is still live may fill the input and set the Review
    // status. A run ended by a manual stop (Stop / X) or superseded by a
    // newer run must not resurrect its words — that is the stale-run leak.
    // Its done()/finally are guarded by the same sequence.
    if(mySeq===voiceRunSeq){
     if(!heard.text.trim())throw Error('nothing-heard');
     fill(heard.text);
     setVoiceStatus('ਪਛਾਣੇ ਹੋਏ ਸ਼ਬਦ ਵੇਖੋ ਅਤੇ ਲੋੜ ਹੋਵੇ ਤਾਂ ਠੀਕ ਕਰੋ।','Review recognised words and correct them if needed.');
    }
   }finally{
    clearTimeout(noHeardTimer);
    // The listeners stay registered (shared). Only this run's own cleanup
    // runs here, and only if it is still the current run. A redundant
    // stop() after a clean 'stopped' end left the recognizer in a bad state
    // where the next search listened but heard nothing — so stop() is only
    // called when the recognizer is actually still running.
    const mine=voiceRun===run;
    if(mine)voiceRun=null;
    if(mine&&run.started&&!run.stopped&&!run.safetyStopped){
     try{const p=native.stop();if(p&&p.catch)p.catch(()=>{})}catch{}
    }
   }
   done('ਹੋ ਗਿਆ।','Done.');
   return;
  }
  // Web Speech API fallback (Chrome / WebView with internet).
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR)throw Error('no-web-speech');
  // v2.2.33 (stale-event fix): a run ended by a manual stop or superseded by
  // a newer run is dead — its late results/restart must not touch the UI.
  const dead=()=>voiceStopRequested||mySeq!==voiceRunSeq;
  setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');
  const heard=await new Promise((resolve,reject)=>{
   let rec;try{rec=new SR();voiceWebRec=rec;}catch(e){reject(e);return}
   rec.lang='pa-IN';rec.interimResults=true;rec.maxAlternatives=3;
   // v2.2.33: same continuous listening as the native path — the recognizer
   // ends on a pause, so restart it and accumulate words until a manual
   // stop (Stop button / X sets voiceStopRequested via resetVoiceNow) or a
   // real error ends the run. v2.2.37: no time cap.
   const parts=[];let seg='';let best='';
   let finished=false;
   const commit=()=>{const s=seg.trim();if(s)parts.push(s);seg='';best=parts.join(' ');};
   // v2.2.37: NO time cap here either — the web fallback listens until the
   // user presses Stop (dead() ends it) or a real error ends it (fail()).
   const finish=v=>{if(finished)return;finished=true;voiceWebRec=null;resolve(v);};
   const fail=e=>{if(finished)return;finished=true;voiceWebRec=null;reject(e);};
   rec.onresult=e=>{
    if(finished||dead())return;
    let tr='';for(let i=0;i<e.results.length;i++){const r=e.results[i];if(r&&r[0]&&r[0].transcript)tr+=r[0].transcript;}
    tr=tr.trim();if(!tr)return;
    // The transcript is this utterance's full text; it grows, so take the
    // latest (extend/revision), never shrink to a stale shorter one.
    if(!seg||tr.startsWith(seg)||!seg.startsWith(tr))seg=tr;
    best=[...parts,seg].filter(Boolean).join(' ');
    fill(best);
   };
   rec.onerror=e=>{fail(new Error(e.error||'recognition failed'));};
   rec.onend=()=>{
    commit();
    if(finished||dead()){finish(best);return;}
    // Small delay: some browsers reject a start() called synchronously
    // inside onend. Re-check the stop flags when the delay elapses, so a
    // manual stop during the delay cannot resurrect the dead run.
    setTimeout(()=>{
     if(finished||dead()){finish(best);return;}
     armVoiceWatchdog(btn);   // v2.2.37: per-segment backstop, like the native path
     try{rec.start();}catch(e){finish(best);}
    },50);
   };
   try{rec.start();setListeningUI(true);
    // v2.2.33 (stale-event fix): a new voice run starts with a clean results
    // area — stale results from the previous search must not linger and be
    // mistaken for the new search. Voice only; typed input is untouched.
    if(input.id==='searchInput'){const out=$('searchResults');if(out)out.innerHTML='';}
   }catch(e){fail(e);}
  });
  // Only a live run may fill the input and set the Review status; a dead
  // run's late resolution must not resurrect its words.
  if(mySeq===voiceRunSeq){
   if(!String(heard||'').trim())throw Error('nothing-heard');
   done('ਪਛਾਣੇ ਹੋਏ ਸ਼ਬਦ ਵੇਖੋ ਅਤੇ ਲੋੜ ਹੋਵੇ ਤਾਂ ਠੀਕ ਕਰੋ।','Review recognised words and correct them if needed.');
  }
 }catch(e){
  const kind=String(e&&e.message||e);
  console.warn('voice search',e);
  if(kind==='permission-denied')done('ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਮਿਲੀ। Settings ਵਿੱਚ ਇਜਾਜ਼ਤ ਦੇ ਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।','Microphone permission was denied. Allow it in Settings and try again.');
  else if(kind==='nothing-heard')done('ਕੁਝ ਸੁਣਿਆ ਨਹੀਂ ਗਿਆ — ਦੁਬਾਰਾ ਬੋਲੋ ਜਾਂ ਲਿਖ ਕੇ ਖੋਜੋ।','Nothing was heard — speak again or type to search.');
  else if(kind==='native-unavailable'||kind==='no-web-speech')done('ਇਸ ਡਿਵਾਈਸ ਉੱਤੇ ਆਵਾਜ਼ ਦੀ ਪਛਾਣ ਨਹੀਂ ਚੱਲੀ। ਲਿਖ ਕੇ ਖੋਜੋ।','Voice recognition did not start on this device. Type to search instead.');
  else done('ਆਵਾਜ਼ ਦੀ ਪਛਾਣ ਵਿੱਚ ਰੁਕਾਵਟ ਆਈ। ਲਿਖ ਕੇ ਖੋਜੋ।','Voice recognition hit a snag. Type to search instead.');
 }finally{
  // Only the live run may reset the shared busy/watchdog state — a
  // dead run's finally must not clear the newer run's watchdog or mark it
  // not-busy.
  if(mySeq===voiceRunSeq){clearVoiceWatchdog();searchVoiceBusy=false;}
 }
}
// Settings "Test microphone": reports the real native state in plain words.
async function micTest(){
 const out=$('micTestStatus');
 const say=(pa,en)=>{if(out)out.textContent=age(pa,en);toast(age(pa,en))};
 const native=window.GS_SPEECH;
 if(!(window.GS_NATIVE_UPDATES?.isNative&&native)){say('ਇਹ ਵੈੱਬ ਝਲਕ ਹੈ — ਅਸਲੀ ਜਾਂਚ Android ਐਪ ਵਿੱਚ ਹੋਵੇਗੀ।','This is a web preview — the real check runs inside the Android app.');return}
 say('ਜਾਂਚ ਹੋ ਰਹੀ ਹੈ…','Checking…');
 try{
  let avail=null;try{avail=await native.available()}catch(e){say('ਸਪੀਚ ਸਰਵਿਸ ਤੱਕ ਪਹੁੰਚ ਨਹੀਂ — '+String(e&&e.message||e),'Could not reach the speech service.');return}
  if(!avail||avail.available===false){say('ਫੋਨ ਵਿੱਚ ਸਪੀਚ ਪਛਾਣ ਸੇਵਾ ਨਹੀਂ ਮਿਲੀ। Google ਐਪ ਅੱਪਡੇਟ ਕਰੋ।','No speech recognition service found on the phone. Update the Google app.');return}
  let perm=null;try{perm=await native.checkPermissions()}catch{}
  const st=perm&&perm.speechRecognition;
  if(st==='granted')say('ਮਾਈਕ ਤਿਆਰ ਹੈ — ਸਪੀਚ ਸੇਵਾ ਮਿਲ ਗਈ, ਇਜਾਜ਼ਤ ਮਿਲੀ ਹੋਈ ਹੈ।','Microphone is ready — speech service found and permission granted.');
  else say('ਸਪੀਚ ਸੇਵਾ ਮਿਲ ਗਈ; ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਬਾਕੀ ਹੈ ('+String(st||'unknown')+')। ਖੋਜ ਵਿੱਚ 🎙 ਦਬਾਉਣ ’ਤੇ ਇਜਾਜ਼ਤ ਮੰਗੀ ਜਾਵੇਗੀ।','Speech service found; microphone permission is still '+String(st||'unknown')+'. It will be requested when you tap 🎙 in search.');
 }catch(e){say('ਜਾਂਚ ਨਹੀਂ ਹੋ ਸਕੀ: '+String(e&&e.message||e),'Check failed.')}
}
/* ---- Progress / update / backup ---- */
function capture(){if(state.view!=='reader'||(activeRemote&&activeRemote.kind!=='ang')||state.readView!=='sggs'||state.mode!=='scroll'||displayAng()!==state.ang)return;let el=[...document.querySelectorAll('.verse-block')].find(n=>n.getBoundingClientRect().bottom>72);if(el){state.verse=Number(el.dataset.line)||0;state.verseOffset=Math.max(0,Math.round(73-el.getBoundingClientRect().top));state.hasProgress=true;persist()}}
function turn(dir){state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,state.page+dir));if(displayAng()===state.ang){state.verse=PAGE_GROUPS[state.page][0];state.verseOffset=0;state.hasProgress=true}persist();render();window.scrollTo({top:0,behavior:'instant'});if(dir>0&&state.page===PAGE_GROUPS.length-1){} }
function readKirtan(id){state.kirtanId=id;state.readView='kirtan';go('reader');window.scrollTo({top:0,behavior:'instant'})}
// Re-enrich the open text (vishraam marks / shabad arth) after a layer toggle.
async function refreshReader(){
 if(state.view!=='reader'||!activeRemote||activeRemote.loading||!activeRemote.lines?.length)return;
 if(state.mode==='scroll'&&(activeRemote.kind==='ang'||activeRemote.kind==='bani'))capture();
 const kind=activeRemote.kind;
 const ref=kind==='ang'?activeRemote.id:kind==='bani'?activeRemote.id:{ang:activeRemote.meta?.ang,lineStart:activeRemote.meta?.lineStart||0};
 try{activeRemote.lines=await enrichLines(activeRemote.lines,kind,ref)}catch{}
 render();
}
function action(a,el){
 switch(a){
 case'edit-layout':homeEditing=true;render();break;
 case'done-layout':homeEditing=false;persist();render();break;
 case'reset-layout':state.homeOrder=[...HOME_IDS];persist();render();toast(age('ਮੂਲ ਤਰਤੀਬ ਵਾਪਸ ਆ ਗਈ','Default layout restored'));break;
 case'continue':case'reader':navReader();break;
 case'library':go('library');break;case'catalog':go('catalog');break;case'kirtan':go('kirtan');break;
 case'ask':go('ask');break;case'hukamnama':go('hukamnama');break;case'daily':go('hukamnama');break;case'hukam-full-ang':if(state.hukamnama?.ang)openAng(state.hukamnama.ang);break;case'hukam-retry':fetchHukamnama(true).then(()=>{if(state.view==='hukamnama')render();});break;
 case'nitnem':go('nitnem');break;
  case'prev':turn(-1);break;case'next':turn(1);break;
 case'lang-pa':state.lang='pa';state.aiLangManual=false;state.aiLang='pa';persist();if(state.view==='reader')refreshReader();else render();break;
 case'lang-en':state.lang='en';state.aiLangManual=false;state.aiLang='en';persist();if(state.view==='reader')refreshReader();else render();break;
 case'open-viewprefs':closeSettings();go('viewprefs');break;
 case'share-current':shareCurrent();break;
 case'toggle-drawer':state.baniDrawer=!state.baniDrawer;persist();render();break;
 case'view-full-ang':openAng(Number(el?.dataset?.ang)||1);break;
 case'mic-test':micTest();break;
   case'menu-settings':openSettings();break;case'check-update':checkUpdate();break;case'install-app':installApp();break;
 case'backup-export':exportBackup();break;case'backup-import':$('menuBackupInput')?.click();break;
 default:break;
 }
}
function updateStatus(message){const x=$('updateStatus');if(x)x.textContent=message;}
async function checkUpdate(){
 if(window.GS_NATIVE_UPDATES?.isNative){
   await window.GS_NATIVE_UPDATES.check((message)=>updateStatus(message),state.lang);
   return;
 }
 if(!navigator.onLine){updateStatus(age('ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਹੈ','You are offline'));return;}
 if(!/^https?:$/.test(location.protocol)){updateStatus(t('updateRequiresWeb'));return;}
 updateStatus(t('updating'));
 try{
  const res=await fetch('./version.json?check='+Date.now(),{cache:'no-store'});
  if(!res.ok)throw Error('Version manifest not available');
  const incoming=await res.json();
  if(!/^\d+\.\d+\.\d+$/.test(incoming.version))throw Error('Invalid version');
  const [a,b,c]=incoming.version.split('.').map(Number);const [x,y,z]=APP_VERSION.split('.').map(Number);
  const newer=a>x||(a===x&&(b>y||(b===y&&c>z)));
  if(!newer){updateStatus(t('upToDate'));toast(t('upToDate'));return;}
  updateStatus(`${t('updateAvailable')} v${incoming.version}`);
  let btn=$('checkUpdateButton');if(btn)btn.textContent=t('update')+' · v'+incoming.version;
  if(state.view==='reader')capture();
  const reg=await navigator.serviceWorker?.getRegistration();
  if(!reg){updateStatus(t('updateRequiresWeb'));return;}
  isApplyingUpdate=true;
  await reg.update();
  if(reg.waiting)reg.waiting.postMessage({type:'SKIP_WAITING'});
  updateStatus(t('updateReady'));
  setTimeout(()=>{if(isApplyingUpdate)location.reload()},2000);
 }catch(e){console.warn('Update check:',e);updateStatus(t('updateFailed'))}
}
async function installApp(){
 if(installPrompt){try{installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;}catch(e){console.warn(e)}return;}
 toast(t('installHint'));
}
function exportBackup(){const blob=new Blob([JSON.stringify({app:'Gurbani Saanjh',version:APP_VERSION,exported:new Date().toISOString(),state},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='gurbani-saanjh-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
async function importBackup(file){try{const obj=JSON.parse(await file.text());if(obj.app!=='Gurbani Saanjh'||!obj.state||typeof obj.state!=='object')throw Error('Invalid backup');const permitted=['lang','meaningLang','readingScript','meanings','theme','mode','font','uiScale','raisedHeadings','spacing','lineLayout','bookCursors','pageTurnSpeed','savedVerses','aiEndpoint','aiAccessToken','ang','fontStyle','margin','readView','verse','verseOffset','page','hasProgress','kirtanId','favorites','homeOrder','depth','daily','hukamnama','questions','nightMode','showTranslit','showEn','showPa','showArth','baniTextSize','fontColor','layerScale','aiApiKey','aiApiEndpoint','aiModel','aiLang','aiLangManual','aiFont','searchHistory','keyboardOn','kbLang','tone'];for(const k of permitted)if(k in obj.state)state[k]=obj.state[k];state.daily={...BASE.daily,...state.daily};state.lang=state.lang==='en'?'en':'pa';state.meaningLang=state.meaningLang==='en'?'en':'pa';state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));state.raisedHeadings=state.raisedHeadings!==false;state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,Number(state.page)||0));state.homeOrder=normalizeHomeOrder(state.homeOrder);state.aiLang=state.aiLang==='en'?'en':'pa';state.aiLangManual=state.aiLangManual===true;if(!state.aiLangManual)state.aiLang=state.lang;persist();closeSettings();render();toast(age('ਬੈਕਅੱਪ ਲਿਆ ਗਿਆ','Backup restored'))}catch(e){toast(age('ਬੈਕਅੱਪ ਫਾਈਲ ਸਹੀ ਨਹੀਂ','Invalid backup file'))}}
/* ---- Per-view wiring ---- */
let kirtanQuery='';
function attach(){
 // v2.2.44: register the voice listeners as early as possible (idempotent —
 // a no-op once registered) so the mic works on the very first tap.
 ensureVoiceListeners();
 syncVoiceStopUI();
 if(state.view==='home'||state.view==='hukamnama'){ensureHukamnama();scheduleHukamNotification();}
 if(state.view==='home')setupHomeDrag();else if(homeDragCleanup){homeDragCleanup();homeDragCleanup=null;}
 if(state.view==='catalog'){const input=$('catalogSearch');if(input)input.addEventListener('input',()=>{catalogFilter=input.value;$('catalogResults').innerHTML=catalogRows(catalogFilter)});
  if(!onlineCatalog.length)window.GS_REMOTE.list().then(list=>{onlineCatalog=list;if(state.view==='catalog'&&$('catalogResults'))$('catalogResults').innerHTML=catalogRows(catalogFilter)}).catch(e=>{console.warn('Offline Bani index could not load',e)});
 }
 if(state.view==='kirtan'){
  const bookInput=$('kirtanBookSearch');
  const renderBook=()=>{const box=$('kirtanBookResults');if(box)box.innerHTML=kirtanBookRows();renderKirtanAlpha()};
  if(bookInput)bookInput.addEventListener('input',()=>{kirtanBookFilter=bookInput.value;renderBook()});
  ensureKirtanBook().then(()=>{if(state.view==='kirtan')renderBook()});
  const strip=$('kirtanAlpha');
  if(strip){
   const pick=e=>{const t=e.target.closest('[data-alpha]');if(t)kirtanAlphaJump(t.dataset.alpha)};
   strip.addEventListener('click',pick);
   strip.addEventListener('touchstart',e=>{e.preventDefault();pick(e)},{passive:false});
   strip.addEventListener('touchmove',e=>{e.preventDefault();const t=e.touches[0];if(!t)return;const el=document.elementFromPoint(t.clientX,t.clientY);const a=el&&el.closest?el.closest('[data-alpha]'):null;if(a)kirtanAlphaJump(a.dataset.alpha)},{passive:false});
  }
  const input=$('kirtanSearch');if(input){input.addEventListener('input',()=>{kirtanQuery=input.value;showOfflineResults(kirtanQuery,'kirtanResults',true)});if(kirtanQuery)showOfflineResults(kirtanQuery,'kirtanResults',true)}
 }
 if(state.view==='search'){
  const input=$('searchInput');
  // v2.2.44: pass save=true so the ♡ save button shows on the main search
  // results (the Kirtan screen already does this; the main search did not).
  const run=()=>showOfflineResults(input.value,'searchResults',true);
  input.addEventListener('input',run);
  input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();pushSearchHistory(input.value);run()}});
  const applyKbLang=()=>{const pa=state.kbLang==='pa';input.readOnly=pa;input.setAttribute('lang',pa?'pa':'en');const t=$('kbToggle');if(t){t.textContent=pa?'ਪੁ':'EN';t.classList.toggle('sel',pa)}const kb=$('gsKeyboard'),anchor=$('voiceStatus');if(pa&&!kb&&anchor){anchor.insertAdjacentHTML('beforebegin',gsKeyboardHTML());wireKeys()}else if(!pa&&kb)kb.remove();};
  // v2.2.33: X is the stop — it clears the search and stops the mic for real.
  // It no longer restarts listening (tap the mic to speak again).
  const clear=$('searchClear');if(clear)clear.onclick=()=>{resetVoiceNow();input.value='';$('searchResults').innerHTML='';};
  const vb=$('voiceBtn');if(vb)vb.onclick=()=>{if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(input);};
  // v2.2.40: no separate Stop button — the mic button itself is the Stop
  // button while listening (tap it to stop); tap it while idle to speak.
  const kbt=$('kbToggle');if(kbt)kbt.onclick=()=>{state.kbLang=state.kbLang==='pa'?'en':'pa';persist();applyKbLang();input.focus({preventScroll:true})};
  const wireKeys=()=>{document.querySelectorAll('[data-gs-key]').forEach(b=>b.onclick=()=>{
   const k=b.dataset.gsKey;
   if(k==='⌫')input.value=input.value.slice(0,-1);
   else input.value+=GS_KEY_VALUE[k]||k;
   run();input.focus({preventScroll:true});
  })};
  wireKeys();applyKbLang();
  document.querySelectorAll('[data-search-mode]').forEach(b=>b.addEventListener('click',()=>{searchMode=b.dataset.searchMode;document.querySelectorAll('[data-search-mode]').forEach(x=>x.classList.toggle('sel',x===b));if(input.value.trim())run()}));
  const is=$('iconSearch');if(is)is.onclick=()=>{pushSearchHistory(input.value);input.focus();run()};
  const ib=$('iconBookmarks');if(ib)ib.onclick=()=>go('bookmarks');
  const ih=$('iconHistory');if(ih)ih.onclick=()=>{const box=$('searchHistoryBox');if(box){box.classList.toggle('hidden');if(!box.classList.contains('hidden'))box.innerHTML=searchHistoryBoxHTML()}};
 }
 if(state.view==='ask'){const av=$('askVoiceBtn');if(av)av.onclick=()=>{const qi=$('questionInput');if(!qi)return;if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(qi)};}
 if(state.view==='viewprefs'){
  const fs=$('vpFontSlider'),fv=$('vpFontValue');
  const setVpFont=n=>{state.font=Math.min(40,Math.max(18,Number(n)||24));if(fs)fs.value=state.font;if(fv)fv.textContent=state.font+'px';theme();persist();};
  if(fs)fs.addEventListener('input',()=>setVpFont(fs.value));
  const fm=$('vpFontMinus');if(fm)fm.onclick=()=>setVpFont((Number(state.font)||24)-2);
  const fp=$('vpFontPlus');if(fp)fp.onclick=()=>setVpFont((Number(state.font)||24)+2);
  const ls=$('vpLayerSlider'),lv=$('vpLayerValue');
  const setVpLayer=n=>{state.layerScale=Math.min(1,Math.max(0.7,Math.round((Number(n)||0.8)*20)/20));if(ls)ls.value=state.layerScale;if(lv)lv.textContent=Math.round(state.layerScale*100)+'%';theme();persist();};
  if(ls)ls.addEventListener('input',()=>setVpLayer(ls.value));
  const lm=$('vpLayerMinus');if(lm)lm.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)-0.05);
  const lp=$('vpLayerPlus');if(lp)lp.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)+0.05);
 }
 if(state.view==='reader'){const aj=$('angJumpInput'),ag=$('angJumpGo');if(aj&&ag){const jump=()=>{highlightLine=-1;openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)};ag.onclick=jump;aj.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();jump()}})}}
 if(state.view==='reader'&&state.mode==='scroll'&&activeRemote?.kind==='ang'){
  const el=$('verses');let touch=null;
  el?.addEventListener('touchstart',e=>{touch={x:e.changedTouches[0].clientX,y:e.changedTouches[0].clientY}},{passive:true});
  el?.addEventListener('touchend',e=>{if(!touch)return;let dx=e.changedTouches[0].clientX-touch.x,dy=e.changedTouches[0].clientY-touch.y;if(Math.abs(dx)>95&&Math.abs(dx)>Math.abs(dy)*1.75){const cur=displayAng();openAng(cur+(dx<0?1:-1),false,cur===state.ang)}touch=null},{passive:true});
 }
 if(state.view==='reader'&&state.mode==='page'){
  const stage=$('bookStage');
  if(stage&&window.GS_PAGE_TURN){
   const source=activeRemote?.lines?.length?activeRemote.lines:(state.readView==='kirtan'?(CONTENT.kirtan.find(x=>x.id===state.kirtanId)||CONTENT.kirtan[0]).lines:[]);
   const kind=activeRemote?.kind||'kirtan';
   const key=activeRemote?`${activeRemote.kind}:${activeRemote.id}`:`kirtan:${state.kirtanId}`;
   const oldCursor=state.bookCursors[key]||{verse:activeRemote?.kind==='ang'?state.verse:0,word:0};
   bookReader=window.GS_PAGE_TURN.mount(stage,{
    lines:source,kind,lang:state.lang,meaningLang:state.lang,readingScript:state.readingScript,
    meanings:state.showPa||state.showEn,vishraams:false,cursor:oldCursor,pageTurnSpeed:state.pageTurnSpeed,
    onChange(cursor,index,pages){
     state.bookCursors[key]=cursor;
     if(kind==='ang'&&displayAng()===state.ang){state.verse=cursor.verse;state.verseOffset=0;state.hasProgress=true;}
     persist();
    },
    onEdge(dir){
     if(kind==='ang'&&activeRemote&&((dir>0&&displayAng()<1430)||(dir<0&&displayAng()>1))){const cur=displayAng(),target=cur+dir;if(dir<0)state.bookCursors[`ang:${target}`]={verse:Number.MAX_SAFE_INTEGER,word:0};else if(!state.bookCursors[`ang:${target}`])state.bookCursors[`ang:${target}`]={verse:0,word:0};persist();openAng(target,false,cur===state.ang);}
    }
   });
  }
 }
}
/* ---- Global wiring ---- */
const LAYER_SETTINGS=new Set(['showTranslit','showEn','showPa','showArth','nightMode','lang']);
function bindGlobals(){
$('nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){if(b.dataset.view==='reader')navReader();else go(b.dataset.view)}});
$('backBtn').onclick=()=>{if(state.view==='reader'&&state.readView==='kirtan')go('kirtan');else if(state.view==='reader'&&activeRemote?.kind==='kirtan')go('kirtan');else go('home')};$('settingsBtn').onclick=openSettings;$('closeSheet').onclick=closeSettings;
$('sheetOverlay').addEventListener('click',e=>{if(e.target===$('sheetOverlay'))closeSettings()});
$('main').addEventListener('click',e=>{
 const found=e.target.closest('[data-found-ang],[data-open-saved-ang]');if(found){stopVoiceSearch();highlightLine=Number(found.dataset.foundIdx||found.dataset.openSavedIdx)||0;openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true);return}
 const foundBani=e.target.closest('[data-found-bani],[data-open-saved-bani]');if(foundBani){stopVoiceSearch();highlightLine=Number(foundBani.dataset.foundIdx||foundBani.dataset.openSavedIdx)||0;openBani(Number(foundBani.dataset.foundBani||foundBani.dataset.openSavedBani),foundBani.dataset.baniTitle||'Bani',true);return}
 const save=e.target.closest('[data-save-hit],[data-remove-saved]');if(save){const raw=String(save.dataset.saveHit||save.dataset.removeSaved);const parts=raw.split(':');const isBani=parts[0]==='bani';const baniId=isBani?Number(parts[1])||0:0;const ang=isBani?0:Number(parts[0])||0;const idx=Number(parts[isBani?2:1])||0;const exists=state.savedVerses.find(v=>isBani?(v.src==='bani'&&v.baniId===baniId&&v.idx===idx):(v.src!=='bani'&&v.ang===ang&&v.idx===idx));if(exists)state.savedVerses=state.savedVerses.filter(v=>v!==exists);else if(isBani){const m=window.GS_SCRIPTURE_SEARCH?.lookupBani?.(baniId,idx);if(m)state.savedVerses.unshift({src:'bani',baniId,idx,g:m.g,baniTitle:m.baniTitle||m.titlePa,titlePa:m.titlePa,titleEn:m.titleEn,group:m.group||'sggs'})}else{const match=window.GS_SCRIPTURE_SEARCH?.lookup(ang,idx);if(match)state.savedVerses.unshift({ang,idx,g:match.g})}persist();render();return}
 const ks=e.target.closest('[data-kirtan-shabad]');if(ks){openKirtanShabad(ks.dataset.kirtanShabad);return}
 const dc=e.target.closest('[data-drawer-close]');if(dc){state.baniDrawer=false;render();return}
 const b=e.target.closest('[data-remote-bani]');if(b){state.baniDrawer=false;openBani(b.dataset.remoteBani,b.dataset.baniTitle);return}
 const ab=e.target.closest('[data-open-ang]');if(ab){highlightLine=-1;openAng($('angPicker')?.value||displayAng(),false,true);return}
 const retry=e.target.closest('[data-retry-remote]');if(retry&&activeRemote){if(activeRemote.kind==='kirtan')openKirtanShabad(activeRemote.id);else loadRemote(activeRemote.kind,activeRemote.id,activeRemote.title);return}
 if(e.target.closest('[data-home-id]')&&(homeEditing||Date.now()-lastHomeDragEnded<600)){e.preventDefault();e.stopPropagation();return;}
 // v2.2.44: delete search history — Clear all and per-item × are checked
 // BEFORE the query-tap branch, so tapping × deletes and does NOT re-run
 // the search. Both re-render the whole history box (heading + list), so
 // the Clear-all button appears exactly when history is non-empty.
 const ch=e.target.closest('[data-clear-history]');if(ch){state.searchHistory=[];persist();const box=$('searchHistoryBox');if(box)box.innerHTML=searchHistoryBoxHTML();return}
 const rh=e.target.closest('[data-remove-history]');if(rh){const q=rh.dataset.removeHistory;state.searchHistory=state.searchHistory.filter(x=>x!==q);persist();const box=$('searchHistoryBox');if(box)box.innerHTML=searchHistoryBoxHTML();return}
 const hq=e.target.closest('[data-history-q]');if(hq){const inp=$('searchInput');if(inp){inp.value=hq.dataset.historyQ;showOfflineResults(inp.value,'searchResults',true)}return}
 const act=e.target.closest('[data-action]');if(act){action(act.dataset.action,act);return}
 const word=e.target.closest('[data-word]');if(word){e.stopPropagation();openLineMeaning(word);return}
 const fav=e.target.closest('[data-favorite]');if(fav){let id=fav.dataset.favorite;state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];persist();render();return}
 const selectedBani=e.target.closest('[data-catalog-id]');if(selectedBani){const item=CATALOG.find(x=>x.id===Number(selectedBani.dataset.catalogId));if(item)openCatalogBani(item);return}
 const depth=e.target.closest('[data-depth]');if(depth){state.depth=depth.dataset.depth;persist();document.querySelectorAll('[data-depth]').forEach(b=>b.classList.toggle('sel',b.dataset.depth===state.depth));return}
 const aiZoom=e.target.closest('[data-ai-zoom]');
 if(aiZoom){state.aiFont=Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)));persist();theme();render();return;}
 const aiLang=e.target.closest('[data-ai-lang]');if(aiLang){state.aiLang=aiLang.dataset.aiLang;state.aiLangManual=true;persist();document.querySelectorAll('[data-ai-lang]').forEach(b=>b.classList.toggle('sel',b.dataset.aiLang===state.aiLang));return}
});
$('main').addEventListener('change',e=>{
 if(e.target.id==='dailySource'){state.daily.source=e.target.value;persist();render()}
 if(e.target.id==='dailyTime'){state.daily.time=e.target.value;persist()}
 if(e.target.id==='menuBackupInput'&&e.target.files?.[0])importBackup(e.target.files[0]);
 if(e.target.id==='aiKeyInput'){state.aiApiKey=e.target.value.trim();persist();toast(age('API key ਸੇਵ ਹੋ ਗਈ','API key saved'))}
 if(e.target.id==='aiApiEndpointInput'){const u=e.target.value.trim();if(!u||/^https:\/\//.test(u)){state.aiApiEndpoint=u;persist()}else toast('HTTPS URL only')}
 if(e.target.id==='aiModelInput'){state.aiModel=e.target.value.trim();persist()}
 if(e.target.id==='aiAccessInput'){state.aiAccessToken=e.target.value;persist()}
 if(e.target.id==='aiEndpointInput'){const url=e.target.value.trim();if(!url||/^https:\/\//.test(url)){state.aiEndpoint=url;persist()}else toast('HTTPS URL only')}
});
$('main').addEventListener('click',e=>{if(e.target.closest('#askButton'))answerQuestion()});
$('wordPopup').addEventListener('click',e=>{if(e.target.closest('[data-close-word]')){e.preventDefault();closeWord();return}const ll=e.target.closest('[data-line-lang]');if(ll){state.meaningLang=ll.dataset.lineLang;persist();document.querySelectorAll('[data-line-lang]').forEach(b=>b.classList.toggle('sel',b.dataset.lineLang===state.meaningLang));fillLineMeaning(lineMeaningLine)}});
document.addEventListener('pointerdown',e=>{
 if(!$('wordPopup').classList.contains('hidden')&&!e.target.closest('#wordPopup')&&!e.target.closest('[data-word]'))closeWord();
},{passive:true});
document.addEventListener('click',e=>{
 if(!$('wordPopup').classList.contains('hidden')&&!e.target.closest('[data-word]')&&!e.target.closest('#wordPopup'))closeWord();
});
$('sheetBody').addEventListener('click',async e=>{
 let setting=e.target.closest('[data-setting]');
 if(setting){
  const prop=setting.dataset.setting,val=setting.dataset.value;
  if(state.view==='reader'&&state.mode==='scroll')capture();
  const bools=new Set(['raisedHeadings','showTranslit','showEn','showPa','showArth','nightMode']);
  state[prop]=bools.has(prop)?val==='true':val;
  if(prop==='mode'){state.verseOffset=0}
  persist();theme();
  $('sheetBody').innerHTML=settingsHTML();$('settingsTitle').textContent=t('readerSettings');
  if(LAYER_SETTINGS.has(prop))await refreshReader();else render();
  return;
 }
 let act=e.target.closest('[data-action]');if(act){action(act.dataset.action,act);return}
});
$('main').addEventListener('click',async e=>{
 const setting=e.target.closest('.page [data-setting]');
 if(!setting)return;
 const prop=setting.dataset.setting,val=setting.dataset.value;
 const bools=new Set(['raisedHeadings','showTranslit','showEn','showPa','showArth','nightMode','keyboardOn']);
 state[prop]=bools.has(prop)?val==='true':val;
 persist();theme();render();
});
$('sheetBody').addEventListener('click',e=>{const u=e.target.closest('#uiMinus,#uiPlus');if(!u)return;state.uiScale=Math.min(1.35,Math.max(1,Math.round((state.uiScale+(u.id==='uiPlus'?.05:-.05))*100)/100));$('uiSlider').value=state.uiScale;$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();});
$('sheetBody').addEventListener('click',e=>{const plus=e.target.closest('#fontPlus,#fontMinus');if(!plus)return;state.font=Math.min(40,Math.max(18,state.font+(plus.id==='fontPlus'?1:-1)));$('fontSlider').value=state.font;$('fontValue').textContent=state.font+'px';theme();persist()});
$('sheetBody').addEventListener('input',e=>{if(e.target.id==='uiSlider'){state.uiScale=Number(e.target.value);$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();}if(e.target.id==='fontSlider'){state.font=Number(e.target.value);$('fontValue').textContent=state.font+'px';theme();persist()}if(e.target.id==='toneSlider'){state.tone=Number(e.target.value);theme();persist()}});
$('sheetBody').addEventListener('change',e=>{if(e.target.id==='backupInput'&&e.target.files?.[0])importBackup(e.target.files[0])});
let scrollTimer;window.addEventListener('scroll',()=>{if(!$('wordPopup').classList.contains('hidden'))closeWord();onReaderScroll();if(state.view!=='reader'||state.mode!=='scroll'||state.readView!=='sggs')return;clearTimeout(scrollTimer);scrollTimer=setTimeout(capture,130)},{passive:true});
window.addEventListener('pagehide',capture);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')capture()});
window.addEventListener('gs-open-hukamnama',()=>{go('hukamnama');});
window.addEventListener('popstate',e=>{if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();closeWord();closeSettings();state.view=(e.state?.gsView)||'home';render();if(state.view!=='reader')window.scrollTo(0,0)});
try{window.Capacitor?.Plugins?.App?.addListener('backButton',()=>{
  if(!$('sheetOverlay').classList.contains('hidden')){closeSettings();return}
  if(!$('wordPopup').classList.contains('hidden')){closeWord();return}
  if(state.baniDrawer){state.baniDrawer=false;render();return}
  if(state.view!=='home')window.history.back();
})}catch(e){console.warn('Native back handler unavailable',e)}
document.addEventListener('keydown',e=>{const homeCard=e.target.closest?.('[data-home-id]');if(state.view==='home'&&homeCard&&homeEditing&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();moveHomeCard(homeCard.dataset.homeId,['ArrowLeft','ArrowUp'].includes(e.key)?-1:1);return;}if(state.view==='home'&&homeCard&&!homeEditing&&e.key===' '){e.preventDefault();homeEditing=true;render();document.querySelector(`[data-home-id="${homeCard.dataset.homeId}"]`)?.focus();return;}if(e.key==='Escape'){closeWord();closeSettings()}if(state.view==='reader'&&state.mode==='page'&&!e.target.matches('input,textarea')){if(e.key==='ArrowRight')bookReader?.navigate(1);if(e.key==='ArrowLeft')bookReader?.navigate(-1)}});
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(isApplyingUpdate){isApplyingUpdate=false;location.reload()}})}
bindGlobals();bootData();render();
// v2.2.44: register the voice listeners NOW (fire-and-forget — the native
// bridge is already loaded, native-updates.js runs before app.js), so the mic
// works on the very first tap after launch. The mic-tap path still calls
// ensureVoiceListeners() as a backstop.
ensureVoiceListeners();
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator&&location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(console.warn));
})();
