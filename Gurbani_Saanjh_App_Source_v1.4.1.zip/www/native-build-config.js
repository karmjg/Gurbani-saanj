window.GS_BUILD={"version":"1.4.1","repo":"karmjg/Gurbani-saanj"};
