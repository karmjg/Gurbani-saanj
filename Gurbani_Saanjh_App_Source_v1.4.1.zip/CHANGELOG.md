# Gurbani Saanjh v1.4.1 — Setting label

- Settings → Reading now shows **Vishraam** with On / Off. No change to pause colours, saved preference, or Gurbani text.

# Gurbani Saanjh v1.4.0 — Coloured Vishraam words

- Short pauses appear as **gold/amber words**; longer pauses appear as **teal-green words**. Removed all pause underlines.
- Settings → Reading → **Vishraam** → **On / Off**, independently of language and meaning preferences. The choice is saved on the device using the same existing app-storage key, so reading progress persists across upgrades.
- With pause colours off, all Gurbani words use normal text colour. The text itself is never altered.
- Reader remains distraction-free and shows Gurbani only; change settings after leaving reader with Samsung Back.
- Colour variants are readable in light, sepia, dark and charcoal themes.
- Pause annotations currently cover only 2 test positions in a selected Japji Sahib excerpt. These remain interpretive teaching aids, subject to qualified review.
- No new audio content or AI recitation bundled. Word-specific audio remains pending verified timestamp alignment.

## v1.3.0 — Vishraam private test

- Home Punjabi/English toggle positioned at left side of hero image.
- Immersive reader: only the scripture is visible. No app menu/header/navigation is shown.
- Word popover opens on a 560ms press-and-hold; normal taps do nothing.
- Japji Sahib full-Paath audio player is opened from the Nitnem list (outside the immersive reader).
- Word Listen no longer launches the full Japji Sahib recording. Word-specific clips remain unavailable until timestamps are verified.
- Added Capacitor App back-button handler, with history fallback. Samsung hardware Back still requires device testing.
- New Settings > Vishraam ON/OFF, saved on this phone.
- Prior v1.3 used underlines, now replaced by word colours in v1.4.
- First verified test case: Japji Sahib, Ang 1, opening Pauri, `ਸੋਚੈ` (short) and `ਹੋਵਈ` (long).
- Based on https://discoversikhism.com/learn_gurbani/japji_sahib_visram_test.html ; pause marks are educational interpretations, not original scripture.
- Not yet a complete coverage of pause positions or the entire Japji Sahib text.
- Does NOT add permissions for the separately imported Bhai Jarnail Singh Ji recording.
- Does NOT claim word-specific audio works until timecodes are checked.

## v1.2.0 — Japji Sahib offline audio personal test
- Added local MP3 import and IndexedDB persistence; Android's audio controls plus 10-second skips and rate selection.
- Added Punjabi/English home-screen language toggle.
- Added independent Gurmukhi/English-letter display preference and existing independent meaning language setting.
- Added Nitnem section with Japji audio test entry.
- No source MP3 included in repository. AI remains unconnected; no verified word sync.
