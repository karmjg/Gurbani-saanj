# Gurbani Saanjh private trial v1.4.1

See CHANGELOG.md for new Vishraam pause guides. Pause marks are visible by default only on two positions that were cross-checked with a published teaching example. In Reader Settings toggle Vishraam Off to restore original unmarked typography. No changes are made to the original Gurbani text.

Keep your own audio recordings on your phone, not in public GitHub. The app source still contains selected excerpts, not a complete validated corpus.

To build through your existing workflow, update the ZIP filename from `Gurbani_Saanjh_App_Source_v1.2.zip` to `Gurbani_Saanjh_App_Source_v1.4.1.zip` and upload the ZIP to the repository root. The signing secrets remain unchanged.

## Pause colours
In Settings → Reading, select Vishraam On/Off. Gold = brief pause, teal-green = longer pause. The setting persists on the phone and does not modify source scripture text. Only two sample annotations are available pending human review.
