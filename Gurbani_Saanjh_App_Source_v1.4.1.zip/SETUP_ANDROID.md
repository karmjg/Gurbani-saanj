# Install v1.2 Android test update

1. In your existing **public** GitHub repository `karmjg/Gurbani-saanj`, upload the file `Gurbani_Saanjh_App_Source_v1.2.zip` to the **root** (keep it as ZIP).
2. Replace the existing `.github/workflows/android-apk.yml` with the separately supplied `Gurbani_Saanjh_v1.2_android-apk.yml` file contents. It now extracts the **v1.2** ZIP.
3. Do not modify any of the **four signing secrets** already configured. Do not expose the signing backup.
4. Go to **Actions > Build Gurbani Saanjh Android APK > Run workflow > main**.
5. If green, open **Artifacts > Gurbani-Saanjh-Android-APK**, download and extract the file `Gurbani_Saanjh_v1.2.0.apk`.
6. On Android, open the APK and choose **Update**. The application ID is unchanged. Updates require the same signing key and a larger versionCode.
7. On your phone, separately download `Gurbani_Saanjh_Japji_Sahib_Bhai_Jarnail_Singh_Cleaned.mp3`.
8. In the app, tap **Nitnem > Japji Sahib > Listen > Import MP3**, and choose the MP3. It then plays locally and will usually remain available offline after closing the app.

### Caution
The code is provided as a GitHub build project, **not** a compiled/tested APK. The APK is created by the runner. Avoid uploading any MP3 into a public repository; redistribution rights have not been established. Scriptural excerpts, meaning and transliteration are demonstration content needing review.

**Workflow ZIP name:** `Gurbani_Saanjh_App_Source_v1.4.1.zip`. Update the extraction variable in the workflow on GitHub to this exact name, then commit and run Actions.
