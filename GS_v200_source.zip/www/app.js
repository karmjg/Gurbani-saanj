/* Gurbani Saanjh v1.6.0 reading-library private-test — offline-first personal trial. No synthetic paath audio.
   Plain HTML/CSS/JS by design, so GitHub source stays easy to update.
*/
(()=>{
'use strict';
const CONTENT=window.GS_DATA;
const CATALOG=window.GS_CATALOG||[];
let catalogFilter='';
let activeRemote=null;
let remoteBusy=false;
let onlineCatalog=[];
const APP_VERSION=(window.GS_BUILD?.version||'2.0.0');
let isApplyingUpdate=false;
let installPrompt=null;
const KEY='gurbani-saanjh-trial-v1'; // Keep unchanged: older v0.2 reading progress migrates.
const BASE={bookCursors:{},pageTurnSpeed:'slow',savedVerses:[],aiEndpoint:'',aiAccessToken:'',lineLayout:'compact',ang:1,vishraams:true,lang:'pa',meaningLang:'pa',readingScript:'gurmukhi',meanings:false,theme:'light',mode:'scroll',font:24,uiScale:1.12,raisedHeadings:true,spacing:1.82,fontStyle:'serif',margin:'normal',
  view:'home',readView:'sggs',verse:0,verseOffset:0,page:0,hasProgress:false,kirtanId:'kirtan-lakh',
  favorites:[],homeOrder:['reader','nitnem','catalog','kirtan','ask','daily'],filter:'all',depth:'detail',questions:[],
  daily:{source:'sggs',order:'sequential',amount:2,time:'08:00',enabled:false,startDate:''}};
let stored={};try{stored=JSON.parse(localStorage.getItem(KEY)||'{}')||{};}catch{}
const state={...BASE,...stored,daily:{...BASE.daily,...(stored.daily||{})},favorites:Array.isArray(stored.favorites)?stored.favorites:[],questions:Array.isArray(stored.questions)?stored.questions.slice(-12):[],savedVerses:Array.isArray(stored.savedVerses)?stored.savedVerses:[]};
state.font=Math.min(40,Math.max(18,Number(state.font)||24));
state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));
state.raisedHeadings=state.raisedHeadings!==false;
state.spacing=Math.min(2.35,Math.max(1.45,Number(state.spacing)||1.82));
state.lineLayout=['compact','standard','spacious'].includes(state.lineLayout)?state.lineLayout:'compact';
state.ang=Math.min(1430,Math.max(1,Number(state.ang)||1));
state.meaningLang=state.meaningLang==='en'?'en':'pa';
state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';
state.pageTurnSpeed=['slow','normal','fast'].includes(state.pageTurnSpeed)?state.pageTurnSpeed:'slow';
state.vishraams=state.vishraams!==false;
state.lang=state.lang==='en'?'en':'pa';
state.bookCursors=(state.bookCursors&&typeof state.bookCursors==='object'&&!Array.isArray(state.bookCursors))?state.bookCursors:{};
let bookReader=null;
const HOME_IDS=['reader','nitnem','catalog','kirtan','ask','daily'];
function normalizeHomeOrder(value){const good=Array.isArray(value)?value.filter((id,i)=>HOME_IDS.includes(id)&&value.indexOf(id)===i):[];return [...good,...HOME_IDS.filter(id=>!good.includes(id))]}
state.homeOrder=normalizeHomeOrder(state.homeOrder);
let homeEditing=false;
let homePending=null;
let homeDrag=null;
let homeDragCleanup=null;
let lastHomeDragEnded=0;
state.view='home';
try{window.history.replaceState({gsView:'home'},'',window.location.pathname+window.location.search+'#home')}catch{}
state.fontStyle=['serif','sans'].includes(state.fontStyle)?state.fontStyle:'serif';
state.margin=['narrow','normal','wide'].includes(state.margin)?state.margin:'normal';
state.theme=['light','sepia','dark','charcoal'].includes(state.theme)?state.theme:'light';
const $=id=>document.getElementById(id);
const words=CONTENT.words;
const lines=CONTENT.reader.sections[0].lines;
const PAGE_GROUPS=[[0,1,2,3],[4,5,6],[7,8,9]]; // Visual pagination of ONE trial Ang, not separate Angs.
const txt={
pa:{home:'ਮੁੱਖ',read:'ਪਾਠ',search:'ਖੋਜ',ask:'ਸਵਾਲ',settings:'ਸੈਟਿੰਗਾਂ',menu:'ਮੀਨੂ',readerSettings:'ਪੜ੍ਹਨ ਦੀ ਸੈਟਿੰਗ',appearance:'ਦਿੱਖ',fontStyleLabel:'ਫੌਂਟ',serif:'ਕਿਤਾਬੀ',sans:'ਸਾਫ਼',margins:'ਪਾਸਿਆਂ ਦੀ ਜਗ੍ਹਾ',narrow:'ਘੱਟ',normal:'ਦਰਮਿਆਨੀ',wide:'ਵੱਧ',sepia:'ਸੇਪੀਆ',charcoal:'ਚਾਰਕੋਲ',smallText:'ਛੋਟੇ ਅੱਖਰ',largeText:'ਵੱਡੇ ਅੱਖਰ',updateCenter:'ਐਪ ਅੱਪਡੇਟ',currentVersion:'ਮੌਜੂਦਾ ਵਰਜ਼ਨ',updating:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੱਭ ਰਹੇ ਹਾਂ…',upToDate:'ਇਹ ਵਰਜ਼ਨ ਅੱਪਡੇਟ ਹੈ।',updateAvailable:'ਨਵਾਂ ਵਰਜ਼ਨ ਮਿਲਿਆ ਹੈ। ਅੱਪਡੇਟ ਕਰਨ ਲਈ ਦਬਾਓ।',updateRequiresWeb:'Android APK ਅੱਪਡੇਟ ਲਈ GitHub Releases ਵਰਤੋ।',updateFailed:'ਅੱਪਡੇਟ ਚੈੱਕ ਨਹੀਂ ਹੋ ਸਕੀ। ਇੰਟਰਨੈੱਟ ਚੈੱਕ ਕਰੋ।',updateReady:'ਨਵਾਂ ਵਰਜ਼ਨ ਲੋਡ ਕੀਤਾ ਜਾ ਰਿਹਾ ਹੈ…',install:'ਹੋਮ ਸਕਰੀਨ ਉੱਤੇ ਜੋੜੋ',installHint:'ਇਹ ਪਹਿਲਾਂ ਤੋਂ Android ਐਪ ਵਜੋਂ ਇੰਸਟਾਲ ਹੈ।',menuIntro:'ਇੱਕੋ ਐਪ ਰੱਖੋ — ਨਵੇਂ ਵਰਜ਼ਨ ਸਿੱਧੇ ਅੱਪਡੇਟ ਕਰੋ।',menuBackups:'ਤੁਹਾਡਾ ਡਾਟਾ',backupHint:'ਸਹਿਜ ਪਾਠ ਦੀ ਜਗ੍ਹਾ, ਪਸੰਦੀਦਾ ਸ਼ਬਦ ਅਤੇ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿੰਦੀਆਂ ਹਨ। ਬੈਕਅੱਪ ਵੱਖਰਾ ਸੰਭਾਲੋ।',
  hero:'ਗੁਰਬਾਣੀ ਨਾਲ ਜੁੜਨ ਦੀ ਇੱਕ ਸਾਦੀ ਥਾਂ',welcome:'ਜਿੱਥੇ ਛੱਡਿਆ ਸੀ, ਉੱਥੋਂ ਪੜ੍ਹੋ',continue:'ਸਹਿਜ ਪਾਠ ਜਾਰੀ ਰੱਖੋ',
  sample:'ਪਾਠ ਐਪ ਨਾਲ ਹੀ ਆਉਂਦਾ ਹੈ; ਇੰਟਰਨੈੱਟ ਦੀ ਲੋੜ ਨਹੀਂ।',
  readerTitle:'ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ', ang:'ਅੰਗ', excerpt:'ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ',
  meanings:'ਅਰਥ',on:'ਚਾਲੂ',off:'ਬੰਦ',meaning:'ਅਰਥ',
  audioPending:'ਪਲੇਅਰ ਵਿੱਚ ਅਸਲੀ ਮਨੁੱਖੀ ਰਿਕਾਰਡਿੰਗ ਸੁਣ ਸਕਦੇ ਹੋ। ਸ਼ਬਦ-ਵਾਰ ਸਮਾਂ ਹਾਲੇ ਨਹੀਂ ਮਿਲਾਇਆ।',
  wordPending:'ਇਸ ਸ਼ਬਦ ਦੇ ਪ੍ਰਮਾਣਿਤ ਅਰਥ ਹਾਲੇ ਜੋੜਣੇ ਹਨ।',
  start:'ਪੜ੍ਹੋ',next:'ਅਗਲਾ',prev:'ਪਿਛਲਾ',last:'ਅਗਲਾ ਅੰਗ ਅਜੇ ਟਰਾਇਲ ਵਿੱਚ ਨਹੀਂ ਹੈ।',
  library:'ਗੁਰਬਾਣੀ ਸੰਗ੍ਰਹਿ',catalog:'ਅਨੇਕ ਬਾਣੀਆਂ',catalogSearch:'ਬਾਣੀ ਦਾ ਨਾਮ ਖੋਜੋ...',catalogNotice:'ਬਾਣੀਆਂ ਦੀ ਸੂਚੀ। ਸੁੰਦਰ ਗੁਟਕਾ ਦੇ ਉਪਲਬਧ ਪਾਠ ਆਫਲਾਈਨ ਹਨ। ਕੁਝ ਖਾਸ ਪਾਠ-ਰੂਪ ਹਾਲੇ ਸਰੋਤ ਵਿੱਚ ਨਹੀਂ ਹਨ।',catalogPending:'ਇਸ ਬਾਣੀ ਦਾ ਪ੍ਰਮਾਣਿਤ ਪੂਰਾ ਪਾਠ ਅਜੇ ਜੋੜਿਆ ਜਾਣਾ ਹੈ।',catalogSection1:'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੀਆਂ ਬਾਣੀਆਂ',catalogSection2:'ਦਸਮ ਗ੍ਰੰਥ ਸੰਬੰਧੀ ਬਾਣੀਆਂ',catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਵੱਖਰੇ ਰੂਪ',catalogSection4:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',catalogResults:'ਬਾਣੀਆਂ',collection:'ਹੋਰ ਬਾਣੀਆਂ',kirtan:'ਕੀਰਤਨ ਸ਼ਬਦ',
  kirtanDesc:'ਵਾਰ-ਵਾਰ ਪੜ੍ਹਨ ਲਈ ਪਸੰਦੀਦਾ ਸ਼ਬਦ',kirtanNote:'ਇਸ ਟਰਾਇਲ ਵਿੱਚ ਸ਼ਬਦਾਂ ਦੀਆਂ ਚੁਣੀਆਂ ਪੰਗਤੀਆਂ ਹਨ; ਪੂਰੇ ਸ਼ਬਦ ਬਾਅਦ ਵਿੱਚ ਜੋੜੇ ਜਾਣਗੇ।',
  fav:'ਪਸੰਦੀਦਾ',all:'ਸਾਰੇ',onlyFav:'ਸਿਰਫ਼ ਪਸੰਦੀਦਾ',noFav:'ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੇਵ ਨਹੀਂ ਕੀਤਾ।',
  nitnem:'ਨਿਤਨੇਮ',dasam:'ਦਸਮ ਗ੍ਰੰਥ ਸਾਹਿਬ',bhai:'ਭਾਈ ਗੁਰਦਾਸ ਜੀ',pending:'ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਅਤੇ ਵਰਤੋਂ ਦੀ ਇਜਾਜ਼ਤ ਤੋਂ ਬਾਅਦ ਪੂਰੀ ਸਮੱਗਰੀ ਜੋੜੀ ਜਾਵੇਗੀ।',
  searchTitle:'ਗੁਰਬਾਣੀ ਖੋਜੋ',searchHint:'ਪੰਗਤੀ ਜਾਂ ਸ਼ਬਦ ਲਿਖੋ ਜਾਂ ਬੋਲੋ...',voicePending:'ਆਵਾਜ਼ ਨਾਲ ਖੋਜ ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਉਪਲਬਧ ਨਹੀਂ ਜਾਂ ਇੰਟਰਨੈੱਟ ਚਾਹੀਦਾ ਹੈ।',
  noResults:'ਇਸ ਖੋਜ ਨਾਲ ਮੇਲ ਖਾਂਦੀ ਪੰਗਤੀ ਨਹੀਂ ਮਿਲੀ।',results:'ਨਤੀਜੇ',
  askTitle:'ਗੁਰਬਾਣੀ ਤੋਂ ਪੁੱਛੋ',askHint:'ਕੋਈ ਵੀ ਸਵਾਲ ਪੁੱਛੋ...',askButton:'ਪੁੱਛੋ',short:'ਸੰਖੇਪ',detail:'ਵਿਸਥਾਰ',deep:'ਡੂੰਘਾਈ',
  askNotLive:'AI ਹਾਲੇ ਕਨੈਕਟ ਨਹੀਂ ਹੈ। ਇਹ ਸਿਰਫ਼ ਗੱਲਬਾਤ ਦੇ ਡਿਜ਼ਾਈਨ ਦਾ ਟਰਾਇਲ ਹੈ। ਅਸਲ ਜਵਾਬ ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਹਵਾਲਿਆਂ ਨਾਲ ਤਿਆਰ ਹੋਣਗੇ; ਦਸਮ ਗ੍ਰੰਥ ਅਤੇ ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਸਹਾਇਕ ਸਰੋਤ ਹੋਣਗੇ।',
  askRules:'AI ਸਵਾਲਾਂ ਦੇ ਅਸਲੀ ਜਵਾਬ ਇਸ ਵਰਜ਼ਨ ਵਿੱਚ ਹਾਲੇ ਉਪਲਬਧ ਨਹੀਂ ਹਨ।',
  language:'ਐਪ ਦੀ ਭਾਸ਼ਾ',meanLang:'ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ',viewMeaning:'ਪੰਗਤੀ ਹੇਠਾਂ ਅਰਥ',mode:'ਪੰਨਾ ਬਦਲਣ ਦਾ ਤਰੀਕਾ',scroll:'ਸਕ੍ਰੋਲ',page:'ਪੰਨਾ ਪਲਟੋ',font:'ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',spacing:'ਲਾਈਨਾਂ ਵਿਚਕਾਰ ਜਗ੍ਹਾ',theme:'ਰੰਗ',light:'ਹਲਕਾ',dark:'ਗੂੜ੍ਹਾ',
  reading:'ਪੜ੍ਹਨ ਦਾ ਤਰੀਕਾ',preferences:'ਤੁਹਾਡੀਆਂ ਸੈਟਿੰਗਾਂ ਇਸ ਫੋਨ ਵਿੱਚ ਸੇਵ ਰਹਿਣਗੀਆਂ।',
  update:'ਅੱਪਡੇਟ ਚੈੱਕ ਕਰੋ',backup:'ਬੈਕਅੱਪ',restore:'ਬੈਕਅੱਪ ਲਿਆਓ',
  daily:'ਰੋਜ਼ਾਨਾ ਗੁਰਬਾਣੀ',dailyTitle:'ਅੱਜ ਲਈ ਗੁਰਬਾਣੀ',dailyDesc:'ਤੁਹਾਡੀ ਆਪਣੀ ਰਫ਼ਤਾਰ ਨਾਲ ਪੜ੍ਹਨ ਲਈ',dailySetup:'ਰੋਜ਼ਾਨਾ ਪਾਠ ਸੈੱਟ ਕਰੋ',dailyPreview:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦਾ ਨਮੂਨਾ',dailyOpen:'ਅੱਜ ਦਾ ਪਾਠ ਖੋਲ੍ਹੋ',
  amount:'ਰੋਜ਼ ਕਿੰਨੇ ਅੰਗ?',order:'ਚੋਣ ਦਾ ਤਰੀਕਾ',sequential:'ਲੜੀਵਾਰ',random:'ਰੈਂਡਮ',source:'ਕਿਹੜਾ ਸਰੋਤ?',time:'ਸਮਾਂ',
  enable:'ਰੋਜ਼ਾਨਾ ਯਾਦ ਦਿਵਾਉਣਾ',savePlan:'ਪਲਾਨ ਸੇਵ ਕਰੋ',sendTest:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ',
  dailyLimit:'ਹੁਣ ਇਹ ਪਲਾਨ ਅਤੇ ਐਪ ਅੰਦਰਲਾ ਨਮੂਨਾ ਕੰਮ ਕਰਦੇ ਹਨ। ਐਪ ਬੰਦ ਹੋਣ ’ਤੇ ਹਰ ਰੋਜ਼ ਭਰੋਸੇਯੋਗ ਨੋਟੀਫਿਕੇਸ਼ਨ ਲਈ ਅਗਲੇ ਵਰਜ਼ਨ ਵਿੱਚ Android reminder ਜਾਂ push service ਜੋੜਨੀ ਪਵੇਗੀ।',
  notificationsUnsupported:'ਇਸ ਬ੍ਰਾਊਜ਼ਰ ਵਿੱਚ ਨੋਟੀਫਿਕੇਸ਼ਨ ਉਪਲਬਧ ਨਹੀਂ।',notificationDenied:'ਨੋਟੀਫਿਕੇਸ਼ਨ ਦੀ ਇਜਾਜ਼ਤ ਨਹੀਂ ਮਿਲੀ।',notificationSent:'ਟੈਸਟ ਨੋਟੀਫਿਕੇਸ਼ਨ ਭੇਜੀ ਗਈ।',
  planSaved:'ਤੁਹਾਡਾ ਪਲਾਨ ਸੇਵ ਹੋ ਗਿਆ।',preview:'ਨਮੂਨਾ · ਅਸਲ ਪਾਠ ਨਹੀਂ',
  pageHint:'ਸਵਾਈਪ ਕਰਕੇ ਪੰਨਾ ਬਦਲੋ',transNote:'ਅਰਥ ਸੌਖੀ ਵਿਆਖਿਆ ਦੇ ਨਮੂਨੇ ਹਨ; ਹਾਲੇ ਵਿਦਵਾਨਾਂ ਤੋਂ ਸਮੀਖਿਆ ਅਤੇ ਅਧਿਕਾਰਾਂ ਦੀ ਪੁਸ਼ਟੀ ਬਾਕੀ ਹੈ।',saved:'ਆਖ਼ਰੀ ਪੜ੍ਹੀ ਜਗ੍ਹਾ ਆਪਣੇ ਆਪ ਸੇਵ ਹੁੰਦੀ ਹੈ।'},
en:{home:'Home',read:'Read',search:'Search',ask:'Ask',settings:'Settings',menu:'Menu',readerSettings:'Reading settings',appearance:'Appearance',fontStyleLabel:'Font',serif:'Book',sans:'Clean',margins:'Page margins',narrow:'Narrow',normal:'Comfort',wide:'Wide',sepia:'Sepia',charcoal:'Charcoal',smallText:'Smaller text',largeText:'Larger text',updateCenter:'App updates',currentVersion:'Current version',updating:'Checking for a newer version…',upToDate:'You are using the latest published version.',updateAvailable:'A newer version is ready. Tap to update.',updateRequiresWeb:'Android APK updates are delivered through GitHub Releases.',updateFailed:'Could not check for updates. Check your connection.',updateReady:'Loading the updated app…',install:'Add to home screen',installHint:'You already have the Android app installed.',menuIntro:'Keep the same installed app and receive new versions without reinstalling.',menuBackups:'Your data',backupHint:'Your Sahaj Paath position, favourites and settings stay saved on this phone. Keep a backup for extra safety.',
  hero:'A calm place to reconnect with Gurbani',welcome:'Continue from where you left off',continue:'Continue Sehaj Paath',
  sample:'Scripture is bundled inside the app; no internet needed.',
  readerTitle:'Japji Sahib Ji',ang:'Ang',excerpt:'Selected lines',meanings:'Meanings',on:'On',off:'Off',meaning:'Meaning',
  audioPending:'Original human audio available in the player. Word timing is not yet verified.',wordPending:'Reviewed word meaning is not yet available.',
  start:'Read',next:'Next',prev:'Back',last:'The next Ang is not available in this trial.',
  library:'Scripture library',catalog:'Anek Baaniyaan',catalogSearch:'Search a Bani by name...',catalogNotice:'Available Sundar Gutka Banis are bundled offline. Some tradition-specific compositions are still outside this source.',catalogPending:'The verified full text for this Bani has not been added yet.',catalogSection1:'Baaniyaan from Sri Guru Granth Sahib Ji',catalogSection2:'Dasam Granth related compositions',catalogSection3:'Other recitations and variations',catalogSection4:'Bhai Gurdas Ji',catalogResults:'Baaniyaan',collection:'Other Banis',kirtan:'Kirtan Shabads',kirtanDesc:'Favourite Shabads to read again',
  kirtanNote:'This trial contains selected lines only; full Shabads will be included after content review.',
  fav:'Favourites',all:'All',onlyFav:'Favourites only',noFav:'No saved Shabads yet.',
  nitnem:'Nitnem',dasam:'Sri Dasam Granth Sahib',bhai:'Bhai Gurdas Ji',pending:'Full content will be added after text verification and the necessary permissions.',
  searchTitle:'Search Gurbani',searchHint:'Type or speak a word or line...',voicePending:'Voice search is unavailable here or needs an online speech service.',
  noResults:'No matching Gurbani line was found.',results:'Results',
  askTitle:'Ask Gurbani',askHint:'Ask any question...',askButton:'Ask',short:'Brief',detail:'Detailed',deep:'In depth',
  askNotLive:'Live AI is not connected yet. This is a conversation-design trial. Future answers will cite Sri Guru Granth Sahib Ji first, with Sri Dasam Granth and Bhai Gurdas Ji as relevant supporting sources.',askRules:'Real AI responses are not available in this version yet.',
  language:'App language',meanLang:'Meaning language',viewMeaning:'Meanings under each line',mode:'Page navigation',scroll:'Scroll',page:'Page Turn',font:'Font size',spacing:'Line spacing',theme:'Theme',light:'Light',dark:'Dark',
  reading:'Reading preferences',preferences:'Preferences are saved on this device.',update:'Check for updates',backup:'Export backup',restore:'Import backup',
  daily:'Daily Gurbani',dailyTitle:'Your Gurbani for today',dailyDesc:'A reading rhythm that feels right for you',dailySetup:'Set daily reading',dailyPreview:'Notification preview',dailyOpen:'Open today’s reading',
  amount:'Daily Ang goal',order:'Selection',sequential:'In order',random:'Random',source:'Starting collection',time:'Time',
  enable:'Daily reminder preference',savePlan:'Save reading plan',sendTest:'Test notification',
  dailyLimit:'Your plan and the in-app preview work now. Reliable daily delivery while the app is closed requires a future Android reminder feature or push service.',
  notificationsUnsupported:'Notifications are unavailable in this browser.',notificationDenied:'Notification permission was not granted.',notificationSent:'Test notification sent.',
  planSaved:'Your plan is saved.',preview:'Preview · not full scripture',pageHint:'Swipe to turn pages',transNote:'Meanings are illustrative paraphrases, not yet scholarly reviewed or licensed for release.',saved:'Your last reading position is saved automatically.'}}
txt.pa.readingScript='ਗੁਰਬਾਣੀ ਦੀ ਲਿਪੀ';txt.en.readingScript='Gurbani script';
txt.pa.roman='ਅੰਗਰੇਜ਼ੀ ਅੱਖਰ';txt.en.roman='English letters';
txt.pa.nitnemNote='ਨਿਤਨੇਮ ਦਾ ਪਾਠ ਐਪ ਵਿੱਚ ਆਫਲਾਈਨ ਹੈ।';txt.en.nitnemNote='Nitnem texts are included for offline reading.';
const t=k=>(txt[state.lang]||txt.pa)[k]||k;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const age=(k,en)=>state.lang==='pa'?k:en;
function persist(){try{localStorage.setItem(KEY,JSON.stringify(state))}catch{}}
function toast(msg){let x=$('toast');x.textContent=msg;x.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>x.classList.remove('show'),3400)}
function theme(){
 const html=document.documentElement;
 html.classList.toggle('dark',state.theme==='dark'||state.theme==='charcoal');
 html.dataset.tone=state.theme;html.dataset.lineLayout=state.lineLayout;html.dataset.font=state.fontStyle;html.dataset.margin=state.margin;html.dataset.raisedText=state.raisedHeadings?'on':'off';
 html.style.setProperty('--font',state.font+'px');
 html.style.setProperty('--ui-scale',state.uiScale);
 const ls={compact:[1.45,'0px'],standard:[1.65,'0px'],spacious:[1.85,'0px']}[state.lineLayout];
 html.style.setProperty('--leading',ls[0]);html.style.setProperty('--verse-gap',ls[1]);html.lang=state.lang;
 document.querySelector('meta[name=theme-color]')?.setAttribute('content',state.theme==='dark'||state.theme==='charcoal'?'#19221f':state.theme==='sepia'?'#f4eddf':'#fbfaf7');
}
function go(view,opts={}){if(view!=='home')homeEditing=false;if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();closeWord();const oldView=state.view;state.view=view;if(view==='reader'&&opts.reader)state.readView=opts.reader;if(oldView!==view&&!opts.noHistory){try{history.pushState({gsView:view},'',`#${view}`)}catch{}}persist();render();if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});}
function navReader(){state.readView='sggs';openAng(state.ang,true)}
function labelSource(src){return ({sggs:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),japji:age('ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ','Japji Sahib Ji'),dasam:t('dasam'),bhai:t('bhai')})[src]||src}
/* Consistent daily sample: a deterministic date-based excerpt, not a fake five-Ang pack. */
function dailyAngNumber(){
 const now=new Date(),key=`${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
 const origin=state.daily.startDate||key;
 const days=Math.max(0,Math.floor((Date.parse(key+'T12:00:00')-Date.parse(origin+'T12:00:00'))/86400000));
 if(state.daily.order==='random'){let n=0;for(const c of key)n=(n*31+c.charCodeAt(0))>>>0;return n%1430+1}
 return (days*Math.max(1,state.daily.amount)%1430)+1;
}
function dailyExcerpt(){return null} // Never display hard-coded sample Gurbani as today's actual source.
function dailyQuote(){return `<div id="dailyQuoteActual" class="daily-quote fine">${age('ਆਫਲਾਈਨ ਪਾਠ ਖੋਲ੍ਹ ਰਹੇ ਹਾਂ…','Loading the offline Ang…')}</div>`}
function render(){if(bookReader){bookReader.destroy();bookReader=null;}theme();document.documentElement.classList.toggle('home-open',state.view==='home');document.documentElement.classList.toggle('reading-open',state.view==='reader');$('brand').textContent='ਗੁਰਬਾਣੀ ਸਾਂਝ';$('labelHome').textContent=t('home');$('labelRead').textContent=t('read');$('labelSearch').textContent=t('search');$('labelBookmarks').textContent=age('ਸੰਭਾਲੇ','Saved');$('labelMenu').textContent=t('settings');$('settingsBtn').title=t('readerSettings');$('settingsBtn').style.visibility=state.view==='reader'?'visible':'hidden';$('backBtn').style.visibility=state.view==='home'?'hidden':'visible';
for(const v of ['home','reader','search','bookmarks','menu'])$('nav-'+v).classList.toggle('active',state.view===v);
const views={home:homeScreen,nitnem:nitnemScreen,reader:readerScreen,library:libraryScreen,catalog:catalogScreen,kirtan:kirtanScreen,search:searchScreen,ask:askScreen,bookmarks:bookmarksScreen,daily:dailyScreen,coming:comingScreen,menu:menuScreen};
$('main').innerHTML=(views[state.view]||homeScreen)();attach();
if(state.view==='reader'&&!activeRemote&&state.readView==='sggs'&&state.mode==='scroll'&&state.hasProgress){requestAnimationFrame(()=>{const node=document.querySelector(`[data-line="${Math.min(lines.length-1,state.verse)}"]`);if(node){const y=window.scrollY+node.getBoundingClientRect().top-73+state.verseOffset;window.scrollTo({top:Math.max(0,y),behavior:'instant'})}})}}
function homeCard(id){
 const icons={
 reader:'<path d="M12 6.5C9.6 4.6 6.7 4.1 3 4v15c3.7.1 6.6.8 9 2.3 2.4-1.5 5.3-2.2 9-2.3V4c-3.7.1-6.6.6-9 2.5Z"/><path d="M12 6.5v14.8"/>',
 nitnem:'<path d="M5 4.5h14v15H5z"/><path d="M9 2v5m6-5v5M5 10h14"/><path d="M9 14h2m2 0h2m-6 3h2"/>',
 catalog:'<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/>',
 kirtan:'<path d="M4 6a4 4 0 0 1 4-3h12v16H8a4 4 0 0 0-4 2Z"/><path d="M4 6v15M10 8h7M10 12h7"/>',
 ask:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>',
 daily:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41m11.32 11.32 1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41m11.32-11.32 1.41-1.41"/>'
 };
 const titles={reader:age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ','Sri Guru Granth Sahib Ji'),nitnem:t('nitnem'),catalog:t('catalog'),kirtan:t('kirtan'),ask:t('askTitle'),daily:t('daily')};
 const descriptions={reader:age('ਪੜ੍ਹਨ ਲਈ','For reading'),nitnem:age('ਨਿਤਨੇਮ ਪਾਠ','Daily prayers'),catalog:age('ਹੋਰ ਬਾਣੀਆਂ','Other Banis'),kirtan:age('ਕੇਵਲ ਪੜ੍ਹਨ ਲਈ','For reading only'),ask:age('ਸਵਾਲ ਅਤੇ ਵਿਆਖਿਆ','Questions & meaning'),daily:age('ਅੱਜ ਦਾ ਪਾਠ','Today’s reading')};
 return `<button type="button" class="feature home-tile tile-3d ${id==='ask'||id==='daily'?'tile-wide':''} ${id==='daily'?'tile-daily':''}" data-action="${id}" data-home-id="${id}" aria-label="${esc(titles[id])}" aria-grabbed="${homeEditing}"><span class="drag-handle" aria-hidden="true">⠿</span><span class="tile-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.55" stroke-linecap="round" stroke-linejoin="round">${icons[id]}</svg></span><strong>${titles[id]}</strong><span class="tile-foot"><small>${descriptions[id]}</small><span aria-hidden="true">›</span></span></button>`;
}
function homeScreen(){return `<div class="home home-v6 home-v7 home-v10 ${homeEditing?'home-editing':''}">
  <section class="premium-hero" aria-label="Gurbani Saanjh">
    <div class="hero-brand"><img src="icons/icon-192.png" alt="" class="hero-mark"><h1>ਗੁਰਬਾਣੀ ਸਾਂਝ</h1></div>
    <div class="hero-temple" role="img" aria-label="Sri Harmandir Sahib illustration"></div>
    <div class="home-lang-switch" role="group" aria-label="App language"><button data-action="lang-pa" class="${state.lang==='pa'?'sel':''}">ਪੰਜਾਬੀ</button><button data-action="lang-en" class="${state.lang==='en'?'sel':''}">English</button></div>
  </section>
  <button class="continue-card" data-action="continue"><span class="continue-icon" aria-hidden="true">↗</span><span class="continue-copy"><strong>${t('continue')}</strong><small>${age('ਸਹਿਜ ਪਾਠ · ਅੰਗ','Sahaj Paath · Ang')} ${state.ang}</small></span><span class="go" aria-hidden="true">›</span></button>
  <div class="section-head home-label"><span>${t('library')}</span><button class="text-link reorder-trigger" data-action="${homeEditing?'done-layout':'edit-layout'}">${homeEditing?age('ਹੋ ਗਿਆ','Done'):age('ਤਰਤੀਬ ਬਦਲੋ','Rearrange')}</button></div>
  ${homeEditing?`<div class="layout-edit-banner"><span>${age('ਕਿਸੇ ਕਾਰਡ ਨੂੰ ਫੜ ਕੇ ਨਵੀਂ ਜਗ੍ਹਾ ਲੈ ਜਾਓ।','Hold a card and move it to a new position.')}</span><button data-action="reset-layout">${age('ਮੂਲ ਤਰਤੀਬ','Reset')}</button></div>`:''}
  <div class="feature-grid home-grid home-drag-grid" id="homeDragGrid" aria-label="${age('ਘਰ ਦੇ ਕਾਰਡ','Home cards')}">${state.homeOrder.map(homeCard).join('')}</div>
  <p class="home-trial-label">${age('ਗੁਰਬਾਣੀ ਪੜ੍ਹਨਾ ਆਫਲਾਈਨ · AI ਲਈ ਇੰਟਰਨੈੱਟ ਲੋੜੀਂਦਾ ਹੋ ਸਕਦਾ ਹੈ','Offline Gurbani reading · Live AI may require internet')}</p>
 </div>`} 
function moveHomeCard(id,delta){const order=normalizeHomeOrder(state.homeOrder),from=order.indexOf(id),to=Math.max(0,Math.min(order.length-1,from+delta));if(to===from)return;order.splice(from,1);order.splice(to,0,id);state.homeOrder=order;persist();render();const node=document.querySelector(`[data-home-id="${id}"]`);node?.focus();}
function setupHomeDrag(){
 if(homeDragCleanup)homeDragCleanup();
 const grid=$('homeDragGrid');if(!grid)return;
 function stopPending(){if(homePending){clearTimeout(homePending.timer);homePending=null}}
 function beginDrag(info){
  if(!info)return;
  if(!homeEditing){homeEditing=true;render();}
  const list=$('homeDragGrid'),tile=[...list.querySelectorAll('[data-home-id]')].find(x=>x.dataset.homeId===info.id);
  if(!tile)return;
  const r=tile.getBoundingClientRect();
  const ghost=tile.cloneNode(true);ghost.classList.add('tile-drag-ghost');ghost.removeAttribute('id');
  ghost.style.width=r.width+'px';ghost.style.height=r.height+'px';
  ghost.style.left=r.left+'px';ghost.style.top=r.top+'px';
  document.body.appendChild(ghost);tile.classList.add('tile-placeholder');
  homeDrag={pointerId:info.pointerId,ghost,tile,list,dx:info.x-r.left,dy:info.y-r.top};
  lastHomeDragEnded=Date.now();
  if(navigator.vibrate)try{navigator.vibrate(18)}catch{}
 }
 grid.addEventListener('pointerdown',e=>{
  const tile=e.target.closest('[data-home-id]');if(!tile||e.button!==0)return;
  stopPending();homePending={id:tile.dataset.homeId,pointerId:e.pointerId,x:e.clientX,y:e.clientY};
  if(homeEditing){beginDrag(homePending);homePending=null;return}
  homePending.timer=setTimeout(()=>{const p=homePending;homePending=null;beginDrag(p)},460);
 });
 const onMove=e=>{
  if(homePending&&homePending.pointerId===e.pointerId){
   if(Math.hypot(e.clientX-homePending.x,e.clientY-homePending.y)>11)stopPending();
  }
  const d=homeDrag;if(!d||d.pointerId!==e.pointerId)return;
  if(e.cancelable)e.preventDefault();
  d.ghost.style.left=(e.clientX-d.dx)+'px';d.ghost.style.top=(e.clientY-d.dy)+'px';
  const el=document.elementFromPoint(e.clientX,e.clientY);
  const over=el?.closest?.('[data-home-id]');
  if(!over||over===d.tile||!d.list.contains(over))return;
  const from=[...d.list.children].indexOf(d.tile),to=[...d.list.children].indexOf(over);
  if(from<to)d.list.insertBefore(d.tile,over.nextSibling);else d.list.insertBefore(d.tile,over);
 };
 document.addEventListener('pointermove',onMove,{passive:false});
 function finishDrag(e){
  if(homePending&&(!e||homePending.pointerId===e.pointerId))stopPending();
  const d=homeDrag;if(!d||e&&d.pointerId!==e.pointerId)return;
  d.ghost.remove();d.tile.classList.remove('tile-placeholder');homeDrag=null;
  state.homeOrder=[...d.list.querySelectorAll('[data-home-id]')].map(n=>n.dataset.homeId);persist();
  lastHomeDragEnded=Date.now();render();
 }
 document.addEventListener('pointerup',finishDrag);
 document.addEventListener('pointercancel',finishDrag);
 grid.addEventListener('contextmenu',e=>{if(e.target.closest('[data-home-id]'))e.preventDefault()});
 homeDragCleanup=()=>{document.removeEventListener('pointermove',onMove);document.removeEventListener('pointerup',finishDrag);document.removeEventListener('pointercancel',finishDrag);stopPending();if(homeDrag){homeDrag.ghost.remove();homeDrag=null}};
}
const NITNEM_LIST=[['ਜਪੁਜੀ ਸਾਹਿਬ','Japji Sahib',2],['ਜਾਪੁ ਸਾਹਿਬ','Jaap Sahib',4],['ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ','Tav-Prasad Savaiye',6],['ਚੌਪਈ ਸਾਹਿਬ','Chaupai Sahib',9],['ਅਨੰਦੁ ਸਾਹਿਬ','Anand Sahib',10],['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',21],['ਕੀਰਤਨ ਸੋਹਿਲਾ','Kirtan Sohila',23]];
function nitnemScreen(){return `<section class="page nitnem-page"><h1>${t('nitnem')}</h1><p class="muted fine">${t('nitnemNote')}</p>${NITNEM_LIST.map(([pa,en,id])=>`<button class="catalog-row" data-remote-bani="${id}" data-bani-title="${esc(state.lang==='pa'?pa:en)}"><span>${state.lang==='pa'?pa:en}</span><span aria-hidden="true">›</span></button>`).join('')}<p class="fine muted">${age('ਨੋਟ: ਰਹਰਾਸਿ ਸਾਹਿਬ ਦਾ ਸਰੋਤ ਪਾਠ Damdami Taksal ਰੂਪ ਨਾਲ ਵੱਖਰਾ ਹੋ ਸਕਦਾ ਹੈ। ਵੱਖਰਾ ਪ੍ਰਮਾਣਿਤ ਰੂਪ ਬਾਅਦ ਵਿੱਚ ਜੋੜਾਂਗੇ।','Note: the source Rehras Sahib text may differ from the Damdami Taksal version. A separate verified edition remains to be added.')}</p></section>`}

// Complete texts are bundled at GitHub build time and loaded from the app itself.
// No MP3/AI pronunciation is bundled or requested in this reading-first release.
async function loadRemote(kind,id,title,preserveProgress=false){
  if(remoteBusy)return;
  remoteBusy=true;
  activeRemote={kind,id,title,loading:true,lines:[]};
  if(state.view!=='reader')go('reader');else render();
  try{
    const result=await window.GS_REMOTE.read(kind,id);
    if(!result.lines.length)throw new Error('Empty Bani text');
    activeRemote={kind,id,title,loading:false,lines:result.lines,offline:result.offline};
    if(kind==='ang'){state.ang=Number(id);if(!preserveProgress){state.verse=0;state.verseOffset=0}state.hasProgress=true;persist()}
  }catch(e){
    activeRemote={kind,id,title,loading:false,lines:[],error:String(e.message||e)};
  }finally{remoteBusy=false;if(state.view==='reader'){render();if(preserveProgress&&activeRemote?.lines?.length){const idx=Math.max(0,Math.min(state.verse,activeRemote.lines.length-1));const node=document.querySelector(`[data-line="${idx}"]`);node?.scrollIntoView({block:'start'});}else window.scrollTo({top:0,behavior:'instant'})}}
}
function openAng(n,preserveProgress=false){let num=Math.max(1,Math.min(1430,Number(n)||1));return loadRemote('ang',num,`${age('ਅੰਗ','Ang')} ${num}`,preserveProgress)}
function openBani(id,title){return loadRemote('bani',Number(id),title||'Bani')}
function normalizeBaniName(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[^\p{L}\p{N}]+/gu,'').replace(/sahib|ji|ਸਾਹਿਬ/gu,'')}
async function openCatalogBani(item){
 let id=null;
 if(!id){
  try{
   const list=onlineCatalog.length?onlineCatalog:await window.GS_REMOTE.list();
   onlineCatalog=list;
   const target=normalizeBaniName(item.titleEn);
   const match=list.find(x=>normalizeBaniName(x.titleEn)===target||normalizeBaniName(x.titlePa)===normalizeBaniName(item.titlePa));
   id=match?.id;
  }catch(e){console.warn('Bani index unavailable',e)}
 }
 if(!id){toast(age('ਇਸ ਬਾਣੀ ਦਾ ਪ੍ਰਮਾਣਿਤ ਪੂਰਾ ਪਾਠ ਇਸ ਸਰੋਤ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ।','A complete matching Bani was not found in this source.'));return}
 openBani(id,item[state.lang==='pa'?'titlePa':'titleEn']);
}
// Preserve individual pankti in both readers. A larger gap is reserved for an
// authentic numbered stanza/shabad ending, never randomly between every line.
function stanzaEnds(line){
 const text=String(line||'').trim();
 return /(?:॥|\|\|)\s*[੦-੯0-9]+\s*(?:॥|\|\|)\s*$/u.test(text)||/ਰਹਾਉ\s*(?:॥|\|\|)/u.test(text);
}
function lineHTML(v,idx,kind='sggs'){
 const roman=state.readingScript==='roman'&&v.roman;
 const original=String(v.g||'').trim().split(/\s+/),visible=String(roman?v.roman:v.g||'').trim().split(/\s+/);
 const rendered=visible.map((part,i)=>{
   const pause=state.vishraams && v.vishraam?.[i];
   const safePause=['short','long'].includes(pause)?pause:'';
   return `<button type="button" class="word ${safePause?'vishraam-'+safePause:''}" data-word="${esc(original[i]||part)}" data-kind="${kind}" data-idx="${idx}" data-widx="${i}" aria-label="${esc(part)}">${esc(part)}</button>`;
 }).join(' ');
 const variant=kind==='bani'?'gs-bani-pankti':'gs-sggs-pankti';
 const boundary=stanzaEnds(v.g)?' gs-stanza-end':'';
 const lineMeaning=state.meanings&&v[state.meaningLang]?`<div class="verse-meaning" lang="${state.meaningLang}">${esc(v[state.meaningLang])}</div>`:'';
 return `<div class="verse-block gs-pankti ${variant}${boundary}" data-line="${idx}"><div class="verse-text ${roman?'roman-text':''}" lang="${roman?'en':'pa'}">${rendered}</div>${lineMeaning}</div>`;
}
function readerScreen(){
 if(activeRemote){
  if(activeRemote.loading)return `<section class="reading reading-immersive"><p class="remote-state">${age('ਪਾਠ ਖੋਲ੍ਹ ਰਹੇ ਹਾਂ…','Loading scripture…')}</p></section>`;
  if(activeRemote.error)return `<section class="reading reading-immersive remote-error"><p>${age('ਇਹ ਪਾਠ ਐਪ ਦੀ ਆਫਲਾਈਨ ਲਾਇਬ੍ਰੇਰੀ ਵਿੱਚ ਨਹੀਂ ਮਿਲਿਆ। ਬਿਲਡ ਦੀ ਜਾਂਚ ਕਰੋ।','This text is not in the installed offline library. Check the build report.')}</p><button data-retry-remote="1" class="secondary">${age('ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼','Retry')}</button></section>`;
  const isSggs=activeRemote.kind==='ang';
  const sgAng=isSggs?Number(activeRemote.id):null;
  const references=[...new Set(activeRemote.lines.filter(l=>l.source==='G'&&Number.isInteger(Number(l.ang))&&Number(l.ang)>0).map(l=>Number(l.ang)))];
  const sourceLabel=isSggs?`${age('ਅੰਗ','Ang')} ${sgAng}`:references.length?`${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ — ਅੰਗ','Sri Guru Granth Sahib Ji — Ang')} ${references.length===1?references[0]:`${Math.min(...references)}–${Math.max(...references)}`}`:'';
  const head=`<div class="gs-reading-reference"><strong>${esc(isSggs?sourceLabel:activeRemote.title)}</strong>${!isSggs&&sourceLabel?`<small>${esc(sourceLabel)}</small>`:''}</div>`;
  return state.mode==='page'?`<section class="reading reading-immersive gs-book-reading ${isSggs?'gs-reader-sggs':'gs-reader-bani'}"><div class="gs-book-reference" aria-label="${esc(sourceLabel||activeRemote.title)}">${esc(sourceLabel||activeRemote.title)}</div><div class="gs-book-stage" id="bookStage" aria-label="${age('ਕਿਤਾਬ ਵਾਂਗ ਪਾਠ','Book-style scripture reading')}"></div></section>`:`<section class="reading reading-immersive ${isSggs?'gs-reader-sggs':'gs-reader-bani'}">${head}<div class="verse-list" id="verses">${activeRemote.lines.map((l,i)=>lineHTML(l,i,activeRemote.kind)).join('')}</div></section>`;
 }
 if(state.readView==='kirtan'){
  const item=CONTENT.kirtan.find(x=>x.id===state.kirtanId)||CONTENT.kirtan[0];
  return state.mode==='page'?`<section class="reading reading-immersive gs-book-reading"><div class="gs-book-stage" id="bookStage" aria-label="${age('ਕਿਤਾਬ ਵਾਂਗ ਪਾਠ','Book-style scripture reading')}"></div></section>`:`<section class="reading reading-immersive"><div class="verse-list">${item.lines.map((v,i)=>lineHTML(v,i,'kirtan')).join('')}</div></section>`;
 }
 return `<section class="reading reading-immersive remote-error"><p>${age('ਅੰਗ ਖੋਲ੍ਹਣ ਲਈ ਵਾਪਸ ਜਾਓ।','Go back to select an Ang.')}</p></section>`;
}
function libraryScreen(){return `<section class="page"><h1>${t('library')}</h1><div class="ang-picker"><strong>${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ — ਅੰਗ ੧–੧੪੩੦','Sri Guru Granth Sahib Ji — Ang 1–1430')}</strong><div class="ang-picker-controls"><input type="number" id="angPicker" min="1" max="1430" value="${state.ang}" aria-label="Ang number"><button data-open-ang="1" class="primary">${age('ਅੰਗ ਖੋਲ੍ਹੋ','Read Ang')}</button></div><p class="fine muted">${age('ਸਾਰੇ ੧੪੩੦ ਅੰਗ ਐਪ ਦੇ ਅੰਦਰ ਹਨ। ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਚਾਹੀਦਾ।','All 1,430 Angs are bundled inside the APK and work offline.')}</p></div>
${[['nitnem',t('nitnem')],['catalog',t('catalog')],['kirtan',t('kirtan')]].map(([a,name])=>`<button class="catalog-row" data-action="${a}"><span>${name}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}
function catalogScreen(){return `<section class="page catalog-page"><h1>${t('catalog')}</h1><p class="muted fine">${t('catalogNotice')}</p>
<label class="catalog-search-box"><span aria-hidden="true">⌕</span><input type="search" id="catalogSearch" autocomplete="off" placeholder="${t('catalogSearch')}" value="${esc(catalogFilter)}" aria-label="${t('catalogSearch')}"></label>
<div id="catalogResults">${catalogRows(catalogFilter)}</div></section>`}
function catalogRows(filter){const q=String(filter||'').trim().toLocaleLowerCase();const groups=[['sggs','catalogSection1'],['dasam','catalogSection2'],['tradition','catalogSection3'],['bhai','catalogSection4']];const count=CATALOG.filter(i=>!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))).length;
return `<div class="catalog-count">${count} ${t('catalogResults')}</div>`+groups.map(([g,header])=>{const items=CATALOG.filter(i=>i.group===g&&(!q||[i.titlePa,i.titleEn].some(v=>v.toLocaleLowerCase().includes(q))));if(!items.length)return '';return `<section class="catalog-section"><h2>${t(header)}</h2>${items.map(i=>`<button class="catalog-row" data-catalog-id="${i.id}"><span>${esc(i[state.lang==='pa'?'titlePa':'titleEn'])}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`}).join('')+(!onlineCatalog.length?`<section class="catalog-section"><h2>${age('ਸੁੰਦਰ ਗੁਟਕਾ — ਸੂਚੀ ਖੋਲ੍ਹ ਰਹੇ ਹਾਂ…','Sundar Gutka — opening offline index…')}</h2></section>`:(()=>{const remote=onlineCatalog.filter(v=>[v.titlePa,v.titleEn].some(t=>t&&t.toLowerCase().includes(q))).filter(v=>!CATALOG.some(c=>normalizeBaniName(c.titleEn)===normalizeBaniName(v.titleEn)));
return remote.length?`<section class="catalog-section"><h2>${age('ਸੁੰਦਰ ਗੁਟਕਾ — ਪੂਰੀ ਉਪਲਬਧ ਸੂਚੀ','Sundar Gutka — full available catalogue')} (${remote.length})</h2>${remote.map(v=>`<button class="catalog-row" data-remote-bani="${v.id}" data-bani-title="${esc(state.lang==='pa'?(v.titlePa||v.titleEn):v.titleEn)}"><span>${esc(state.lang==='pa'?(v.titlePa||v.titleEn):v.titleEn)}</span><span aria-hidden="true">›</span></button>`).join('')}</section>`:''})())}
function comingScreen(){return `<section class="page"><h1>${esc(state.comingTitle||t('collection'))}</h1><div class="simple-card"><p>${t('pending')}</p><p class="fine">${t('sample')}</p></div><button class="secondary full" data-action="library">← ${t('library')}</button></section>`}
function kirtanScreen(){
 const saved=state.savedVerses||[];
 const hasQuery=kirtanQuery.trim().length>0;
 return `<section class="page"><h1>${t('kirtan')}</h1><p class="muted fine">${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਵਿੱਚੋਂ ਸ਼ਬਦ ਖੋਜੋ, ਪੜ੍ਹੋ ਅਤੇ ਸੰਭਾਲੋ। ਕੇਵਲ ਪਾਠ, ਆਡੀਓ ਨਹੀਂ।','Find, read and save Shabads from Sri Guru Granth Sahib Ji. Text only, no audio.')}</p>
 <div class="inputrow"><span aria-hidden="true">⌕</span><input type="search" id="kirtanSearch" placeholder="${age('ਸ਼ਬਦ ਜਾਂ ਪਹਿਲੀ ਪੰਗਤੀ ਖੋਜੋ','Search a word or first line')}" value="${esc(kirtanQuery)}"></div>
 <div id="kirtanResults">${hasQuery?`<p class="fine">${age('ਪਾਠ ਵਿੱਚ ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching the offline text…')}</p>`:''}</div>
 <div class="section-head">${age('ਸੰਭਾਲੇ ਹੋਏ ਸ਼ਬਦ','Saved Shabads')} (${saved.length})</div>
 ${saved.length?saved.map(v=>`<div class="simple-card item-row"><button class="item-main" data-open-saved-ang="${Number(v.ang)}" data-open-saved-idx="${Number(v.idx)}"><strong lang="pa">${esc(v.g)}</strong><small>${t('ang')} ${Number(v.ang)}</small></button><button data-remove-saved="${Number(v.ang)}:${Number(v.idx)}" class="favorite selected" aria-label="Remove bookmark">♥</button></div>`).join(''):`<p class="fine muted">${age('ਖੋਜ ਨਤੀਜੇ ਵਿੱਚੋਂ ♡ ਦਬਾ ਕੇ ਸ਼ਬਦ ਸੰਭਾਲੋ।','Tap ♡ beside a search result to save it.')}</p>`}
 </section>`;
}
function bookmarksScreen(){return `<section class="page bookmarks-page"><h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1>${(state.savedVerses||[]).length?state.savedVerses.map(v=>`<button class="catalog-row" data-open-saved-ang="${v.ang}" data-open-saved-idx="${v.idx}"><span lang="pa">${esc(v.g)}</span><span>${age('ਅੰਗ','Ang')} ${v.ang} ›</span></button>`).join(''):`<p class="fine">${age('ਹਾਲੇ ਕੋਈ ਸ਼ਬਦ ਸੰਭਾਲਿਆ ਨਹੀਂ।','Nothing saved yet.')}</p>`}<button class="secondary full" data-action="kirtan">${t('kirtan')} ›</button></section>`}
function menuScreen(){
 return `<section class="page menu-page"><div class="settings-page-header"><h1>${t('settings')}</h1><p class="muted fine">ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}</p></div>

 <div class="menu-group-label">${t('reading')}</div>
 <button class="menu-item" data-action="menu-settings"><span class="menu-copy"><strong>${t('readerSettings')}</strong><small>${t('font')} · ${t('theme')} · ${t('mode')}</small></span><span class="menu-chevron">›</span></button>

 <button class="menu-item" data-action="daily"><span class="menu-copy"><strong>${t('dailySetup')}</strong><small>${t('dailyDesc')}</small></span><span class="menu-chevron">›</span></button>
 <button class="menu-item" data-action="reset-layout"><span class="menu-copy"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਦੀ ਤਰਤੀਬ ਰੀਸੈੱਟ','Reset home layout')}</strong><small>${age('ਕਾਰਡਾਂ ਨੂੰ ਮੂਲ ਜਗ੍ਹਾ ਵਾਪਸ ਲਿਆਓ','Restore the original card positions')}</small></span><span class="menu-chevron">›</span></button>
 <div class="menu-group-label">${t('updateCenter')}</div>
 <div class="menu-update-card"><div class="version-info"><div><span class="muted fine">${t('currentVersion')}</span><strong>v${APP_VERSION}</strong></div><span class="version-dot" aria-hidden="true"></span></div><p class="fine" id="updateStatus">${t('menuIntro')}</p><button class="primary full" data-action="check-update" id="checkUpdateButton">↻ ${t('update')}</button>${window.GS_NATIVE_UPDATES?.isNative?'':`<button class="secondary full install-button" data-action="install-app">${t('install')} ↗</button><p class="fine muted">${t('installHint')}</p>`}</div>
 <div class="menu-group-label">${t('menuBackups')}</div>
 <p class="fine muted">${t('backupHint')}</p><div class="menu-backup-row"><button class="secondary" data-action="backup-export">${t('backup')} ↓</button><button class="secondary" data-action="backup-import">${t('restore')} ↑</button></div>
 <input id="menuBackupInput" class="hidden" type="file" accept="application/json,.json">
 <p class="fine trial-menu-note">${age('ਕੁਝ ਬਾਣੀਆਂ ਲਈ ਸਰੋਤ ਪੂਰਾ ਪਾਠ ਮੁਹੱਈਆ ਨਹੀਂ ਕਰ ਸਕਦਾ; ਦਿਖਾਇਆ ਸਿਰਲੇਖ ਪੂਰਾ ਪਾਠ ਹੋਣ ਦਾ ਭਰੋਸਾ ਨਹੀਂ।','Some titles are not available as full text from the source. A listed title alone is not a complete Bani.')}</p></section>`;
}
let kirtanQuery='';
function scriptureResultsMarkup(arr,{save=false}={}){
 return arr.map(v=>`<div class="gs-result-row"><button class="result gs-result-open" data-found-ang="${v.ang}" data-found-idx="${v.idx}"><strong lang="pa">${esc(v.g)}</strong><small>${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ · ਅੰਗ','Sri Guru Granth Sahib Ji · Ang')} ${v.ang}</small></button>${save?`<button class="favorite" data-save-hit="${v.ang}:${v.idx}" aria-label="Save Shabad">${state.savedVerses.some(x=>x.ang===v.ang&&x.idx===v.idx)?'♥':'♡'}</button>`:''}</div>`).join('');
}
function searchScreen(){const modes=[['auto',age('ਸਭ','All')],['first',age('ਪਹਿਲੇ ਅੱਖਰ','First letters')],['any-first',age('ਵਿਚਕਾਰਲੇ ਅੱਖਰ','Letters anywhere')],['word',age('ਪੂਰਾ ਸ਼ਬਦ','Full word')],['roman',age('English ਅੱਖਰ','Romanised')],['ang',age('ਅੰਗ','Ang')]];
return `<section class="page"><h1>${t('searchTitle')}</h1><p class="muted fine">${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਵਿੱਚ ਗੁਰਮੁਖੀ, English ਅੱਖਰ ਜਾਂ ਪਹਿਲੇ ਅੱਖਰਾਂ ਨਾਲ ਲੱਭੋ।','Search Sri Guru Granth Sahib Ji by Gurmukhi, Romanisation or initials.')}</p><div class="inputrow"><span aria-hidden="true">⌕</span><input id="searchInput" type="search" autocomplete="off" placeholder="${t('searchHint')}"><button type="button" id="voiceBtn" aria-label="${age('ਬੋਲ ਕੇ ਖੋਜ','Voice search')}" title="${age('ਬੋਲ ਕੇ ਖੋਜ','Voice search')}">🎙</button></div><div class="gs-search-modes" role="group" aria-label="Search method">${modes.map(([v,label])=>`<button type="button" data-search-mode="${v}" class="${v===searchMode?'sel':''}">${label}</button>`).join('')}</div><p id="voiceStatus" role="status" class="fine muted"></p><div id="searchResults"></div></section>`}

function askScreen(){return `<section class="page ask"><h1>${t('askTitle')}</h1><p class="fine">${age('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਤੋਂ ਹਵਾਲਿਆਂ ਸਮੇਤ ਖੋਜ। AI ਜਵਾਬ ਲਈ ਆਪਣਾ ਸੁਰੱਖਿਅਤ ਸਰਵਰ ਜੋੜੋ।','Find relevant Gurbani passages with Ang citations. Connect a secure server for full AI answers.')}</p>
 <textarea id="questionInput" placeholder="${t('askHint')}"></textarea><div class="answer-pills">${[['short','short'],['detail','detail'],['deep','deep']].map(([k,name])=>`<button data-depth="${k}" class="${state.depth===k?'sel':''}">${t(name)}</button>`).join('')}</div>
 <button id="askButton" class="primary full" style="margin-top:14px">${t('askButton')}</button><div id="conversation">${state.questions.map(v=>`<div class="simple-card"><strong>${esc(v.q)}</strong>${v.answer?`<p class="ai-answer">${esc(v.answer)}</p>`:''}${v.matches?.length?`<div class="ai-sources">${scriptureResultsMarkup(v.matches)}</div>`:`<p class="fine">${age('ਇਸ ਸਵਾਲ ਨਾਲ ਸਬੰਧਤ ਕੋਈ ਹਵਾਲਾ ਨਹੀਂ ਮਿਲਿਆ।','No matching passage was retrieved for this question.')}</p>`}${!v.answer?`<p class="fine muted">${age('AI ਵਿਆਖਿਆ ਲਈ ਸਰਵਰ ਕਨੈਕਟ ਕਰਨਾ ਬਾਕੀ ਹੈ। ਸਿਰਫ਼ ਅਸਲੀ ਹਵਾਲੇ ਦਿਖਾਏ ਗਏ ਹਨ।','AI interpretation is not connected. Only source-text matches are shown.')}</p>`:''}</div>`).join('')}</div>
 <p class="fine muted">${age('AI ਦੀ ਵਿਆਖਿਆ ਨੂੰ ਮੂਲ ਗੁਰਬਾਣੀ ਤੋਂ ਵੱਖਰਾ ਰੱਖਿਆ ਜਾਂਦਾ ਹੈ।','AI interpretation is always distinct from original Gurbani.')}</p></section>`}
function dailyScreen(){const c=state.daily;const opts=(val,items,attr)=>`<div class="choice">${items.map(([k,label])=>`<button data-daily="${attr}" data-value="${k}" class="${String(val)===String(k)?'sel':''}">${label}</button>`).join('')}</div>`;
return `<section class="page"><h1>${t('dailySetup')}</h1><p class="muted fine">${t('dailyDesc')}</p><div class="setting-row"><div><strong>${t('source')}</strong></div><select id="dailySource" aria-label="${t('source')}">${['sggs','japji'].map(s=>`<option value="${s}" ${s===c.source?'selected':''}>${labelSource(s)}</option>`).join('')}</select></div>
<div class="setting-row"><strong>${t('order')}</strong>${opts(c.order,[['sequential',t('sequential')],['random',t('random')]],'order')}</div>
<div class="setting-row"><strong>${t('amount')}</strong>${opts(c.amount,[[1,'1'],[2,'2'],[5,'5']],'amount')}</div>
<div class="setting-row"><strong>${t('time')}</strong><input id="dailyTime" type="time" value="${esc(c.time)}"></div>
<div class="setting-row"><strong>${t('enable')}</strong>${opts(!!c.enabled,[[false,t('off')],[true,t('on')]],'enabled')}</div>
<button class="primary full" data-action="save-daily" style="margin-top:19px">${t('savePlan')}</button>
<div class="section-head">${t('dailyPreview')}</div><div class="daily-preview"><div class="eyebrow">ਗੁਰਬਾਣੀ ਸਾਂਝ</div><h2>${t('dailyTitle')}</h2><p>${labelSource(c.source)} · ${c.amount} ${age('ਅੰਗ','Ang')} · ${c.order==='random'?t('random'):t('sequential')}</p>${dailyQuote()}<button class="secondary" data-action="daily-open">${t('dailyOpen')} →</button></div>
<button class="secondary full" data-action="test-notification">${t('sendTest')}</button><p class="notice">${t('dailyLimit')} ${t('sample')}</p></section>`}
function settingsHTML(){
 const choice=(key,options)=>`<div class="choice">${options.map(([v,name])=>`<button data-setting="${key}" data-value="${v}" class="${String(state[key])===String(v)?'sel':''}">${name}</button>`).join('')}</div>`;
 const themes=[['light',t('light'),'#ffffff'],['sepia',t('sepia'),'#f4ead6'],['dark',t('dark'),'#1b2822'],['charcoal',t('charcoal'),'#303438']];
 return `<div class="settings-preview"><div class="settings-caption">${t('appearance')}</div><div class="theme-choice">${themes.map(([value,label,color])=>`<button data-setting="theme" data-value="${value}" class="theme-swatch ${state.theme===value?'sel':''}" aria-pressed="${state.theme===value}"><span class="tone-dot" style="background:${color}"></span><span>${label}</span></button>`).join('')}</div></div>
 <div class="setting-section">${t('font')}</div>
 <div class="settings-control-block"><div class="settings-control-head"><strong>${t('font')}</strong>${choice('fontStyle',[['serif',t('serif')],['sans',t('sans')]])}</div>
 <div class="settings-control-head"><strong>${t('font')}</strong><span class="desc" id="fontValue">${state.font}px</span></div>
 <div class="slider-row"><button id="fontMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="18" max="40" step="1" value="${state.font}" id="fontSlider" aria-label="${t('font')}"><button id="fontPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('ਮੁੱਖ ਪੰਨੇ ਅਤੇ ਮੀਨੂ ਦੇ ਅੱਖਰ','Home & menu font size')}</strong><span class="desc" id="uiScaleValue">${Math.round(state.uiScale*100)}%</span></div>
 <div class="slider-row"><button id="uiMinus" class="adjust" aria-label="${t('smallText')}">A−</button><input type="range" min="1" max="1.35" step="0.05" value="${state.uiScale}" id="uiSlider" aria-label="${age('ਮੁੱਖ ਪੰਨੇ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ','Home text size')}"><button id="uiPlus" class="adjust" aria-label="${t('largeText')}">A+</button></div>
 <div class="settings-control-head"><strong>${age('3D ਮੀਨੂ ਅੱਖਰ','3D menu text')}</strong>${choice('raisedHeadings',[['true',t('on')],['false',t('off')]])}</div>
 <div class="settings-control-head line-layout-choice"><strong>${t('spacing')}</strong>${choice('lineLayout',[['compact',age('ਘੱਟ','Compact')],['standard',age('ਆਮ','Standard')],['spacious',age('ਵੱਧ','Spacious')]])}</div>
 <div class="settings-control-head"><strong>${t('margins')}</strong>${choice('margin',[['narrow',t('narrow')],['normal',t('normal')],['wide',t('wide')]])}</div></div>
 <div class="setting-section">${t('reading')}</div>
 <div class="setting-row"><strong>${t('mode')}</strong>${choice('mode',[['scroll',t('scroll')],['page',t('page')]])}</div>
 <div class="setting-row"><strong>${age('ਪੰਨਾ ਪਲਟਣ ਦੀ ਰਫ਼ਤਾਰ','Page turning speed')}</strong>${choice('pageTurnSpeed',[['slow',age('ਹੌਲੀ','Slow')],['normal',age('ਆਮ','Normal')],['fast',age('ਤੇਜ਼','Fast')]])}</div>
 <div class="setting-row"><strong>${age('ਵਿਸਰਾਮ','Vishraam')}</strong>${choice('vishraams',[['true',t('on')],['false',t('off')]])}</div>
 <p class="vishraam-settings-legend" aria-label="${age('ਵਿਸਰਾਮ ਦੇ ਰੰਗ','Vishraam colour legend')}"><span class="vishraam-legend-item"><span class="vishraam-swatch short">ਸੋਚੈ</span> ${age('ਛੋਟਾ ਵਿਸਰਾਮ','Short pause')}</span><span class="vishraam-legend-item"><span class="vishraam-swatch long">ਹੋਵਈ</span> ${age('ਲੰਮਾ ਵਿਸਰਾਮ','Long pause')}</span></p>
 <p class="vishraam-settings-note">${age('ਚਾਲੂ ਹੋਣ ’ਤੇ ਸਿਰਫ਼ ਜਾਂਚੇ ਗਏ ਵਿਸਰਾਮ ਵਾਲੇ ਸ਼ਬਦ ਰੰਗੀਨ ਹੋਣਗੇ। ਬੰਦ ਕਰਨ ’ਤੇ ਸਾਰੇ ਸ਼ਬਦ ਆਮ ਰੰਗ ਵਿੱਚ ਦਿਖਣਗੇ। ਇਹ ਸੰਕੇਤ ਅਸਲੀ ਗੁਰਬਾਣੀ ਦਾ ਹਿੱਸਾ ਨਹੀਂ ਹਨ।','When enabled, only reviewed test pause words are coloured. Turn off to display all words in the normal text colour. These are reading aids, not part of the original Gurbani.')}</p>
 <div class="setting-row"><strong>${t('viewMeaning')}</strong>${choice('meanings',[['false',t('off')],['true',t('on')]])}</div>
 <div class="setting-row"><strong>${t('readingScript')}</strong>${choice('readingScript',[['gurmukhi','ਗੁਰਮੁਖੀ'],['roman','English letters']])}</div>
 <div class="setting-row"><strong>${t('meanLang')}</strong>${choice('meaningLang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <div class="setting-row"><strong>${t('language')}</strong>${choice('lang',[['pa','ਪੰਜਾਬੀ'],['en','English']])}</div>
 <div class="setting-row"><div><strong>${age('AI ਸਰਵਰ URL (ਵਿਕਲਪਿਕ)','AI server URL (optional)')}</strong><span class="desc">${age('ਸੁਰੱਖਿਅਤ HTTPS ਸਰਵਰ ਦੀ ਲਿੰਕ; API ਕੁੰਜੀ ਨਹੀਂ','HTTPS server URL only; never enter an API key')}</span></div><input type="url" id="aiEndpointInput" placeholder="https://…/ask" value="${esc(state.aiEndpoint||'')}" style="max-width:50%;min-width:130px"></div>
 <div class="setting-row"><div><strong>${age('AI access code','AI access code')}</strong><span class="desc">${age('ਕੇਵਲ ਆਪਣੇ ਨਿੱਜੀ AI ਸਰਵਰ ਲਈ','Only for your private AI server')}</span></div><input id="aiAccessInput" type="password" autocomplete="off" placeholder="Access code" value="${esc(state.aiAccessToken||'')}" style="max-width:50%;min-width:130px"></div>
 <p class="fine muted settings-footer">${t('preferences')}</p>`;
}
function openSettings(){closeWord();$('settingsTitle').textContent=t('readerSettings');$('sheetBody').innerHTML=settingsHTML();$('sheetOverlay').classList.remove('hidden')}
function closeSettings(){$('sheetOverlay').classList.add('hidden')}
let focusedWord='', wordRequest=0, wordContext=null, wordOrigin=null;
function closeWord(){
 wordRequest++;
 const pop=$('wordPopup');pop.classList.add('hidden');pop.innerHTML='';
 if(wordOrigin){wordOrigin.removeAttribute('aria-expanded');wordOrigin=null}
}
function openWord(el){
 const clean=String(el.dataset.word||'').replace(/[॥।੦-੯,;!?]+/gu,'').trim().normalize('NFC');
 if(!clean)return;
 if(wordOrigin===el&&!$('wordPopup').classList.contains('hidden')){closeWord();return}
 closeWord();focusedWord=clean;wordOrigin=el;wordOrigin.setAttribute('aria-expanded','true');
 const kind=el.dataset.kind,idx=Number(el.dataset.idx);
 wordContext=kind==='kirtan'?(CONTENT.kirtan.find(x=>x.id===state.kirtanId)?.lines||[])[idx]:activeRemote?.lines?.[idx];
 const pop=$('wordPopup');const rect=el.getBoundingClientRect();
 pop.innerHTML=`<div class="gs-word-popup-head"><strong class="popup-title" lang="pa">${esc(clean)}</strong><button type="button" class="gs-word-close" data-close-word="1" aria-label="${age('ਬੰਦ ਕਰੋ','Close')}">×</button></div><div class="popup-note" id="wordNote" role="status">${age('ਅਰਥ ਲੱਭ ਰਹੇ ਹਾਂ…','Finding meaning…')}</div>`;
 pop.classList.remove('hidden');
 const width=Math.min(342,window.innerWidth-24);
 pop.style.width=width+'px';
 const left=Math.max(12,Math.min(window.innerWidth-width-12,rect.left+rect.width/2-width/2));
 const height=180;
 const top=rect.bottom+12+height>window.innerHeight?Math.max(12,rect.top-height-12):rect.bottom+12;
 pop.style.left=left+'px';pop.style.top=top+'px';
 pop.style.setProperty('--arrow-left',Math.max(14,Math.min(width-20,rect.left+rect.width/2-left))+'px');
 showWordNote();
}
async function showWordNote(){
 const box=$('wordNote');if(!box)return;
 const request=++wordRequest,current=focusedWord;
 const local=words[current]?.[state.meaningLang];
 if(local){box.innerHTML=`<p lang="${state.meaningLang}">${esc(local)}</p>`;return}
 // Show accurate *line context* immediately, even when offline dictionary is
 // unavailable or slow. This is distinct from a word definition.
 const explanation=wordContext?.[state.meaningLang];
 if(explanation)box.innerHTML=`<small>${age('ਇਸ ਪੰਗਤੀ ਦਾ ਭਾਵ (ਸ਼ਬਦ ਦਾ ਵੱਖਰਾ ਅਰਥ ਨਹੀਂ)','Meaning of the full line (not a word definition)')}</small><p lang="${state.meaningLang}">${esc(explanation)}</p>`;
 let result={definitions:[]};
 try{result=await window.GS_KOSH?.lookup(current,state.meaningLang) || result}catch{}
 if(request!==wordRequest||$('wordPopup').classList.contains('hidden'))return;
 const definitions=(result.definitions||[]).filter(d=>d.meaning);
 if(definitions.length){
  box.innerHTML=definitions.slice(0,3).map(d=>`<p lang="${state.meaningLang}">${esc(d.meaning)}</p>`).join('')+`<small>${result.source==='basic-gloss'?age('ਸਧਾਰਨ ਸ਼ਬਦੀ ਅਰਥ; ਪ੍ਰਸੰਗ ਵੀ ਦੇਖੋ','Basic gloss; consult the full context'):age('ਸਰੋਤ: ਬਾਣੀ ਡੀਬੀ ਕੋਸ਼','Source: BaniDB Kosh')}</small>`;
  return;
 }
 // The meaning of an entire pankti is *not* incorrectly presented as a
 // dictionary definition of the single selected word.
 if(explanation){box.innerHTML=`<small>${age('ਇਸ ਪੰਗਤੀ ਦਾ ਭਾਵ (ਸ਼ਬਦ ਦਾ ਵੱਖਰਾ ਅਰਥ ਨਹੀਂ)','Meaning of the full line (not a word definition)')}</small><p lang="${state.meaningLang}">${esc(explanation)}</p>`;return}
 box.textContent=age('ਇਸ ਸ਼ਬਦ ਦਾ ਕੋਸ਼ੀ ਅਰਥ ਹਾਲੇ ਉਪਲਬਧ ਨਹੀਂ।','A dictionary definition for this word is not yet available.');
}

let searchSeq=0;
let searchMode='auto';
let searchVoiceBusy=false;
async function showOfflineResults(q,target='searchResults',save=false){
 const id=++searchSeq;const out=$(target);if(!out)return;
 if(!q.trim()){out.innerHTML='';return}
 out.innerHTML=`<p class="fine">${age('ਪਾਠ ਵਿੱਚ ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching the offline library…')}</p>`;
 try{
  const matches=await window.GS_SCRIPTURE_SEARCH.query(q,40,target==='searchResults'?searchMode:'auto');
  if(id!==searchSeq||!$(target))return;
  $(target).innerHTML=matches.length?scriptureResultsMarkup(matches,{save}):`<p class="empty">${t('noResults')}</p>`;
 }catch(e){if($(target))$(target).innerHTML=`<p class="notice">${age('ਆਫਲਾਈਨ ਖੋਜ ਸੂਚੀ ਨਹੀਂ ਮਿਲੀ। APK ਦਾ ਬਿਲਡ ਜਾਂਚੋ।','Offline search index missing. Verify the APK build.')}</p>`;console.warn(e)}
}
async function answerQuestion(){
 const field=$('questionInput'),q=field?.value.trim();if(!q){toast(age('ਸਵਾਲ ਲਿਖੋ','Enter a question'));return}
 const btn=$('askButton');if(btn){btn.disabled=true;btn.textContent=age('ਖੋਜ ਹੋ ਰਹੀ ਹੈ…','Searching…')}
 try{
  const matches=await window.GS_SCRIPTURE_SEARCH.query(q,Math.min(state.depth==='short'?3:state.depth==='detail'?7:12,12));
  let answer='';
  const endpoint=String(state.aiEndpoint||window.GS_BUILD?.aiEndpoint||'').trim();
  if(endpoint && /^https:\/\//.test(endpoint) && matches.length){
    try{
      const res=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','Authorization':state.aiAccessToken?'Bearer '+state.aiAccessToken:''},body:JSON.stringify({question:q,depth:state.depth,language:state.lang,verses:matches})});
      if(!res.ok)throw Error('AI service returned '+res.status);
      const data=await res.json();answer=typeof data.answer==='string'?data.answer.slice(0,12000):'';
    }catch(e){toast(age('AI ਸਰਵਰ ਨਹੀਂ ਜੁੜ ਸਕਿਆ; ਅਸਲੀ ਹਵਾਲੇ ਦਿਖਾਏ ਗਏ ਹਨ।','AI server unavailable. Showing original references.'));console.warn(e)}
  }
  state.questions.push({q,depth:state.depth,answer,matches:matches.map(({ang,idx,g})=>({ang,idx,g}))});state.questions=state.questions.slice(-12);persist();render();
 }catch(e){toast(age('ਆਫਲਾਈਨ ਡਾਟਾ ਨਹੀਂ ਮਿਲਿਆ','Offline scripture index missing'));console.warn(e)}
 finally{if($('askButton')){$('askButton').disabled=false;$('askButton').textContent=t('askButton')}}
}
function capture(){if(state.view!=='reader'||(activeRemote&&activeRemote.kind!=='ang')||state.readView!=='sggs'||state.mode!=='scroll')return;let el=[...document.querySelectorAll('.verse-block')].find(n=>n.getBoundingClientRect().bottom>72);if(el){state.verse=Number(el.dataset.line)||0;state.verseOffset=Math.max(0,Math.round(73-el.getBoundingClientRect().top));state.hasProgress=true;persist()}}
function turn(dir){state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,state.page+dir));state.verse=PAGE_GROUPS[state.page][0];state.verseOffset=0;state.hasProgress=true;persist();render();window.scrollTo({top:0,behavior:'instant'});if(dir>0&&state.page===PAGE_GROUPS.length-1){} }
function readKirtan(id){state.kirtanId=id;state.readView='kirtan';go('reader');window.scrollTo({top:0,behavior:'instant'})}
function toggleMeaning(){if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();state.meanings=!state.meanings;persist();render()}
function action(a){switch(a){case'edit-layout':homeEditing=true;render();break;case'done-layout':homeEditing=false;persist();render();break;case'reset-layout':state.homeOrder=[...HOME_IDS];persist();render();toast(age('ਮੂਲ ਤਰਤੀਬ ਵਾਪਸ ਆ ਗਈ','Default layout restored'));break;case'continue':case'reader':navReader();break;case'library':go('library');break;case'catalog':go('catalog');break;case'kirtan':go('kirtan');break;case'ask':go('ask');break;case'daily':go('daily');break;case'daily-open':openAng(dailyAngNumber());break;case'toggle-meaning':toggleMeaning();break;case'prev':turn(-1);break;case'next':turn(1);break;
case'lang-pa':state.lang='pa';persist();render();break;
case'lang-en':state.lang='en';persist();render();break;
case'script-gurmukhi':state.readingScript='gurmukhi';persist();render();break;
case'script-roman':state.readingScript='roman';persist();render();break;
case'open-japji':openBani(2,age('ਜਪੁਜੀ ਸਾਹਿਬ','Japji Sahib'));break;
case'bani-pending':toast(age('ਪੂਰੇ ਪ੍ਰਮਾਣਿਤ ਪਾਠ ਦੀ ਜਾਂਚ ਬਾਕੀ ਹੈ।','Full text is pending verification.'));break;
case'nitnem':go('nitnem');break;case'dasam':case'bhai':state.comingTitle=a==='nitnem'?t('nitnem'):a==='dasam'?t('dasam'):t('bhai');go('coming');break;
case'save-daily':if(!state.daily.startDate)state.daily.startDate=new Date().toISOString().slice(0,10);persist();toast(t('planSaved'));render();break;
case'test-notification':testNotification();break;
case'open-daily':closeSettings();go('daily');break;case'menu-settings':openSettings();break;case'check-update':checkUpdate();break;case'install-app':installApp();break;case'backup-export':exportBackup();break;case'backup-import':$('menuBackupInput')?.click();break;default:break}}
async function testNotification(){if(!('Notification' in window)){toast(t('notificationsUnsupported'));return}let permission=Notification.permission;try{if(permission==='default')permission=await Notification.requestPermission();if(permission!=='granted'){toast(t('notificationDenied'));return}const sample=dailyExcerpt();const body=sample?`${sample.g} · ${sample[state.meaningLang].slice(0,70)}`:`${labelSource(state.daily.source)} · ${state.daily.amount} ${age('ਅੰਗ','Ang')}`;if('serviceWorker' in navigator&&location.protocol.startsWith('http')){const reg=await navigator.serviceWorker.ready;await reg.showNotification('ਗੁਰਬਾਣੀ ਸਾਂਝ',{body,icon:'icons/icon-192.png',tag:'gurbani-saanjh-demo',data:{url:'./'}})}else new Notification('ਗੁਰਬਾਣੀ ਸਾਂਝ',{body});toast(t('notificationSent'))}catch(e){toast(t('notificationsUnsupported'));console.warn(e)}}
function updateStatus(message){const x=$('updateStatus');if(x)x.textContent=message;}
async function checkUpdate(){
 if(window.GS_NATIVE_UPDATES?.isNative){
   await window.GS_NATIVE_UPDATES.check((message)=>updateStatus(message),state.lang);
   return;
 }
 if(!navigator.onLine){updateStatus(age('ਇੰਟਰਨੈੱਟ ਨਹੀਂ ਹੈ','You are offline'));return;}
 if(!/^https?:$/.test(location.protocol)){updateStatus(t('updateRequiresWeb'));return;}
 updateStatus(t('updating'));
 try{
  const res=await fetch('./version.json?check='+Date.now(),{cache:'no-store'});
  if(!res.ok)throw Error('Version manifest not available');
  const incoming=await res.json();
  if(!/^\d+\.\d+\.\d+$/.test(incoming.version))throw Error('Invalid version');
  const [a,b,c]=incoming.version.split('.').map(Number);const [x,y,z]=APP_VERSION.split('.').map(Number);
  const newer=a>x||(a===x&&(b>y||(b===y&&c>z)));
  if(!newer){updateStatus(t('upToDate'));toast(t('upToDate'));return;}
  updateStatus(`${t('updateAvailable')} v${incoming.version}`);
  let btn=$('checkUpdateButton');if(btn)btn.textContent=t('update')+' · v'+incoming.version;
  if(state.view==='reader')capture();
  const reg=await navigator.serviceWorker?.getRegistration();
  if(!reg){updateStatus(t('updateRequiresWeb'));return;}
  isApplyingUpdate=true;
  await reg.update();
  if(reg.waiting)reg.waiting.postMessage({type:'SKIP_WAITING'});
  updateStatus(t('updateReady'));
  // Browser update lifecycle can take a moment. We wait for the new worker to control this page.
  setTimeout(()=>{if(isApplyingUpdate)location.reload()},2000);
 }catch(e){console.warn('Update check:',e);updateStatus(t('updateFailed'))}
}
async function installApp(){
 if(installPrompt){try{installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;}catch(e){console.warn(e)}return;}
 toast(t('installHint'));
}
function exportBackup(){const blob=new Blob([JSON.stringify({app:'Gurbani Saanjh',version:APP_VERSION,exported:new Date().toISOString(),state},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='gurbani-saanjh-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000)}
async function importBackup(file){try{const obj=JSON.parse(await file.text());if(obj.app!=='Gurbani Saanjh'||!obj.state||typeof obj.state!=='object')throw Error('Invalid backup');const permitted=['lang','meaningLang','readingScript','meanings','theme','mode','font','uiScale','raisedHeadings','spacing','lineLayout','bookCursors','pageTurnSpeed','savedVerses','aiEndpoint','ang','fontStyle','margin','readView','verse','verseOffset','page','hasProgress','kirtanId','favorites','homeOrder','depth','daily','questions'];for(const k of permitted)if(k in obj.state)state[k]=obj.state[k];state.daily={...BASE.daily,...state.daily};state.lang=state.lang==='en'?'en':'pa';state.meaningLang=state.meaningLang==='en'?'en':'pa';state.readingScript=state.readingScript==='roman'?'roman':'gurmukhi';state.uiScale=Math.min(1.35,Math.max(1,Number(state.uiScale)||1.12));state.raisedHeadings=state.raisedHeadings!==false;state.page=Math.max(0,Math.min(PAGE_GROUPS.length-1,Number(state.page)||0));state.homeOrder=normalizeHomeOrder(state.homeOrder);persist();closeSettings();render();toast(age('ਬੈਕਅੱਪ ਲਿਆ ਗਿਆ','Backup restored'))}catch(e){toast(age('ਬੈਕਅੱਪ ਫਾਈਲ ਸਹੀ ਨਹੀਂ','Invalid backup file'))}}
async function startVoiceSearch(input){
 if(searchVoiceBusy)return;searchVoiceBusy=true;
 const status=$('voiceStatus');const btn=$('voiceBtn');if(btn)btn.disabled=true;
 const msg=(pa,en)=>{if(status)status.textContent=age(pa,en)};
 msg('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');
 const fill=spoken=>{if(!spoken)return;input.value=spoken;showOfflineResults(spoken);msg('ਪਛਾਣੇ ਹੋਏ ਸ਼ਬਦ ਵੇਖੋ ਅਤੇ ਲੋੜ ਹੋਵੇ ਤਾਂ ਠੀਕ ਕਰੋ।','Review recognised words and correct them if needed.')};
 try{
  const native=window.GS_SPEECH;
  if(window.GS_NATIVE_UPDATES?.isNative&&native){
   const avail=await native.available();if(!avail.available)throw Error('native recognition unavailable');
   const p=await native.checkPermissions();if(p.speechRecognition!=='granted'){const next=await native.requestPermissions();if(next.speechRecognition!=='granted')throw Error('microphone permission denied')}
   const res=await native.start({language:'pa-IN',maxResults:4,partialResults:false,popup:true});
   fill(res.matches?.[0]||'');return;
  }
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)throw Error('Browser has no speech recognizer');
  await new Promise((resolve,reject)=>{let rec=new SR();rec.lang='pa-IN';rec.maxAlternatives=4;rec.onresult=e=>{fill(e.results[0][0].transcript);resolve()};rec.onerror=e=>reject(new Error(e.error||'recognition failed'));rec.onend=resolve;rec.start()});
 }catch(e){msg('ਇਸ ਫੋਨ ਉੱਤੇ ਆਵਾਜ਼ ਦੀ ਪਛਾਣ ਨਹੀਂ ਚੱਲੀ। ਲਿਖ ਕੇ ਖੋਜ ਸਕਦੇ ਹੋ।','Voice recognition unavailable. Typed search still works.');console.warn('voice search',e)}
 finally{searchVoiceBusy=false;if(btn)btn.disabled=false}
}
function attach(){
 if(state.view==='daily'){
   const requested=state.daily.source==='japji'?{kind:'bani',id:2}:{kind:'ang',id:dailyAngNumber()};
   window.GS_REMOTE.read(requested.kind,requested.id).then(data=>{
     const el=$('dailyQuoteActual');if(!el||state.view!=='daily')return;
     const picked=data.lines.slice(0,Math.max(1,Math.min(5,Number(state.daily.amount)||2)));
     el.innerHTML=picked.map(x=>`<p lang="pa">${esc(x.g)}</p>${state.meanings?`<p class="daily-meaning">${esc(x[state.meaningLang]||'')}</p>`:''}`).join('');
   }).catch(()=>{const el=$('dailyQuoteActual');if(el)el.textContent=age('ਆਫਲਾਈਨ ਪਾਠ ਨਹੀਂ ਮਿਲਿਆ।','Offline text was not found.')});
 }
 if(state.view==='home')setupHomeDrag();else if(homeDragCleanup){homeDragCleanup();homeDragCleanup=null;}if(state.view==='catalog'){const input=$('catalogSearch');if(input)input.addEventListener('input',()=>{catalogFilter=input.value;$('catalogResults').innerHTML=catalogRows(catalogFilter)});
  if(!onlineCatalog.length)window.GS_REMOTE.list().then(list=>{onlineCatalog=list;if(state.view==='catalog'&&$('catalogResults'))$('catalogResults').innerHTML=catalogRows(catalogFilter)}).catch(e=>{console.warn('Offline Bani index could not load',e);if(state.view==='catalog'&&$('catalogResults'))$('catalogResults').querySelector('.catalog-section:last-child h2')?.replaceChildren(document.createTextNode(age('ਆਫਲਾਈਨ ਸੂਚੀ ਨਹੀਂ ਮਿਲੀ','Offline index missing')))});
 }if(state.view==='kirtan'){const input=$('kirtanSearch');if(input){input.addEventListener('input',()=>{kirtanQuery=input.value;showOfflineResults(kirtanQuery,'kirtanResults',true)});if(kirtanQuery)showOfflineResults(kirtanQuery,'kirtanResults',true)}}
if(state.view==='search'){const input=$('searchInput');input.addEventListener('input',()=>showOfflineResults(input.value));$('voiceBtn').onclick=()=>startVoiceSearch(input);
 document.querySelectorAll('[data-search-mode]').forEach(b=>b.addEventListener('click',()=>{searchMode=b.dataset.searchMode;document.querySelectorAll('[data-search-mode]').forEach(x=>x.classList.toggle('sel',x===b));if(input.value.trim())showOfflineResults(input.value)}));}
if(state.view==='reader'&&state.mode==='scroll'&&activeRemote?.kind==='ang'){
  const el=$('verses');let touch=null;
  el?.addEventListener('touchstart',e=>{touch={x:e.changedTouches[0].clientX,y:e.changedTouches[0].clientY}},{passive:true});
  el?.addEventListener('touchend',e=>{if(!touch)return;let dx=e.changedTouches[0].clientX-touch.x,dy=e.changedTouches[0].clientY-touch.y;if(Math.abs(dx)>95&&Math.abs(dx)>Math.abs(dy)*1.75)openAng(state.ang+(dx<0?1:-1));touch=null},{passive:true});
 }
if(state.view==='reader'&&state.mode==='page'){
 const stage=$('bookStage');
 if(stage&&window.GS_PAGE_TURN){
  const source=activeRemote?.lines?.length?activeRemote.lines:(state.readView==='kirtan'?(CONTENT.kirtan.find(x=>x.id===state.kirtanId)||CONTENT.kirtan[0]).lines:[]);
  const kind=activeRemote?.kind||'kirtan';
  const key=activeRemote?`${activeRemote.kind}:${activeRemote.id}`:`kirtan:${state.kirtanId}`;
  const oldCursor=state.bookCursors[key]||{verse:activeRemote?.kind==='ang'?state.verse:0,word:0};
  bookReader=window.GS_PAGE_TURN.mount(stage,{
   lines:source,kind,lang:state.lang,meaningLang:state.meaningLang,readingScript:state.readingScript,
   meanings:state.meanings,vishraams:state.vishraams,cursor:oldCursor,pageTurnSpeed:state.pageTurnSpeed,
   onChange(cursor,index,pages){
    state.bookCursors[key]=cursor;
    if(kind==='ang'){state.verse=cursor.verse;state.verseOffset=0;state.hasProgress=true;}
    persist();
   },
   onEdge(dir){
    if(kind==='ang'&&activeRemote&&((dir>0&&state.ang<1430)||(dir<0&&state.ang>1))){const target=state.ang+dir;if(dir<0)state.bookCursors[`ang:${target}`]={verse:Number.MAX_SAFE_INTEGER,word:0};else if(!state.bookCursors[`ang:${target}`])state.bookCursors[`ang:${target}`]={verse:0,word:0};persist();openAng(target,false);}
   }
  });
 }
}
}
function bindGlobals(){
$('nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b){if(b.dataset.view==='reader')navReader();else go(b.dataset.view)}});
$('backBtn').onclick=()=>{if(state.view==='reader'&&state.readView==='kirtan')go('kirtan');else go('home')};$('settingsBtn').onclick=openSettings;$('closeSheet').onclick=closeSettings;
$('sheetOverlay').addEventListener('click',e=>{if(e.target===$('sheetOverlay'))closeSettings()});
$('main').addEventListener('click',e=>{
 const found=e.target.closest('[data-found-ang],[data-open-saved-ang]');if(found){state.verse=Number(found.dataset.foundIdx||found.dataset.openSavedIdx)||0;state.verseOffset=0;state.hasProgress=true;openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true);return}
 const save=e.target.closest('[data-save-hit],[data-remove-saved]');if(save){const parts=String(save.dataset.saveHit||save.dataset.removeSaved).split(':').map(Number);const [ang,idx]=parts;const exists=state.savedVerses.find(v=>v.ang===ang&&v.idx===idx);if(exists)state.savedVerses=state.savedVerses.filter(v=>v!==exists);else{const match=window.GS_SCRIPTURE_SEARCH?.lookup(ang,idx);if(match)state.savedVerses.unshift({ang,idx,g:match.g})}persist();render();return}
 const b=e.target.closest('[data-remote-bani]');if(b){openBani(b.dataset.remoteBani,b.dataset.baniTitle);return}const ab=e.target.closest('[data-open-ang]');if(ab){openAng($('angPicker')?.value||state.ang);return}const retry=e.target.closest('[data-retry-remote]');if(retry&&activeRemote){loadRemote(activeRemote.kind,activeRemote.id,activeRemote.title);return}if(e.target.closest('[data-home-id]')&&(homeEditing||Date.now()-lastHomeDragEnded<600)){e.preventDefault();e.stopPropagation();return;}const act=e.target.closest('[data-action]');if(act){action(act.dataset.action);return}const word=e.target.closest('[data-word]');if(word){e.stopPropagation();openWord(word);return}const fav=e.target.closest('[data-favorite]');if(fav){let id=fav.dataset.favorite;state.favorites=state.favorites.includes(id)?state.favorites.filter(x=>x!==id):[...state.favorites,id];persist();render();return}const k=e.target.closest('[data-kirtan]');if(k){readKirtan(k.dataset.kirtan);return}const selectedBani=e.target.closest('[data-catalog-id]');if(selectedBani){const item=CATALOG.find(x=>x.id===selectedBani.dataset.catalogId);if(item)openCatalogBani(item);return}const filter=e.target.closest('[data-filter]');if(filter){state.filter=filter.dataset.filter;persist();render();return}const result=e.target.closest('[data-search-kind]');if(result){let kind=result.dataset.searchKind;if(kind==='sggs'){state.verse=Number(result.dataset.searchIdx);state.page=PAGE_GROUPS.findIndex(g=>g.includes(state.verse));state.verseOffset=0;state.hasProgress=true;navReader()}else readKirtan(kind);return}const depth=e.target.closest('[data-depth]');if(depth){state.depth=depth.dataset.depth;persist();document.querySelectorAll('[data-depth]').forEach(b=>b.classList.toggle('sel',b.dataset.depth===state.depth));return}const day=e.target.closest('[data-daily]');if(day){let key=day.dataset.daily,v=day.dataset.value;state.daily[key]=key==='amount'?Number(v):key==='enabled'?v==='true':v;persist();render();return}});
$('main').addEventListener('change',e=>{if(e.target.id==='dailySource'){state.daily.source=e.target.value;persist();render()}if(e.target.id==='dailyTime'){state.daily.time=e.target.value;persist()}});
$('main').addEventListener('click',e=>{if(e.target.closest('#askButton'))answerQuestion()});
// Tap a word: show its meaning immediately. Scroll gestures never activate a button click.
$('wordPopup').addEventListener('click',e=>{if(e.target.closest('[data-close-word]')){e.preventDefault();closeWord()}});
document.addEventListener('pointerdown',e=>{
 if(!$('wordPopup').classList.contains('hidden')&&!e.target.closest('#wordPopup')&&!e.target.closest('[data-word]'))closeWord();
},{passive:true});
document.addEventListener('click',e=>{
 if(!$('wordPopup').classList.contains('hidden')&&!e.target.closest('[data-word]')&&!e.target.closest('#wordPopup'))closeWord();
});
$('sheetBody').addEventListener('click',e=>{let setting=e.target.closest('[data-setting]');if(setting){const prop=setting.dataset.setting,val=setting.dataset.value;if(state.view==='reader'&&state.mode==='scroll')capture();state[prop]=(prop==='meanings'||prop==='raisedHeadings'||prop==='vishraams')?val==='true':val;if(prop==='mode'){state.verseOffset=0}persist();$('sheetBody').innerHTML=settingsHTML();$('settingsTitle').textContent=t('readerSettings');render();return}let act=e.target.closest('[data-action]');if(act){action(act.dataset.action);return}let button=e.target.closest('[data-settings-action]');if(button){const a=button.dataset.settingsAction;if(a==='export')exportBackup();if(a==='import')$('backupInput').click();if(a==='update')checkUpdate()}});
$('sheetBody').addEventListener('click',e=>{const u=e.target.closest('#uiMinus,#uiPlus');if(!u)return;state.uiScale=Math.min(1.35,Math.max(1,Math.round((state.uiScale+(u.id==='uiPlus'?.05:-.05))*100)/100));$('uiSlider').value=state.uiScale;$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();});
$('sheetBody').addEventListener('click',e=>{const plus=e.target.closest('#fontPlus,#fontMinus');if(!plus)return;state.font=Math.min(40,Math.max(18,state.font+(plus.id==='fontPlus'?1:-1)));$('fontSlider').value=state.font;$('fontValue').textContent=state.font+'px';theme();persist()});
$('sheetBody').addEventListener('input',e=>{if(e.target.id==='uiSlider'){state.uiScale=Number(e.target.value);$('uiScaleValue').textContent=Math.round(state.uiScale*100)+'%';theme();persist();}if(e.target.id==='fontSlider'){state.font=Number(e.target.value);$('fontValue').textContent=state.font+'px';theme();persist()}});
$('sheetBody').addEventListener('change',e=>{if(e.target.id==='aiAccessInput'){state.aiAccessToken=e.target.value;persist()}if(e.target.id==='aiEndpointInput'){const url=e.target.value.trim();if(!url||/^https:\/\//.test(url)){state.aiEndpoint=url;persist()}else toast('HTTPS URL only')}if(e.target.id==='backupInput'&&e.target.files?.[0])importBackup(e.target.files[0])});
$('main').addEventListener('change',e=>{if(e.target.id==='menuBackupInput'&&e.target.files?.[0])importBackup(e.target.files[0])});
let scrollTimer;window.addEventListener('scroll',()=>{if(!$('wordPopup').classList.contains('hidden'))closeWord();if(state.view!=='reader'||state.mode!=='scroll'||state.readView!=='sggs')return;clearTimeout(scrollTimer);scrollTimer=setTimeout(capture,130)},{passive:true});
window.addEventListener('pagehide',capture);document.addEventListener('visibilitychange',()=>{if(document.visibilityState==='hidden')capture()});
window.addEventListener('popstate',e=>{if(state.view==='reader'&&state.readView==='sggs'&&state.mode==='scroll')capture();closeWord();closeSettings();state.view=(e.state?.gsView)||'home';render();if(state.view!=='reader')window.scrollTo(0,0)});
// Capacitor's App plugin forwards the Samsung system Back button to web history.
try{window.Capacitor?.Plugins?.App?.addListener('backButton',()=>{
  if(!$('sheetOverlay').classList.contains('hidden')){closeSettings();return}
  if(!$('wordPopup').classList.contains('hidden')){closeWord();return}
  if(state.view!=='home')window.history.back();
})}catch(e){console.warn('Native back handler unavailable',e)}
document.addEventListener('keydown',e=>{const homeCard=e.target.closest?.('[data-home-id]');if(state.view==='home'&&homeCard&&homeEditing&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();moveHomeCard(homeCard.dataset.homeId,['ArrowLeft','ArrowUp'].includes(e.key)?-1:1);return;}if(state.view==='home'&&homeCard&&!homeEditing&&e.key===' '){e.preventDefault();homeEditing=true;render();document.querySelector(`[data-home-id="${homeCard.dataset.homeId}"]`)?.focus();return;}if(e.key==='Escape'){closeWord();closeSettings()}if(state.view==='reader'&&state.mode==='page'&&!e.target.matches('input,textarea')){if(e.key==='ArrowRight')bookReader?.navigate(1);if(e.key==='ArrowLeft')bookReader?.navigate(-1)}});
}
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;});
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator){navigator.serviceWorker.addEventListener('controllerchange',()=>{if(isApplyingUpdate){isApplyingUpdate=false;location.reload()}})}
bindGlobals();render();
if(!window.GS_NATIVE_UPDATES?.isNative && 'serviceWorker' in navigator&&location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js',{updateViaCache:'none'}).catch(console.warn));
})();
