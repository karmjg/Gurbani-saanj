#!/usr/bin/env python3
"""Fix v312 (app v2.2.92) — 2 changes vs v2.2.91 (GSv311), the 'light fix'
for the Vaaran scrolling the user reported 2026-11-23 ('not smooth
scrolling compared to others', 'sometimes it stuck', 'if I scroll fast
why its not letting me scroll it fast'). He approved this light fix
('Ok') over page numbers — keep the one long scroll, do not paginate.
Mockup: none needed (no visible UI change).

Root cause (measured here): Bhai Gurdas Ji di Vaaran is 7,226 lines
against ~400 for other Banis — 1,707 verse blocks, 55,104 tappable
word buttons, ~8 MB of HTML drawn at once. Two things make it stick:
(1) the phone draws all 55,000 words at once, even far off screen, so
a fast fling cannot keep up; (2) after every scroll, captureAnchor()
scans ALL 1,707 blocks one by one with getBoundingClientRect() to find
the top line — deep in the Vaaran that scan blocks the main thread and
the page freezes for a moment.

1) Skip drawing off-screen verse blocks (CSS only). Add
   content-visibility:auto + contain-intrinsic-size to .verse-block,
   so the browser only lays out and paints blocks near the viewport.
   Same text, same layout, same tap-a-word — the browser just does far
   less work while scrolling. Short readers are unaffected (their
   blocks are all on screen anyway).
2) Find the top line directly instead of scanning. captureAnchor()
   now uses document.elementFromPoint(centre, 73) + .closest(
   '.verse-block') — one hit-test instead of up to 1,707
   getBoundingClientRect() calls. Same result (the first block that
   extends below y=72), same readerAnchor/readerAnchorTop values, so
   the re-render anchor restore (v2.2.55) works exactly as before.
   capture() (SGGS Ang only, ~20 blocks) is left untouched.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP = ROOT / "www" / "app.js"
CSS = ROOT / "www" / "styles.css"


def replace(path, old, new, note):
    s = path.read_text(encoding="utf-8")
    if old not in s:
        print(f"FAIL: not found in {path.name}: {note}")
        sys.exit(1)
    if s.count(old) != 1:
        print(f"FAIL: {s.count(old)} matches in {path.name}: {note}")
        sys.exit(1)
    path.write_text(s.replace(old, new), encoding="utf-8")
    print(f"ok: {note}")


# ---- 1) content-visibility on .verse-block ---------------------------
replace(
    CSS,
    ".verse-block{margin:0 0 var(--verse-gap,0px)}",
    ".verse-block{margin:0 0 var(--verse-gap,0px)}\n"
    "/* v2.2.92: long readers (Vaaran) — skip drawing off-screen verse\n"
    "   blocks so scrolling stays smooth; the browser only lays out and\n"
    "   paints blocks near the viewport. contain-intrinsic-size keeps the\n"
    "   scrollbar steady (auto = remember the measured size). */\n"
    ".verse-block{content-visibility:auto;contain-intrinsic-size:auto 120px}",
    "content-visibility on .verse-block",
)

# ---- 2) captureAnchor: elementFromPoint instead of the linear scan ---
old_anchor = """function captureAnchor(){
  if(state.view!=='reader'||!activeRemote?.lines?.length)return;
  const el=[...document.querySelectorAll('.verse-block')].find(n=>n.getBoundingClientRect().bottom>72);
  if(!el)return;
  readerAnchor=Number(el.dataset.line)||0;
  readerAnchorTop=el.getBoundingClientRect().top;
}"""
new_anchor = """// v2.2.92: find the top line with one hit-test instead of scanning all
// verse blocks — the old [...querySelectorAll('.verse-block')].find(...)
// called getBoundingClientRect() up to 1,707 times (Vaaran) after every
// scroll, blocking the main thread and freezing the page. Same result:
// the block at y=73 is the first one extending below y=72.
function captureAnchor(){
  if(state.view!=='reader'||!activeRemote?.lines?.length)return;
  const hit=document.elementFromPoint(window.innerWidth/2,73);
  const el=hit?hit.closest('.verse-block'):null;
  if(!el)return;
  readerAnchor=Number(el.dataset.line)||0;
  readerAnchorTop=el.getBoundingClientRect().top;
}"""
replace(APP, old_anchor, new_anchor, "captureAnchor uses elementFromPoint")

print("fix-v312 done")
