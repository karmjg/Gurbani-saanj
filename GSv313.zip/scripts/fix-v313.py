#!/usr/bin/env python3
"""v2.2.93 (GSv313) — Save a page. His request, mockup mockup_save_page.png
(v4, star final) approved, his go 2026-11-23 14:43, star confirmed
2026-11-23 14:45 ('star is much better').

Design (his confirmed words): tapping the star ONLY saves — it does NOT
move him, he stays on the same page; the saved page only shows when he
goes to the Saved tab; tap the star once = saved (solid star), tap it
again on the same page = unsaved (outline star, removed from the list).
Heart = save a shabad, star = save a page — two different things, two
different marks, no confusion.

Changes (all in www/app.js unless noted):
1. state.savedPages: [] — one entry per (kind, id): {kind, id, line,
   title, sub}. Persisted by the existing persist() (whole state).
2. Star button in the reader top bar beside Aa, in ALL THREE top-bar
   variants (Ang, Bani, Kirtan) — savePageStarBtn().
3. toggleSavePage(): refreshes the anchor (captureAnchor) so the saved
   line is the line actually on screen, toggles the entry, persists, and
   updates the star IN PLACE — never full-renders, so the reader does
   not move (same stay-put pattern as the saved-verse heart, v2.2.63).
4. Saved tab (bookmarksScreen): a 'Saved Pages' section at the top
   (savedPagesSection) — tap a row to open that Ang/Bani/Kirtan at the
   saved line (highlightLine + scroll-to-centre, reusing the saved-verse
   open path), red x on each row to remove it.
5. action() switch: case 'toggle-save-page'.
6. www/styles.css: .save-page-star (gold when saved) + .remove-saved-page
   (red x).
Nothing else changes: the mic, the Ask page, the Vaaran smooth-scroll
fix (v2.2.92), the Kirtan short-reading bars (v2.2.91) and the saved
shabads (heart) are untouched.
"""
import pathlib, re, sys

root = pathlib.Path(__file__).resolve().parents[1]
app = root / "www" / "app.js"
css = root / "www" / "styles.css"
src = app.read_text(encoding="utf-8")
css_src = css.read_text(encoding="utf-8")


def rep(old, new, count=1):
    global src
    n = src.count(old)
    assert n >= count, f"anchor not found ({n}x): {old[:90]!r}"
    src = src.replace(old, new, count)


# ---- 1. state: savedPages in BASE + the stored-state construction ----
rep("const BASE={savedVerses:[],",
    "const BASE={savedVerses:[],savedPages:[],")
rep("savedVerses:Array.isArray(stored.savedVerses)?stored.savedVerses:[],",
    "savedVerses:Array.isArray(stored.savedVerses)?stored.savedVerses:[],savedPages:Array.isArray(stored.savedPages)?stored.savedPages:[],")

# ---- 2. helpers + Saved-pages section, before bookmarksScreen() ----
helpers = '''
/* v2.2.93: Save a page (reading position). Star in the reader top bar
   beside Aa. Heart = save a shabad, star = save a page — two different
   things, two different marks, no confusion. One saved page per
   (kind, id). Tapping the star only saves/unsaves; it never moves the
   reader. The saved page only shows in the Saved tab. */
function isPageSaved(kind,id){return (state.savedPages||[]).some(p=>p.kind===kind&&p.id===id)}
function savePageStarBtn(){
  const saved=activeRemote&&activeRemote.kind!=null&&activeRemote.id!=null?isPageSaved(activeRemote.kind,Number(activeRemote.id)):false;
  return `<button type="button" class="icon-button save-page-star${saved?' saved':''}" data-action="toggle-save-page" aria-label="${age('ਪੰਨਾ ਸੰਭਾਲੋ','Save this page')}" title="${age('ਪੰਨਾ ਸੰਭਾਲੋ','Save this page')}">${saved?'★':'☆'}</button>`;
}
function pageTitleSub(kind,id,line){
  const lines=activeRemote?.lines||[];
  const g=String(lines[line]?.g||lines[0]?.g||'').replace(/\\s+/g,' ').trim();
  if(kind==='ang')return{title:'Ang '+id,sub:g?g.slice(0,60):''};
  if(kind==='kirtan'){const m=activeRemote?.meta||{};return{title:m.firstLine||activeRemote?.title||'Shabad',sub:m.ang?('Ang '+m.ang):(g?g.slice(0,60):'')}}
  return{title:activeRemote?.title||'Bani',sub:g?g.slice(0,60):''};
}
function toggleSavePage(el){
  if(!activeRemote||!activeRemote.kind||activeRemote.id==null||!activeRemote.lines?.length)return;
  const kind=activeRemote.kind,id=Number(activeRemote.id);
  captureAnchor();
  const line=Math.max(0,Math.min(readerAnchor>=0?readerAnchor:(kind==='ang'?(state.verse||0):0),activeRemote.lines.length-1));
  const idx=(state.savedPages||[]).findIndex(p=>p.kind===kind&&p.id===id);
  if(idx>=0)state.savedPages.splice(idx,1);
  else{const t=pageTitleSub(kind,id,line);state.savedPages.unshift({kind,id,line,title:t.title,sub:t.sub});}
  persist();
  // Stay put: update the star in place, never full-render — a full render
  // would re-scroll the reader. Same stay-put pattern as the saved-verse
  // heart (v2.2.63).
  const saved=isPageSaved(kind,id);
  const btn=el||document.querySelector('[data-action="toggle-save-page"]');
  if(btn){btn.textContent=saved?'★':'☆';btn.classList.toggle('saved',saved);}
}
function savedPagesSection(){
  const pages=state.savedPages||[];
  const pa=s=>/[\\u0A00-\\u0A7F]/.test(s||'')?' lang="pa"':'';
  const head=`<div class="section-head">${age('ਸੰਭਾਲੇ ਪੰਨੇ','Saved Pages')} (${pages.length})</div>`;
  if(!pages.length)return head+`<p class="fine muted">${age('ਤਾਰਾ ਦਬਾ ਕੇ ਪੰਨਾ ਸੰਭਾਲੋ।','Tap the star to save a page.')}</p>`;
  return head+pages.map(p=>`<div class="simple-card item-row"><button class="item-main" data-open-saved-page="${p.kind}:${p.id}:${Number(p.line)||0}"${p.kind==='bani'?` data-bani-title="${esc(p.title||'')}"`:''}><strong${pa(p.title)}>${esc(p.title)}</strong><small${pa(p.sub)}>${esc(p.sub||'')}</small></button><button data-remove-saved-page="${p.kind}:${p.id}" class="favorite remove-saved-page" aria-label="Remove saved page">×</button></div>`).join('');
}
function bookmarksScreen(){'''
rep("function bookmarksScreen(){", helpers)

# ---- 3. star button in all three top-bar variants ----
n = src.count('<span class="gs-reading-actions">')
assert n == 3, f"expected 3 top-bar actions spans, found {n}"
src = src.replace('<span class="gs-reading-actions">',
                  '<span class="gs-reading-actions">${savePageStarBtn()}', 3)

# ---- 4. action() switch ----
rep(" case'toggle-drawer':state.baniDrawer=!state.baniDrawer;persist();render();break;",
    " case'toggle-drawer':state.baniDrawer=!state.baniDrawer;persist();render();break;\n  case'toggle-save-page':toggleSavePage(el);break;")

# ---- 5. Saved tab: Saved Pages section at the top ----
rep("<h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1>${(state.savedVerses",
    "<h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1>${savedPagesSection()}${(state.savedVerses")

# ---- 6. click handlers: open a saved page / remove a saved page ----
anchor = " const foundBani=e.target.closest('[data-found-bani],[data-open-saved-bani]');if(foundBani){stopVoiceSearch();highlightLine=Number(foundBani.dataset.foundIdx||foundBani.dataset.openSavedIdx)||0;if(foundBani.dataset.foundBani){lastOpenedKey=`bani:${foundBani.dataset.foundBani}:${highlightLine}`;lastOpenedQuery=lastSearchQuery;}openBani(Number(foundBani.dataset.foundBani||foundBani.dataset.openSavedBani),foundBani.dataset.baniTitle||'Bani',true);return}\n"
assert anchor in src, "foundBani handler anchor not found"
handlers = anchor + (
    " const sp=e.target.closest('[data-open-saved-page]');if(sp){const parts=String(sp.dataset.openSavedPage).split(':');const kind=parts[0];const id=Number(parts[1])||0;highlightLine=Number(parts[2])||0;stopVoiceSearch();if(kind==='ang')openAng(id,true);else if(kind==='bani')openBani(id,sp.dataset.baniTitle||'Bani',true);else if(kind==='kirtan')openKirtanShabad(id);return}\n"
    " const rsp=e.target.closest('[data-remove-saved-page]');if(rsp){const parts=String(rsp.dataset.removeSavedPage).split(':');const kind=parts[0];const id=Number(parts[1])||0;state.savedPages=(state.savedPages||[]).filter(p=>!(p.kind===kind&&p.id===id));persist();render();return}\n"
)
src = src.replace(anchor, handlers, 1)

app.write_text(src, encoding="utf-8")

# ---- 7. styles.css: star + red delete cross ----
css_anchor = "html.reading-open.gs-short-reading .reading{padding-bottom:calc(110px + env(safe-area-inset-bottom))}\n"
assert css_anchor in css_src, "short-reading css anchor not found"
css_new = css_anchor + (
    "/* v2.2.93: save-a-page star in the reader top bar (gold when saved,\n"
    "   like the heart) and the red delete cross on a saved-page row. */\n"
    ".save-page-star{font-size:22px;line-height:1}\n"
    ".save-page-star.saved{color:#ba7e38}\n"
    ".remove-saved-page{color:#c0392b}\n"
)
css_src = css_src.replace(css_anchor, css_new, 1)
css.write_text(css_src, encoding="utf-8")

print("fix-v313 applied: savedPages state, star button x3, toggleSavePage, Saved Pages section, open/remove handlers, css")
