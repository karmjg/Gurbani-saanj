/* v2.2.92 test - 2 changes vs v2.2.91 (GSv311), the 'light fix' for the
 * Vaaran scrolling the user reported 2026-11-23 ('not smooth scrolling
 * compared to others', 'sometimes it stuck', 'if I scroll fast why its
 * not letting me scroll it fast'). He approved this light fix ('Ok')
 * over page numbers — keep the one long scroll, do not paginate.
 *
 * Root cause (measured): the Vaaran is 7,226 lines — 1,707 verse blocks,
 * 55,104 tappable word buttons, ~8 MB of HTML drawn at once.
 * Change 1 - Skip drawing off-screen verse blocks: .verse-block gets
 * content-visibility:auto + contain-intrinsic-size:auto 120px, so the
 * browser only lays out and paints blocks near the viewport. Same text,
 * same layout, same tap-a-word; short readers are unaffected.
 * Change 2 - captureAnchor() finds the top line with one hit-test
 * (document.elementFromPoint + .closest('.verse-block')) instead of
 * scanning all 1,707 blocks with getBoundingClientRect() after every
 * scroll. Same result (the first block extending below y=72), same
 * readerAnchor/readerAnchorTop values, so the re-render anchor restore
 * (v2.2.55) works exactly as before. capture() (SGGS Ang only, ~20
 * blocks) is left untouched.
 *
 * The proofs below run the REAL captureAnchor() from the shipped app.js
 * in a VM (mocked DOM) and check the shipped styles.css.
 * Negative control: the same checks run against /tmp/v311-check
 * (pristine v2.2.91, extracted from GSv311.zip) and must show the OLD
 * behaviour (no content-visibility, old linear scan in captureAnchor).
 * Run: node test-v312.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB = '/tmp/v311-check/www';
const rbApp = fs.readFileSync(path.join(RB, 'app.js'), 'utf8');
const rbCss = fs.readFileSync(path.join(RB, 'styles.css'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: version ----------
{
  const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
  ok('package.json version is 2.2.92', pj.version === '2.2.92', `got ${pj.version}`);
  const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
  ok('version.json is 2.2.92', vj.version === '2.2.92', `got ${vj.version}`);
  ok('version.json notes carry v2.2.92', vj.notes.includes('v2.2.92:'));
  const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
  ok('native-build-config.js is 2.2.92', nbc.includes('"version":"2.2.92"') && nbc.match(/2\.2\.92/g).length === 1);
}

// ---------- static checks: Change 1 (content-visibility) ----------
{
  ok('CSS gives .verse-block content-visibility:auto',
    css.includes('.verse-block{content-visibility:auto;contain-intrinsic-size:auto 120px}'));
  ok('the .verse-block margin rule is untouched',
    css.includes('.verse-block{margin:0 0 var(--verse-gap,0px)}'));
  ok('the found-line highlight rule is untouched',
    css.includes('.verse-block.gs-found{background:#fff2a8'));
}

// ---------- static checks: Change 2 (captureAnchor hit-test) ----------
function extractFn(src, name) {
  const start = src.indexOf(`function ${name}(){`);
  if (start === -1) return null;
  let depth = 0, i = start;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) { i++; break; } }
  }
  return src.slice(start, i);
}
const anchorSrc = extractFn(app, 'captureAnchor');
ok('captureAnchor extracts cleanly', !!anchorSrc);
if (anchorSrc) {
  ok('captureAnchor uses elementFromPoint at (centre, 73)',
    anchorSrc.includes('document.elementFromPoint(window.innerWidth/2,73)'));
  ok('captureAnchor finds the block with .closest(\'.verse-block\')',
    anchorSrc.includes(".closest('.verse-block')"));
  ok('captureAnchor has NO querySelectorAll scan any more',
    !anchorSrc.includes('querySelectorAll'));
  ok('captureAnchor has NO .find( scan any more',
    !anchorSrc.includes('.find('));
  ok('captureAnchor still sets readerAnchor from dataset.line',
    anchorSrc.includes('readerAnchor=Number(el.dataset.line)||0;'));
  ok('captureAnchor still sets readerAnchorTop from getBoundingClientRect().top',
    anchorSrc.includes('readerAnchorTop=el.getBoundingClientRect().top;'));
  ok('captureAnchor still guards on reader view + lines',
    anchorSrc.includes("if(state.view!=='reader'||!activeRemote?.lines?.length)return;"));
}
// capture() (SGGS Ang only) is deliberately untouched.
{
  const capSrc = extractFn(app, 'capture');
  ok('capture() (SGGS Ang) is unchanged — still the short scan',
    !!capSrc && capSrc.includes("querySelectorAll('.verse-block')"));
  ok('scroll-back rule unchanged (show on up >= 5px, hide on down >= 5px)',
    app.includes("function barScrollDecision(lastY,curY){const d=curY-lastY;if(d<=-5)return 'show';if(d>=5)return 'hide';return null;}"));
  ok('v2.2.91 short-reading fix intact (updateShortReadingBars)',
    app.includes('function updateShortReadingBars(){'));
  ok('v2.2.91 Ask short pills intact',
    app.includes("[['pa','ਪ'],['en','EN']]"));
}

// ---------- runtime: the REAL captureAnchor() (mocked DOM) ----------
function runAnchor(appSrc, setup) {
  const code = extractFn(appSrc, 'captureAnchor');
  if (!code) return null;
  const ctx = setup();
  vm.createContext(ctx);
  vm.runInContext('let readerAnchor=-1,readerAnchorTop=0;', ctx);
  vm.runInContext(code, ctx);
  vm.runInContext('captureAnchor()', ctx);
  ctx.readerAnchor = vm.runInContext('readerAnchor', ctx);
  ctx.readerAnchorTop = vm.runInContext('readerAnchorTop', ctx);
  return ctx;
}
function mockBlock(line, top) {
  return {
    dataset: { line: String(line) },
    getBoundingClientRect: () => ({ top, bottom: top + 60 }),
  };
}
{
  // The block at the top of the screen (y=73) is found and anchored.
  let r = runAnchor(app, () => {
    const block = mockBlock(512, 40);
    const hit = { closest: sel => (sel === '.verse-block' ? block : null) };
    return {
      state: { view: 'reader' },
      activeRemote: { lines: [{ g: 'x' }] },
      document: { elementFromPoint: (x, y) => (y === 73 ? hit : null) },
      window: { innerWidth: 480 },
    };
  });
  ok('hit-test finds the top block: readerAnchor set to its line',
    r && r.readerAnchor === 512, r ? `got ${r.readerAnchor}` : 'no run');
  ok('hit-test sets readerAnchorTop from the block top',
    r && r.readerAnchorTop === 40, r ? `got ${r.readerAnchorTop}` : 'no run');

  // elementFromPoint returns null (gap between blocks) -> anchor untouched.
  r = runAnchor(app, () => ({
    state: { view: 'reader' },
    activeRemote: { lines: [{ g: 'x' }] },
    document: { elementFromPoint: () => null },
    window: { innerWidth: 480 },
  }));
  ok('gap (no element at y=73): anchor stays at -1, no crash',
    r && r.readerAnchor === -1 && r.readerAnchorTop === 0);

  // Not in the reader -> returns early, anchor untouched.
  r = runAnchor(app, () => ({
    state: { view: 'home' },
    activeRemote: { lines: [{ g: 'x' }] },
    document: { elementFromPoint: () => { throw new Error('must not be called'); } },
    window: { innerWidth: 480 },
  }));
  ok('not in the reader: elementFromPoint never called, anchor untouched',
    r && r.readerAnchor === -1);

  // No lines loaded -> returns early.
  r = runAnchor(app, () => ({
    state: { view: 'reader' },
    activeRemote: { lines: [] },
    document: { elementFromPoint: () => { throw new Error('must not be called'); } },
    window: { innerWidth: 480 },
  }));
  ok('no lines loaded: returns early, anchor untouched',
    r && r.readerAnchor === -1);

  // The hit is a word button inside a block: .closest finds the block.
  r = runAnchor(app, () => {
    const block = mockBlock(1200, 71);
    const wordBtn = { closest: sel => (sel === '.verse-block' ? block : null) };
    return {
      state: { view: 'reader' },
      activeRemote: { lines: [{ g: 'x' }] },
      document: { elementFromPoint: () => wordBtn },
      window: { innerWidth: 480 },
    };
  });
  ok('hit on a word button inside a block: closest() finds the block',
    r && r.readerAnchor === 1200 && r.readerAnchorTop === 71);
}

// ---------- negative control: pristine v2.2.91 must show the OLD behaviour ----------
{
  const rbAnchor = extractFn(rbApp, 'captureAnchor');
  ok('rollback (v2.2.91) captureAnchor still has the linear scan',
    !!rbAnchor && rbAnchor.includes("querySelectorAll('.verse-block')"));
  ok('rollback captureAnchor has NO elementFromPoint',
    !!rbAnchor && !rbAnchor.includes('elementFromPoint'));
  ok('rollback CSS has NO content-visibility rule',
    !rbCss.includes('content-visibility'));
  const rbPj = JSON.parse(fs.readFileSync(path.join('/tmp/v311-check', 'package.json'), 'utf8'));
  ok('rollback version is 2.2.91', rbPj.version === '2.2.91', `got ${rbPj.version}`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
