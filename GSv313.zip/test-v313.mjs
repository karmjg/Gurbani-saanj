/* v2.2.93 test — Save a page (GSv313). His request, mockup
 * mockup_save_page.png (v4, star final) approved, go 2026-11-23 14:43,
 * star confirmed 2026-11-23 14:45 ('star is much better').
 *
 * Confirmed behaviour (his words): tapping the star ONLY saves — it does
 * NOT move him, he stays on the same page; the saved page only shows
 * when he goes to the Saved tab; tap once = saved (solid star), tap
 * again on the same page = unsaved (outline star, removed). Heart =
 * save a shabad, star = save a page.
 *
 * Change 1 — state.savedPages (one entry per kind+id: {kind,id,line,
 * title,sub}), persisted by the existing persist().
 * Change 2 — star button in the reader top bar beside Aa, in all three
 * top-bar variants (Ang, Bani, Kirtan).
 * Change 3 — toggleSavePage(): refreshes the anchor (captureAnchor) so
 * the saved line is the line on screen, toggles the entry, persists, and
 * updates the star IN PLACE — never full-renders, so the reader does
 * not move.
 * Change 4 — Saved tab: 'Saved Pages' section at the top; tap a row to
 * open that Ang/Bani/Kirtan at the saved line; red x on each row removes.
 * Change 5 — action() case 'toggle-save-page'.
 * Change 6 — styles.css: .save-page-star (gold when saved) +
 * .remove-saved-page (red x).
 *
 * The proofs below run the REAL toggleSavePage / isPageSaved /
 * savePageStarBtn / pageTitleSub / savedPagesSection from the shipped
 * app.js in a VM (mocked DOM + state) and check the shipped styles.css.
 * Negative control: the same checks run against the pre-fix backup
 * (/tmp/app-v312-backup.js, /tmp/styles-v312-backup.css) and must show
 * the OLD behaviour (no savedPages, no star, no Saved Pages section).
 * Run: node test-v313.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const RB_APP = '/tmp/app-v312-backup.js';
const RB_CSS = '/tmp/styles-v312-backup.css';
const rbApp = fs.readFileSync(RB_APP, 'utf8');
const rbCss = fs.readFileSync(RB_CSS, 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: working copy ----------
ok('state: savedPages in BASE', app.includes('savedPages:[],'));
ok('state: savedPages from stored', app.includes('savedPages:Array.isArray(stored.savedPages)?stored.savedPages:[]'));
ok('helper: isPageSaved defined', /function isPageSaved\(kind,id\)/.test(app));
ok('helper: savePageStarBtn defined', /function savePageStarBtn\(\)/.test(app));
ok('helper: toggleSavePage defined', /function toggleSavePage\(el\)/.test(app));
ok('helper: savedPagesSection defined', /function savedPagesSection\(\)/.test(app));
ok('helper: pageTitleSub defined', /function pageTitleSub\(kind,id,line\)/.test(app));
ok('top bar: star button in all 3 variants',
  (app.match(/\$\{savePageStarBtn\(\)\}/g) || []).length === 3);
ok('top bar: star is beside Aa (inside gs-reading-actions)',
  app.includes('<span class="gs-reading-actions">${savePageStarBtn()}'));
ok('action: toggle-save-page case', app.includes("case'toggle-save-page':toggleSavePage(el);break;"));
ok('Saved tab: Saved Pages section at top',
  app.includes("<h1>${age('ਸੰਭਾਲੇ ਸ਼ਬਦ','Saved Shabads')}</h1>${savedPagesSection()}"));
ok('Saved Pages: section head', app.includes("age('ਸੰਭਾਲੇ ਪੰਨੇ','Saved Pages')"));
ok('Saved Pages: row opens page', app.includes('data-open-saved-page='));
ok('Saved Pages: row has red x remove', app.includes('data-remove-saved-page='));
ok('click: open-saved-page handler', app.includes("e.target.closest('[data-open-saved-page]')"));
ok('click: remove-saved-page handler', app.includes("e.target.closest('[data-remove-saved-page]')"));
ok('click: open uses highlightLine for resume',
  app.includes("highlightLine=Number(parts[2])||0;stopVoiceSearch();if(kind==='ang')openAng(id,true)"));
ok('click: open covers ang + bani + kirtan',
  app.includes("else if(kind==='bani')openBani(id,sp.dataset.baniTitle||'Bani',true);else if(kind==='kirtan')openKirtanShabad(id)"));
ok('toggle: refreshes anchor before saving', app.includes('captureAnchor();\n  const line=Math.max(0,Math.min(readerAnchor>=0'));
ok('toggle: updates star in place (no full render)',
  app.includes("btn.textContent=saved?'★':'☆';btn.classList.toggle('saved',saved);")
  && !/function toggleSavePage[\s\S]{0,900}render\(\)/.test(app));
ok('css: .save-page-star', css.includes('.save-page-star{font-size:22px;line-height:1}'));
ok('css: .save-page-star.saved gold', css.includes('.save-page-star.saved{color:#ba7e38}'));
ok('css: .remove-saved-page red', css.includes('.remove-saved-page{color:#c0392b}'));

// ---------- functional: run the REAL helpers in a VM ----------
const start = app.indexOf('/* v2.2.93: Save a page');
const end = app.indexOf('function bookmarksScreen(){', start);
const block = app.slice(start, end);
// Mocked environment: state, activeRemote, anchor, persist, DOM, age, esc.
const state = { savedPages: [], verse: 0 };
let readerAnchor = -1;
let persistCalls = 0;
let renderCalls = 0;
const starBtn = { textContent: '☆', classList: { _s: new Set(), toggle(c, on) { on ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } } };
const ctx = {
  state,
  activeRemote: { kind: 'ang', id: 250, lines: [{ g: 'ਓਅੰ ਸਾਧ ਸਤਿਗੁਰ ਨਮਸਕਾਰੰ ॥' }, { g: 'ਆਦਿ ਮਧਿ ਅੰਤਿ ਨਿਰੰਕਾਰੰ ॥' }] },
  readerAnchor: -1,
  captureAnchor() { readerAnchor = 1; ctx.readerAnchor = 1; },
  persist() { persistCalls++; },
  render() { renderCalls++; },
  document: { querySelector() { return starBtn; } },
  age: (pa) => pa,
  esc: (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;'),
  console,
};
vm.createContext(ctx);
vm.runInContext(block + '\nthis.__fns={isPageSaved,savePageStarBtn,pageTitleSub,toggleSavePage,savedPagesSection};', ctx);
const F = ctx.__fns;

// Save an Ang page: star was outline, tap -> saved, star solid, no render.
ctx.activeRemote = { kind: 'ang', id: 250, lines: [{ g: 'ਓਅੰ ਸਾਧ ਸਤਿਗੁਰ ਨਮਸਕਾਰੰ ॥' }, { g: 'ਆਦਿ ਮਧਿ ਅੰਤਿ ਨਿਰੰਕਾਰੰ ॥' }] };
readerAnchor = -1; ctx.readerAnchor = -1; persistCalls = 0; renderCalls = 0;
starBtn.textContent = '☆'; starBtn.classList._s.clear();
ok('fn: ang not saved at first', F.isPageSaved('ang', 250) === false);
F.toggleSavePage(starBtn);
ok('fn: tap star saves the page', state.savedPages.length === 1
  && state.savedPages[0].kind === 'ang' && state.savedPages[0].id === 250);
ok('fn: saved line is the line on screen (anchor)', state.savedPages[0].line === 1);
ok('fn: saved title is Ang 250', state.savedPages[0].title === 'Ang 250');
ok('fn: star turns solid after save', starBtn.textContent === '★' && starBtn.classList.contains('saved'));
ok('fn: save persists', persistCalls === 1);
ok('fn: save does NOT re-render (stays on the page)', renderCalls === 0);
ok('fn: ang now shows saved', F.isPageSaved('ang', 250) === true);
ok('fn: star button renders solid when saved', F.savePageStarBtn().includes('★') && F.savePageStarBtn().includes('saved'));
// Tap again on the same page: unsaves, star back to outline, still no render.
F.toggleSavePage(starBtn);
ok('fn: tap star again unsaves', state.savedPages.length === 0);
ok('fn: star turns outline after unsave', starBtn.textContent === '☆' && !starBtn.classList.contains('saved'));
ok('fn: unsave does NOT re-render either', renderCalls === 0);
// One entry per kind+id: save two different Angs, then a Bani.
F.toggleSavePage(starBtn); // re-save Ang 250
ctx.activeRemote = { kind: 'ang', id: 500, lines: [{ g: 'ਸੋ ਦਰੁ ਕੇਹਾ ॥' }] };
readerAnchor = 0; ctx.readerAnchor = 0;
F.toggleSavePage(starBtn);
ctx.activeRemote = { kind: 'bani', id: 2, title: 'ਜਪੁਜੀ ਸਾਹਿਬ', lines: [{ g: 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ॥' }] };
readerAnchor = 0; ctx.readerAnchor = 0;
F.toggleSavePage(starBtn);
ok('fn: three saved pages (two Angs + one Bani)', state.savedPages.length === 3);
ok('fn: Bani title kept', state.savedPages.some(p => p.kind === 'bani' && p.title === 'ਜਪੁਜੀ ਸਾਹਿਬ'));
// pageTitleSub for Kirtan uses firstLine + Ang.
ctx.activeRemote = { kind: 'kirtan', id: 7, title: '', meta: { firstLine: 'ਮਿਤ੍ਰ ਪਿਆਰੇ ਨੂੰ ਹਾਲੁ ॥', ang: 682 }, lines: [{ g: 'ਮਿਤ੍ਰ ਪਿਆਰੇ ਨੂੰ ਹਾਲੁ ॥' }] };
const kt = F.pageTitleSub('kirtan', 7, 0);
ok('fn: kirtan title is firstLine, sub is Ang', kt.title === 'ਮਿਤ੍ਰ ਪਿਆਰੇ ਨੂੰ ਹਾਲੁ ॥' && kt.sub === 'Ang 682');
// Saved Pages section renders rows with open + remove, and the empty state.
const html = F.savedPagesSection();
ok('fn: section lists saved pages', html.includes('ਸੰਭਾਲੇ ਪੰਨੇ') && html.includes('Ang 250') && html.includes('ਜਪੁਜੀ ਸਾਹਿਬ'));
ok('fn: section row opens at saved line', html.includes('data-open-saved-page="ang:250:1"'));
ok('fn: section row has remove x', html.includes('data-remove-saved-page="ang:250"'));
state.savedPages = [];
ok('fn: empty section shows the star hint', F.savedPagesSection().includes('ਤਾਰਾ ਦਬਾ ਕੇ ਪੰਨਾ ਸੰਭਾਲੋ।'));

// ---------- negative control: pre-fix backup must NOT have it ----------
ok('neg: backup has no savedPages', !rbApp.includes('savedPages'));
ok('neg: backup has no star button', !rbApp.includes('savePageStarBtn') && !rbApp.includes('toggle-save-page'));
ok('neg: backup has no Saved Pages section', !rbApp.includes('savedPagesSection') && !rbApp.includes('Saved Pages'));
ok('neg: backup css has no star styles', !rbCss.includes('.save-page-star') && !rbCss.includes('.remove-saved-page'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
