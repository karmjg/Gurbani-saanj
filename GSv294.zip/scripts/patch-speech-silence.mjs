import fs from 'node:fs';
// Gurbani Saanjh v2.2.73: make each mic listening stretch last ~8s of silence
// before the speech service ends it. The stock timeout (~2s) ends the segment
// (and the phone beeps) every ~2s while idle; the app restarts the recognizer
// after each stop, so a longer wait means fewer restarts and fewer beeps.
// Runs on postinstall (after `npm ci`), so the patch survives a clean
// install — node_modules is NOT in the source zip. Idempotent: a second run
// is a no-op. Fails loudly if the plugin file or anchor changed, so a build
// never silently ships without the fix.
const p='node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
if(!fs.existsSync(p))throw new Error('speech plugin not installed — silence patch cannot apply; investigate before shipping');
let s=fs.readFileSync(p,'utf8');
if(s.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS')){console.log('speech silence patch already applied');process.exit(0);}
const anchor='        intent.putExtra("android.speech.extra.DICTATION_MODE", partialResults);';
if(!s.includes(anchor))throw new Error('speech plugin anchor changed — silence patch cannot apply; investigate before shipping');
const insert=anchor+'\n        // Gurbani Saanjh v2.2.73: keep each listening stretch to ~8s of silence\n        // before the service ends it (stock ~2s ends the segment and beeps\n        // every ~2s while idle; the app restarts after each stop).\n        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000);\n        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000);';
s=s.replace(anchor,insert);
fs.writeFileSync(p,s);
console.log('speech silence patch applied (8s)');
