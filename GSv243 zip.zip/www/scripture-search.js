/* iGranth-style Gurbani search: first letter of each word (from start / anywhere),
 * full phrase, word, Romanized, and Ang. All matching runs against the SGGS
 * offline index packaged during the Android build; no query is sent to a server.
 * The scripture corpus is from the separately credited BaniDB snapshot.
 */
(()=>{'use strict';
let loading=null,rows=[];
const norm=s=>String(s||'').normalize('NFC').toLocaleLowerCase().replace(/[\u200c\u200d]/gu,'').trim();
// Strip leading/trailing punctuation from tokens so ॥੧॥ and । don't contribute
// spurious first-letter characters. Preserve vowels and matras inside words.
const words=s=>norm(s).split(/[\s,;?!.।॥:()"'\[\]{}\-।੦-੯\d|]+/u).map(w=>w.replace(/^[^\p{L}\p{N}ੴ]+|[^\p{L}\p{N}\p{M}]+$/gu,'')).filter(Boolean);
const compact=s=>norm(s).replace(/[^\p{L}\p{N}ੴ]/gu,'');
// iGranth rule: a word's first letter is its BARE base letter — no matra on top.
// ਐਸੇ/ਐਸਾ start with ਅ (ਐ is ਅ + ੈ), ਤੂ starts with ਤ, ਮਾਧੋ with ਮ.
// So ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ is typed as ਮਹਅਤਅ. Fold precomposed vowels to base.
const foldFirst=ch=>({'ਆ':'ਅ','ਈ':'ਇ','ਊ':'ਉ','ਏ':'ਅ','ਐ':'ਅ','ਓ':'ਅ','ਔ':'ਅ'})[ch]||ch;
const initials=s=>words(s).filter(w=>w!=='ੴ').map(w=>foldFirst(Array.from(w)[0]||'')).join('');
const romanized=s=>/[a-z]/i.test(s);
const stopwords=new Set(['why','how','can','the','and','what','where','with','about','from','are','does','have','for','search','find','gurbani','guru','sahib','granth','is','of','to','a','in','say','says','tell','tells','mean','means','explain','explains','answer','question','please','ਮੈਨੂੰ','ਵਿੱਚ','ਅਤੇ','ਕਿਵੇਂ','ਕੀ','ਤੋਂ','ਦਾ','ਦੀ','ਦੇ','ਹੈ','ਗੁਰਬਾਣੀ','ਬਾਰੇ','ਕਹਿੰਦੀ','ਕਹਿੰਦਾ','ਕਹਿੰਦੇ','ਦੱਸੋ','ਦੱਸ','ਕਿਉਂ','ਕਿਹੜਾ','ਕਿਹੜੀ','ਕਿਸ','ਲਈ','ਕਰਕੇ','ਕਰਦਾ','ਕਰਦੀ','ਕਰਦੇ','ਹੋਵੇ','ਨਾਲ','ਨੂੰ','ਤੇ','ਭੀ','ਵੀ','ਜੇ','ਜੋ','ਇਹ','ਉਹ','ਕਰੋ','ਚਾਹੀਦਾ','ਚਾਹੀਦੀ']);
const useful=s=>words(s).filter(w=>w.length>1&&!stopwords.has(w)).slice(0,10);
let prepared=[],lookupMap=new Map();
function prepare(arr){
 prepared=arr.map(r=>{
  const [a,i,g,en='',pa='',roman='']=r;
  const text=norm(g),trans=norm(roman);
  return {ang:Number(a),idx:Number(i),g:String(g||''),text,trans,
   all:norm([g,en,pa,roman].join(' ')),initial:compact(initials(g)),romanInitial:compact(initials(roman)),tokens:words(g),romanTokens:words(roman)};
 });
 lookupMap=new Map(prepared.map(x=>[`${x.ang}:${x.idx}`,{ang:x.ang,idx:x.idx,g:x.g}]));
 return prepared;
}
async function load(){
 if(!loading)loading=fetch('offline/search.json',{cache:'force-cache'}).then(async r=>{
  if(!r.ok)throw Error('Offline index missing');const arr=await r.json();
  if(!Array.isArray(arr)||arr.length<1000)throw Error('Offline scripture index incomplete');
  rows=arr;prepare(arr);return arr;
 }).catch(e=>{loading=null;throw e});
 return loading;
}
function matchRows(arr,q,limit=40,mode='auto'){
 const needle=norm(q),signature=Array.from(compact(needle)).map(foldFirst).join(''),terms=useful(q);if(!needle)return [];
 const n=/^(?:ang\s*)?(\d{1,4})$/i.exec(needle);
 const selection=mode==='auto'&&n?'ang':mode;
 const data=arr===rows&&prepared.length?prepared:arr.map(r=>{
  const [a,i,g,en='',pa='',roman='']=r;
  return {ang:Number(a),idx:Number(i),g:String(g||''),text:norm(g),trans:norm(roman),
   all:norm([g,en,pa,roman].join(' ')),initial:compact(initials(g)),romanInitial:compact(initials(roman)),tokens:words(g),romanTokens:words(roman)};
 });
 const found=[];
 for(const x of data){
  if(!x.g)continue;
  let score=0;
  if(selection==='ang')score=(n&&x.ang===Number(n[1]))?150:0;
  else if(selection==='first')score=signature&&x.initial.startsWith(signature)?150:0;
  else if(selection==='any-first')score=signature&&x.initial.includes(signature)?130:0;
  else if(selection==='roman')score=(x.trans.includes(needle)?100:0)||(signature&&x.romanInitial.startsWith(signature)?95:0);
  else if(selection==='word')score=x.tokens.some(w=>w===needle||w.includes(needle))||x.romanTokens.some(w=>w===needle||w.includes(needle))?110:0;
  else{
   if(x.all.includes(needle))score=120;
   else if(terms.length){const hits=terms.filter(w=>x.all.includes(w)).length;
    if(hits>=Math.min(2,terms.length))score=hits*8;}
   if(!score&&signature){
    // In auto mode, short Gurmukhi sequences are also first-letter searches.
    const candidate=romanized(needle)?x.romanInitial:x.initial;
    if(candidate.startsWith(signature))score=105;
    else if(signature.length>=2&&candidate.includes(signature))score=70;
    if(!score){
     // v2.2.21: a full phrase is also tried by its first letters. The
     // spoken/typed words may be slightly off (a matra or spelling), but the
     // first letter of each word still matches the line. e.g. "ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ
     // ਵੇਲੇ" gives first letters "ਬਅਵ", which matches "ਬਾਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੈ
     // ਬੋਲਿਆ" (Ang 1285). Only for 2+ words, so the signature stays specific.
     const firstSig=compact(initials(needle));
     if(firstSig.length>=2&&candidate.startsWith(firstSig))score=105;
     else if(firstSig.length>=2&&candidate.includes(firstSig))score=70;
    }
   }
  }
  if(score)found.push({ang:x.ang,idx:x.idx,g:x.g,score});
 }
 found.sort((a,b)=>b.score-a.score||a.ang-b.ang||a.idx-b.idx);
 return found.slice(0,Math.max(1,Math.min(100,Number(limit)||40))).map(({score,...rest})=>rest);
}
async function query(q,limit=40,mode='auto'){await load();return matchRows(rows,q,limit,mode)}
function lookup(ang,idx){return lookupMap.get(`${Number(ang)}:${Number(idx)}`)||null}
window.GS_SCRIPTURE_SEARCH={load,query,lookup,matchRows};
})();
