/* Gurbani Saanjh v2.2.0 — pure layered verse renderer (no DOM, no network).
 * Shared by the Ang reader, Bani reader and Kirtan book so all three show the
 * same stacked layers in the same order:
 *   Gurmukhi / Transliteration (roman) / English / Punjabi / Shabad Arth
 * Tokenization follows the vishraam data contract EXACTLY:
 *   g.trim().split(/\s+/)  — INCLUDING ॥..॥ numeral tokens.
 * Exposes window.GS_VERSES. Testable in node via vm (see test-v220.mjs).
 */
(()=>{
'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// EXACT contract tokenization — never change this without changing the data.
const tokens=g=>String(g||'').trim().split(/\s+/).filter(Boolean);
// Word cleanup ONLY for dictionary lookup (display keeps the original token).
const cleanWord=w=>String(w||'').normalize('NFC').replace(/^[॥।,;!?(){}\[\]"'“”‘’]+|[॥।,;!?(){}\[\]"'“”‘’]+$/gu,'').replace(/[੦-੯0-9]+/gu,'').trim();
const stanzaEnds=s=>/(?:॥|\|\|)\s*[੦-੯0-9]+\s*(?:॥|\|\|)\s*$/u.test(String(s||'').trim())||/ਰਹਾਉ\s*(?:॥|\|\|)/u.test(String(s||''));
const wordCount=s=>String(s||'').trim().split(/\s+/).filter(Boolean).length;
// Conservative Sundar Gutka chhand/section heading detection. Only short,
// clearly-marked headings qualify — never a regular pankti.
function isBaniHeading(g){
 const t=String(g||'').trim();if(!t)return false;
 const wc=wordCount(t);
 if(/^॥[^॥]*॥$/.test(t))return true;
 if(/ਛੰਦ/.test(t)&&wc<=10)return true;
 if(/ਸਵੱਯੇ|ਸਵਈਆ|ਸਵੈਯਾ/.test(t)&&wc<=10)return true;
 if(/ਚੌਪਈ/.test(t)&&wc<=10)return true;
 if(/ਪਾਤਿਸਾਹੀ|ਮੁਖਵਾਕ/.test(t)&&wc<=10)return true;
 if(/ਸਤਿਗੁਰ\s*ਪ੍ਰਸਾਦਿ/.test(t)&&wc<=10)return true;
 if(/^(ਜਾਪੁ|ਜਪੁ)\s*॥/.test(t))return true;
 return false;
}
// v2.2.5: a Bani paragraph ends at a verse-number line (॥੧॥). Used to group
// consecutive panktis into Sundar Gutka-style flowing paragraphs.
const verseNumEnd=s=>/(?:॥|\|\|)\s*[੦-੯0-9]+\s*(?:॥|\|\|)\s*$/u.test(String(s||'').trim());
// Group Bani lines into flowing paragraphs: consecutive non-heading panktis
// run together; a paragraph breaks at a verse-number line or a heading.
// v2.2.5-fix: after a "ਪ੍ਰਯਾਤ" (Prayat) heading, panktis are paired two-per-line
// (Sundar Gutka's Bhujang Prayat layout) instead of flowing.
// Returns [{type:'heading'|'para', items:[{line,idx}]}].
function groupBaniParagraphs(lines){
 const groups=[];let cur=null;let pairMode=false;
 const flush=()=>{if(cur&&cur.items.length){groups.push(cur);cur=null;}};
 (lines||[]).forEach((line,idx)=>{
  const g=String((line&&line.g)||'');
  if(isBaniHeading(g)){flush();groups.push({type:'heading',items:[{line,idx}]});pairMode=/ਪ੍ਰਯਾਤ/.test(g);return;}
  if(pairMode){
   if(!cur||cur.items.length>=2){flush();cur={type:'pair',items:[]};}
   cur.items.push({line,idx});
   if(cur.items.length>=2||verseNumEnd(g))flush();
  }else{
   if(!cur)cur={type:'para',items:[]};
   cur.items.push({line,idx});
   if(verseNumEnd(g))flush();
  }
 });
 flush();
 return groups;
}
// One tappable word button (shared by verseHTML and the paragraph renderer).
function wordBtn(part,idx,w,kind,o){
 o=o||{};
 let cls='word',vCls='';
 if(o.vishraamOn){
  const m=o.marks?o.marks[w]:null;
  if(m==='s')vCls=' vishraam-short';
  else if(m==='l')vCls=' vishraam-long';
  else{const lm=o.legacy?o.legacy[w]:null;
   if(lm==='short')vCls=' vishraam-short';else if(lm==='long')vCls=' vishraam-long';}
 }
 // Plain black text per user request; every word stays a tappable button.
 return `<button type="button" class="${cls}${vCls}" data-word="${esc(part)}" data-kind="${kind}" data-idx="${idx}" data-widx="${w}" lang="pa" aria-label="${esc(part)}">${esc(part)}</button>`;
}
/* v2.2.5: flowing Bani paragraphs (Sundar Gutka structure).
 * Each paragraph is ONE wrapping block with all its panktis' words flowing
 * inline (still individually tappable via data-word). Headings stay centered
 * blocks. Stacked layers (transliteration/translation/arth) are joined across
 * the paragraph. Bani scroll view only; Ang/Kirtan/page-mode untouched.
 */
function baniFlowHTML(lines,o={}){
 const show=o.show||{};
 const groups=groupBaniParagraphs(lines);
 return groups.map(gr=>{
  if(gr.type==='heading'){
   const h=gr.items[0];
   return verseHTML(h.line,{idx:h.idx,kind:'bani',vishraamOn:o.vishraamOn,
    marks:h.line._marks||null,legacyVishraam:h.line._legacyVishraam||null,
    koshHas:o.koshHas,arth:h.line._arth||null,show,heading:true,found:h.idx===o.foundIdx});
  }
  const words=gr.items.map(it=>{
   const oo={vishraamOn:o.vishraamOn,marks:it.line._marks||null,legacy:it.line._legacyVishraam||null};
   return tokens(it.line.g).map((part,w)=>wordBtn(part,it.idx,w,'bani',oo)).join(' ');
  }).join(' ');
  const cls=gr.type==='pair'?'gs-bani-para gs-bani-pair':'gs-bani-para';
  let html=`<div class="verse-block ${cls}${gr.items.some(it=>it.idx===o.foundIdx)?' gs-found':''}" data-lines="${gr.items.map(x=>x.idx).join(',')}"><div class="verse-text" lang="pa">${words}</div>`;
  const layer=(key,cls,lang)=>{const t=gr.items.map(it=>String(it.line[key]||'').trim()).filter(Boolean).join(' ');return t?`<div class="verse-layer ${cls}" lang="${lang}">${esc(t)}</div>`:'';};
  if(show.translit)html+=layer('roman','verse-roman','en');
  if(show.en)html+=layer('en','verse-en','en');
  if(show.pa)html+=layer('pa','verse-pa','pa');
  if(show.hi)html+=layer('hi','verse-hi','hi');
  if(show.arth){
   const ap=[];
   gr.items.forEach(it=>{if(Array.isArray(it.line._arth))it.line._arth.forEach(a=>ap.push(a));});
   if(ap.length)html+=`<div class="verse-layer verse-arth" lang="pa">${ap.map(a=>`<span class="arth-pair"><b>${esc(a.word)}</b> = ${esc(a.meaning)}</span>`).join(' ')}</div>`;
  }
  return html+'</div>';
 }).join('');
}
// Traditional opening header is rendered only when the Bani text itself does
// not already carry the manglacharan (avoids duplicating scripture).
function baniHeaderNeeded(lines){
 const first=String(lines?.[0]?.g||'');
 if(/ਸਤਿਗੁਰ\s*ਪ੍ਰਸਾਦਿ/.test(first))return false;
 if(/ਵਾਹਿਗੁਰੂ\s*ਜੀ\s*ਕੀ\s*ਫਤਹ/.test(first))return false;
 return true;
}
/* Render ONE verse as stacked layers.
 * line: {g, roman?, en?, pa?, hi?}
 * o: {idx, kind('ang'|'bani'|'kirtan'), vishraamOn, marks:{widx:'s'|'l'}|null,
 *     legacyVishraam:{widx:'short'|'long'}|null, koshHas(word)->bool,
 *     arth:[{word,meaning}]|null, show:{translit,en,pa,hi,arth},
 *     heading:bool, gurmukhiClass:''|'gs-gurmukhi-blue'}
 */
function verseHTML(line,o={}){
 const show=o.show||{};
 const idx=Number(o.idx)||0,kind=o.kind||'ang';
 const parts=tokens(line.g);
 const marks=o.marks||null,legacy=o.legacyVishraam||null;
 const koshHas=typeof o.koshHas==='function'?o.koshHas:null;
 const words=parts.map((part,w)=>{
  let cls='word',vCls='';
  if(o.vishraamOn){
   const m=marks?marks[w]:null;
   if(m==='s')vCls=' vishraam-short';
   else if(m==='l')vCls=' vishraam-long';
   else{
    const lm=legacy?legacy[w]:null;
    if(lm==='short')vCls=' vishraam-short';
    else if(lm==='long')vCls=' vishraam-long';
   }
  }
  // No orange/color highlight on kosh words (plain black text per user request).
  // Tap-a-word still works: every word is a button with data-word.
  const kCls='';
  return `<button type="button" class="${cls}${vCls}${kCls}" data-word="${esc(part)}" data-kind="${kind}" data-idx="${idx}" data-widx="${w}" lang="pa" aria-label="${esc(part)}">${esc(part)}</button>`;
 }).join(' ');
 const variant=kind==='bani'?'gs-bani-pankti':kind==='kirtan'?'gs-kirtan-pankti':'gs-sggs-pankti';
 const boundary=stanzaEnds(line.g)?' gs-stanza-end':'';
 const heading=o.heading?' gs-verse-heading':'';
 const found=o.found?' gs-found':'';
 const gClass='verse-text'+(o.gurmukhiClass?' '+o.gurmukhiClass:'');
 let html=`<div class="verse-block gs-pankti ${variant}${boundary}${heading}${found}" data-line="${idx}"><div class="${gClass}" lang="pa">${words}</div>`;
 const roman=String(line.roman||'').trim();
 if(show.translit&&roman)html+=`<div class="verse-layer verse-roman" lang="en">${esc(roman)}</div>`;
 const en=String(line.en||'').trim();
 if(show.en&&en)html+=`<div class="verse-layer verse-en" lang="en">${esc(en)}</div>`;
 const pa=String(line.pa||'').trim();
 if(show.pa&&pa)html+=`<div class="verse-layer verse-pa" lang="pa">${esc(pa)}</div>`;
 const hi=String(line.hi||'').trim();
 if(show.hi&&hi)html+=`<div class="verse-layer verse-hi" lang="hi">${esc(hi)}</div>`;
 const arth=Array.isArray(o.arth)?o.arth:[];
 if(show.arth&&arth.length){
  html+=`<div class="verse-layer verse-arth" lang="pa">${arth.map(a=>`<span class="arth-pair"><b>${esc(a.word)}</b> = ${esc(a.meaning)}</span>`).join(' ')}</div>`;
 }
 return html+'</div>';
}
window.GS_VERSES={esc,tokens,cleanWord,stanzaEnds,isBaniHeading,baniHeaderNeeded,verseHTML,verseNumEnd,groupBaniParagraphs,baniFlowHTML,wordBtn};
})();
