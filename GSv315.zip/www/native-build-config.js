window.GS_BUILD={"version":"2.2.95","repo":"","hideAiSettings":false};
