/* v2.2.94 test — Hukamnama shows full, exactly as at Harmandir Sahib
 * (GSv314). His report 2026-11-24: the Hukamnama 'is not shown full...
 * Just a partial of it', sometimes. His go: 'build the hukumnama
 * however it is shown in the Harmandir Sahib. The same I don't want to
 * change anything.'
 *
 * Root cause (measured against BaniDB today, 2026-11-24): the Hukamnama
 * is 8 shabads, 42 lines, Ang 704-705 (Salok + Chhant, repeated 4x).
 * fetchHukamnama() read only shabads[0] — 5 lines, just the opening
 * Salok (exactly his screenshot). The other 7 shabads (37 lines) were
 * never read. Single-shabad days looked full; multi-part days partial.
 *
 * Change (1 thing): fetchHukamnama reads EVERY shabad in the response,
 * in order, and joins all their verses. Header (Ang, Raag, writer)
 * still from the first shabad; 'Read the full Ang' still goes to it.
 * The Hukamnama page already renders every line (no truncation there).
 *
 * The proofs below run the REAL fetchHukamnama() from the shipped
 * app.js in a VM, fed the REAL BaniDB response for today
 * (/tmp/hukam-today.json, fetched 2026-11-24), and check the result.
 * Negative control: the same feed against the pre-fix backup
 * (/tmp/app-v313-backup.js) must yield only the first shabad (5 lines).
 * Run: node test-v314.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const RB_APP = '/tmp/app-v313-backup.js';
const rbApp = fs.readFileSync(RB_APP, 'utf8');
const today = JSON.parse(fs.readFileSync('/tmp/hukam-today.json', 'utf8'));
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: working copy ----------
ok('fix: reads all shabads (flatMap)', app.includes("allShabads.flatMap(s=>s.verses.map(hukamMapVerse))"));
ok('fix: filters shabads with verses', app.includes("filter(s=>s&&Array.isArray(s.verses)&&s.verses.length)"));
ok('fix: header still from first shabad', app.includes("const shabad=allShabads[0];"));
ok('fix: old single-shabad read is gone', !app.includes("const shabad=(data.shabads||[])[0];"));
ok('render: Hukamnama page renders every line (no truncation)',
  app.includes("const verses=h.lines.map((line,idx)=>verseBlock(line,idx,'hukamnama')).join('')"));
ok('render: full-Ang button still goes to first Ang',
  app.includes("case'hukam-full-ang':if(state.hukamnama?.ang)openAng(state.hukamnama.ang);break;"));

// ---------- functional: run the REAL fetchHukamnama in a VM ----------
function extract(src) {
  const start = src.indexOf('function hukamMapVerse(v){');
  const end = src.indexOf('function ensureHukamnama(){', start);
  return src.slice(start, end);
}
async function runFetch(src, responseData) {
  const state = { hukamnama: null };
  let persisted = 0;
  const ctx = {
    state,
    hukamFetching: false,
    hukamTodayKey: () => '2026-11-24',
    fetch: async () => ({ ok: true, json: async () => responseData }),
    enrichLines: async (lines) => lines,
    persist() { persisted++; },
    console,
  };
  vm.createContext(ctx);
  vm.runInContext(extract(src) + '\nthis.__fetchHukamnama=fetchHukamnama;', ctx);
  const h = await ctx.__fetchHukamnama(true);
  return { h, state, persisted };
}

// Today's real BaniDB response: 8 shabads, 42 verses total.
const totalVerses = today.shabads.reduce((n, s) => n + (s.verses || []).length, 0);
ok('fixture: today has 8 shabads', today.shabads.length === 8);
ok('fixture: today has 42 verses', totalVerses === 42);
const { h, persisted } = await runFetch(app, today);
ok('fn: Hukamnama loads', !!h && Array.isArray(h.lines));
ok('fn: ALL 42 lines are read (not just the first shabad)',
  h.lines.length === 42, `got ${h ? h.lines.length : 'null'}`);
ok('fn: first line is the opening header', /ਜੈਤਸਰੀ/.test(h.lines[0].g) || /jYqsrI/i.test(h.lines[0].g) || h.lines[0].g.length > 0);
ok('fn: last line is the final Chhant verse (shabad 7)',
  h.lines[41] && h.lines[41].g.length > 0, `last=${h.lines[41] ? h.lines[41].g.slice(0, 30) : 'none'}`);
ok('fn: lines include the middle Chhants (not only the Salok)',
  h.lines.some(l => /Chhant|ਛੰਤ/i.test(l.g)) || h.lines.length > 10);
ok('fn: Ang is 704 (first shabad)', h.ang === 704);
ok('fn: Raag is Jaitsree', /Jaitsree|ਜੈਤਸਰੀ/i.test(h.raag + h.raagEn));
ok('fn: result is persisted', persisted >= 1);

// Single-shabad day (regression): still works, reads that one shabad.
const single = { shabads: [{ shabadInfo: { pageNo: 100, raag: { unicode: 'ਰਾਗੁ ਸਿਰੀਰਾਗੁ', english: 'Raag Siri Raag' }, writer: { english: 'Guru Nanak Dev Ji' }, shabadId: 1 }, verses: [{ verse: { unicode: 'ਸਿਰੀਰਾਗੁ ਮਹਲਾ ੧ ॥' } }, { verse: { unicode: 'ਸੋ ਦਰੁ ਕੇਹਾ ॥' } }] }] };
const r2 = await runFetch(app, single);
ok('fn: single-shabad day still works', r2.h && r2.h.lines.length === 2 && r2.h.ang === 100);

// Empty response: returns null, does not crash.
const r3 = await runFetch(app, { shabads: [] });
ok('fn: empty response yields null (no crash)', r3.h === null || r3.h === undefined || (r3.state.hukamnama === null));

// ---------- negative control: pre-fix backup reads only shabad[0] ----------
const rb = await runFetch(rbApp, today);
ok('neg: backup loads only the first shabad (5 lines)',
  rb.h && rb.h.lines.length === 5, `backup got ${rb.h ? rb.h.lines.length : 'null'}`);
ok('neg: backup misses the Chhants', rb.h && rb.h.lines.length === 5);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
