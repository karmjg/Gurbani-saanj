/* v2.2.95 test — Hukamnama cache: re-fetch today's saved copy once if
 * it came from the old version (GSv315). Follow-up to v2.2.94 (GSv314).
 * His question 2026-11-24 11:13: 'from now on, it's gonna show every
 * time the full Hukamnama, right?' — yes, but with one catch, and my
 * call (he asked 'What do u think?'): fix it.
 *
 * The catch: the phone already saved TODAY's Hukamnama as the old
 * partial (5 lines) this morning. The app keeps today's saved copy and
 * does not fetch again today, so even after installing GSv314, today
 * would still show the partial. From tomorrow it would be full. That
 * would look like the fix did not work.
 *
 * Change (3 small edits): fetchHukamnama marks the saved Hukamnama
 * full:true; both cache checks (fetchHukamnama + ensureHukamnama) now
 * also require state.hukamnama.full. A saved copy without the mark
 * (from the old version) is treated as stale and fetched again once,
 * full. A copy saved by this version carries full:true, so it is kept
 * and used normally — no extra fetching, no loop (v2.2.62 guards kept).
 *
 * The proofs below run the REAL fetchHukamnama() + ensureHukamnama()
 * from the shipped app.js in a VM, fed the REAL BaniDB response for
 * today (/tmp/hukam-today.json, 8 shabads, 42 lines). Negative control:
 * the pre-fix backup (/tmp/app-v314-backup.js) keeps serving the old
 * cached partial without fetching.
 * Run: node test-v315.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const RB_APP = '/tmp/app-v314-backup.js';
const rbApp = fs.readFileSync(RB_APP, 'utf8');
const today = JSON.parse(fs.readFileSync('/tmp/hukam-today.json', 'utf8'));
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---------- static checks: working copy ----------
ok('fix: saved Hukamnama is marked full', app.includes('fetchedAt:Date.now(),stale:false,full:true};'));
ok('fix: fetch cache check requires full', app.includes("state.hukamnama.date===key&&state.hukamnama.full&&Array.isArray(state.hukamnama.lines)"));
ok('fix: ensure cache check requires full', app.includes("state.hukamnama.date===key&&state.hukamnama.full&&Array.isArray(state.hukamnama.lines)"));
ok('fix: v2.2.94 all-shabads read still there', app.includes("allShabads.flatMap(s=>s.verses.map(hukamMapVerse))"));

// ---------- functional: run the REAL functions in a VM ----------
function extract(src) {
  const start = src.indexOf('function hukamMapVerse(v){');
  const end = src.indexOf('let hukamNotifScheduled=false;', start);
  return src.slice(start, end);
}
function makeCtx(responseData, cached) {
  const state = { hukamnama: cached || null, view: 'home' };
  let fetchCalls = 0;
  const ctx = {
    state,
    hukamFetching: false,
    hukamTodayKey: () => '2026-11-24',
    fetch: async () => { fetchCalls++; return { ok: true, json: async () => responseData }; },
    enrichLines: async (lines) => lines,
    persist() {},
    render() {},
    console,
    get fetchCalls() { return fetchCalls; },
  };
  vm.createContext(ctx);
  vm.runInContext(extract(app) + '\nthis.__fetch=fetchHukamnama;\nthis.__ensure=ensureHukamnama;', ctx);
  return ctx;
}
const oldPartial = { date: '2026-11-24', ang: 704, lines: today.shabads[0].verses.map(v => ({ g: String(v.verse?.unicode || '') })) };
// NOTE: oldPartial has NO `full` flag — exactly what the old version saved.

// Scenario A — today's OLD cached partial (5 lines, no full mark):
// the app must NOT serve it; it must fetch fresh and return all 42.
const ctxA = makeCtx(today, oldPartial);
const hA = await ctxA.__fetch();
ok('fn: old cached partial is NOT served', ctxA.fetchCalls === 1, `fetchCalls=${ctxA.fetchCalls}`);
ok('fn: re-fetch returns all 42 lines', hA && hA.lines.length === 42, `got ${hA ? hA.lines.length : 'null'}`);
ok('fn: re-fetched copy is marked full', hA && hA.full === true);
ok('fn: re-fetched copy is cached in state', ctxA.state.hukamnama && ctxA.state.hukamnama.full === true && ctxA.state.hukamnama.lines.length === 42);

// Scenario A2 — ensureHukamnama with the old cached partial also fetches.
const ctxA2 = makeCtx(today, oldPartial);
ctxA2.__ensure();
await new Promise(r => setTimeout(r, 50));
ok('fn: ensureHukamnama re-fetches an old partial', ctxA2.fetchCalls === 1, `fetchCalls=${ctxA2.fetchCalls}`);
ok('fn: ensureHukamnama leaves the full copy cached',
  ctxA2.state.hukamnama && ctxA2.state.hukamnama.lines.length === 42);

// Scenario B — today's NEW cached full (42 lines, full:true):
// the app must serve it WITHOUT fetching again.
const fullCached = { date: '2026-11-24', ang: 704, full: true, lines: today.shabads.flatMap(s => s.verses.map(v => ({ g: String(v.verse?.unicode || '') }))) };
const ctxB = makeCtx(today, fullCached);
const hB = await ctxB.__fetch();
ok('fn: new cached full IS served without fetching', ctxB.fetchCalls === 0 && hB && hB.lines.length === 42, `fetchCalls=${ctxB.fetchCalls}`);
const ctxB2 = makeCtx(today, fullCached);
ctxB2.__ensure();
await new Promise(r => setTimeout(r, 50));
ok('fn: ensureHukamnama does NOT re-fetch a full copy', ctxB2.fetchCalls === 0, `fetchCalls=${ctxB2.fetchCalls}`);

// Scenario C — no cache at all: fetches once and saves full.
const ctxC = makeCtx(today, null);
const hC = await ctxC.__fetch();
ok('fn: no cache fetches once and saves full', ctxC.fetchCalls === 1 && hC && hC.lines.length === 42 && hC.full === true);

// ---------- negative control: pre-fix backup serves the old partial ----------
function makeCtxRb(responseData, cached) {
  const state = { hukamnama: cached || null, view: 'home' };
  let fetchCalls = 0;
  const ctx = {
    state,
    hukamFetching: false,
    hukamTodayKey: () => '2026-11-24',
    fetch: async () => { fetchCalls++; return { ok: true, json: async () => responseData }; },
    enrichLines: async (lines) => lines,
    persist() {},
    render() {},
    console,
    get fetchCalls() { return fetchCalls; },
  };
  vm.createContext(ctx);
  vm.runInContext(extract(rbApp) + '\nthis.__fetch=fetchHukamnama;', ctx);
  return ctx;
}
const ctxRb = makeCtxRb(today, oldPartial);
const hRb = await ctxRb.__fetch();
ok('neg: backup serves the old cached partial without fetching',
  ctxRb.fetchCalls === 0 && hRb && hRb.lines.length === 5, `fetchCalls=${ctxRb.fetchCalls}, lines=${hRb ? hRb.lines.length : 'null'}`);
ok('neg: backup never marks full', !rbApp.includes('full:true'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
