#!/usr/bin/env python3
"""v2.2.95 (GSv315) — Hukamnama: re-fetch today's saved copy once if it
came from the old version. Follow-up to v2.2.94 (GSv314), which made
fetchHukamnama read ALL shabads. His question 2026-11-24 11:13: 'from
now on, it's gonna show every time the full Hukamnama, right?' — yes,
but with one catch, and my call (he asked 'What do u think?'): fix it.

The catch: the phone already saved TODAY's Hukamnama as the old partial
(5 lines) this morning. The app keeps today's saved copy and does not
fetch again today, so even after installing GSv314, today would still
show the partial. From tomorrow it would be full. That would look like
the fix did not work.

Change (3 small edits, all in www/app.js):
1. When fetchHukamnama saves the Hukamnama, mark it full:true.
2. fetchHukamnama's cache check now also requires state.hukamnama.full.
   A saved copy without the mark (from the old version) is treated as
   stale and fetched again once, full.
3. ensureHukamnama's cache check gets the same full requirement, so
   the home screen does not keep serving the old partial either.
A copy saved by this version carries full:true, so it is kept and used
normally — no extra fetching, no loop (the v2.2.62 guards are untouched).
Nothing else changes: the layout, the star save-pages, the Vaaran
smooth scrolling, the mic and the saved shabads are untouched.
"""
import pathlib

root = pathlib.Path(__file__).resolve().parents[1]
app = root / "www" / "app.js"
src = app.read_text(encoding="utf-8")


def rep(old, new):
    global src
    n = src.count(old)
    assert n == 1, f"anchor found {n}x (want 1): {old[:90]!r}"
    src = src.replace(old, new, 1)


# 1. fetchHukamnama cache check: require the full mark.
rep(" if(!force&&state.hukamnama&&state.hukamnama.date===key&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return state.hukamnama;",
    " if(!force&&state.hukamnama&&state.hukamnama.date===key&&state.hukamnama.full&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return state.hukamnama;")
# 2. ensureHukamnama cache check: same full requirement.
rep(" if(state.hukamnama&&state.hukamnama.date===key&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return;",
    " if(state.hukamnama&&state.hukamnama.date===key&&state.hukamnama.full&&Array.isArray(state.hukamnama.lines)&&state.hukamnama.lines.length)return;")
# 3. Mark the saved Hukamnama as full.
rep("lines:enriched,fetchedAt:Date.now(),stale:false};",
    "lines:enriched,fetchedAt:Date.now(),stale:false,full:true};")

app.write_text(src, encoding="utf-8")
print("fix-v315 applied: Hukamnama cache re-fetches an old partial once")
