#!/usr/bin/env python3
"""v2.2.94 (GSv314) — Hukamnama shows full, exactly as at Harmandir Sahib.
His report 2026-11-24: the Hukamnama 'is not shown full... Just a partial
of it', sometimes. His go 2026-11-24 11:09: 'build the hukumnama however
it is shown in the Harmandir Sahib. The same I don't want to change
anything.'

Root cause (measured against BaniDB today, 2026-11-24): the Hukamnama is
8 shabads, 42 lines, Ang 704-705 (a Salok + a Chhant, repeated 4 times).
fetchHukamnama() read only (data.shabads||[])[0] — the first shabad, 5
lines, just the opening Salok. That is exactly what his screenshot shows.
The other 7 shabads (37 lines) were never read. On days when the
Hukamnama is a single shabad it looked full; on multi-part days it
looked partial.

Change (1 thing, in www/app.js, fetchHukamnama only): read EVERY shabad
in the BaniDB response, in order, and join all their verses into the
one lines array. The header (Ang, Raag, writer) still comes from the
first shabad, and the 'Read the full Ang' button still goes to that
Ang. Nothing else changes: the Hukamnama page already renders every
line in state.hukamnama.lines (no truncation there), the layout and
styling are untouched, and the mic, Ask page and saved pages are
untouched. The Hukamnama is shown exactly as BaniDB (Harmandir Sahib)
gives it — nothing added, nothing removed.
"""
import pathlib

root = pathlib.Path(__file__).resolve().parents[1]
app = root / "www" / "app.js"
src = app.read_text(encoding="utf-8")

old = """  const shabad=(data.shabads||[])[0];
  if(!shabad||!Array.isArray(shabad.verses)||!shabad.verses.length)throw new Error('Hukamnama empty');
  const info=shabad.shabadInfo||{};
  const lines=shabad.verses.map(hukamMapVerse).filter(l=>l.g);"""
new = """  // v2.2.94: a Hukamnama can span several shabads (today: 8 parts, 42
  // lines, Ang 704-705). BaniDB returns them all; read every one, in
  // order, so the Hukamnama shows full exactly as at Harmandir Sahib.
  // The old code read only shabads[0] (the opening Salok), so on
  // multi-part days it showed a partial.
  const allShabads=(data.shabads||[]).filter(s=>s&&Array.isArray(s.verses)&&s.verses.length);
  if(!allShabads.length)throw new Error('Hukamnama empty');
  const shabad=allShabads[0];
  const info=shabad.shabadInfo||{};
  const lines=allShabads.flatMap(s=>s.verses.map(hukamMapVerse)).filter(l=>l.g);"""
assert src.count(old) == 1, f"fetchHukamnama anchor found {src.count(old)}x"
src = src.replace(old, new, 1)
app.write_text(src, encoding="utf-8")
print("fix-v314 applied: fetchHukamnama reads all shabads")
