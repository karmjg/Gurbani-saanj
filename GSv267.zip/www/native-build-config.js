window.GS_BUILD={"version":"2.2.47","repo":"","hideAiSettings":false};
