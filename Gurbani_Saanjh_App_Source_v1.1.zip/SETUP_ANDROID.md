# Gurbani Saanjh v1.1 — Android APK (not a website)

This is an Android APP PROJECT for building a signed installable APK through GitHub Actions. It is not itself an APK. There is no need for GitHub Pages.

## Step 1 — Create your repository
1. Sign in at github.com and create a repository called `gurbani-saanjh`.
2. You can start with a **private** repository for your personal trial.
3. Extract `Gurbani_Saanjh_Android_v1.1_GitHub_Source.zip` and upload the **contents** to the repository root, preserving `.github/workflows/android-apk.yml`, `www/`, `src/`, `scripts/`, `native-icons/`, and all root files. If using a phone, GitHub web uploads of nested folders can be awkward; a computer or GitHub Desktop is easier.
4. Do NOT upload the separate `PRIVATE_SIGNING_BACKUP` file or `.jks` to GitHub.

## Step 2 — Configure four GitHub Actions secrets (one time)
Go to your repository → Settings → Secrets and variables → Actions → New repository secret.
Open the **separate private signing backup** ZIP we supplied and copy the four exact values from `GITHUB_SECRETS_PRIVATE.txt`:
- `ANDROID_KEYSTORE_BASE64`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

All four are required. Keep the private backup somewhere safe and offline. Losing the signing key means you cannot issue in-place updates to that installed app. Keep it out of source control, messages and screenshots.

## Step 3 — Build the first signed APK
1. Go to **Actions → Build Gurbani Saanjh Android APK**.
2. Select **Run workflow → main → Run workflow** (or wait for the workflow started by your upload).
3. When the run shows green success, open it and find **Artifacts → Gurbani-Saanjh-Android-APK**.
4. Download the artifact ZIP and extract the single `.apk` file.
5. On your Samsung phone, open that APK via My Files → Downloads and confirm Android's **Install** request. If prompted, temporarily allow 'Install unknown apps' for My Files/Chrome.
6. Launch the new **ਗੁਰਬਾਣੀ ਸਾਂਝ** icon.

## Step 4 — Subsequent updates: no uninstall
1. Edit the same source repository. Keep `appId` as `com.gurbanisaanjh.app` and do not change the four signing secrets.
2. Change version in `package.json` and `www/version.json` (example: 1.1.1); the Android versionCode is assigned from the GitHub Actions run number and increases on every run.
3. Trigger Actions → Build Gurbani Saanjh Android APK again; download the new APK.
4. Open the new APK and Android offers **Update** for the installed app. Existing app storage normally stays intact. Do not clear app data; export backups before risky changes.

## Optional — use 'Check for updates' inside the app
The in-app update checker reads the **latest PUBLIC GitHub Release** for this repository. To use it:
- The GitHub repo/release must be publicly readable, or you need a separately designed private update service. A private repo is fine for the initial trial, but in-app public GitHub update checking will not work from private releases.
- After building the APK, create a GitHub Release with a tag matching package.json (`v1.1.0` for this build). The tag-triggered workflow signs the APK and attaches it to the release.
- When a newer release is published, open the installed app → Settings → Check for updates → tap again when it reports an update; a GitHub download opens. Install the APK over the old one. Android always asks for installation approval.
- This is APK update checking and downloading, **not silent automatic APK installation**. It requires Internet access for the check/download; reading the bundled trial works offline.

## Important scope
This v1.1 is a private test build based on the approved premium interface, with existing sample reading, adjustable font/theme, Punjabi and English, scroll/book mode, draggable 3D cards, saved settings/bookmarks and trial progress.

NOT included: full verified Sri Guru Granth Sahib Ji, Sri Dasam Granth Sahib or Bhai Gurdas Ji corpus; complete Ang; licensed recitation recordings; synced word highlighting; real source-grounded AI; recurring scheduled Android notifications. Existing trial excerpt texts/meanings are only illustrative and must not be mistaken for complete authenticated text.

## Why there is no ready-to-install APK in this download
The source was assembled in an environment without an Android SDK or online dependency downloads. The GitHub Actions workflow is designed to compile/sign the APK on GitHub runners, but it must be run and verified on your repository. Android build and on-phone installation have not yet been performed.

## Tech details
- Capacitor 8 / Android 16 SDK API 36 / Java 21 / Node 22.
- App ID is `com.gurbanisaanjh.app`; preserve it permanently.
- Native content is bundled inside the APK; no live website required.
- App settings currently use the same internal localStorage key, `gurbani-saanjh-trial-v1`, for migration between native APK builds. Note that Chrome/PWA storage does not automatically migrate into an Android APK.
- Code is stored in `www/`, and the native Android project is regenerated by `npx cap add android` during GitHub Actions; do not commit secrets.
- Build artifact names indicate the package version; versionCode advances via GitHub workflow run number.
- Android APK must be signed with the SAME private key for every release to upgrade an installed app.
