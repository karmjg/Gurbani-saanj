# Changelog

## v1.1.0 — Android APK project
- Converted the v1.0 premium home/reader personal-trial files into a Capacitor 8 Android build project.
- Added an Android GitHub Actions workflow to compile a SIGNED APK for direct install.
- Added an in-app GitHub Releases update checker for public repository releases; no website/PWA installation needed.
- Preserved existing reader settings and saved-data keys in the native app.
- Uses the chosen clean cream/green/gold app icon.
- No complete Gurbani collection, licensed paath audio or live AI is claimed or included.
