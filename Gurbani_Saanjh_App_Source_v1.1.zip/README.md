# ਗੁਰਬਾਣੀ ਸਾਂਝ — Android Personal Trial v1.1

**Actual Android APK source**, not a GitHub Pages website. See [SETUP_ANDROID.md](SETUP_ANDROID.md) for step-by-step GitHub upload, signing, building, installation and updates.

The UI is bundled in `www/` and wrapped with Capacitor 8. A signed APK is built in GitHub Actions using your privately stored permanent signing key. No APK is included in this source ZIP because the Android toolchain is unavailable locally.

This is an early personal trial. All sample scripture content and meanings require verification before a public release.
