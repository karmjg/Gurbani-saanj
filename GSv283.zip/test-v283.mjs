/* Gurbani Saanj v2.2.63 — Kirtan heart saves + heart tap stays put + Saved tab
 * gets a delete button (Karamjit, 2026-11-13):
 * (1) KIRTAN HEART DID NOT SAVE. On the Kirtan Shabads screen each row shows
 * a heart (♡) next to the › arrow, but tapping it did NOT save the Shabad —
 * it stayed ♡ and never appeared in the Saved tab (screenshot from his phone).
 * ROOT CAUSE: the save branch (data-save-hit handler) looked the line up via
 * window.GS_SCRIPTURE_SEARCH.lookup(ang, idx), and lookup() reads lookupMap —
 * which is only built by load(), which is only called by query(), i.e. only
 * by a SEARCH. The Kirtan screen (ensureKirtanBook) loads kirtan-shabads.json
 * but never loads the search index, so on the Kirtan screen lookupMap is an
 * EMPTY Map and lookup() returns null — and the old code did `if(match)...`
 * with no fallback, so the save silently did nothing. Verified against the
 * real data: all 1,618 Kirtan Shabads DO have a lookupMap entry (ang:lineStart
 * matches the search index, e.g. Ang 702 lineStart 16 = 'ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ
 * ਸਰਣੀ ॥'), so the KEY is right — the index just is not loaded yet. The
 * v2.2.60 test masked this: it mocked lookup() to always return a match.
 * FIX: when lookup() returns null, fall back to the Kirtan book itself —
 * kirtanBookList already has the Shabad (ang + lineStart + firstLine), so
 * save {ang, idx, g: firstLine} from there. The heart now fills even before
 * any search. The A–Z strip is NOT the cause: in his screenshot the strip
 * sits clear of the hearts (a gap between the heart button and the strip),
 * and the tap does reach the save handler — it was the lookup that failed.
 * (2) STAY PUT ON HEART TAP. He reports tapping a heart in search (or the
 * Kirtan book) "goes straight into Saved". The save handler never called
 * go('bookmarks') — there is no such call anywhere — but the old handler did
 * a full render() after every heart tap, which rebuilds the whole screen:
 * on search it wipes the results AND the query (searchScreen has no preserved
 * input value and run() is not called on attach), on Kirtan it flashes the
 * "Opening the book…" placeholder and can jump the scroll. FIX: a save-hit
 * tap now updates the tapped heart IN PLACE (class + ♡/♥) and refreshes the
 * Kirtan Saved section in place — no full render, so the tap saves and stays
 * on the current screen (search / Kirtan), never navigates, never wipes the
 * results, never jumps the scroll. A remove (data-remove-saved) still does a
 * full render() so the saved list updates. The Saved tab reads
 * state.savedVerses when it is opened.
 * (3) DELETE IN SAVED. The Saved tab (bookmarksScreen) had NO way to remove
 * a saved item — each row was an open button only. Now every saved row is an
 * item-row with the open button AND a ♥ data-remove-saved button (same as the
 * Kirtan screen's Saved list), using the existing remove handler. The remove
 * tap only removes that item (and re-renders Saved), never opens it: the
 * open button is a sibling of the remove button, never its parent, and the
 * found/open checks run before the save/remove check.
 * Kept from v2.2.62: language-toggle hang fix (ensureHukamnama guards), no
 * Mool Mantar in the drawer, Kirtan heart, ensureCatalog, icon row gone,
 * clock after ਪੁ/EN, pills nowrap. No Help button (cancelled).
 * Run: node test-v283.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.63', vj.version === '2.2.63');
ok('package.json is 2.2.63', pj.version === '2.2.63');
ok('native-build-config.js is 2.2.63', nbc.includes('"version":"2.2.63"'));
ok('version notes mention v2.2.63 + Kirtan heart + stay put + Saved remove',
  vj.notes.includes('v2.2.63:') && vj.notes.includes('Kirtan heart') && vj.notes.includes('stays on the current screen') && vj.notes.includes('remove button'));

// ---- 1. The fix, statically ----
ok('Kirtan fallback present: save falls back to kirtanBookList when lookup() is null',
  app.includes('Kirtan book fallback') &&
  app.includes('const kb=Array.isArray(kirtanBookList)?kirtanBookList:[];') &&
  app.includes('const s=kb.find(x=>x.ang===ang&&x.lineStart===idx);') &&
  app.includes("if(s&&s.firstLine){state.savedVerses.unshift({ang,idx,g:s.firstLine});added=true;}"));
ok('stay-put: save-hit tap updates the heart in place (class + ♡/♥), no render() on that path',
  app.includes("save.classList.toggle('selected',added);") &&
  app.includes("save.textContent=added?'♥':'♡';") &&
  app.includes('refreshKirtanSavedSection();'));
ok('stay-put: the save branch does NOT do persist()+render() for a save-hit (old pattern gone)',
  !app.includes('if(match)state.savedVerses.unshift({ang,idx,g:match.g})}persist();render();return}'));
ok('stay-put: remove (data-remove-saved) still re-renders so the saved list updates',
  app.includes("if(save.hasAttribute('data-remove-saved')){render();}"));
ok('stay-put: no navigation to bookmarks anywhere in the save path (no go(bookmarks))',
  !app.includes("go('bookmarks')") && !app.includes('view=\'bookmarks\'') && !app.includes('view="bookmarks"'));
ok('Kirtan Saved section extracted: kirtanSavedSectionHTML + refreshKirtanSavedSection exist, screen uses the container',
  app.includes('function kirtanSavedSectionHTML(){') &&
  app.includes('function refreshKirtanSavedSection(){') &&
  app.includes('<div id="kirtanSavedSection">${kirtanSavedSectionHTML()}</div>'));
ok('Saved tab: every saved row has a remove control (data-remove-saved ♥), open button is its sibling',
  (() => {
    const bm = app.split('\n').find(l => l.startsWith('function bookmarksScreen(){'));
    return !!bm && bm.includes('data-remove-saved="${Number(v.ang)}:${Number(v.idx)}"') &&
      bm.includes('data-remove-saved="bani:${v.baniId}:${Number(v.idx)}"') &&
      bm.includes('class="simple-card item-row"') &&
      // remove button follows the closing </button> of the open button (sibling, never nested)
      bm.includes('</button><button data-remove-saved=');
  })());
ok('Saved tab: tapping a saved row still opens it (open button keeps data-open-saved-ang/bani)',
  (() => {
    const bm = app.split('\n').find(l => l.startsWith('function bookmarksScreen(){'));
    return !!bm && bm.includes('data-open-saved-ang="${Number(v.ang)}"') && bm.includes('data-open-saved-bani="${v.baniId}"');
  })());
ok('handler order: save/remove is checked BEFORE the Kirtan open, and open-saved before save',
  (() => {
    const h = app.indexOf("const found=e.target.closest('[data-found-ang],[data-open-saved-ang]');");
    const s = app.indexOf("const save=e.target.closest('[data-save-hit],[data-remove-saved]');");
    const k = app.indexOf("const ks=e.target.closest('[data-kirtan-shabad]');");
    return h !== -1 && s !== -1 && k !== -1 && h < s && s < k;
  })());
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 2. v2.2.62 markers intact ----
ok('v2.2.62: language-toggle hang guards still in ensureHukamnama',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.60: Kirtan heart button still on each Shabad row (♡/♥, data-save-hit ang:lineStart)',
  app.includes('class="favorite') && app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: History clock still AFTER the ਪੁ/EN button in the search box',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));

// ---- 3. vm: the REAL save branch + Kirtan saved section + Saved tab ----
// Extract real functions verbatim (markers, not line numbers).
const _lines = app.split('\n');
function extractFn(lines, startPrefix) {
  const s = lines.findIndex(l => l.startsWith(startPrefix));
  if (s === -1) return '';
  let e = s;
  while (e < lines.length && lines[e] !== '}') e++;
  return lines.slice(s, e + 1).join('\n');
}
// Brace-matched block extraction (the save branch is multi-line now).
function extractBlock(lines, startMarker) {
  const s = lines.findIndex(l => l.includes(startMarker));
  if (s === -1) return '';
  let depth = 0, e = s;
  for (; e < lines.length; e++) {
    for (const ch of lines[e]) { if (ch === '{') depth++; else if (ch === '}') depth--; }
    if (e > s && depth === 0) break;
  }
  return lines.slice(s, e + 1).join('\n');
}
const markupSrc = extractFn(_lines, 'function scriptureResultsMarkup(');
const kirtanSavedSrc = extractFn(_lines, 'function kirtanSavedSectionHTML(){');
const refreshSrc = extractFn(_lines, 'function refreshKirtanSavedSection(){');
const bookmarksLine = _lines.find(l => l.startsWith('function bookmarksScreen(){'));
const saveBranch = extractBlock(_lines, "const save=e.target.closest('[data-save-hit],[data-remove-saved]');");
ok('vm: markup + Kirtan saved section + refresh + Saved tab + save branch extractable from app.js',
  markupSrc.includes('data-save-hit') && kirtanSavedSrc.includes('kirtanSavedSection') &&
  refreshSrc.includes("kirtanSavedSection") && !!bookmarksLine && saveBranch.includes('Kirtan book fallback'));

// Real Kirtan book entries (from www/offline/kirtan-shabads.json).
const KIRTAN = [
  { id: 'k73', firstLine: 'ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥', raag: 'ਰਾਗੁ ਜੈਤਸਰੀ', mahla: 'ਮਹਲਾ ੫', ang: 702, lineStart: 16, lineCount: 6 },
  { id: 'k1', firstLine: 'ਓਅੰ ਸਾਧ ਸਤਿਗੁਰ ਨਮਸਕਾਰੁ ॥', raag: 'ਰਾਗੁ ਗਉੜੀ', mahla: 'ਮਹਲਾ ੫', ang: 250, lineStart: 0, lineCount: 8 },
];
const escFn = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function makeCtx(view) {
  const state = { view, lang: 'pa', showTranslit: true, savedVerses: [] };
  let persistN = 0, renderN = 0;
  const savedBox = { innerHTML: '' };
  const sandbox = {
    state, console,
    age: (pa, en) => state.lang === 'pa' ? pa : en,
    esc: escFn,
    t: (k) => ({ ang: 'ਅੰਗ', kirtan: 'ਕੀਰਤਨ' }[k] || k),
    persist: () => { persistN++; },
    render: () => { renderN++; },
    kirtanBookList: KIRTAN,
    // lookup() returns null for the Kirtan rows: the search index (lookupMap)
    // is NOT loaded on the Kirtan screen — the exact real-world failure.
    // It returns a match for the search case (244:0), where the index IS loaded.
    window: {
      GS_SCRIPTURE_SEARCH: {
        lookup: (ang, idx) => (ang === 244 && idx === 0) ? { g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥' } : null,
        lookupBani: (baniId, idx) => (baniId === 4 && idx === 0) ? { g: 'ਜਾਪੁ ਸਾਹਿਬ ਪਹਿਲੀ ਲਾਈਨ', baniTitle: 'Jaap Sahib', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam' } : null,
      },
    },
    $: (id) => (id === 'kirtanSavedSection' ? savedBox : null),
  };
  vm.createContext(sandbox);
  vm.runInContext(markupSrc + '\n' + kirtanSavedSrc + '\n' + refreshSrc + '\n' + bookmarksLine + '\nfunction __saveTap(e){' + saveBranch + '}', sandbox);
  return {
    state, savedBox, sandbox,
    get persistN() { return persistN; },
    get renderN() { return renderN; },
    tap(el) { sandbox.__ev = { target: { closest: (sel) => (sel.includes('data-save-hit') || sel.includes('data-remove-saved')) ? el : null } }; vm.runInContext('__saveTap(__ev)', sandbox); },
    bookmarks() { return vm.runInContext('bookmarksScreen()', sandbox); },
    kirtanSaved() { return vm.runInContext('kirtanSavedSectionHTML()', sandbox); },
  };
}
function fakeHeart(key, field, isRemove) {
  const el = {
    dataset: { [field]: key },
    _cls: new Set(),
    classList: {
      toggle: (c, force) => { if (force) el._cls.add(c); else el._cls.delete(c); },
      contains: (c) => el._cls.has(c),
    },
    textContent: '♡',
    hasAttribute: (a) => (a === 'data-remove-saved') === !!isRemove,
    closest: () => null,
  };
  return el;
}

// (a) KIRTAN HEART SAVES even when the search index / lookupMap is NOT loaded.
{
  const t = makeCtx('kirtan');
  const heart = fakeHeart('702:16', 'saveHit', false);
  t.tap(heart);
  ok('(a) Kirtan heart: tap ♡ saves the Shabad even with lookup() returning null (Kirtan fallback)',
    t.state.savedVerses.length === 1 && t.state.savedVerses[0].ang === 702 && t.state.savedVerses[0].idx === 16 &&
    t.state.savedVerses[0].g === 'ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥', JSON.stringify(t.state.savedVerses));
  ok('(a) Kirtan heart: the heart fills red ♥ in place',
    heart.textContent === '♥' && heart.classList.contains('selected'));
  ok('(a) Kirtan heart: no full render on the tap (stay-put, no navigation, no flicker)',
    t.renderN === 0 && t.persistN === 1, `renderN=${t.renderN} persistN=${t.persistN}`);
  ok('(a) Kirtan heart: view stays on Kirtan (never jumps to Saved)',
    t.state.view === 'kirtan');
  ok('(a) Kirtan heart: the Kirtan Saved section refreshes in place (count 1 + the Shabad listed)',
    t.savedBox.innerHTML.includes('ਸੰਭਾਲੇ ਹੋਏ ਸ਼ਬਦ') && t.savedBox.innerHTML.includes('ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥') &&
    t.savedBox.innerHTML.includes('(1)'), t.savedBox.innerHTML.slice(0, 200));
  ok('(a) Kirtan heart: Saved tab lists the saved Shabad (Ang 702)',
    t.bookmarks().includes('ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥') && t.bookmarks().includes('702'));
  // Tap again → removes it, heart back to ♡, still no render, still on Kirtan.
  t.tap(heart);
  ok('(a) Kirtan heart: tap ♥ again removes it (toggle), heart back to ♡',
    t.state.savedVerses.length === 0 && heart.textContent === '♡' && !heart.classList.contains('selected') && t.renderN === 0,
    JSON.stringify(t.state.savedVerses));
}

// (b) SEARCH HEART SAVES and stays in search.
{
  const t = makeCtx('search');
  const heart = fakeHeart('244:0', 'saveHit', false);
  t.tap(heart);
  ok('(b) search heart: tap ♡ saves the result (lookup match) and the heart fills ♥',
    t.state.savedVerses.length === 1 && t.state.savedVerses[0].ang === 244 && heart.textContent === '♥' &&
    heart.classList.contains('selected'), JSON.stringify(t.state.savedVerses));
  ok('(b) search heart: NO full render on the tap (results + query stay, no wipe)',
    t.renderN === 0 && t.persistN === 1, `renderN=${t.renderN}`);
  ok('(b) search heart: view stays on search (never jumps to Saved/bookmarks)',
    t.state.view === 'search');
  // The search result row itself still renders a ♥ for the saved item.
  t.sandbox.__rows = [{ src: 'sggs', ang: 244, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', roman: 'mil mere preetamaa jeeo', en: '' }];
  const m = vm.runInContext('scriptureResultsMarkup(__rows,{save:true})', t.sandbox);
  ok('(b) search heart: the saved result now shows ♥ in its row',
    m.includes('data-save-hit="244:0"') && m.includes('♥'));
  // Tap again → removes, heart back to ♡.
  t.tap(heart);
  ok('(b) search heart: tap ♥ again removes it',
    t.state.savedVerses.length === 0 && heart.textContent === '♡', JSON.stringify(t.state.savedVerses));
}

// (c) KIRTAN HEART STAYS IN KIRTAN (explicit, second Shabad, no search ever run).
{
  const t = makeCtx('kirtan');
  const heart = fakeHeart('250:0', 'saveHit', false);
  t.tap(heart);
  ok('(c) Kirtan heart (2nd Shabad): saves via the Kirtan fallback and stays on Kirtan, no render',
    t.state.savedVerses.length === 1 && t.state.savedVerses[0].ang === 250 && t.state.view === 'kirtan' && t.renderN === 0,
    JSON.stringify(t.state.savedVerses));
}

// (d) SAVED TAB: remove control per item, removes only that item.
{
  const t = makeCtx('bookmarks');
  // Save two items first (one via search lookup, one via Kirtan fallback).
  t.tap(fakeHeart('244:0', 'saveHit', false));
  t.state.view = 'bookmarks';
  const t2 = makeCtx('bookmarks');
  t2.state.savedVerses = [
    { ang: 244, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥' },
    { ang: 702, idx: 16, g: 'ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥' },
  ];
  const bm = t2.bookmarks();
  ok('(d) Saved tab: every saved row shows a remove control (data-remove-saved ♥)',
    bm.includes('data-remove-saved="244:0"') && bm.includes('data-remove-saved="702:16"') &&
    (bm.match(/data-remove-saved=/g) || []).length === 2, bm.slice(0, 300));
  ok('(d) Saved tab: every saved row still has its open button (data-open-saved-ang)',
    bm.includes('data-open-saved-ang="244"') && bm.includes('data-open-saved-ang="702"'));
  // Remove only the first item.
  const rm = fakeHeart('244:0', 'removeSaved', true);
  const before = t2.renderN;
  t2.tap(rm);
  ok('(d) Saved tab: tapping remove deletes ONLY that item, the other stays',
    t2.state.savedVerses.length === 1 && t2.state.savedVerses[0].ang === 702, JSON.stringify(t2.state.savedVerses));
  ok('(d) Saved tab: remove re-renders Saved (list updates) and stays on the Saved tab',
    t2.renderN === before + 1 && t2.state.view === 'bookmarks', `renderN=${t2.renderN}`);
  const bm2 = t2.bookmarks();
  ok('(d) Saved tab: after removal the list shows only the remaining Shabad',
    !bm2.includes('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ') && bm2.includes('ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥'));
}

// (e) TAPPING A SAVED ROW ITSELF STILL OPENS IT (structural: open button is a
// sibling of the remove button, and the open-saved check runs before save).
{
  const t = makeCtx('bookmarks');
  t.state.savedVerses = [{ ang: 702, idx: 16, g: 'ਆਏ ਅਨਿਕ ਜਨਮ ਭ੍ਰਮਿ ਸਰਣੀ ॥' }];
  const bm = t.bookmarks();
  ok('(e) saved row: the remove button is a SIBLING of the open button (never nested inside it)',
    bm.includes('</button><button data-remove-saved="702:16"'));
  ok('(e) saved row: the open-saved check runs before the save/remove check in the handler',
    app.indexOf("[data-found-ang],[data-open-saved-ang]") < app.indexOf("[data-save-hit],[data-remove-saved]"));
  ok('(e) saved row: tapping the row (open button) is not a save/remove tap — closest(save) is null for it',
    (() => {
      // A tap on the open button: its closest('[data-save-hit],[data-remove-saved]') is null,
      // so the save branch is skipped and the open branch runs.
      const openBtn = { dataset: { openSavedAng: '702', openSavedIdx: '16' }, closest: (sel) => sel.includes('data-open-saved-ang') ? openBtn : null };
      return openBtn.closest('[data-save-hit],[data-remove-saved]') === null &&
        openBtn.closest('[data-found-ang],[data-open-saved-ang]') === openBtn;
    })());
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
