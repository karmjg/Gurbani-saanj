/* Gurbani Saanj v2.2.13 — functional checks (node, offline).
 *  1. Interleaved AI answer: verse -> its explanation, one at a time
 *     (prompt in app.js + ai-server/cloudflare-worker.mjs).
 *  2. AI answer renders at the top, right under the question;
 *     related Shabads below it.
 *  3. Ask shows only the current (latest) question; old ones hidden
 *     (stored history untouched, still used for follow-up context).
 * Run: node test-v233.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

// ---- 0. Version ----
ok('version.json is 2.2.13', vj.version === '2.2.13');
ok('package.json is 2.2.13', pj.version === '2.2.13');

// ---- 1. Interleaved prompt (app + worker) ----
const INTERLEAVED = 'one at a time: quote the first verse exactly as given, in Gurmukhi, with its Ang number, then explain that verse';
ok('app prompt: interleaved, one verse at a time',
  app.includes(INTERLEAVED.replace("verse's", "verse\\'s")));
ok('worker prompt: interleaved, one verse at a time',
  worker.includes(INTERLEAVED));
ok('app prompt: never quote all verses first',
  app.includes('Never quote all the verses first and explain them afterwards'));
ok('worker prompt: never quote all verses first',
  worker.includes('Never quote all the verses first and explain them afterwards'));
ok('app prompt: total saar still follows the last verse',
  app.includes('After the last verse and its explanation, explain the reasoning behind them'));
ok('worker prompt: total saar still follows the last verse',
  worker.includes('After the last verse and its explanation, explain the reasoning behind them'));
ok('app prompt: old all-verses-first wording gone',
  !app.includes('Quote 2-3 relevant Gurbani verses FIRST'));
ok('worker prompt: old all-verses-first wording gone',
  !worker.includes('Quote 2-3 relevant Gurbani verses FIRST'));
ok('app prompt: never-explain line updated',
  app.includes('Never explain a verse before quoting it') && !app.includes('Never explain without quoting the verse first'));
ok('worker prompt: never-explain line updated',
  worker.includes('Never explain a verse before quoting it') && !worker.includes('Never explain without quoting the verse first'));
ok('app prompt: GGS-only guardrail intact',
  app.includes('Answer ONLY from these passages'));
ok('worker prompt: GGS-only guardrail intact',
  worker.includes('Answer ONLY from these passages'));

// ---- 2 + 3. renderQA order + latest-only (static) ----
const rqStart = app.indexOf('function renderQA(v){');
const rqEnd = app.indexOf('\n}\n', rqStart) + 3;
const rqSrc = app.slice(rqStart, rqEnd);
ok('renderQA: AI answer block comes before related-Shabads block',
  rqSrc.indexOf("t('aiAnswerLabel')") < rqSrc.indexOf("t('relatedOffline')"));
ok('askScreen renders only the latest question',
  app.includes('renderQA(state.questions[state.questions.length-1])'));
ok('askScreen no longer maps all questions',
  !app.includes('state.questions.map(renderQA)'));
ok('stored history untouched for follow-up context',
  app.includes('state.questions.push(entry)') && app.includes('state.questions.slice(-12)') && app.includes('state.questions.slice(-3)'));
ok('toast says related Shabads are shown below',
  app.includes('related Shabads are shown below'));
ok('toast no longer says above',
  !app.includes('related Shabads are shown above'));

// ---- Functional: renderQA in a vm with mocks ----
const ctx = {
  t: k => k,
  esc: s => String(s ?? ''),
  age: (pa, en) => en,
  scriptureResultsMarkup: () => '[[SOURCES]]',
  state: { aiApiKey: '', aiEndpoint: '' },
};
vm.createContext(ctx);
vm.runInContext(rqSrc + '\n;globalThis.__renderQA=renderQA;', ctx);
const renderQA = ctx.__renderQA;

const answered = {
  q: 'QUESTION_MARKER Guru kon hai?',
  matches: [{ ang: 8, idx: 0, g: 'ਪਵਣੁ ਗੁਰੁ ਪਾਣੀ ਪਿਤਾ' }],
  answer: 'ANSWER_MARKER (1) ਪਵਣੁ ਗੁਰੁ ਪਾਣੀ ਪਿਤਾ (Ang 8) — explanation here.',
  answerSource: 'your API key', aiError: '', aiPending: false,
};
const html = renderQA(answered);
ok('renderQA: question first, then AI answer, then sources',
  html.indexOf('QUESTION_MARKER') < html.indexOf('ANSWER_MARKER') &&
  html.indexOf('ANSWER_MARKER') < html.indexOf('[[SOURCES]]'),
  `q@${html.indexOf('QUESTION_MARKER')} a@${html.indexOf('ANSWER_MARKER')} s@${html.indexOf('[[SOURCES]]')}`);
ok('renderQA: AI answer label present', html.includes('aiAnswerLabel'));

const failed = {
  q: 'Q2', matches: [{ ang: 8, idx: 0, g: 'x' }],
  answer: '', aiError: 'AI API returned 503', aiPending: false,
};
const htmlErr = renderQA(failed);
ok('renderQA: error shows before sources when AI fails',
  htmlErr.includes('AI API returned 503') &&
  htmlErr.indexOf('AI API returned 503') < htmlErr.indexOf('[[SOURCES]]'));

const noKey = {
  q: 'Q3', matches: [{ ang: 8, idx: 0, g: 'x' }],
  answer: '', aiError: '', aiPending: false,
};
const htmlNoKey = renderQA(noKey);
ok('renderQA: needs-key hint shows when no key/server',
  htmlNoKey.includes('aiNeedsKey'));

// Latest-only simulation: askScreen renders one card, the latest entry.
const entries = [
  { q: 'OLD_Q1', matches: [], answer: '', aiError: '', aiPending: false },
  { q: 'OLD_Q2', matches: [], answer: '', aiError: '', aiPending: false },
  { q: 'LATEST_Q3', matches: [{ ang: 8, idx: 0, g: 'x' }], answer: 'A3', aiError: '', aiPending: false },
];
const latestOnly = entries.length ? renderQA(entries[entries.length - 1]) : '';
ok('latest-only: only the newest question renders',
  latestOnly.includes('LATEST_Q3') && !latestOnly.includes('OLD_Q1') && !latestOnly.includes('OLD_Q2'));

// ---- Regression: v2.2.12 behaviours intact ----
ok('v2.2.12: reader Ang-jump box passes sahaj=true',
  app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.12: Library Ang picker passes sahaj=true',
  app.includes("openAng($('angPicker')?.value||displayAng(),false,true)"));
ok('v2.2.12: kirtan first-letter helpers intact',
  app.includes('const kirtanWords=') && app.includes('gsAlphaKey'));
ok('v2.2.11: real AI error display intact',
  app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines',
  app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
