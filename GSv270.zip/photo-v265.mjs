/* Gurbani Saanj v2.2.45 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a fresh profile
 * (945x2051), and captures 5 photos:
 *   v2.2.45-photo-chaupai-dohra.png — Chaupai Sahib (Nitnem) with the
 *     "ਸ੍ਵੈਯਾ ॥" and "ਦੋਹਰਾ ॥" headings CENTRED in the middle
 *   v2.2.45-photo-akalustat-dohra.png — Akal Ustat (catalog / Anek Baniyaan)
 *     with a "ਦੋਹਰਾ ॥" heading CENTRED
 *   v2.2.45-photo-nitnem-rakhia.png — Nitnem screen: all 8 Banis, with
 *     "ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ" 7th between Rehras and Kirtan Sohila
 *   v2.2.45-photo-rakhia-reader.png — Rakhia De Shabad reader, first lines
 *   v2.2.45-photo-pauri.png — Asa Di Vaar (catalog / Anek Baniyaan) with a
 *     "ਪਉੜੀ ॥" heading CENTRED
 * Also asserts in the live app: the headings carry the gs-verse-heading
 * class (CSS centres them) and sit centred in the viewport; the Nitnem
 * list has 8 rows in the right order; the Rakhia reader shows all 6
 * shabads in order with the 4 headings centred; the Pauri heading is
 * centred and the "ਦੁਰਗਾ ਪਾਠ ਬਣਾਇਆ ਸਭੇ ਪਉੜੀਆਂ ॥" verse line is not.
 * Run: node photo-v265.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME,
  args: ['--disable-dev-shm-usage'] }); // /dev/shm is only 794MB — without this the renderer crashes on this heavy page
const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
await page.goto(base, { waitUntil: 'load' });
await page.waitForTimeout(5000); // bootData + kosh load + first render + kosh re-render settle (clicking during the kosh re-render crashes the renderer)

// app.js is an IIFE, so go()/openBani() are NOT globals — navigate through
// the UI exactly as a user would: home tiles (data-home-id) + bottom nav
// (data-view) + the Bani rows (data-remote-bani / data-catalog-id) + the
// browser Back button to leave a reader (popstate restores the view, like
// Android back). NEVER click [data-view="home"] while already on home:
// go('home') from home crashes the renderer (reproduced in diag2.mjs).
// Clicking home FROM another view is safe.
const goNitnemFromHome = async () => {
  await page.evaluate(() => document.querySelector('[data-home-id="nitnem"]')?.click());
  await page.waitForTimeout(900);
};
const goCatalogFromHome = async () => {
  await page.evaluate(() => document.querySelector('[data-home-id="catalog"]')?.click());
  await page.waitForTimeout(900);
};
const goHomeFromOther = async () => {
  await page.evaluate(() => document.querySelector('[data-view="home"]')?.click());
  await page.waitForTimeout(800);
};
const backToList = async () => {
  await page.goBack();
  await page.waitForTimeout(900);
};
const booted = await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]'));
ok('photo: app booted, home tiles present', booted);

// ---- Photo 3: Nitnem screen — 8 Banis, Rakhia De Shabad 7th ----
await goNitnemFromHome();
const nitnem = await page.evaluate(() => {
  const rows = [...document.querySelectorAll('.nitnem-page [data-remote-bani]')].map(b => ({
    id: Number(b.dataset.remoteBani), title: b.textContent.trim().replace(/›$/, '').trim(),
  }));
  return { rows, count: rows.length };
});
ok('photo: Nitnem screen lists 8 Banis', nitnem.count === 8, JSON.stringify(nitnem.rows.map(r => r.id)));
ok('photo: Rakhia De Shabad (130) is 7th, between Rehras (21) and Kirtan Sohila (23)',
  nitnem.rows.length === 8 && nitnem.rows[5].id === 21 && nitnem.rows[6].id === 130 && nitnem.rows[7].id === 23,
  JSON.stringify(nitnem.rows.map(r => `${r.id}:${r.title}`)));
await page.screenshot({ path: path.join(OUT, 'v2.2.45-photo-nitnem-rakhia.png') });

// ---- Photo 4: Rakhia De Shabad reader — first lines ----
await page.evaluate(() => document.querySelector('.nitnem-page [data-remote-bani="130"]').click());
await page.waitForTimeout(1200); // loadRemote fetch + render
const rakhia = await page.evaluate(() => {
  const txt = document.querySelector('#verses')?.textContent || '';
  const heads = [...document.querySelectorAll('#verses .gs-verse-heading .verse-text')].map(h => h.textContent.trim());
  return {
    hasFirst: txt.includes('ਸਿਰ ਮਸ੍ਤਕ ਰਖੵਾ'),
    hasSecond: txt.includes('ਘੋਰ ਦੁਖੰ'), // Sundar Gutka (photo) spelling, not SGGS ਦੁਖੵੰ
    hasSorath: txt.includes('ਗੁਰ ਕਾ ਸਬਦੁ ਰਖਵਾਰੇ'),
    hasBilawal: txt.includes('ਤਾਤੀ ਵਾਉ ਨ ਲਗਈ'),
    hasSalok256: txt.includes('ਜਹ ਸਾਧੂ ਗੋਬਿਦ'),
    hasSalok519: txt.includes('ਮਨ ਮਹਿ ਚਿਤਵਉ'),
    heads,
  };
});
ok('photo: Rakhia reader shows shabad 1 (ਸਿਰ ਮਸ੍ਤਕ…) + shabad 2 (ਘੋਰ ਦੁਖੰ…)',
  rakhia.hasFirst && rakhia.hasSecond, JSON.stringify(rakhia));
ok('photo: Rakhia reader shows all 6 shabads (Sorath, Bilawal, both Saloks)',
  rakhia.hasSorath && rakhia.hasBilawal && rakhia.hasSalok256 && rakhia.hasSalok519);
ok('photo: Rakhia reader has 4 centred headings (ਸੋਰਠਿ, ਬਿਲਾਵਲੁ, ਸਲੋਕੁ, ਸਲੋਕ ਮਃ ੫)',
  rakhia.heads.length === 4 && rakhia.heads[0].includes('ਸੋਰਠਿ') && rakhia.heads[1].includes('ਬਿਲਾਵਲੁ') &&
  rakhia.heads[2].includes('ਸਲੋਕੁ') && rakhia.heads[3].includes('ਸਲੋਕ'),
  JSON.stringify(rakhia.heads));
// The reader opens at the top — the first lines are already in view.
await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
await page.waitForTimeout(400);
await page.screenshot({ path: path.join(OUT, 'v2.2.45-photo-rakhia-reader.png') });
await backToList(); // back to the Nitnem screen

// ---- Photo 1: Chaupai Sahib (Nitnem) — Savaiya + Dohra headings centred ----
// Helper: open a Bani from the Nitnem screen and scroll a line into the middle.
const openNitnemBani = async (id) => {
  // Caller must already be on the Nitnem screen (after backToList).
  await page.evaluate((bid) => document.querySelector(`.nitnem-page [data-remote-bani="${bid}"]`).click(), id);
  await page.waitForTimeout(1200);
};
const scrollLineToMiddle = async (idx) => {
  await page.evaluate((i) => {
    const el = document.querySelector(`#verses [data-line="${i}"]`);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, idx);
  await page.waitForTimeout(600);
};
// A heading is centred when its text box is centred in the viewport
// (its centre x is within 60px of the viewport centre) AND the computed
// text-align is center.
const headingCentred = (idx) => page.evaluate((i) => {
  const el = document.querySelector(`#verses [data-line="${i}"]`);
  if (!el) return { found: false };
  const txt = el.querySelector('.verse-text');
  const r = txt.getBoundingClientRect();
  const vw = window.innerWidth;
  const centre = r.left + r.width / 2;
  return {
    found: true,
    text: txt.textContent.trim(),
    textAlign: getComputedStyle(txt).textAlign,
    headingClass: !!el.closest('.gs-verse-heading') || el.classList.contains('gs-verse-heading'),
    centreX: Math.round(centre), viewportCentre: Math.round(vw / 2),
    offBy: Math.round(Math.abs(centre - vw / 2)),
    visible: r.top > 0 && r.bottom < window.innerHeight,
  };
}, idx);

await openNitnemBani(9);
const chaupaiTitle = await page.evaluate(() => document.querySelector('.gs-bani-topbar-title')?.textContent || '');
ok('photo: Chaupai Sahib reader opened', chaupaiTitle.includes('ਚੌਪਈ'), JSON.stringify(chaupaiTitle));
await scrollLineToMiddle(122);
const sav = await headingCentred(122);
const doh = await headingCentred(127);
ok('photo: Chaupai Savaiya (idx122) is a centred heading',
  sav.found && sav.text.includes('ਸ੍ਵੈਯਾ') && sav.textAlign === 'center' && sav.headingClass && sav.offBy <= 60 && sav.visible,
  JSON.stringify(sav));
ok('photo: Chaupai Dohra (idx127) is a centred heading',
  doh.found && doh.text.includes('ਦੋਹਰਾ') && doh.textAlign === 'center' && doh.headingClass && doh.offBy <= 60 && doh.visible,
  JSON.stringify(doh));
await page.screenshot({ path: path.join(OUT, 'v2.2.45-photo-chaupai-dohra.png') });
await backToList(); // back to the Nitnem screen
await goHomeFromOther(); // home FROM nitnem (safe — only home-from-home crashes)
await goCatalogFromHome();

// ---- Photo 2: Akal Ustat (catalog / Anek Baniyaan) — Dohra heading centred ----
await page.evaluate(() => document.querySelector('[data-catalog-id="119"]').click());
await page.waitForTimeout(1200);
const akalTitle = await page.evaluate(() => document.querySelector('.gs-bani-topbar-title')?.textContent || '');
ok('photo: Akal Ustat reader opened from the catalog', akalTitle.includes('ਅਕਾਲ'), JSON.stringify(akalTitle));
await scrollLineToMiddle(822);
const akalDoh = await headingCentred(822);
ok('photo: Akal Ustat Dohra (idx822) is a centred heading',
  akalDoh.found && akalDoh.text.includes('ਦੋਹਰਾ') && akalDoh.textAlign === 'center' && akalDoh.headingClass && akalDoh.offBy <= 60 && akalDoh.visible,
  JSON.stringify(akalDoh));
await page.screenshot({ path: path.join(OUT, 'v2.2.45-photo-akalustat-dohra.png') });

// ---- Photo 5: Asa Di Vaar (catalog / Anek Baniyaan) — Pauri heading centred ----
await backToList(); // back to the catalog (we are in the Akal Ustat reader)
await page.evaluate(() => document.querySelector('[data-catalog-id="113"]').click());
await page.waitForTimeout(1200);
const asaTitle = await page.evaluate(() => document.querySelector('.gs-bani-topbar-title')?.textContent || '');
ok('photo: Asa Di Vaar reader opened from the catalog', asaTitle.includes('ਆਸਾ'), JSON.stringify(asaTitle));
await scrollLineToMiddle(20);
const pauri = await headingCentred(20);
ok('photo: Asa Di Vaar Pauri (idx20) is a centred heading',
  pauri.found && pauri.text === 'ਪਉੜੀ ॥' && pauri.textAlign === 'center' && pauri.headingClass && pauri.offBy <= 60 && pauri.visible,
  JSON.stringify(pauri));
await page.screenshot({ path: path.join(OUT, 'v2.2.45-photo-pauri.png') });

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
