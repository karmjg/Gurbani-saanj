# Gurbani Saanjh — optional live AI (not required for offline reading)

**Status:** The app's offline scripture search works without a server once the BaniDB corpus has been packaged. Generative AI responses require a securely hosted service. The APK contains **no AI key**. The AI is **free**: Google Gemini's free tier — no OpenAI, no payment.

1. Get a **free Gemini API key** from Google AI Studio (aistudio.google.com → Get API key). No billing needed; the free tier has a daily limit that is plenty for a new app.
2. Create a Cloudflare Worker from `ai-server/cloudflare-worker.mjs` in your Cloudflare account.
3. Set the **secret** environment variables `GEMINI_API_KEY` (your free Gemini key from step 1) and `GS_AI_ACCESS_TOKEN` (your own random strong token). Optional: `GEMINI_MODEL` = `gemini-3.8-flash` (the default). Never put these values into the public GitHub repository or into a chat screenshot.
4. Use Cloudflare rate limits / access restrictions to cap usage and prevent abuse; for a future public launch, use real account-based authentication instead of the test access token.
5. Copy the deployed HTTPS Worker URL to **Gurbani Saanjh → Settings → Reading settings → AI server URL**. Enter your `GS_AI_ACCESS_TOKEN` in the separate **AI access code** field.
6. Ask a question. The app retrieves source passages locally and sends only selected verse text and your question to the Worker. The Worker returns an AI interpretation with original Ang references. The API key never goes to the phone.

**Important:** This optional service does not automatically become active by building the APK; deployment, a Google account and an access token are still needed. Treat AI interpretation as fallible. Always verify important meanings against a primary source and qualified scholarship. The free-text token is stored locally on the device for this private prototype; use more secure storage and authentication for public release.
