/* Gurbani Saanj v2.2.16 — mic visual correction checks (node, offline).
 *  The v2.2.15 green-circle + red-pulsing mic is gone. The mic button is back
 *  to exactly how it was (the original emoji), and the listening state is a
 *  clean green ring + green status — no red, no pulsing. Everything else from
 *  v2.2.15 (mic fast, AI language, Hukamnama settings fix) is unchanged.
 * Run: node test-v236.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.16', vj.version === '2.2.16');
ok('package.json is 2.2.16', pj.version === '2.2.16');

// ---- Mic visual: back to the original ----
ok('search mic button is the original emoji again', app.includes('Voice search\')}">🎙</button>'));
ok('ask mic button is the original emoji again', app.includes('Ask by voice\')}">🎙</button>'));
ok('no SVG mic left in the buttons', !app.includes('viewBox="0 0 24 24" width="26" height="26"'));
ok('no green-circle mic button CSS', !css.includes('#voiceBtn,#askVoiceBtn{display:inline-flex'));
ok('no red pulsing mic CSS', !css.includes('gs-mic-pulse') && !css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{background:#c0392b'));
ok('no red mic background anywhere in the mic rules', !/#voiceBtn\.gs-listening[^}]*#c0392b/.test(css));

// ---- Professional listening state ----
ok('listening: clean green ring on the mic button', css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{box-shadow:0 0 0 2px #14532d'));
ok('listening: button stays fully opaque', css.includes('#voiceBtn.gs-listening:disabled,#askVoiceBtn.gs-listening:disabled{opacity:1;}'));
ok('listening: status line is green + semibold (not huge bold)', css.includes('#voiceStatus.gs-listening{color:#0b3d20;font-weight:600;}'));
ok('listening: no large bold status', !css.includes('#voiceStatus.gs-listening{font-size:18px'));
ok('setListeningUI helper still exists and is wired', app.includes('function setListeningUI(on)') && app.includes('setListeningUI(false)') && app.includes('setListeningUI(true)'));

// ---- v2.2.15 work unchanged ----
ok('mic fast: permission cache intact', app.includes('let voicePermGranted=false;'));
ok('mic fast: parallel checks intact', app.includes('Promise.all([native.available().catch(()=>null),native.checkPermissions().catch(()=>null)])'));
ok('mic fast: parallel listeners intact', app.includes('const [hPartial,hListen]=await Promise.all(['));
ok('AI language toggle intact', app.includes("aiLang:'pa'") && app.includes('data-ai-lang="${k}"') && app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('Hukamnama follows settings (no forced en+pa)', !app.includes('en:true,pa:true') && app.includes("verseBlock(line,idx,'hukamnama')).join('')"));

// ---- Regression ----
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines', app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
