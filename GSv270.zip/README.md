# ਗੁਰਬਾਣੀ ਸਾਂਝ — Gurbani Saanjh v2.2.2 (Android private beta)

A Punjabi/English scripture **reading** app, built from the existing Capacitor project. This ZIP is the **Android source**, not an installable APK.

## v2.2.1 — what changed

- **Kobo-style Reading settings.** Tone dimmer slider, Light/Sepia/Dark/Charcoal pills with pure-white Light default, 3 Gurmukhi-safe fonts, margins control the reading column width. Reachable from any screen via the Aa button; settings persist on-device.
## v2.2.0 — what changed

- **Sundar Gutka (Damdami Taksal) Bani layout.** Light page, dark Gurmukhi body, pankti-per-line, traditional opening header (orange ੴ + "ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥" where the text doesn't already carry it), centered Bani titles and chhand headings, verse numerals kept inline. Side drawer with the full Bani list; new **ਸੁੰਦਰ ਗੁਟਕਾ** menu (ਮੂਲ ਮੰਤਰ, ਨਿਤਨੇਮ, ਸੁੰਦਰ ਗੁਟਕਾ, ਬੇਅੰਤ ਬਾਣੀ, ਸੁੰਦਰ ਗੁਟਕਾ (ਬੁੱਢਾ ਦਲ), ਦਸ ਗ੍ਰੰਥੀ (ਹਜ਼ੂਰੀ), ਮੇਰੀ ਲਿਸਟ — entries without content show an honest "coming soon" placeholder, never fabricated scripture).
- **Vishraam pause colors are real.** Green = short pause, orange = long pause, from the new `www/offline/vishraam.json` (Vishraam Pothi tradition; marks are never invented — absent keys render plain text). A visible **ਵਿਸ਼ਰਾਮ / Pause** switch sits on the home screen, in reading settings, and in Bani View Preferences. Default ON; OFF strips all coloring.
- **iGranth-style GGS search.** Dark blue "Gurbani Saanj" header, search box with clear (✕), mic, and options buttons, icon row (search / saved / history), and a built-in 35-key Gurmukhi first-letter keyboard. Results show Raag/Mahla + "Ang N" with the bold matching line; tap opens the Ang at that line.
- **Layered verses everywhere** (Ang, Bani, Kirtan): Gurmukhi / Transliteration (red) / English (black) / Punjabi (maroon) / Shabad Arth (word=meaning pairs, maroon) — each toggleable in the new **Bani View Preferences** screen, with Night Mode and Bani text size (Normal/Large/Extra-large). Ang view shows Gurmukhi in blue bold.
- **Voice search genuinely fixed.** Root causes found in the v2.1.0 code: the language-list check was awaited before any status (it can hang forever), and the plugin's error path never signaled "stopped" (60s hangs). The workflow now runs `npm ci` from the bundled lockfile before `cap sync`, fail-fasts if the voice bundle is missing, and verifies RECORD_AUDIO in the manifest. The app requests microphone permission with a clear prompt before listening, shows heard text live in the search box, and falls back to the Web Speech API where the plugin is unavailable. A "Test microphone" button in settings reports the real state in plain words.
- **Tap-a-word fixed.** Lookup chain: exact → strip kosh-stems.json suffixes (longest-first) → strip ॥।/numerals → silent give-up. Words with a dictionary entry render **orange** (Sundar Gutka style). Fully offline; no invented definitions.
- **Kirtan Shabad book.** Browsable, searchable-by-first-line book of full Shabads sliced from the bundled Angs (raag/mahla/Ang refs, same layered display, "View full Ang" link). No audio, no external links.
- **Ask Guru Granth Sahib.** Conversational UI with type or voice input. Offline retrieval is always shown first and labeled **"Related Shabads (offline)"** — never presented as an AI answer. A detailed **"AI answer"** is only attempted when you enter your own API key in Settings (default OpenAI endpoint, model configurable); the system prompt constrains it to the provided passages with Ang citations. The private-server hook (AI_SERVER_SETUP.md) remains as the commercial path.
- **Build hardening.** `package-lock.json` is now bundled; the workflow uses `npm ci`, requires `www/offline/{vishraam.json,kosh-stems.json,kirtan-shabads.json}`, and keeps the fail-fast offline-file checks. No build-time text download.

## Honest caveats (please read)

- **Not tested on a real phone by the builder.** The code was verified offline in node (99 automated checks: rendering, vishraam colors + toggle, keyboard, layers, tap-a-word chain, kirtan book, AI labeling, workflow YAML, existing test suites) — but only Karamjit's install on his device is real proof, especially the microphone.
- **Damdami Taksal exactness** of Bani texts and vishraam marks needs his review on device against the printed Sundar Gutka / Vishraam Pothi. The vishraam.json `source` field names the tradition source used.
- The data files `www/offline/vishraam.json`, `www/offline/kosh-stems.json`, and `www/offline/kirtan-shabads.json` are produced by the data pipeline and must be present before zipping — the workflow fails fast without them.
- Hindi per-verse meanings are not bundled yet (the toggle is there and will light up if data arrives).
- English/Roman search modes only match where the bundled rows carry that data (Gurmukhi first-letter/word/phrase search fully works).

## v2.1.0 — what changed

- **All scripture is now bundled inside the ZIP — no build-time download.** The GitHub workflow no longer fetches texts from the internet; `www/offline/` ships complete: all **1,430 Angs** (60,555 lines), a prebuilt search index (60,555 rows), **29 Banis** (7 Nitnem + 22 more Sundar Gutka Banis, 9,452 lines), and a word dictionary (**6,963 words** with Punjabi and English meanings). Total offline data ~34.5 MB; ZIP stays under 40 MB.
- **Voice search is real.** The mic button now uses the phone's speech recognition (Punjabi pa-IN preferred, English fallback), with the old "unavailable" message only as a fallback.
- **Tap-a-word works fully offline** against the bundled dictionary, in your language setting (English/Punjabi), with dismiss controls.
- **Text source:** Shabad OS database (MIT, https://github.com/shabados/database). English glosses: shabados/translation (CC BY-SA 4.0). Punjabi/English word meanings: Mahan Kosh multilingual dataset (Gurmukhi original public domain; dataset CC BY 4.0, https://github.com/redroyals/mahan-kosh-multilingual). See SOURCE_AND_LICENSE.md. BaniDB is no longer the bundled text source.
- **Reference apps:** Nitnem and Banis follow Sundar Gutka (Damdami Taksal) presentation as closely as the data allows; GGS search (first-letter-of-each-word typing), Ang page display, and word-meaning presentation follow the iGranth behavior. Behavior reimplemented with open data — no proprietary content copied.
- **Honest caveats:** Damdami Taksal exactness of every Bani text (especially the long Chaupai Sahib and Rehras Sahib) still needs Karamjit's review against the printed Sundar Gutka. Vishraam highlight data is not bundled, so that toggle is inert. English/Roman search modes have no translation data and won't match — Gurmukhi first-letter/word/phrase search fully works. Not tested on a real device; your install is the real proof.

## What is implemented

- Continuous Gurmukhi text flow without artificial newlines between source verses. **Compact / Standard / Spacious** control line height, not paragraph gaps. Meanings, when enabled, appear underneath their corresponding verse.
- Distraction-free reading: no in-app menu, title, or buttons. Use Samsung Back to exit.
- Two modes: continuous Scroll and 3D **Page Turn**; speed defaults to **Slow** and can be set to Slow / Normal / Fast.
- Sri Guru Granth Sahib Ji **1,430 Angs** and BaniDB Sundar Gutka compositions: the GitHub build is programmed to fetch and validate the texts **at build time** and embed them in the APK; the reader does not require internet after a successful build.
- Punjabi / English app text, independently controlled English-letter Gurbani and Punjabi / English meanings where the source provides them.
- Optional Vishraam word colouring. These markings are incomplete and should NOT be treated as a complete Santhiya edition.
- **Kirtan Shabads**: full offline scripture search, save/bookmark matching lines, open the originating full Ang. This is a **text-reading collection, not a music player**.
- **Ask Gurbani**: retrieval of exact scripture passages with Ang references and Brief / Detailed / In-depth choices. Optional genuine AI explanations require a secure external AI endpoint; see `AI_SERVER_SETUP.md`.
- Daily Gurbani retrieves passages from the actual locally bundled texts.
- **No MP3, audio or synthetic Paath** in this version (postponed by request).

## What has NOT been verified or completed

- No signed APK was built in the assistant's environment; the Android SDK and internet access for the 1,430-Ang download were unavailable. GitHub must complete the download and Android build before we can call the offline library installed and functional.
- No server has been deployed for live AI; do not describe it as active yet.
- Not every named variation of historical or tradition-specific Bani has been sourced/verified. If a complete matching text is unavailable, the app does not fabricate one. In particular, a Damdami Taksal-specific Rehras text needs independent review.
- Complete expert-reviewed Vishraam and word-by-word arth require content review.
- Kirtan Shabad search navigates to the source Ang; full Shabad segmentation beyond an Ang is not yet implemented.
- Samsung hardware testing, text proofreading, licence clearance and release QA are pending.

## Build your existing app (same signing key and app ID)

1. Upload **`GS_v220_source.zip`** (unextracted) to the root of your public `karmjg/Gurbani-saanj` repository on branch `main`.
2. **Overwrite `.github/workflows/android-apk-1.yml`** with the delivered `android-apk-1-v220.yml` (its `zip=` line already says `GS_v220_source.zip`). Commit to `main`.
3. Use **Run workflow** to start a *new* run. Do not press **Re-run jobs** on an old run.
4. The action installs dependencies with `npm ci` (bundled lockfile), verifies the voice-search bundle and RECORD_AUDIO, builds the full validated corpus, signs the release with the four **already configured** GitHub secrets, and uploads the signed APK in the run's Artifacts.
5. Install that signed APK over your existing app. Do not uninstall first; the app ID is `com.gurbanisaanjh.app` and the same signing key is required.

**Important:** Your repo also has `.github/workflows/android-apk.yml` (without `-1`), which can cause duplicate workflows. Use the correct one, and remove/disable the duplicate *only after* you have confirmed the intended workflow is building successfully.

## Text and licensing

See `SOURCE_AND_LICENSE.md`. This is a **private, noncommercial beta**. The full scripture texts are not in this source ZIP because they are downloaded during the build. Review the provider's licensing and permissions before any public/commercial release.
