#!/usr/bin/env python3
"""Demo photo: English first-letter search — 'mhata' typed, Ang 613 found."""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>',
     f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']
# topbar
s += [rect(0, 0, W, 116, PAPER, 0, LINE),
      f'<line x1="0" y1="116" x2="{W}" y2="116" stroke="{LINE}" stroke-width="2"/>',
      text(36, 76, '‹', 56, INK, SYM, '400'),
      text(96, 76, 'ਗੁਰਬਾਣੀ ਸਾਂਝ', 42, INK, SERIF, '750'),
      text(W - 36, 76, '⚙', 44, INK, SYM, '400', 'end')]
s.append(text(36, 190, 'ਖੋਜ', 40, INK, SERIF, '700'))
# search box with mhata typed
s.append(rect(28, 220, W - 56, 96, '#ffffff', 28, LINE, 2))
s.append(text(60, 282, 'mhata', 36, INK, LATIN, '400'))
s.append(text(W - 170, 282, '×', 40, MUTED, SYM, '400'))
s.append(rect(W - 140, 244, 96, 48, PRIMARY, 24))
s.append(text(W - 92, 278, 'ਪੁ', 28, '#ffffff', SANS, '700', 'middle'))
# modes row
modes = [('ਸਭ', True), ('ਪਹਿਲੇ ਅੱਖਰ', False), ('ਪੂਰਾ ਸ਼ਬਦ', False), ('ਅੰਗ', False)]
x = 28
for label, sel in modes:
    w = 90 + len(label) * 8
    s.append(rect(x, 340, w, 52, PRIMARY if sel else '#ffffff', 26, PRIMARY if sel else LINE, 2))
    s.append(text(x + w / 2, 375, label, 24, '#ffffff' if sel else INK, SANS, '650' if sel else '400', 'middle'))
    x += w + 14
# result card
s.append(rect(28, 430, W - 56, 330, '#ffffff', 32, LINE, 2))
s.append(text(60, 510, 'ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ ॥', 38, INK, SERIF, '550'))
s.append(tspans(60, 556, [('ਸੋਰਠਿ ਮ: ੫ ', SANS, '400', MUTED), ('·', SYM, '400', MUTED), (' ਅੰਗ 613', SANS, '400', MUTED)], 26))
s.append(text(60, 620, 'maadho; ham aise. too aisaa |', 26, MUTED, LATIN, '400'))
s.append(text(60, 676, 'O Lord, this is what we are,', 28, INK, LATIN, '400'))
s.append(text(60, 716, 'and this is what You are.', 28, INK, LATIN, '400'))
# note
s.append(tspans(36, 850, [('M = ', LATIN, '700', PRIMARY), ('ਮਾਧੋ', SANS, '700', PRIMARY), (' · ', SYM, '700', PRIMARY), ('H = ', LATIN, '700', PRIMARY), ('ਹਮ', SANS, '700', PRIMARY), (' · ', SYM, '700', PRIMARY), ('A = ', LATIN, '700', PRIMARY), ('ਐਸੇ', SANS, '700', PRIMARY), (' · ', SYM, '700', PRIMARY), ('T = ', LATIN, '700', PRIMARY), ('ਤੂ', SANS, '700', PRIMARY), (' · ', SYM, '700', PRIMARY), ('A = ', LATIN, '700', PRIMARY), ('ਐਸਾ', SANS, '700', PRIMARY)], 28))
s.append(text(36, 896, 'Same procedure for any line, in Punjabi or English.', 26, MUTED, LATIN, '400'))
# bottom nav
s.append(rect(0, H - 128, W, 128, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="{H-128}" x2="{W}" y2="{H-128}" stroke="{LINE}" stroke-width="2"/>')
items = [('Home', False), ('Search', True), ('Saved', False), ('Settings', False)]
cx = W / 8
for i, (label, active) in enumerate(items):
    x = cx + i * (W / 4)
    col = PRIMARY if active else MUTED
    w = '750' if active else '400'
    if label == 'Home':
        s.append(f'<path d="M {x-20} {H-92} l 20 -18 l 20 18 v 20 h -14 v -12 h -12 v 12 h -14 z" fill="{col}"/>')
    elif label == 'Search':
        s.append(f'<circle cx="{x}" cy="{H-88}" r="15" fill="none" stroke="{col}" stroke-width="5"/><line x1="{x+11}" y1="{H-77}" x2="{x+20}" y2="{H-68}" stroke="{col}" stroke-width="5" stroke-linecap="round"/>')
    elif label == 'Saved':
        s.append(text(x, H - 68, '♡', 46, col, SYM, '400', 'middle'))
    else:
        s.append(text(x, H - 68, '⚙', 46, col, SYM, '400', 'middle'))
    s.append(text(x, H - 34, label, 22, col, LATIN, w, 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v229_preview_roman_search.png'))
print('v229_preview_roman_search.png done')
