/* Gurbani Saanj v2.2.29 — page-turn top gap removed.
 * Karamjit's screenshot (Tav-Prasad Savaiye, page-turn mode): the top of the
 * page was EMPTY — a large blank gap above the top bar (circled red).
 * Root cause: .gs-book-reading had top padding 60px + safe-area (line 356
 * override beat the 48px shorthand). The 60px was meant to clear the main
 * app topbar, but that topbar is HIDDEN while reading, so the 60px was pure
 * empty space pushing the bar down. The section does not scroll, so the bar
 * is already fixed in place — only the padding pushed it down.
 * Fix: book top padding is now just the status-bar clearance,
 * calc(max(env(safe-area-inset-top, 0px), 24px) + 4px), same clearance as
 * the scroll-mode bar (v2.2.27). The 60px override is deleted; the shorthand
 * is the single source of truth. Bottom/side padding unchanged, so the stage
 * (flex:1) gains the freed ~60px and the page is fuller.
 * Scroll mode is NOT touched (its 60px .reading rule stays).
 * Run: node test-v249.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.29', vj.version === '2.2.29');
ok('package.json is 2.2.29', pj.version === '2.2.29');
ok('version.json notes mention v2.2.29 + top gap', vj.notes.includes('v2.2.29:') && vj.notes.includes('top gap removed'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');

// ---- 1. Book top padding is now status-bar clearance only (a) ----
// Extract every rule whose selector mentions .gs-book-reading.
const bookRules = [...css.matchAll(/[^{}]*\.gs-book-reading[^{}]*\{[^}]*\}/g)].map(m => m[0]);
ok('book rules found', bookRules.length >= 5, `got ${bookRules.length}`);
ok('no 60px top padding in any book rule', !bookRules.some(r => r.includes('60px')), bookRules.filter(r => r.includes('60px')).join(' | ').slice(0, 120));
ok('no 48px top padding in any book rule', !bookRules.some(r => r.includes('48px')), bookRules.filter(r => r.includes('48px')).join(' | ').slice(0, 120));
const shorthand = bookRules.find(r => r.includes('html.reading-open .reading.gs-book-reading') && r.includes('height:100dvh'));
ok('book shorthand rule exists', !!shorthand);
ok('book shorthand top is status-bar clearance max(safe-area,24px)+4px',
  !!shorthand && shorthand.includes('padding:calc(max(env(safe-area-inset-top, 0px), 24px) + 4px)'),
  shorthand ? shorthand.slice(0, 160) : 'missing');
ok('book 60px override rule is gone', !css.includes('.reading.gs-book-reading{padding-top:calc(60px'));

// ---- 2. Bottom/side padding unchanged (b) ----
ok('book side padding still 13px', !!shorthand && /\) 13px calc\(17px \+ env\(safe-area-inset-bottom\)\)/.test(shorthand), shorthand ? shorthand.slice(0, 200) : 'missing');
ok('book bottom padding still 17px + safe-area bottom', !!shorthand && shorthand.includes('calc(17px + env(safe-area-inset-bottom))'));

// ---- 3. Section still full-page (c) ----
ok('book section still height:100dvh', !!shorthand && shorthand.includes('height:100dvh'));
ok('book section still overflow:hidden', !!shorthand && shorthand.includes('overflow:hidden'));
ok('book section still box-sizing:border-box', !!shorthand && shorthand.includes('box-sizing:border-box'));
ok('book has-topbar still flex column', css.includes('.gs-book-reading.gs-has-topbar{display:flex;flex-direction:column}'));
ok('book stage still flex:1 (full page)', css.includes('.gs-book-reading.gs-has-topbar .gs-book-stage{flex:1;min-height:0;height:auto}'));
ok('book reference still hidden in has-topbar', css.includes('.gs-book-reading.gs-has-topbar .gs-book-reference{display:none}'));

// ---- 4. Top bar still a flex child at the top, pressable (d) ----
ok('book topbar still flex:none child', css.includes('.gs-book-reading.gs-has-topbar .gs-reading-topbar{flex:none}'));
const pageReturn = app.match(/gs-book-reading gs-has-topbar[\s\S]{0,500}?gs-book-stage/);
ok('page-mode template puts top bar (head) before the stage', !!pageReturn && pageReturn[0].includes('${head}'), pageReturn ? pageReturn[0].slice(0, 200) : 'no match');
ok('topbar sticky top still clears status bar (24px min)', css.includes('top: max(env(safe-area-inset-top, 0px), 24px)'));

// ---- 5. Scroll mode untouched (e) ----
ok('scroll-mode 60px .reading padding-top rule still present (exactly 1)',
  (css.match(/html\.reading-open \.reading\{padding-top:calc\(60px \+ env\(safe-area-inset-top\)\);\}/g) || []).length === 1);
ok('v2.2.27 scroll-direction bar logic kept', app.includes('barScrollDecision') && app.includes('onReaderScroll') && app.includes('readerBarHidden'));
ok('v2.2.27 bar hidden class still display:none', css.includes('.gs-reading-topbar.gs-topbar-hidden{display:none}'));

// ---- 6. Regressions ----
// v2.2.28: unified search
const baniPath = path.join(ROOT, 'www/offline/bani-search.json');
ok('v2.2.28 bani-search.json exists', fs.existsSync(baniPath));
const baniIdx = JSON.parse(fs.readFileSync(baniPath, 'utf8'));
ok('v2.2.28 bani-search.json has 9,452 lines', baniIdx.length === 9452, `got ${baniIdx.length}`);
ok('v2.2.28 search loads BOTH indexes', ss.includes("offline/search.json") && ss.includes('offline/bani-search.json'));
ok('v2.2.28 Dasam label kept', ss.includes('dasam') && app.includes('Dasam Granth'));
// v2.2.26
ok('v2.2.26 Bani heading patterns kept', rv.includes('ਮਹਲਾ') && rv.includes('ਅਸਟਪਦੀ'));
ok('v2.2.26 viewport pinch-off kept', html.includes('user-scalable=no') && html.includes('maximum-scale=1'));
ok('v2.2.26 page-turn min-height fallback kept', css.includes('.gs-book-reading{min-height:calc(100dvh - 122px)}'));
// v2.2.25
ok('v2.2.25 A+/A- row still gone', !app.includes('ai-zoom-row'));
ok('v2.2.25 document-level pinch kept', app.includes('setupPinchZoom') && app.includes('pinchWired'));
// v2.2.23
const aiFontSizes = [...css.matchAll(/\.ai-answer\s*\{[^}]*font-size\s*:[^;}]+/g)].map(m => m[0]);
ok('v2.2.23 one .ai-answer font-size, var(--ai-font,18px)', aiFontSizes.length === 1 && aiFontSizes[0].includes('var(--ai-font,18px)'), `got ${aiFontSizes.length}`);
// v2.2.22
ok('v2.2.22 not-hearing status kept', app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ'));
// v2.2.21
ok('v2.2.21 first-letter phrase fallback kept', ss.includes('firstSig'));
// v2.2.20
ok('v2.2.20 guarded stop kept', app.includes('run.started&&!run.stopped&&!run.safetyStopped'));
// v2.2.18
ok('v2.2.18 ai-verse bold/highlight + font clamp 14-32', app.includes('ai-verse') && app.includes('Math.min(32,Math.max(14'));
// v2.2.15
ok('v2.2.15 AI language toggle kept', app.includes('aiLang') && app.includes('data-ai-lang'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
