#!/usr/bin/env python3
"""Render 3 Gurbani v2.2.8 mockup photos (SVG -> PNG via cairosvg).
Real app colors, real Ang 205 text, real Punjabi meaning.
Fonts: Noto Serif/Sans Gurmukhi (Gurmukhi), Noto Sans (Latin), DejaVu Sans (symbols).
"""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'; YELLOW = '#fff2a8'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def svg_open():
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
            f'<rect width="{W}" height="{H}" fill="{BG}"/>',
            f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    # parts: list of (string, family, weight, fill)
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

def magnifier(cx, cy, r, color, sw=5):
    return (f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{color}" stroke-width="{sw}"/>'
            f'<line x1="{cx + r * 0.7}" y1="{cy + r * 0.7}" x2="{cx + r * 1.35}" y2="{cy + r * 1.35}" stroke="{color}" stroke-width="{sw}" stroke-linecap="round"/>')

def mic(cx, cy, color):
    return (f'<rect x="{cx - 13}" y="{cy - 26}" width="26" height="40" rx="13" fill="{color}"/>'
            f'<path d="M {cx - 22} {cy + 2} A 22 22 0 0 0 {cx + 22} {cy + 2}" fill="none" stroke="{color}" stroke-width="5"/>'
            f'<line x1="{cx}" y1="{cy + 24}" x2="{cx}" y2="{cy + 34}" stroke="{color}" stroke-width="5" stroke-linecap="round"/>')

def bookmark(cx, cy, color):
    return (f'<path d="M {cx - 14} {cy - 22} h 28 v 46 l -14 -12 l -14 12 z" fill="{color}"/>')

def bottom_nav(active):
    items = [('home', 'Home'), ('search', 'Search'), ('heart', 'Saved'), ('gear', 'Settings')]
    out = [rect(0, H - 128, W, 128, PAPER, 0, LINE),
           f'<line x1="0" y1="{H-128}" x2="{W}" y2="{H-128}" stroke="{LINE}" stroke-width="2"/>']
    cx = W / 8
    for i, (kind, label) in enumerate(items):
        x = cx + i * (W / 4)
        col = PRIMARY if label == active else MUTED
        w = '750' if label == active else '400'
        if kind == 'home':
            out.append(f'<path d="M {x-20} {H-92} l 20 -18 l 20 18 v 20 h -14 v -12 h -12 v 12 h -14 z" fill="{col}"/>')
        elif kind == 'search':
            out.append(magnifier(x, H - 88, 15, col, 5))
        elif kind == 'heart':
            out.append(text(x, H - 68, '♡', 46, col, SYM, '400', 'middle'))
        else:
            out.append(text(x, H - 68, '⚙', 46, col, SYM, '400', 'middle'))
        out.append(text(x, H - 34, label, 22, col, LATIN, w, 'middle'))
    return out

def topbar():
    return [rect(0, 0, W, 116, PAPER, 0, LINE),
            f'<line x1="0" y1="116" x2="{W}" y2="116" stroke="{LINE}" stroke-width="2"/>',
            text(36, 76, '‹', 56, INK, SYM, '400'),
            text(96, 76, 'ਗੁਰਬਾਣੀ ਸਾਂਝ', 42, INK, SERIF, '750'),
            text(W - 36, 76, '⚙', 44, INK, SYM, '400', 'end')]

# ---------------- Photo 1: Search (pu toggle + Gurmukhi keyboard) ----------------
s = svg_open()
s += topbar()
s += [rect(0, 116, W, 150, PRIMARY),
      text(36, 178, 'Gurbani Saanj', 44, '#ffffff', LATIN, '700'),
      text(36, 228, 'ਖੋਜ — ਸ਼ਬਦ, ਪਹਿਲੇ ਅੱਖਰ ਜਾਂ ਅੰਗ', 26, '#cfe0d4', SANS, '400')]
# search box
s += [rect(28, 296, W - 56, 92, '#ffffff', 28, LINE, 2),
      magnifier(92, 342, 17, MUTED, 5),
      text(132, 356, 'ਸਚ', 36, INK, SERIF, '550'),
      text(430, 356, '✕', 36, MUTED, SYM, '400'),
      rect(478, 318, 78, 48, '#edf3ed', 20),
      mic(517, 342, PRIMARY),
      rect(568, 314, 92, 56, PRIMARY, 18),
      text(614, 354, 'ਪੁ', 34, '#ffffff', SANS, '700', 'middle')]
# icon row
for i, (kind, lb) in enumerate([('mag', 'Search'), ('bkm', 'Saved'), ('lines', 'History')]):
    x = 100 + i * 260
    if kind == 'mag':
        s.append(magnifier(x, 436, 15, PRIMARY, 5))
    elif kind == 'bkm':
        s.append(bookmark(x, 436, PRIMARY))
    else:
        for dy in (-14, 0, 14):
            s.append(f'<line x1="{x-16}" y1="{436+dy}" x2="{x+16}" y2="{436+dy}" stroke="{PRIMARY}" stroke-width="5" stroke-linecap="round"/>')
    s.append(text(x, 490, lb, 22, MUTED, LATIN, '400', 'middle'))
# search modes
# modes shown on two rows so every mode is visible in the photo
# (in the app the row scrolls sideways)
mode_rows = [[('ਸਭ', True, SANS, 90), ('ਪਹਿਲੇ ਅੱਖਰ', False, SANS, 180), ('ਵਿਚਕਾਰਲੇ ਅੱਖਰ', False, SANS, 210)],
             [('ਪੂਰਾ ਸ਼ਬਦ', False, SANS, 160), ('English ਅੱਖਰ', False, 'MIX', 220), ('ਅੰਗ', False, SANS, 90)]]
for ri, row in enumerate(mode_rows):
    x = 28
    for label, sel, fam, w in row:
        y0 = 520 + ri * 70
        s.append(rect(x, y0, w, 58, PRIMARY if sel else '#ffffff', 30, LINE if not sel else PRIMARY, 2))
        if fam == 'MIX':
            s.append(tspans(x + w / 2, y0 + 36, [('English ', LATIN, '400', '#ffffff' if sel else INK), ('ਅੱਖਰ', SANS, '400', '#ffffff' if sel else INK)], 22, 'middle'))
        else:
            s.append(text(x + w / 2, y0 + 36, label, 22, '#ffffff' if sel else INK, fam, '650' if sel else '400', 'middle'))
        x += w + 12
# Gurmukhi keyboard
keys = [['ੳ/ਓ', 'ਅ', 'ੲ', 'ਸ', 'ਹ'], ['ਕ', 'ਖ', 'ਗ', 'ਘ', 'ਙ'], ['ਚ', 'ਛ', 'ਜ', 'ਝ', 'ਞ'],
        ['ਟ', 'ਠ', 'ਡ', 'ਢ', 'ਣ'], ['ਤ', 'ਥ', 'ਦ', 'ਧ', 'ਨ'], ['ਪ', 'ਫ', 'ਬ', 'ਭ', 'ਮ'],
        ['ਯ', 'ਰ', 'ਲ', 'ਵ', 'ੜ']]
y = 680
for row in keys:
    x = 28
    for k in row + ['⌫']:
        s.append(rect(x, y, 108, 74, '#ffffff', 16, LINE, 2))
        if k == '⌫':
            s.append(text(x + 54, y + 50, '⌫', 30, INK, SYM, '400', 'middle'))
        else:
            s.append(text(x + 54, y + 50, k, 32, INK, SANS, '550', 'middle'))
        x += 118
    y += 86
# one result row
s += [text(36, y + 40, 'ਸਚੁ', 38, INK, SERIF, '650'),
      tspans(36, y + 84, [('ਅੰਗ 1 ', SANS, '400', MUTED), ('·', SYM, '400', MUTED), (' ਸਿਰੀਰਾਗੁ', SANS, '400', MUTED)], 24),
      text(W - 36, y + 60, '›', 40, MUTED, SYM, '400', 'end')]
s += bottom_nav('Search')
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_search.png'))
print('search done')

# ---------------- Photo 2: Reader (Ang-jump bar + yellow highlight) ----------------
def ang_jump_bar():
    return [rect(0, 0, W, 108, PAPER, 0, LINE),
            f'<line x1="0" y1="108" x2="{W}" y2="108" stroke="{LINE}" stroke-width="2"/>',
            text(32, 68, 'ਅੰਗ', 30, INK, SANS, '700'),
            rect(118, 26, 150, 56, '#ffffff', 14, LINE, 2),
            text(193, 66, '205', 32, INK, LATIN, '400', 'middle'),
            rect(284, 22, 130, 64, PRIMARY, 18),
            tspans(349, 66, [('ਜਾਓ ', SANS, '650', '#ffffff'), ('›', SYM, '650', '#ffffff')], 28, 'middle'),
            text(W - 32, 68, 'Aa', 32, INK, LATIN, '400', 'end')]

s = svg_open()
s += ang_jump_bar()
verses = [
    ('ਅੰਤਰਿ ਅਲਖੁ ਨ ਜਾਈ ਲਖਿਆ', 'ਵਿਚਿ ਪੜਦਾ ਹਉਮੈ ਪਾਈ ॥', False),
    ('ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', True),
    ('ਏਕਾ ਸੰਗਤਿ ਇਕਤੁ ਗ੍ਰਿਹਿ ਬਸਤੇ', 'ਮਿਲਿ ਬਾਤ ਨ ਕਰਤੇ ਭਾਈ ॥', False),
    ('ਏਕ ਬਸਤੁ ਬਿਨੁ ਪੰਚ ਦੁਹੇਲੇ', 'ਓਹ ਬਸਤੁ ਅਗੋਚਰ ਠਾਈ ॥੨॥', False),
    ('ਜਿਸ ਕਾ ਗ੍ਰਿਹੁ ਤਿਨਿ ਦੀਆ ਤਾਲਾ', 'ਕੁੰਜੀ ਗੁਰ ਸਉਪਾਈ ॥', False),
    ('ਅਨਿਕ ਉਪਾਵ ਕਰੇ ਨਹੀ ਪਾਵੈ', 'ਬਿਨੁ ਸਤਿਗੁਰ ਸਰਣਾਈ ॥੩॥', False),
    ('ਜਿਨ ਕੇ ਬੰਧਨ ਕਾਟੇ ਸਤਿਗੁਰ', 'ਤਿਨ ਸਾਧਸੰਗਤਿ ਲਿਵ ਲਾਈ ॥', False),
    ('ਪੰਚ ਜਨਾ ਮਿਲਿ ਮੰਗਲੁ ਗਾਇਆ', 'ਹਰਿ ਨਾਨਕ ਭੇਦੁ ਨ ਭਾਈ ॥੪॥', False),
]
y = 190
for l1, l2, found in verses:
    h = 118
    if found:
        s.append(rect(24, y - 8, W - 48, h + 16, YELLOW, 16))
    s.append(text(W / 2, y + 42, l1, 40, INK, SERIF, '550', 'middle'))
    s.append(text(W / 2, y + 96, l2, 40, INK, SERIF, '550', 'middle'))
    y += h + 14
s.append(tspans(W / 2, y + 60, [('ਅੰਗ 205 ', SANS, '400', MUTED), ('·', SYM, '400', MUTED), (' ਸਿਰੀਰਾਗੁ', SANS, '400', MUTED)], 24, 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_reader.png'))
print('reader done')

# ---------------- Photo 3: Whole-line meaning popup ----------------
s = svg_open()
s += ang_jump_bar()
s.append(rect(24, 182, W - 48, 118, YELLOW, 16))
s.append(text(W / 2, 232, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 282, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 40, INK, SERIF, '550', 'middle'))
px, py, pw = 36, 360, W - 72
s.append(rect(px, py, pw, 560, '#ffffff', 36, LINE, 2))
s.append(text(W / 2, py + 64, 'ਪੂਰੀ ਲਾਈਨ ਦਾ ਅਰਥ', 28, MUTED, SANS, '700', 'middle'))
s.append(text(W / 2, py + 132, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, py + 184, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 38, INK, SERIF, '550', 'middle'))
s.append(rect(W / 2 - 190, py + 220, 190, 62, PRIMARY, 16))
s.append(text(W / 2 - 95, py + 261, 'ਪੰਜਾਬੀ', 28, '#ffffff', SANS, '700', 'middle'))
s.append(rect(W / 2, py + 220, 190, 62, '#edf3ed', 16))
s.append(text(W / 2 + 95, py + 261, 'English', 28, PRIMARY, LATIN, '650', 'middle'))
meaning = ['ਧਨ-ਦੌਲਤ ਦੀ ਮੁਹੱਬਤ ਅੰਦਰ ਸਾਰਾ', 'ਸੰਸਾਰ ਸੁੱਤਾ ਪਿਆ ਹੈ। ਦੱਸੋ! ਇਹ', 'ਸੰਦੇਹ ਕਿਸ ਤਰ੍ਹਾਂ ਦੂਰ ਹੋ ਸਕਦਾ ਹੈ?']
yy = py + 350
for line in meaning:
    s.append(text(W / 2, yy, line, 32, INK, SANS, '400', 'middle'))
    yy += 52
s.append(tspans(W / 2, py + 522, [('ਅੰਗ 205 ', SANS, '400', MUTED), ('·', SYM, '400', MUTED), (' ਸਿਰੀਰਾਗੁ', SANS, '400', MUTED)], 24, 'middle'))
s.append(text(W / 2, py + 640, 'ਏਕਾ ਸੰਗਤਿ ਇਕਤੁ ਗ੍ਰਿਹਿ ਬਸਤੇ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, py + 694, 'ਮਿਲਿ ਬਾਤ ਨ ਕਰਤੇ ਭਾਈ ॥', 40, INK, SERIF, '550', 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_meaning.png'))
print('meaning done')
