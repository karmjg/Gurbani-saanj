/* Gurbani Saanj v2.2.23 — Ask A+/A- zoom actually changes the AI answer text size (node, offline).
 * The user tapped A+ on the Ask screen and the answer text never grew.
 * Root cause: styles.css had TWO .ai-answer font-size rules. The v2.2.18 rule
 * (line 364) uses var(--ai-font,18px), which the zoom buttons update — but a
 * later rule (line 540) set a FIXED font-size: 14px with the same specificity,
 * so it always won and the text stayed 14px. The fix removes ONLY the fixed
 * font-size from the line-540 rule; the zoom handler, theme(), and the
 * line-364 rule are untouched.
 * Run: node test-v243.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.23', vj.version === '2.2.23');
ok('package.json is 2.2.23', pj.version === '2.2.23');
ok('version.json notes mention v2.2.23', vj.notes.includes('v2.2.23'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 1. CSS: exactly one .ai-answer font-size, and it is the variable ----
const aiAnswerBlocks = [...css.matchAll(/\.ai-answer\s*\{[^}]*\}/g)].map(m => m[0]);
ok('three .ai-answer rules exist', aiAnswerBlocks.length === 3, `got ${aiAnswerBlocks.length}`);
const fontSizeDecls = aiAnswerBlocks.flatMap(b => [...b.matchAll(/font-size\s*:\s*([^;}]+)/g)].map(m => m[1].trim()));
ok('exactly ONE .ai-answer font-size declaration', fontSizeDecls.length === 1, `got ${JSON.stringify(fontSizeDecls)}`);
ok('that font-size is var(--ai-font,18px)', fontSizeDecls[0] === 'var(--ai-font,18px)', `got ${JSON.stringify(fontSizeDecls[0])}`);
ok('no fixed 14px on any .ai-answer rule', !aiAnswerBlocks.some(b => /font-size\s*:\s*14px/.test(b)));
ok('line-364 variable rule intact', css.includes('.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,18px);color:var(--ink);}'));
const late = aiAnswerBlocks.find(b => b.includes('line-height: 1.75'));
ok('line-540 rule kept line-height/color/white-space, lost only font-size',
  !!late && late.includes('line-height: 1.75') && late.includes('color: var(--ink)') && late.includes('white-space: pre-wrap') && !late.includes('font-size'));
ok('.ai-verse has no own font-size (inherits .ai-answer)', !/\.ai-verse\{[^}]*font-size/.test(css));

// ---- 2. VM: the real theme() sets --ai-font from state.aiFont ----
const themeSrc = app.slice(app.indexOf('function theme(){'), app.indexOf('// ---- Offline data boot'));
ok('theme() source extracted', themeSrc.includes("html.style.setProperty('--ai-font'"));
const props = {};
const fakeHtml = {
  classList: { toggle() {} },
  dataset: {},
  style: { setProperty(k, v) { props[k] = v; } },
  lang: '',
};
const state = { theme: 'light', lineLayout: 'compact', fontStyle: 'default', margin: 'normal', raisedHeadings: true, nightMode: false, baniTextSize: 'medium', font: 18, aiFont: 18, uiScale: 1.12, tone: 50, lang: 'pa' };
const ctx = vm.createContext({ document: { documentElement: fakeHtml, querySelector: () => null }, state, console });
vm.runInContext(themeSrc + '\n;globalThis.__theme=theme;', ctx);
ctx.__theme();
ok('theme() sets --ai-font to 18px at default', props['--ai-font'] === '18px', `got ${props['--ai-font']}`);
state.aiFont = 24; ctx.__theme();
ok('theme() sets --ai-font to 24px after zoom', props['--ai-font'] === '24px', `got ${props['--ai-font']}`);

// ---- 3. VM: the real zoom expression updates state.aiFont with clamps ----
const zoomExpr = 'state.aiFont=Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))';
ok('zoom expression present verbatim in app.js', app.includes(zoomExpr));
ok('zoom handler calls persist + theme + render', app.includes('persist();theme();render();return;}') && app.includes("const aiZoom=e.target.closest('[data-ai-zoom]');"));
ok('A- / A+ buttons exist on the Ask screen', app.includes('data-ai-zoom="-2"') && app.includes('data-ai-zoom="2"'));
const zoom = (start, delta) => {
  const s = { aiFont: start };
  const c2 = vm.createContext({ state: s, aiZoom: { dataset: { aiZoom: String(delta) } } });
  vm.runInContext(zoomExpr + ';', c2);
  return s.aiFont;
};
ok('A+ 18 -> 20', zoom(18, 2) === 20, `got ${zoom(18, 2)}`);
ok('A- 18 -> 16', zoom(18, -2) === 16, `got ${zoom(18, -2)}`);
ok('A+ clamps at 32', zoom(31, 2) === 32, `got ${zoom(31, 2)}`);
ok('A- clamps at 14', zoom(15, -2) === 14, `got ${zoom(15, -2)}`);
ok('missing aiFont defaults to 18 then +2 = 20', zoom(undefined, 2) === 20, `got ${zoom(undefined, 2)}`);

// ---- Regression (grep) ----
ok('v2.2.22: no-heard timer intact', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('v2.2.22: X restarts the mic intact', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('v2.2.21: first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.18: AI verse bold+highlight intact', app.includes('ai-verse') && css.includes('.ai-verse{'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'"));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
