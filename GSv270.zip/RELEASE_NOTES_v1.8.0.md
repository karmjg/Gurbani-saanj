# Gurbani Saanjh v1.8.0 — private beta release notes

**Implemented:** Real inline continuous Gurbani flow; 3D page flipping with a slower (1250 ms) default and speed choices (1250/800/430 ms); offline SGGS searchable source corpus generated during GitHub build; Kirtan Shabads text search/save; AI evidence retrieval with exact Ang citations and optional secure generative-AI endpoint; audio deferred; original Punjabi/English and word meaning settings retained.

**Verified locally:** JavaScript syntax; offline BaniDB importer fixture; source ZIP contents; mobile Chromium UI with test data (continuous verse spans compute `display:inline`, Nitnem opens, Page Turn renders, speed setting accessible, offline Kirtan search returns results and bookmarking works). Local UI uses test data only, NEVER distributed as Gurbani corpus.

**Unverified:** real full BaniDB corpus download, signed Android APK, on-device Samsung testing, full-accuracy Vishraam data, non-available specialist Banis, and deployment of optional live AI service. These are blockers to calling this a finished, publicly launched product.
