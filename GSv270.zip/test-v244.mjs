/* Gurbani Saanj v2.2.24 — pinch-to-zoom on the AI answer (Ask screen), node, offline.
 * The A+/A- buttons do not change the answer size on the user's phone (root
 * cause unknown; user dropped that fix). Replacement: two-finger pinch on the
 * answer text — pinch out grows it, pinch in shrinks it, size is saved.
 * The pinch reuses the --ai-font mechanism (theme() sets it from state.aiFont;
 * .ai-answer font-size is var(--ai-font,18px)); touch-action:pan-y on
 * .ai-answer keeps the browser from hijacking the pinch while one-finger
 * vertical scroll still works. Single-finger touch is never intercepted.
 * Run: node test-v244.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.24', vj.version === '2.2.24');
ok('package.json is 2.2.24', pj.version === '2.2.24');
ok('version.json notes mention v2.2.24 pinch-to-zoom', vj.notes.includes('v2.2.24: pinch-to-zoom'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 1. Pinch helpers: math in a VM ----
const helpersSrc = app.slice(app.indexOf('function pinchDist'), app.indexOf('function askScreen(){'));
ok('pinch helpers present in app.js', helpersSrc.includes('function pinchDist') && helpersSrc.includes('function pinchFont'));
const hctx = vm.createContext({ Math });
vm.runInContext(helpersSrc + '\n;globalThis.__pinchDist=pinchDist;globalThis.__pinchFont=pinchFont;', hctx);
const pinchDist = hctx.__pinchDist, pinchFont = hctx.__pinchFont;
ok('pinchDist 3-4-5 triangle is 5', pinchDist([{ clientX: 0, clientY: 0 }, { clientX: 3, clientY: 4 }]) === 5);
ok('pinch-out 18 x1.5 -> 27', pinchFont(18, 100, 150) === 27, `got ${pinchFont(18, 100, 150)}`);
ok('pinch-in 18 x0.5 -> 14 (clamped low)', pinchFont(18, 100, 50) === 14, `got ${pinchFont(18, 100, 50)}`);
ok('pinch-out 18 x2 -> 32 (clamped high)', pinchFont(18, 100, 200) === 32, `got ${pinchFont(18, 100, 200)}`);
ok('no-scale 18 x1.0 -> 18', pinchFont(18, 100, 100) === 18);
ok('zero start distance guards to start font', pinchFont(18, 0, 100) === 18);
ok('zero current distance guards to start font', pinchFont(18, 100, 0) === 18);
ok('missing start font defaults to 18', pinchFont(undefined, 100, 150) === 27, `got ${pinchFont(undefined, 100, 150)}`);
ok('pinch from 24 x0.75 -> 18', pinchFont(24, 200, 150) === 18, `got ${pinchFont(24, 200, 150)}`);

// ---- 2. Behavioral: the real attach() ask-block with a fake DOM ----
const askStart = app.indexOf("if(state.view==='ask'){const av=$('askVoiceBtn')");
const askEndMark = "conv.addEventListener('touchcancel',endPinch);}}";
const askEnd = app.indexOf(askEndMark);
ok('exactly one attach() ask-block', askStart !== -1 && askStart === app.lastIndexOf("if(state.view==='ask'){const av=$('askVoiceBtn')") && askEnd !== -1);
const askBlock = app.slice(askStart, askEnd + askEndMark.length);

const mkConv = () => ({ _h: {}, addEventListener(t, f, o) { (this._h[t] = this._h[t] || []).push({ f, o }); } });
const conv = mkConv();
const state = { view: 'ask', aiFont: 18 };
let themeCalls = 0, persistCalls = 0;
const bctx = vm.createContext({
  $: (id) => (id === 'conversation' ? conv : null),
  state,
  pinchDist, pinchFont,
  theme() { themeCalls++; },
  persist() { persistCalls++; },
  startVoiceSearch() {},
  console,
});
vm.runInContext(askBlock, bctx);
const H = conv._h;
ok('touchstart listener attached', (H.touchstart || []).length === 1);
ok('touchmove listener attached', (H.touchmove || []).length === 1);
ok('touchmove listener is NON-passive (preventDefault works)', H.touchmove[0].o && H.touchmove[0].o.passive === false, `got ${JSON.stringify(H.touchmove[0].o)}`);
ok('touchstart listener is passive', H.touchstart[0].o && H.touchstart[0].o.passive === true);
ok('touchend + touchcancel listeners attached', (H.touchend || []).length === 1 && (H.touchcancel || []).length === 1);

const touch = (x, y) => ({ clientX: x, clientY: y });
const evt = (touches, onAnswer) => ({
  touches, _pd: false,
  target: { closest: (s) => (s === '.ai-answer' && onAnswer ? {} : null) },
  preventDefault() { this._pd = true; },
});
const fire = (type, e) => H[type][0].f(e);

// 2-finger pinch-out on the answer: 18 -> 27, live theme, default prevented
fire('touchstart', evt([touch(0, 0), touch(100, 0)], true));
const mvOut = evt([touch(0, 0), touch(150, 0)], true);
fire('touchmove', mvOut);
ok('pinch-out 1.5x: aiFont 18 -> 27', state.aiFont === 27, `got ${state.aiFont}`);
ok('pinch-out calls theme() (live --ai-font)', themeCalls === 1, `got ${themeCalls}`);
ok('pinch-out preventDefault called', mvOut._pd === true);
// pinch-in on the same run: 27 x (50/150) = 9 -> clamped 14
const mvIn = evt([touch(0, 0), touch(50, 0)], true);
fire('touchmove', mvIn);
ok('pinch-in clamps at 14', state.aiFont === 14, `got ${state.aiFont}`);
ok('pinch-in preventDefault called', mvIn._pd === true);
// single-finger move: NOT intercepted
themeCalls = 0;
const mvOne = evt([touch(0, 0)], true);
fire('touchmove', mvOne);
ok('single-finger move does not preventDefault', mvOne._pd === false);
ok('single-finger move does not change aiFont or call theme', state.aiFont === 14 && themeCalls === 0);
// touchend saves the size
fire('touchend', {});
ok('touchend persists the size once', persistCalls === 1, `got ${persistCalls}`);
// after touchend the pinch is dead: a later 2-finger move does nothing
const mvDead = evt([touch(0, 0), touch(200, 0)], true);
fire('touchmove', mvDead);
ok('move after touchend does nothing', state.aiFont === 14 && mvDead._pd === false);
// 2-finger touch NOT on the answer never arms the pinch
fire('touchstart', evt([touch(0, 0), touch(100, 0)], false));
const mvOff = evt([touch(0, 0), touch(200, 0)], false);
fire('touchmove', mvOff);
ok('pinch off the answer does nothing', state.aiFont === 14 && mvOff._pd === false);

// ---- 3. CSS ----
const aiAnswerBlocks = [...css.matchAll(/\.ai-answer\s*\{[^}]*\}/g)].map(m => m[0]);
ok('three .ai-answer rules exist', aiAnswerBlocks.length === 3, `got ${aiAnswerBlocks.length}`);
ok('.ai-answer has touch-action:pan-y', aiAnswerBlocks.some(b => /touch-action\s*:\s*pan-y/.test(b)));
const fontSizeDecls = aiAnswerBlocks.flatMap(b => [...b.matchAll(/font-size\s*:\s*([^;}]+)/g)].map(m => m[1].trim()));
ok('exactly ONE .ai-answer font-size, still var(--ai-font,18px)', fontSizeDecls.length === 1 && fontSizeDecls[0] === 'var(--ai-font,18px)', `got ${JSON.stringify(fontSizeDecls)}`);

// ---- 4. Wiring greps ----
ok('pinch gates on .ai-answer target', app.includes("e.target.closest('.ai-answer')"));
ok('pinch only arms on exactly 2 touches', app.includes('e.touches.length===2'));
ok('pinch calls theme() live, no render() per move', app.includes("state.aiFont=pinchFont(pinch.f,pinch.d,pinchDist(e.touches));theme()}") && !app.includes('pinchFont(pinch.f,pinch.d,pinchDist(e.touches));theme();render()'));
ok('pinch persists on touchend/touchcancel', app.includes("const endPinch=()=>{if(pinch){pinch=null;persist()}}"));

// ---- Regression ----
ok('v2.2.23: A+/A- buttons still present (left as-is)', app.includes('data-ai-zoom="-2"') && app.includes('data-ai-zoom="2"'));
ok('v2.2.23: A+/A- handler still present', app.includes("const aiZoom=e.target.closest('[data-ai-zoom]');"));
ok('v2.2.23: theme() still sets --ai-font', app.includes("html.style.setProperty('--ai-font'"));
ok('v2.2.22: no-heard timer intact', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('v2.2.22: X restarts the mic intact', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('v2.2.21: first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.18: ai-verse highlight intact', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('v2.2.18: aiFont clamp 14-32 intact', app.includes('Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))'));
ok('v2.2.15: AI language toggle intact', app.includes("data-ai-lang") && app.includes("state.aiLang=aiLang.dataset.aiLang"));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
