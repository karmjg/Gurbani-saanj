/* Gurbani Saanj v2.2.38 — ONE change (includes ALL of v2.2.37).
 * The Daily Hukamnama card on Home is more compact — smaller padding,
 * tighter gaps between the kicker/title/date/meta/preview, a smaller title
 * (21px, was 26px) and slimmer preview spacing — so more of the home page
 * fits on one screen. All card content is kept (kicker, title, date,
 * Ang/Raag meta, first-line preview, chevron); the green-and-gold card,
 * hero, Continue card, library tiles and trial label are unchanged.
 * Run: node test-v258.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.38', vj.version === '2.2.38');
ok('package.json is 2.2.38', pj.version === '2.2.38');
ok('version notes mention v2.2.33 + continuous listening + X stops mic',
  vj.notes.includes('v2.2.33:') && vj.notes.includes('listens continuously') && vj.notes.includes('stops the mic for real'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.35 + the 3 changes',
  vj.notes.includes('v2.2.35:') && vj.notes.includes('#fdfcf9') && vj.notes.includes('Noto Serif Gurmukhi') && vj.notes.includes('pack tight') && vj.notes.includes('Font size is unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.36 + centred search line',
  vj.notes.includes('v2.2.36:') && vj.notes.includes('middle of the screen') && vj.notes.includes('Page-turn, home and Kirtan jumps are unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.37 + brand language + Muse-style Stop',
  vj.notes.includes('v2.2.37:') && vj.notes.includes('Gurbani Saanjh') && vj.notes.includes('Stop button') && vj.notes.includes('keeps listening until you press Stop'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.38 + compact Hukamnama card',
  vj.notes.includes('v2.2.38:') && vj.notes.includes('more compact') && vj.notes.includes('21px') && vj.notes.includes('All card content is kept'),
  vj.notes.slice(-200));

// ---- 1. Static wiring for the fix ----
ok('voiceStopRequested flag exists', app.includes('let voiceStopRequested=false;'));
ok('partial listener accumulates into heard.seg/parts',
  app.includes('run.heard.seg') && app.includes('run.heard.parts') && app.includes('run.heard.text=[...run.heard.parts,run.heard.seg]'));
ok('listener ends a SEGMENT on stop (no run.finish)', app.includes('run.endSegment()') && !app.includes('run.finish()'));
ok('beginSegment + auto-restart loop present',
  app.includes('const beginSegment=async()=>') && app.includes('if(!(await beginSegment()))break;'));
ok('resetVoiceNow flags manual stop', app.includes('voiceStopRequested=true;') && app.includes('if(run)run.manualStopped=true;'));
ok('runEnded guard checks safety+manual+flag+current',
  app.includes('const runEnded=()=>run.safetyStopped||run.manualStopped||voiceStopRequested||voiceRun!==run;'));
ok('v2.2.37: no 15s cap left (no 15000 timer anywhere)', !app.includes('},15000);'));
ok('4s no-heard timer still present', app.includes('noHeardTimer') && app.includes('},4000);'));
ok('pa-IN -> en-US fallback still present', app.includes("native.start(opts('pa-IN'))") && app.includes("native.start(opts('en-US'))"));
ok('maxResults:5 + partialResults:true unchanged', app.includes('maxResults:5') && app.includes('partialResults:true'));
ok('X handler no longer restarts the mic', (() => {
  const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick'));
  return !!l && !l.includes('startVoiceSearch');
})());
ok('web fallback restarts on onend + accumulates',
  app.includes('rec.onend=()=>{') && app.includes("try{rec.start();}catch(e){finish(best);}"));
ok('web fallback respects manual stop (dead() checks voiceStopRequested + run sequence)',
  app.includes('const dead=()=>voiceStopRequested||mySeq!==voiceRunSeq;') && app.includes('if(finished||dead())return;'));

// ---- 1b. Static wiring for the v2.2.33 stale-event fix ----
ok('stale fix: resetVoiceNow returns a teardown promise (600ms backstop)',
  app.includes('voiceStopPromise=new Promise') && app.includes('to=setTimeout(finish,600);'));
ok('stale fix: teardown resolves on the old run\'s stopped event',
  app.includes('voiceStoppingRun') && app.includes("run._stopResolve=finish;"));
ok('stale fix: startVoiceSearch awaits the old run teardown before starting',
  app.includes('if(searchVoiceBusy){await resetVoiceNow();}'));
ok('stale fix: partialResults guard requires current + started + not manually stopped',
  app.includes('if(!run.started||run.manualStopped||voiceStopRequested)return;'));
ok('stale fix: listeningState guard requires started before endSegment',
  app.includes('if(run.sawStarted&&run.started)run.endSegment();'));
ok('stale fix: new voice run clears the search results area',
  app.includes("if(input.id==='searchInput'){const out=$('searchResults');if(out)out.innerHTML='';}"));
ok('stale fix: run sequence invalidates a dead run (voiceRunSeq)',
  app.includes('let voiceRunSeq=0;') && app.includes('const mySeq=++voiceRunSeq;') && app.includes('if(mySeq!==voiceRunSeq)return;'));
ok('stale fix: dead run cannot fill or set Review status',
  app.includes('if(mySeq===voiceRunSeq){\n     if(!heard.text.trim())throw Error'));
ok('stale fix: dead run finally cannot clear the new run state',
  app.includes('if(mySeq===voiceRunSeq){clearVoiceWatchdog();searchVoiceBusy=false;if(btn)btn.disabled=false;}'));

// ---- 2. Voice VM harness (fake clock + stubbed recognizers) ----
const _voiceLines = app.split('\n');
const _voiceStart = _voiceLines.findIndex(l => l.startsWith('let searchVoiceBusy=false;'));
const _voiceEnd = _voiceLines.findIndex((l, i) => i > _voiceStart && l.startsWith('// Settings "Test microphone"'));
const voiceSlice = _voiceLines.slice(_voiceStart, _voiceEnd).join('\n');
ok('voice slice extracted (searchVoiceBusy..startVoiceSearch)',
  voiceSlice.includes('async function startVoiceSearch') && voiceSlice.includes('function resetVoiceNow'));

function makeClock() {
  let now = 0, next = 1; const timers = new Map();
  const setTimeout = (fn, ms, ...args) => { const id = next++; timers.set(id, { fn, at: now + Math.max(0, ms || 0), args }); return id; };
  const clearTimeout = id => { timers.delete(id); };
  const advance = ms => {
    const end = now + ms; let guard = 0;
    while (guard++ < 20000) {
      let best = null, bestAt = Infinity;
      for (const [id, t] of timers) { if (t.at <= end && t.at < bestAt) { best = id; bestAt = t.at; } }
      if (best === null) break;
      now = bestAt; const t = timers.get(best); timers.delete(best); t.fn(...t.args);
    }
    now = end;
  };
  return { setTimeout, clearTimeout, advance, pending: () => timers.size, get now() { return now; } };
}
async function drive(clock, ms, step = 15) {
  const target = clock.now + ms;
  while (clock.now < target) {
    clock.advance(Math.min(step, target - clock.now));
    await new Promise(r => setImmediate(r));
    await new Promise(r => setImmediate(r));
  }
}
function fakeEl() {
  const classes = new Set();
  return {
    disabled: false, textContent: '', value: '',
    classList: {
      toggle(c, f) { if (f === undefined) { if (classes.has(c)) classes.delete(c); else classes.add(c); } else if (f) classes.add(c); else classes.delete(c); },
      add(c) { classes.add(c); },
      remove(c) { classes.delete(c); },
      contains(c) { return classes.has(c); },
    },
    dispatchEvent() {},
  };
}

// Stub native recognizer. script: array of utterances; each is an array of
// growing partial strings, or {delay, partials} for a late utterance.
// A start() with no scripted utterance emits 'started' and stays listening.
// stop() models a real recognizer: it cancels any pending partial/'stopped'
// timers for that run (a stopped recognizer emits no more events for it) and
// confirms 'stopped' asynchronously (stopDelay ms later), so the teardown
// promise resolves on the event, not on the stop() call. emit() lets a test
// inject a stale event from an old run after a new run started.
function makeStubNative(clock, script, opts = {}) {
  const listeners = {};
  const calls = { start: [], stop: 0, startAt: [] };
  let startCount = 0;
  let pending = [];
  const emit = (ev, data) => { (listeners[ev] || []).forEach(cb => { try { cb(data); } catch (e) { console.error('listener error', e); } }); };
  const stub = {
    available: async () => ({ available: true }),
    checkPermissions: async () => ({ speechRecognition: opts.perm || 'granted' }),
    requestPermissions: async () => ({ speechRecognition: opts.requestPerm || 'granted' }),
    addListener: (ev, cb) => { (listeners[ev] = listeners[ev] || []).push(cb); return Promise.resolve(); },
    start: async (o) => {
      calls.start.push(o && o.language);
      calls.startAt.push(clock.now);
      const idx = startCount++;
      if (opts.failPaIN && o && o.language === 'pa-IN') throw new Error('pa-IN unavailable');
      const raw = script[idx] || [];
      const delay = Array.isArray(raw) ? 0 : (raw.delay || 0);
      const utt = Array.isArray(raw) ? raw : (raw.partials || []);
      pending.push(clock.setTimeout(() => emit('listeningState', { status: 'started' }), 5));
      utt.forEach((p, i) => { pending.push(clock.setTimeout(() => emit('partialResults', { matches: [p] }), delay + 10 + i * 15)); });
      if (utt.length) pending.push(clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), delay + 10 + utt.length * 15 + 10));
      return;
    },
    stop: () => {
      calls.stop++;
      pending.forEach(id => clock.clearTimeout(id)); pending = [];
      clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), opts.stopDelay ?? 50);
      return Promise.resolve();
    },
    emit,
    _calls: calls,
  };
  return stub;
}

function makeNativeCtx(script, opts = {}) {
  const clock = makeClock();
  const stub = makeStubNative(clock, script, opts);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(), voiceStopBtn: fakeEl(), askVoiceStopBtn: fakeEl() };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { GS_SPEECH: stub, GS_NATIVE_UPDATES: { isNative: true } },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, stub, input, els, state, sandbox };
}
function readRun(ctx) {
  vm.runInContext('this.__r={run:voiceRun,busy:searchVoiceBusy,stopReq:voiceStopRequested};', ctx);
  return ctx.__r;
}

// Fake Web SpeechRecognition (for the fallback path). One instance; start()
// is called repeatedly on it, each call playing script[idx].
function makeFakeSR(clock, script) {
  const shared = { instances: [] };
  class FakeSR {
    constructor() { this.lang = ''; this.interimResults = false; this.maxAlternatives = 0; this.onresult = null; this.onerror = null; this.onend = null; this._n = 0; shared.instances.push(this); }
    start() {
      const idx = this._n++;
      const utt = script[idx] || [];
      utt.forEach((p, i) => { clock.setTimeout(() => { if (this.onresult) this.onresult({ results: [[{ transcript: p }]] }); }, 10 + i * 15); });
      if (utt.length) clock.setTimeout(() => { if (this.onend) this.onend(); }, 10 + utt.length * 15 + 10);
    }
    stop() { clock.setTimeout(() => { if (this.onend) this.onend(); }, 5); }
  }
  return { FakeSR, shared };
}
function makeWebCtx(script) {
  const clock = makeClock();
  const sr = makeFakeSR(clock, script);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(), voiceStopBtn: fakeEl(), askVoiceStopBtn: fakeEl() };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { SpeechRecognition: sr.FakeSR },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, sr, input, els, state, sandbox };
}

// ---- 3. Behavioral voice tests (async, fake clock) ----
let p;
// (a) Auto-restart accumulates ALL words across segments (the reported bug)
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(a) auto-restart: all 6 words in the input after 2 segments',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(a) auto-restart: recognizer started 3 times (initial + 2 restarts)',
    t.stub._calls.start.length === 3, JSON.stringify(t.stub._calls.start));
  // v2.2.37: no 15s cap — the run must still be listening long past it.
  await drive(t.clock, 30000);
  ok('(a) v2.2.37: no 15s cap — still listening after 30s (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(a) v2.2.37: no restart storm while waiting (start count stays 3)',
    t.stub._calls.start.length === 3, `starts=${t.stub._calls.start.length}`);
  // Stop ends it right away, words intact.
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(a) v2.2.37: Stop settles the run with the 6 words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(a) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r.run === null && r.busy === false, JSON.stringify(r));
}
// (b) Manual stop (X / resetVoiceNow) — no restart after it
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(b) before stop: 3 words heard, recognizer restarted once',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ' && t.stub._calls.start.length === 2,
    `value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  vm.runInContext('resetVoiceNow()', t.ctx);
  const startsAtStop = t.stub._calls.start.length;
  await drive(t.clock, 3000);
  ok('(b) manual stop: no restart after X (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(b) manual stop: the 3 words stay in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
  await drive(t.clock, 2000);
  ok('(b) v2.2.37: run resolves promptly after manual stop (Stop ends the wait, no safety timer)',
    settled === true, `settled=${settled}`);
}
// (c) v2.2.37: NO 15s cap — the run keeps listening past 15s and past 30s,
// and only Stop ends it.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1000);
  const r1 = readRun(t.ctx);
  ok('(c) run listening after the first segment (voiceRun set, busy)',
    r1.run !== null && r1.busy === true, JSON.stringify({ run: !!r1.run, busy: r1.busy }));
  await drive(t.clock, 30000);
  ok('(c) v2.2.37: still listening after 30s — no 15s cap (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(c) v2.2.37: no restart while waiting (start count stays 2)',
    t.stub._calls.start.length === 2, `starts=${t.stub._calls.start.length}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(c) v2.2.37: Stop ends the run with the words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  const r2 = readRun(t.ctx);
  ok('(c) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r2.run === null && r2.busy === false, JSON.stringify(r2));
}
// (d) 4s no-heard notice, then recovery when words arrive
{
  const t = makeNativeCtx([
    { delay: 5000, partials: ['ਸਤਿਨਾਮੁ'] },
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 4500);
  ok('(d) 4s no-heard notice fires when nothing is heard',
    t.els.voiceStatus.textContent.includes('not hearing'),
    JSON.stringify(t.els.voiceStatus.textContent));
  await drive(t.clock, 1500);
  ok('(d) status returns to Listening when words arrive',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(d) the word is captured after the notice',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (e) Permission denied + pa-IN -> en-US fallback
{
  const t = makeNativeCtx([], { perm: 'denied', requestPerm: 'denied' });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 500);
  ok('(e1) permission denied: status explains it',
    t.els.voiceStatus.textContent.includes('permission was denied'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(e1) permission denied: recognizer never started',
    t.stub._calls.start.length === 0, `starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(e1) permission denied: mic button re-enabled, not busy',
    r.busy === false && t.els.voiceBtn.disabled === false, JSON.stringify({ busy: r.busy, disabled: t.els.voiceBtn.disabled }));
}
{
  const t = makeNativeCtx([[], ['ਸਤਿਨਾਮੁ']], { failPaIN: true });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 800);
  ok('(e2) pa-IN fails -> en-US fallback is tried',
    t.stub._calls.start[0] === 'pa-IN' && t.stub._calls.start[1] === 'en-US',
    JSON.stringify(t.stub._calls.start));
  ok('(e2) fallback run hears words on the en-US start',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) Web Speech fallback accumulates across onend restarts
{
  const t = makeWebCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(f) web fallback: all 6 words after 2 onend restarts',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(f) web fallback: recognizer started 3 times',
    t.sr.shared.instances[0]._n === 3, `starts=${t.sr.shared.instances[0]._n}`);
  // v2.2.37: no 15s cap on the web path either.
  await drive(t.clock, 30000);
  ok('(f) v2.2.37: web fallback still listening after 30s (not settled)',
    settled === false && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(f) v2.2.37: web fallback Stop settles the run with the 6 words',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// (g) v2.2.37: the Stop button shows while listening and stops right away.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  ok('(g) Stop button visible while listening (gs-show on voiceStopBtn)',
    t.els.voiceStopBtn.classList.contains('gs-show') === true,
    JSON.stringify(t.els.voiceStopBtn.classList.contains('gs-show')));
  ok('(g) mic button has the listening ring while listening',
    t.els.voiceBtn.classList.contains('gs-listening') === true,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  ok('(g) status shows Listening while listening',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(g) Stop button itself is not disabled while listening',
    t.els.voiceStopBtn.disabled === false,
    JSON.stringify(t.els.voiceStopBtn.disabled));
  const startsAtStop = t.stub._calls.start.length;
  vm.runInContext('stopVoiceSearch()', t.ctx);
  // Immediate: the listening UI turns off synchronously with the Stop tap.
  ok('(g) Stop turns the listening UI off at once (gs-show removed)',
    t.els.voiceStopBtn.classList.contains('gs-show') === false,
    JSON.stringify(t.els.voiceStopBtn.classList.contains('gs-show')));
  ok('(g) Stop turns the mic ring off at once',
    t.els.voiceBtn.classList.contains('gs-listening') === false,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  await drive(t.clock, 2000);
  ok('(g) Stop settles the run right away',
    settled === true, `settled=${settled}`);
  ok('(g) no restart after Stop (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(g) Stop keeps the spoken words in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
}
// (h) v2.2.37: after a re-render (fresh button elements), the Stop button
// re-appears while a run is still listening.
{
  const t = makeNativeCtx([['ਸਤਿਨਾਮੁ']]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  // Simulate a re-render: the buttons are recreated without the class.
  t.els.voiceStopBtn = fakeEl();
  t.els.askVoiceStopBtn = fakeEl();
  ok('(h) fresh Stop button has no gs-show before sync',
    t.els.voiceStopBtn.classList.contains('gs-show') === false,
    JSON.stringify(t.els.voiceStopBtn.classList.contains('gs-show')));
  vm.runInContext('syncVoiceStopUI()', t.ctx);
  ok('(h) sync restores gs-show on the fresh Stop button while listening',
    t.els.voiceStopBtn.classList.contains('gs-show') === true,
    JSON.stringify(t.els.voiceStopBtn.classList.contains('gs-show')));
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(h) Stop after re-render settles the run with the word intact',
    settled === true && t.input.value.includes('ਸਤਿਨਾਮੁ'),
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// ---- 4. v2.2.32 regressions (static — the full suite also runs in test-v252) ----
ok('regression v2.2.32: AI language follows app language (aiLangManual sync)',
  app.includes('aiLangManual') && app.includes("if(!state.aiLangManual)state.aiLang=state.lang;"));
ok('regression v2.2.32: transliteration in search results',
  app.includes('gs-result-roman') && ss.includes("roman:String(roman||'')"));
ok('regression v2.2.32: cloud AI by default',
  app.includes("AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev'"));
ok('regression v2.2.31: elaborate prompt + Dasam Granth in worker',
  worker.includes('Dasam Granth') && worker.includes('1500') && worker.includes('total essence'));
ok('regression v2.2.30: Hindi absent, English in search results, font slider',
  !app.includes('showHi') && app.includes('gs-result-en') && app.includes('fontSlider'));
ok('regression v2.2.28: search source labels',
  app.includes('gs-result-bani-tag') && app.includes('Dasam Granth'));
ok('regression v2.2.27: reader top bar hide/show',
  app.includes('barScrollDecision') && app.includes('readerBarHidden'));
ok('regression v2.2.26: centered Bani headings, pinch Ask-only',
  css.includes('text-align:center') && app.includes('pinchFont') && app.includes('pinchDist'));
ok('regression: voice permission flow (fast path + listeners once)',
  app.includes('voicePermGranted') && app.includes('ensureVoiceListeners'));

// ---- 5. v2.2.33 stale-event fix (behavioral) ----
// Helper: drive 1ms at a time until a voice run exists (voiceRun set).
// Catches the window after a new run is created but before its 'started'
// event fires (5ms after start()).
async function waitForRun(t, maxMs = 300) {
  for (let i = 0; i < maxMs; i++) {
    if (readRun(t.ctx).run) return true;
    await drive(t.clock, 1, 1);
  }
  return !!readRun(t.ctx).run;
}
// (a) Delayed partial from run A arriving after run B started is IGNORED
{
  const t = makeNativeCtx([
    { delay: 300, partials: ['WORD1'] },
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 100);
  // X: reset stops run A (its pending partial at 310ms is cancelled) + start B.
  vm.runInContext('resetVoiceNow()', t.ctx);
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(a) stale partial: run B keeps ONLY its own words (WORD1 never appears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(a) stale partial: WORD1 never appears even after the full run',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
}
// (a2) Guard: a partial injected after run B is created but before its
// 'started' event is ignored (the started check).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(a2) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale partial from run A right now (run B not started yet).
  t.stub.emit('partialResults', { matches: ['WORD1'] });
  await drive(t.clock, 600);
  ok('(a2) guard: stale partial before started is ignored',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (b) Delayed 'stopped' from run A arriving after run B started does NOT
// end run B's segment (run B keeps listening).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(b) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale 'stopped' from run A right now (run B not started yet).
  t.stub.emit('listeningState', { status: 'stopped' });
  await drive(t.clock, 600);
  const r = readRun(t.ctx);
  ok('(b) stale stopped: run B keeps listening and hears its own words',
    t.input.value === 'WORD2' && r.run !== null && r.busy === true,
    `value=${JSON.stringify(t.input.value)} run=${!!r.run} busy=${r.busy}`);
  await drive(t.clock, 17000);
}
// (c) X -> tap mic -> speak word 2 gives ONLY word 2's results
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  ok('(c) word 1 heard first', t.input.value === 'WORD1', JSON.stringify(t.input.value));
  // X: reset + clear the input (what the X handler does).
  vm.runInContext('resetVoiceNow()', t.ctx);
  t.input.value = '';
  // Tap the mic again and speak word 2.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(c) X -> mic -> word 2: ONLY word 2 in the input (word 1 never reappears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(c) X -> mic -> word 2: word 1 still absent after the full run',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
}
// (d) v2.2.37: a run that hears nothing does NOT end by itself — it keeps
// listening until Stop; Stop settles it and the mic button is re-enabled.
{
  const t = makeNativeCtx([[]]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 20000);
  ok('(d) v2.2.37: nothing heard yet the run keeps listening (not settled)',
    settled === false && readRun(t.ctx).run !== null,
    `settled=${settled}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d) v2.2.37: Stop settles the empty run',
    settled === true, `settled=${settled}`);
  const r = readRun(t.ctx);
  ok('(d) v2.2.37: mic button re-enabled, not busy, run cleaned up after Stop',
    r.busy === false && r.run === null && t.els.voiceBtn.disabled === false,
    `settled=${settled} busy=${r.busy} run=${!!r.run} disabled=${t.els.voiceBtn.disabled}`);
  ok('(d) v2.2.37: input stays empty after Stop with nothing heard',
    t.input.value === '', JSON.stringify(t.input.value));
}
// (e) Starting a new voice run clears the previous search results.
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  // The results area (not in the default els) — add it so the clear is visible.
  t.els.searchResults = { innerHTML: '' };
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  // Simulate run A's search results sitting in the results area.
  t.els.searchResults.innerHTML = '<div>old results for WORD1</div>';
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 600);
  ok('(e) new voice run clears the previous search results',
    t.els.searchResults.innerHTML === '', JSON.stringify(t.els.searchResults.innerHTML));
  ok('(e) new run still hears its own words',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) A mic tap while busy waits for the old run to fully stop before the
// new run starts (serialized, no overlap).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  const tapAt = t.clock.now;
  const startsBeforeTap = t.stub._calls.start.length;
  // Mic tap while run A is busy — must wait for run A to fully stop.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  // Run B's first start is the one after the tap. It must be after the
  // teardown ('stopped' 50ms after stop() at the tap) — no overlap.
  ok('(f) serialized: new run starts only after the old run stopped',
    t.stub._calls.startAt.length > startsBeforeTap && t.stub._calls.startAt[startsBeforeTap] >= tapAt + 50,
    `startAt=${JSON.stringify(t.stub._calls.startAt)} tapAt=${tapAt} startsBeforeTap=${startsBeforeTap}`);
  ok('(f) serialized: new run hears its own words, not the old run\'s',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}


// ---- 6. v2.2.35 white Bani bg + tight Jaap pairs + Noto Serif Gurmukhi ----
const fs2 = fs;
const fontsDir = path.join(ROOT, 'www/assets/fonts');
// (v2.2.35a) The cream bug: NO #fdfcf9 anywhere, Bani reader is pure white.
ok('v235: no #fdfcf9 anywhere in the CSS (the missed cream hex is gone)',
  !/#fdfcf9/i.test(css));
ok('v235: Bani reader background is pure white (#ffffff)',
  css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }'));
ok('v235: no near-cream background left in the Bani reader path',
  // Cream = R>=245, G>=240, B>=235 but not pure white. The night-mode dark
  // background #0b0e0c is intentional and must not fail this check.
  ![...css.matchAll(/\.gs-reader-bani[^\{]*\{([^}]*)\}/g)]
    .some(m => [...m[1].matchAll(/background\s*:\s*#([0-9a-f]{6})/gi)]
      .some(h => { const v = parseInt(h[1], 16);
        return v !== 0xffffff && ((v >> 16) & 255) >= 245 && ((v >> 8) & 255) >= 240 && (v & 255) >= 235; })));
// (v2.2.35b) The ::after strut is gone for Bani blocks (SGGS keeps it).
ok('v235: Bani ::after strut override present (content:none, Bani only)',
  css.includes('.gs-reader-bani #verses .verse-block:after{content:none!important;}'));
ok('v235: SGGS still gets the compact ::after strut (Japji unchanged)',
  css.includes('.verse-list .verse-block:after{content:" ";white-space:pre}'));
ok('v235: pair margin-bottom is 0 (was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}') && !css.includes('margin-bottom:0.25em'));
ok('v235: no +0.15 line-height extra left anywhere',
  !/var\(--leading\)\s*\+\s*0\.15/.test(css));
ok('v235: Bani reader widened to Sundar Gutka side margins (720px / 16px)',
  css.includes('.gs-reader-bani .reading{max-width:720px;padding-left:16px;padding-right:16px;}'));
// (v2.2.35c) Noto Serif Gurmukhi bundled, first in stacks; Tiro kept as fallback.
const tiroG = path.join(fontsDir, 'tiro-gurmukhi-400-gurmukhi.woff2');
const tiroL = path.join(fontsDir, 'tiro-gurmukhi-400-latin.woff2');
const notoG = path.join(fontsDir, 'noto-serif-gurmukhi-400-gurmukhi.woff2');
const notoL = path.join(fontsDir, 'noto-serif-gurmukhi-400-latin.woff2');
const notoG7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-gurmukhi.woff2');
const notoL7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-latin.woff2');
ok('v235: Noto Serif 400 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG) && fs2.statSync(notoG).size > 10000 &&
  fs2.existsSync(notoL) && fs2.statSync(notoL).size > 10000);
ok('v235: Noto Serif 700 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG7) && fs2.statSync(notoG7).size > 10000 &&
  fs2.existsSync(notoL7) && fs2.statSync(notoL7).size > 10000);
ok('v235: Noto Serif woff2 files are real woff2 bytes',
  fs2.readFileSync(notoG).subarray(0, 4).toString() === 'wOF2' &&
  fs2.readFileSync(notoG7).subarray(0, 4).toString() === 'wOF2');
ok('v235: @font-face for Noto Serif 400 + 700 references the bundled files',
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:400;') &&
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:700;') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-700-gurmukhi.woff2)'));
ok('v235: Tiro files still present as fallback (not deleted)',
  fs2.existsSync(tiroG) && fs2.existsSync(tiroL));
// (a) Background #FFFFFF in the default theme: every :root fallback AND the
// light-tone rule that actually wins (html[data-tone="light"]).
for (const [name, re] of [
  ['default :root (line 1)', /:root\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
  ['v0.6 :root', /:root\{--bg:#ffffff;--paper:#ffffff;/],
  ['v1.0 :root', /:root \{--bg:#ffffff;--paper:#ffffff;/],
  ['light tone rule', /html\[data-tone="light"\]\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
]) ok(`bg: ${name} is #FFFFFF`, re.test(css));
ok('bg: sepia tone untouched (#f4eddf)', css.includes('html[data-tone="sepia"]{color-scheme:light;--bg:#f4eddf;--paper:#f4eddf;'));
ok('bg: charcoal tone untouched (#242729)', css.includes('html[data-tone="charcoal"]{color-scheme:dark;--bg:#242729;--paper:#242729;'));
ok('bg: dark theme untouched (#151e19)', css.includes('.dark{color-scheme:dark;--bg:#151e19;--paper:#151f1a;'));
ok('bg: no other default --bg/--paper left behind',
  // Only the --bg/--paper variables must be white. The home screen keeps its
  // own cream surfaces (.home-v10, .home-tile, .home-list-item, .hero-temple,
  // .daily-card) by design, so #fbf7ef/#fffdfa as a `background:` value is fine.
  !/--(?:bg|paper):#(eeeee9|fcfbf8|f2f0e9|faf9f5|f3eee5|fbf7ef)/.test(css));
ok('home: home screen unchanged (cream, per Karamjit)',
  css.includes('.home-v10{padding:0 17px 22px;background:#fbf7ef}') &&
  (css.match(/background:#fffdfa/g) || []).length === 2 &&
  css.includes('linear-gradient(0deg,#fbf7ef 0%,transparent 20%)') &&
  css.includes('background:linear-gradient(130deg,#f2f7ef,#fcfaf3)'));
// (b) Leading + block margin.
ok('gaps: base --leading is 1.5', css.includes('--font:25px;--leading:1.5;'));
ok('gaps: verse-block margin is 8px', css.includes('.verse-block{margin:0 0 8px}'));
ok('gaps: font size still 25px', css.includes('--font:25px;'));
ok('gaps: line-layout leading tightened (compact 1.35 / standard 1.5 / spacious 1.65)',
  css.includes('html[data-line-layout="compact"]{--leading:1.35;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="standard"]{--leading:1.5;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="spacious"]{--leading:1.65;--verse-gap:0px;}'));
ok('gaps: theme() map tightened to match', app.includes("const ls={compact:[1.35,'0px'],standard:[1.5,'0px'],spacious:[1.65,'0px']}"));
ok('gaps: Bani para margin tightened to .3em, no +0.15 line-height extra',
  css.includes('.gs-bani-para{display:block!important;text-align:center!important;line-height:var(--leading)!important;margin:0 0 .3em!important;'));
ok('gaps: Bani stanza-end margin tightened to .3em', css.includes('html.reading-open .gs-reader-bani #verses .gs-pankti.gs-stanza-end{margin-bottom:.3em!important;}'));
ok('gaps: Bani pankti line-height is var(--leading) (no +0.15 extra)',
  css.includes('.gs-bani-pankti .verse-text { line-height: var(--leading); }'));
// (c) Bundled Tiro Gurmukhi font.
ok('font: gurmukhi woff2 bundled', fs2.existsSync(tiroG) && fs2.statSync(tiroG).size > 10000);
ok('font: latin woff2 bundled', fs2.existsSync(tiroL) && fs2.statSync(tiroL).size > 10000);
ok('font: gurmukhi woff2 is real woff2 bytes', fs2.readFileSync(tiroG).subarray(0, 4).toString() === 'wOF2');
ok('font: latin woff2 is real woff2 bytes', fs2.readFileSync(tiroL).subarray(0, 4).toString() === 'wOF2');
ok('font: @font-face references the bundled files',
  css.includes('@font-face{font-family:"Tiro Gurmukhi"') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-latin.woff2)'));
ok('font: Noto Serif Gurmukhi is first in every serif Gurmukhi stack',
  (css.match(/"Noto Serif Gurmukhi","Tiro Gurmukhi"/g) || []).length >= 15 &&
  // A Tiro-first STACK has a comma after Tiro; @font-face declarations end
  // with a semicolon and must not count.
  !/font-family:"Tiro Gurmukhi",/.test(css));
ok('font: serif data-font override uses Noto Serif first',
  css.includes('html[data-font="serif"] .verse-text,html[data-font="serif"] .word,html[data-font="serif"] .daily-quote{font-family:"Noto Serif Gurmukhi","Tiro Gurmukhi","Raavi","Nirmala UI",serif}'));
ok('font: sans/system data-font overrides keep their stacks (no Noto Serif forced)',
  css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Sans Gurmukhi","Mukta Mahee","Nirmala UI",sans-serif}') &&
  !css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Serif Gurmukhi"'));
ok('font: no external/webfont link anywhere (offline)',
  !css.includes('fonts.googleapis') && !css.includes('fonts.gstatic') &&
  !html.includes('fonts.googleapis') && !html.includes('fonts.gstatic') &&
  !app.includes('fonts.googleapis') && !app.includes('fonts.gstatic'));
ok('font: vishraam colours unchanged (green/orange still in CSS)',
  css.includes('.vishraam-short') && css.includes('.vishraam-long'));


// ---- 7. v2.2.35 transliteration per line (iGranth) + Jaap Sahib pairs ----
const vm2 = vm;
const sandbox7 = {window:{}, console};
vm2.runInNewContext(rv, sandbox7);
const V7 = sandbox7.window.GS_VERSES;
const jaapLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/4.json'), 'utf8')).lines;
const anandLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/10.json'), 'utf8')).lines;
// Anand opening: "ਅਨੰਦੁ ਭਇਆ ਮੇਰੀ ਮਾਏ ਸਤਿਗੁਰੂ ਮੈ ਪਾਇਆ ॥" + next pankti.
const anandPara = anandLines.slice(2, 4);
const htmlOn = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{translit:true}, foundIdx:-1});
const htmlOff = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{}, foundIdx:-1});
// (a) Translit ON: one roman block per pankti, directly under its own line.
const romanTexts = [...htmlOn.matchAll(/<div class="verse-layer verse-roman"[^>]*>([^<]*)<\/div>/g)].map(m => m[1]);
ok('translit: one roman block per pankti', romanTexts.length === anandPara.length, `got ${romanTexts.length}, want ${anandPara.length}`);
ok('translit: first roman is that pankti only (not joined)',
  romanTexts[0] === 'anand bheaa meree maae; satiguroo. mai paaeaa |', JSON.stringify(romanTexts[0]));
ok('translit: second roman is that pankti only (not joined)',
  romanTexts[1] === 'satigur. ta paaeaa sehaj setee; man vajeea vaadhaaeea |', JSON.stringify(romanTexts[1]));
ok('translit: each roman sits inside its own pankti block, right after its verse-text',
  [...htmlOn.matchAll(/<div class="verse-block gs-pankti[^>]*><div class="verse-text"[^>]*>[\s\S]*?<\/div><div class="verse-layer verse-roman"/g)].length === anandPara.length);
ok('translit: every word still a tappable button',
  (htmlOn.match(/<button type="button" class="word"/g) || []).length >= 10);
ok('translit: no joined paragraph roman (no single block holding both romans)',
  !romanTexts.some(t => t.includes('anand bheaa') && t.includes('satigur. ta paaeaa')));
// (b) Translit OFF: flowing paragraph unchanged — one verse-text holds the
// whole paragraph's words, no roman at all.
ok('translit off: one flowing verse-text holds the whole paragraph',
  (htmlOff.match(/<div class="verse-block gs-bani-para"/g) || []).length === 1 &&
  htmlOff.includes('ਅਨੰਦੁ') && htmlOff.includes('ਵਾਧਾਈਆ'));
ok('translit off: no roman blocks', !htmlOff.includes('verse-roman'));
// (c) Jaap Sahib pair mode: short "ਨਮਸਤੁੰ" panktis pair two-per-block after
// the "ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥" heading, and render as tight pair blocks.
const jaapGroups = V7.groupBaniParagraphs(jaapLines.slice(2, 30));
const pairGroups = jaapGroups.filter(g => g.type === 'pair');
ok('jaap: short namastun panktis pair two-per-block',
  pairGroups.filter(g => g.items.length === 2).length >= 8,
  `pairs=${pairGroups.length} full=${pairGroups.filter(g => g.items.length === 2).length}`);
const jaapHtml = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{}, foundIdx:-1});
ok('jaap: pair blocks render as gs-bani-para gs-bani-pair',
  (jaapHtml.match(/class="verse-block gs-bani-para gs-bani-pair"/g) || []).length >= 8);
ok('jaap: pair block holds both short panktis on one tight block',
  (jaapHtml.match(/<div class="verse-block gs-bani-para gs-bani-pair"[^>]*>[\s\S]*?<\/div><\/div>/g) || [])
    .some(b => { const t = b.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '); return t.includes('ਨਮਸਤ੍ਵੰ ਅਕਾਲੇ') && t.includes('ਨਮਸਤ੍ਵੰ ਕ੍ਰਿਪਾਲੇ'); }));
ok('jaap: pair/para margin is tight (.3em, not the old .6em)',
  css.includes('margin:0 0 .3em!important;') && !css.includes('margin:0 0 .6em!important;'));
ok('jaap: pair margin-bottom is 0 (tight, was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}'));
// (d) Ang reader untouched: verseHTML still puts roman under each line.
const angLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1.json'), 'utf8')).lines;
const angHtml = angLines.slice(0, 3).map((line, i) => V7.verseHTML(line, {idx:i, kind:'ang', vishraamOn:false, show:{translit:true}})).join('');
ok('ang: roman still per line under its own pankti',
  (angHtml.match(/verse-roman/g) || []).length === 3);


// ---- 8. v2.2.36 centred search line (ONE change) ----
// (a) SGGS scroll-mode resume: the line's centre lands at innerHeight/2.
const resumeLine = app.split('\n').find(l => l.includes('state.readView') && l.includes('state.mode') && l.includes('scroll') && l.includes('getBoundingClientRect'));
ok('v2.2.36: SGGS resume scroll centres the line (r.top + r.height/2 - innerHeight/2)',
  !!resumeLine && resumeLine.includes('r.top+r.height/2-window.innerHeight/2') && resumeLine.includes('Math.max(0,y)'),
  resumeLine ? resumeLine.slice(0, 200) : 'resume line not found');
ok('v2.2.36: SGGS resume scroll has no -73 top offset left',
  !app.includes('getBoundingClientRect().top-73'));
ok('v2.2.36: SGGS resume still keeps the user scroll progress (verseOffset)',
  !!resumeLine && resumeLine.includes('+state.verseOffset'));
// (b) Bani/remote jump (search tap, saved verse, resume): block:'center'.
const jumpLine = app.split('\n').find(l => l.includes('highlightLine') && l.includes('scrollIntoView'));
ok('v2.2.36: remote line jump uses scrollIntoView block center',
  !!jumpLine && jumpLine.includes("scrollIntoView({block:'center'})"),
  jumpLine ? jumpLine.slice(-160) : 'jump line not found');
ok('v2.2.36: remote line jump no longer uses block start',
  !!jumpLine && !jumpLine.includes("block:'start'"));
// (c) Out of scope — unchanged: page-turn, home, Kirtan alphabet jump.
ok('v2.2.36: page-turn still scrolls to top (turn() unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes('function turn(dir)')); return !!l && l.includes('window.scrollTo({top:0,behavior:'); })());
ok('v2.2.36: leaving the reader still scrolls home to top (go() unchanged)',
  app.includes("if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});"));
ok('v2.2.36: Kirtan alphabet jump still block start (list row, not a pangti)',
  app.includes("row.scrollIntoView({block:'start'})"));
ok('v2.2.36: Kirtan shabad open still scrolls to top',
  (() => { const i = app.indexOf('async function openKirtanShabad'); const seg = app.slice(i, i + 1500); return seg.includes('window.scrollTo({top:0,behavior:'); })());
// (d) The search tap still sets highlightLine and opens with progress.
ok('v2.2.36: search tap still sets highlightLine + openAng/openBani with preserveProgress',
  app.includes('highlightLine=Number(found.dataset.foundIdx') && app.includes('openAng(Number(found.dataset.foundAng') && app.includes('openBani(Number(foundBani.dataset.foundBani'));

// ---- 6. v2.2.37: brand follows language + Muse-style Stop button ----
// (a) Brand.
ok('v2.2.37: top-bar brand follows the app language (render uses age)',
  app.includes("$('brand').textContent=age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh');"));
ok('v2.2.37: home hero brand follows the app language',
  app.includes("<h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: search header follows the app language',
  app.includes("<div class=\"search-darkhead\"><h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: no "Saanj" without H left in app.js',
  !/Saanj(?!h)/.test(app));
ok('v2.2.37: settings subtitle left alone (version line, not a brand)',
  app.includes("ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}"));
// (b) Stop button present + wired.
ok('v2.2.37: Stop button in the search box next to the mic',
  app.includes('id="voiceStopBtn"') && app.includes('class="gs-voice-stop"'));
ok('v2.2.37: Stop button on the Ask screen next to the mic',
  app.includes('id="askVoiceStopBtn"'));
ok('v2.2.37: Stop button CSS hides it until listening (gs-show)',
  css.includes('.gs-voice-stop{display:none}') && css.includes('.gs-voice-stop.gs-show{display:inline-flex}'));
ok('v2.2.37: setListeningUI shows/hides the Stop buttons with the ring',
  app.includes("for(const id of ['voiceStopBtn','askVoiceStopBtn']){const b=$(id);if(b)b.classList.toggle('gs-show',on);}"));
ok('v2.2.37: Stop buttons wired in attach (search + Ask)',
  app.includes("if(vsb)vsb.onclick=()=>stopVoiceSearch();") && app.includes("if(avs)avs.onclick=()=>stopVoiceSearch();"));
ok('v2.2.37: stopVoiceSearch stops the mic without clearing the search',
  app.includes('function stopVoiceSearch(){resetVoiceNow();}'));
ok('v2.2.37: Stop sync re-applied after every render (attach calls it)',
  app.includes('function syncVoiceStopUI(){') && app.includes('syncVoiceStopUI();'));
// (c) Listen until Stop.
ok('v2.2.37: watchdog is the 2-minute per-segment backstop (120000)',
  app.includes('},120000);'));
ok('v2.2.37: watchdog re-armed per segment (native + web restarts)',
  (app.match(/armVoiceWatchdog\(btn\);/g) || []).length >= 3);
ok('v2.2.37: resetVoiceNow wakes the run loop at once (endSegment)',
  app.includes('if(run)run.endSegment();'));
ok('v2.2.37: web fallback recognizer stopped right away (voiceWebRec)',
  app.includes('let voiceWebRec=null;') && app.includes('voiceWebRec=rec;') && app.includes('if(voiceWebRec){try{voiceWebRec.stop()}catch{}voiceWebRec=null;}'));
ok('v2.2.37: X still clears search + stops mic (unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick')); return !!l && l.includes('resetVoiceNow()') && l.includes("input.value=''") && l.includes("innerHTML=''"); })());

// ---- v2.2.38: Daily Hukamnama card is more compact (Home) ----
ok('v2.2.38: hukam-hero padding is compact (8px 14px 7px)',
  css.includes('padding:8px 14px 7px;') && !css.includes('padding:12px 16px 11px;'));
ok('v2.2.38: hukam-hero margins tightened (8px 0 5px)',
  css.includes('.hukam-hero{display:block;width:100%;text-align:center;border:0;cursor:pointer;') &&
  /\.hukam-hero\{[^}]*margin:8px 0 5px;/.test(css));
ok('v2.2.38: hukam-hero title smaller (21px, was 26px)',
  css.includes('.hukam-hero-title{display:block;font-size:21px;') && !css.includes('.hukam-hero-title{display:block;font-size:26px;'));
ok('v2.2.38: hukam-hero kicker/date/meta tightened to 12px with 2px gaps',
  css.includes('.hukam-hero-kicker{display:block;font-size:12px;') && css.includes('margin-bottom:2px;}') &&
  css.includes('.hukam-hero-date{display:block;font-size:12px;') && css.includes('margin-top:2px;}') &&
  css.includes('.hukam-hero-meta{display:block;font-size:12px;'));
ok('v2.2.38: hukam-hero preview slimmer (16px, line-height 1.35, margin-top 5px)',
  css.includes('.hukam-hero-preview{display:block;font-size:16px;line-height:1.35;margin-top:5px;') &&
  !css.includes('.hukam-hero-preview{display:block;font-size:18px;line-height:1.5;margin-top:8px;'));
ok('v2.2.38: hukam-hero chevron smaller with tighter gap (16px, margin-top 3px)',
  css.includes('.hukam-hero-go{display:block;font-size:16px;line-height:1;color:#e6c25a;margin-top:3px;}'));
ok('v2.2.38: hukam-hero keeps its green-and-gold card (gradient + radius + shadow)',
  css.includes('background:linear-gradient(180deg,#14532d,#0b3d20);color:#fdf6e3;border-radius:14px;') &&
  css.includes('box-shadow:0 4px 14px rgba(11,61,32,.25);}'));
ok('v2.2.38: no Hukamnama card content removed (kicker/title/date/meta/preview/sub/chevron all rendered)',
  app.includes('hukam-hero-kicker') && app.includes('hukam-hero-title') && app.includes('hukam-hero-date') &&
  app.includes('hukam-hero-meta') && app.includes('hukam-hero-preview') && app.includes('hukam-hero-sub') && app.includes('hukam-hero-go'));
ok('v2.2.38: hero untouched (premium-hero still 274px)',
  css.includes(".premium-hero{position:relative;margin:0 -17px 10px;background:linear-gradient(180deg,#fffaf0,#fcf4e6 74%,#faf4e9);height:274px;"));
ok('v2.2.38: Continue card untouched (home-v10 min-height 65px)',
  css.includes('.home-v10 .continue-card{min-height:65px;'));
ok('v2.2.38: library tiles untouched (tile-3d still min-height 164px)',
  css.includes('.home-v7 .home-tile.tile-3d{min-height:164px;'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
