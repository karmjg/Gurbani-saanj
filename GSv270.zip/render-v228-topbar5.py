#!/usr/bin/env python3
"""Photo of change #5 (reader top bar) — SGGS Ang-jump bar + Bani drawer bar."""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'; YELLOW = '#fff2a8'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>',
     f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']

# --- label + SGGS bar ---
s.append(text(32, 64, 'SGGS — Ang jump bar', 26, PRIMARY, LATIN, '700'))
s.append(rect(0, 88, W, 108, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="196" x2="{W}" y2="196" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 156, 'ਅੰਗ', 30, INK, SANS, '700'))
s.append(rect(118, 114, 150, 56, '#ffffff', 14, LINE, 2))
s.append(text(193, 154, '205', 32, INK, LATIN, '400', 'middle'))
s.append(rect(284, 110, 130, 64, PRIMARY, 18))
s.append(tspans(349, 154, [('ਜਾਓ ', SANS, '650', '#ffffff'), ('›', SYM, '650', '#ffffff')], 28, 'middle'))
s.append(text(W - 32, 156, 'Aa', 32, INK, LATIN, '400', 'end'))
# SGGS verses under it
s.append(text(W / 2, 280, 'ਅੰਤਰਿ ਅਲਖੁ ਨ ਜਾਈ ਲਖਿਆ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 334, 'ਵਿਚਿ ਪੜਦਾ ਹਉਮੈ ਪਾਈ ॥', 40, INK, SERIF, '550', 'middle'))
s.append(rect(24, 372, W - 48, 118, YELLOW, 16))
s.append(text(W / 2, 422, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 472, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 40, INK, SERIF, '550', 'middle'))
s.append(tspans(W / 2, 560, [('ਅੰਗ 205 ', SANS, '400', MUTED), ('·', SYM, '400', MUTED), (' ਸਿਰੀਰਾਗੁ', SANS, '400', MUTED)], 24, 'middle'))

# --- divider ---
s.append(f'<line x1="32" y1="640" x2="{W-32}" y2="640" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 700, 'Nitnem / Bani — drawer bar', 26, PRIMARY, LATIN, '700'))

# --- Bani bar ---
s.append(rect(0, 724, W, 108, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="832" x2="{W}" y2="832" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 792, '☰', 40, INK, SYM, '400'))
s.append(text(96, 792, 'ਜਪੁਜੀ ਸਾਹਿਬ', 36, INK, SERIF, '700'))
s.append(text(W - 32, 792, 'Aa', 32, INK, LATIN, '400', 'end'))
# Bani header + Japji lines
s.append(text(W / 2, 920, 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥', 34, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 980, 'ਜਪੁਜੀ ਸਾਹਿਬ', 44, INK, SERIF, '700', 'middle'))
s.append(text(W / 2, 1080, 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ', 36, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1132, 'ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥', 36, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1212, '॥ ਜਪੁ ॥', 36, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1300, 'ਆਦਿ ਸਚੁ ਜੁਗਾਦਿ ਸਚੁ ॥', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1354, 'ਹੈ ਭੀ ਸਚੁ ਨਾਨਕ ਹੋਸੀ ਭੀ ਸਚੁ ॥੧॥', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1450, 'Bar stays at the top when you scroll — always tappable.', 24, MUTED, LATIN, '400', 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_topbar5.png'))
print('topbar5 done')
