/* Gurbani Saanj v2.2.14 — Daily Hukamnama checks (node, offline).
 *  1. Daily Hukamnama replaces the Daily Gurbani reading plan (no settings).
 *  2. Hukamnama hero at the top of Home + full screen (green/gold design).
 *  3. Today's Hukamnama from BaniDB, cached on the phone, offline fallback.
 *  4. Same meanings as everywhere: en+pa under every line, tap-for-meaning.
 *  5. Morning notification at 6:00 AM (Capacitor local-notifications).
 * Run: node test-v234.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const nuSrc = fs.readFileSync(path.join(ROOT, 'src/native-updates.js'), 'utf8');
const nuBundle = fs.readFileSync(path.join(ROOT, 'www/native-updates.js'), 'utf8');
const patch = fs.readFileSync(path.join(ROOT, 'scripts/patch-android.mjs'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.14', vj.version === '2.2.14');
ok('package.json is 2.2.14', pj.version === '2.2.14');

// ---- 1. Daily reading plan is gone; Hukamnama replaces it ----
ok('dailyScreen function is gone', !app.includes('function dailyScreen('));
ok('no daily Home tile (HOME_IDS has no daily)', !/HOME_IDS=\[[^\]]*'daily'/.test(app));
ok('no daily tile in BASE homeOrder', !app.includes("homeOrder:['reader','nitnem','catalog','kirtan','ask','daily']"));
ok('menu has no daily-setup item', !app.includes("data-action=\"daily\""));
ok('no test-notification / save-daily / daily-open actions', !app.includes("case'save-daily'") && !app.includes("case'daily-open'") && !app.includes("case'test-notification'") && !app.includes('function testNotification('));
ok('no [data-daily] settings handler', !app.includes("[data-daily]"));
ok('views map has hukamnama screen', app.includes('hukamnama:hukamnamaScreen'));
ok('old daily view aliases to the Hukamnama screen', app.includes('daily:hukamnamaScreen'));

// ---- 2. Hukamnama fetch + cache ----
ok('fetchHukamnama exists', app.includes('async function fetchHukamnama('));
ok('BaniDB hukamnamas endpoint used', app.includes('https://api.banidb.com/v2/hukamnamas/'));
ok('fetch keyed by local date (YYYY-MM-DD)', app.includes('function hukamTodayKey('));
ok('cached Hukamnama reused for today', app.includes('state.hukamnama.date===key'));
ok('offline fallback: last saved shown as stale', app.includes("state.hukamnama.stale=true") && app.includes("t('hukamCached')"));
ok('state.hukamnama in BASE', app.includes('hukamnama:null'));
ok('hukamnama in backup permitted list', app.includes("'daily','hukamnama','questions'"));
ok('enrichLines runs on Hukamnama lines', app.includes("enrichLines(lines,'hukamnama',null)"));

// ---- 3. Hero at top of Home + full screen ----
ok('hukamHeroHTML exists', app.includes('function hukamHeroHTML(){'));
ok('hero inserted into homeScreen', app.includes('${hukamHeroHTML()}'));
ok('hero is a button that opens the Hukamnama', app.includes('class="hukam-hero" data-action="hukamnama"'));
ok('hero shows Ang + Raag meta', app.includes('hukam-hero-meta'));
ok('hukamnamaScreen exists', app.includes('function hukamnamaScreen(){'));
ok('screen has the green/gold header', app.includes('hukam-head') && app.includes('hukam-kicker'));
ok('screen has the gold frame', app.includes('hukam-frame'));
ok('screen has Read-full-Ang button', app.includes("data-action=\"hukam-full-ang\"") && app.includes("t('hukamReadFullAng')"));
ok('full-Ang opens the Ang as a detour (does not move Sahaj)', app.includes("case'hukam-full-ang':if(state.hukamnama?.ang)openAng(state.hukamnama.ang);break;"));
ok('retry button re-fetches today', app.includes("case'hukam-retry':fetchHukamnama(true)"));
ok('CSS: hukam hero + page + frame styles', css.includes('.hukam-hero') && css.includes('.hukam-page') && css.includes('.hukam-frame') && css.includes('.hukam-verses'));

// ---- 4. Same meanings as everywhere else ----
ok('verseBlock accepts a show override', app.includes('show:extra.show||layerOpts()'));
ok('Hukamnama forces English + Punjabi visible', app.includes('en:true,pa:true'));
ok('openLineMeaning reads Hukamnama lines from state', app.includes("kind==='hukamnama'?(state.hukamnama?.lines||[])[idx]"));
ok('Hukamnama lines render via verseBlock', app.includes("verseBlock(line,idx,'hukamnama',{show})"));

// ---- 5. Morning notification ----
ok('package.json has local-notifications', Boolean(pj.dependencies && pj.dependencies['@capacitor/local-notifications']));
ok('native source imports LocalNotifications', nuSrc.includes("import { LocalNotifications } from '@capacitor/local-notifications'"));
ok('GS_NOTIFY exposed in native source', nuSrc.includes('window.GS_NOTIFY'));
ok('GS_NOTIFY bundled into www/native-updates.js', nuBundle.includes('GS_NOTIFY'));
ok('notification scheduled daily at 6:00 AM', nuSrc.includes('hour: 6, minute: 0') && nuSrc.includes("every: 'day'"));
ok('notification tap opens the Hukamnama', nuSrc.includes('localNotificationActionPerformed') && nuSrc.includes("CustomEvent('gs-open-hukamnama')"));
ok('app listens for the notification-tap event', app.includes("window.addEventListener('gs-open-hukamnama'"));
ok('app schedules the notification on home/hukamnama', app.includes('scheduleHukamNotification()'));
ok('POST_NOTIFICATIONS declared in patch-android', patch.includes('android.permission.POST_NOTIFICATIONS'));

// ---- Functional: BaniDB verse mapping (real 2026-11-06 verse) ----
function extractFn(src, name, endMarker){
  const start = src.indexOf('function ' + name + '(');
  if(start < 0) return '';
  const end = endMarker ? src.indexOf(endMarker, start) : src.length;
  return src.slice(start, end);
}
const mapSrc = extractFn(app, 'hukamMapVerse', 'let hukamFetching=false;');
const keySrc = extractFn(app, 'hukamTodayKey', 'function hukamMapVerse(v){');
const ctx = {
  state: { hukamnama: null, lang: 'pa', showTranslit: true, showHi: false, showArth: false },
  t: k => k,
  age: (pa, en) => en,
  esc: s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;'),
  verseBlock: (line, idx, kind, extra) => `<div class="verse-block" data-line="${idx}"><div class="verse-text">${line.g}</div>${extra?.show?.en && line.en ? `<div class="verse-en">${line.en}</div>` : ''}${extra?.show?.pa && line.pa ? `<div class="verse-pa">${line.pa}</div>` : ''}</div>`,
  console,
};
vm.createContext(ctx);
vm.runInContext(mapSrc + '\n;globalThis.__map=hukamMapVerse;', ctx);
vm.runInContext(keySrc + '\n;globalThis.__key=hukamTodayKey;', ctx);
const realVerse = {
  verse: { unicode: 'ਗੁਰੁ ਮੇਰੀ ਪੂਜਾ ਗੁਰੁ ਗੋਬਿੰਦੁ ॥' },
  transliteration: { english: 'gur meree poojaa gur gobi(n)dh ||' },
  translation: {
    en: { bdb: 'I worship and adore my Guru; the Guru is the Lord of the Universe.', ms: 'I worship my Guru. My Guru is himself the Lord.' },
    pu: { ss: { unicode: '(ਮੇਰਾ) ਗੁਰੂ (ਗੁਰੂ ਦੀ ਸਰਨ ਹੀ) ਮੇਰੇ ਵਾਸਤੇ (ਦੇਵ-) ਪੂਜਾ ਹੈ, (ਮੇਰਾ) ਗੁਰੂ ਗੋਬਿੰਦ (ਦਾ ਰੂਪ) ਹੈ ।' }, bdb: { unicode: '(ਮੇਰਾ) ਗੁਰੂ (ਗੁਰੂ ਦੀ ਸਰਨ ਹੀ) ਮੇਰੇ ਵਾਸਤੇ (ਦੇਵ-) ਪੂਜਾ ਹੈ, (ਮੇਰਾ) ਗੁਰੂ ਗੋਬਿੰਦ (ਦਾ ਰੂਪ) ਹੈ ।' }, ms: { unicode: 'ਮੈਂ ਕੇਵਲ ਆਪਣੇ ਗੁਰਾਂ ਦੀ ਉਪਾਸ਼ਨਾ ਕਰਦਾ ਹੈ। ਮੇਰੇ ਗੁਰੂ ਜੀ ਖੁਦ ਹੀ ਪਰਮੇਸ਼ਰ ਹਨ।' } },
  },
};
const mapped = ctx.__map(realVerse);
ok('hukamMapVerse: Gurmukhi line', mapped.g === 'ਗੁਰੁ ਮੇਰੀ ਪੂਜਾ ਗੁਰੁ ਗੋਬਿੰਦੁ ॥', `got ${mapped.g}`);
ok('hukamMapVerse: English from bdb', mapped.en === 'I worship and adore my Guru; the Guru is the Lord of the Universe.');
ok('hukamMapVerse: Punjabi from ss', mapped.pa.startsWith('(ਮੇਰਾ) ਗੁਰੂ'));
ok('hukamMapVerse: roman transliteration', mapped.roman === 'gur meree poojaa gur gobi(n)dh ||');
const key = ctx.__key();
ok('hukamTodayKey: YYYY-MM-DD', /^\d{4}-\d{2}-\d{2}$/.test(key), `got ${key}`);

// ---- Functional: hero + screen render (vm, mocked state) ----
const heroSrc = extractFn(app, 'hukamHeroHTML', 'function hukamnamaScreen(){');
const screenSrc = extractFn(app, 'hukamnamaScreen', '/* ---- Nitnem ---- */');
vm.runInContext(heroSrc + '\n;globalThis.__hero=hukamHeroHTML;', ctx);
vm.runInContext(screenSrc + '\n;globalThis.__screen=hukamnamaScreen;', ctx);
const sampleHukam = {
  date: ctx.__key(), ang: 864, raag: 'ਰਾਗੁ ਗੋਂਡ', raagEn: 'Raag Gond', writer: 'Guru Arjan Dev Ji',
  shabadId: 3235, stale: false,
  lines: [
    { g: 'ਗੋਂਡ ਮਹਲਾ ੫ ॥', en: 'Gond, Fifth Mehla:', pa: 'ਗੋਂਡ ਪੰਜਵੀਂ ਪਾਤਿਸ਼ਾਹੀ।' },
    { g: 'ਗੁਰੁ ਮੇਰੀ ਪੂਜਾ ਗੁਰੁ ਗੋਬਿੰਦੁ ॥', en: 'I worship and adore my Guru; the Guru is the Lord of the Universe.', pa: '(ਮੇਰਾ) ਗੁਰੂ (ਗੁਰੂ ਦੀ ਸਰਨ ਹੀ) ਮੇਰੇ ਵਾਸਤੇ (ਦੇਵ-) ਪੂਜਾ ਹੈ।' },
    { g: 'ਗੁਰੁ ਮੇਰਾ ਪਾਰਬ੍ਰਹਮੁ ਗੁਰੁ ਭਗਵੰਤੁ ॥', en: 'My Guru is the Supreme Lord God; the Guru is the Lord God.', pa: 'ਮੇਰਾ ਗੁਰੂ ਪਰਮਾਤਮਾ (ਦਾ ਰੂਪ) ਹੈ।' },
  ],
};
ctx.state.hukamnama = sampleHukam;
const hero = ctx.__hero();
ok('hero: shows Hukamnama title + Ang + Raag', hero.includes('hukamnama') && hero.includes('864') && hero.includes('ਰਾਗੁ ਗੋਂਡ'));
ok('hero: previews the first Shabad line', hero.includes('ਗੁਰੁ ਮੇਰੀ ਪੂਜਾ ਗੁਰੁ ਗੋਬਿੰਦੁ'));
const screen = ctx.__screen();
ok('screen: shows Ang 864 + Raag Gond + writer', screen.includes('864') && screen.includes('ਰਾਗੁ ਗੋਂਡ') && screen.includes('Guru Arjan Dev Ji'));
ctx.state.lang = 'en';
const screenEn = ctx.__screen();
ok('screen (English): shows Raag Gond in English', screenEn.includes('Raag Gond'));
ctx.state.lang = 'pa';
ok('screen: all lines rendered', screen.includes('ਗੋਂਡ ਮਹਲਾ ੫') && screen.includes('ਗੁਰੁ ਮੇਰਾ ਪਾਰਬ੍ਰਹਮੁ'));
ok('screen: English meaning visible under a line', screen.includes('I worship and adore my Guru'));
ok('screen: Punjabi meaning visible under a line', screen.includes('(ਮੇਰਾ) ਗੁਰੂ'));
ok('screen: Read-full-Ang button for Ang 864', screen.includes('hukamReadFullAng') && screen.includes('864'));
ctx.state.hukamnama = null;
const heroEmpty = ctx.__hero();
ok('hero (no Hukamnama yet): shows loading, still opens the screen', heroEmpty.includes('hukamLoading') && heroEmpty.includes('data-action="hukamnama"'));
const screenEmpty = ctx.__screen();
ok('screen (no Hukamnama yet): shows unavailable + retry', screenEmpty.includes('hukamUnavailable') && screenEmpty.includes('hukam-retry'));

// ---- Regression: earlier versions intact ----
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.13: Ask shows only the latest question', app.includes('renderQA(state.questions[state.questions.length-1])'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.12: Library Ang picker passes sahaj=true', app.includes("openAng($('angPicker')?.value||displayAng(),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines', app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
