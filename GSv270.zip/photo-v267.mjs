/* Gurbani Saanj v2.2.47 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a fresh profile
 * (945x2051), and captures 5 photos:
 *   v2.2.47-photo-raag-gauri.png — Kirtan Sohila (Nitnem, id 23) idx 32
 *     "ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੪ ॥" CENTRED in the middle (the line the
 *     user circled in his screenshot; 6 words, so the old ≤5-word Mahla
 *     rule missed it).
 *   v2.2.47-photo-raag-gauri-5.png — Kirtan Sohila idx 43
 *     "ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੫ ॥" CENTRED (the second circled line).
 *   v2.2.47-photo-anand-title.png — Anand Sahib (Nitnem, id 10) idx 0
 *     "ਰਾਮਕਲੀ ਮਹਲਾ ੩ ਅਨੰਦੁ ॥" CENTRED (the Anand title line).
 *   v2.2.47-photo-kabit.png — Akal Ustat (Anek Baniyaan, id 119) idx 49
 *     "ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥ ਕਬਿਤ ॥" CENTRED (the compound Kabit heading).
 *   v2.2.47-photo-nitnem-no-note.png — the Nitnem screen: all 8 Bani
 *     buttons, and NO note line at the bottom (deleted in v2.2.47).
 * Also asserts in the live app: each heading is a centred heading (text
 * centre within 60px of viewport centre, text-align center, gs-verse-heading
 * class), the verse line "ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧ ॥" is NOT a
 * heading, and the Nitnem screen has no note text.
 * Run: node photo-v267.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME,
  args: ['--disable-dev-shm-usage'] }); // /dev/shm is only 794MB — without this the renderer crashes on this heavy page
const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
await page.goto(base, { waitUntil: 'load' });
await page.waitForTimeout(5000); // bootData + kosh load + first render + kosh re-render settle

// app.js is an IIFE, so go()/openBani() are NOT globals — navigate through
// the UI exactly as a user would: home tiles (data-home-id) + the Bani rows
// (data-remote-bani) + the browser Back button to leave a reader (popstate
// restores the view, like Android back). NEVER click [data-view="home"]
// while already on home: go('home') from home crashes the renderer.
const goNitnemFromHome = async () => {
  await page.evaluate(() => document.querySelector('[data-home-id="nitnem"]')?.click());
  await page.waitForTimeout(900);
};
const goCatalogFromHome = async () => {
  await page.evaluate(() => document.querySelector('[data-home-id="catalog"]')?.click());
  await page.waitForTimeout(900);
};
const backToList = async () => {
  await page.goBack();
  await page.waitForTimeout(900);
};
const booted = await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]'));
ok('photo: app booted, home tiles present', booted);
await goNitnemFromHome();

// A heading is centred when its text box is centred in the viewport
// (its centre x is within 60px of the viewport centre) AND the computed
// text-align is center.
const scrollLineToMiddle = async (idx) => {
  await page.evaluate((i) => {
    const el = document.querySelector(`#verses [data-line="${i}"]`);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, idx);
  await page.waitForTimeout(600);
};
const headingCentred = (idx) => page.evaluate((i) => {
  const el = document.querySelector(`#verses [data-line="${i}"]`);
  if (!el) return { found: false };
  const txt = el.querySelector('.verse-text');
  const r = txt.getBoundingClientRect();
  const vw = window.innerWidth;
  const centre = r.left + r.width / 2;
  return {
    found: true,
    text: txt.textContent.trim(),
    textAlign: getComputedStyle(txt).textAlign,
    fontWeight: getComputedStyle(txt).fontWeight,
    color: getComputedStyle(txt).color,
    headingClass: !!el.closest('.gs-verse-heading') || el.classList.contains('gs-verse-heading'),
    centreX: Math.round(centre), viewportCentre: Math.round(vw / 2),
    offBy: Math.round(Math.abs(centre - vw / 2)),
    visible: r.top > 0 && r.bottom < window.innerHeight,
  };
}, idx);
const assertHeadingCentred = async (name, idx, expectedText) => {
  await scrollLineToMiddle(idx);
  const h = await headingCentred(idx);
  // A live-app heading is centred + ORANGE (#f3541d) + gs-verse-heading.
  // (font-weight is 400 in the live app: the more specific
  // .gs-bani-para .verse-text rule wins over the .gs-verse-heading 700 rule
  // — the visual difference is the orange colour, not the weight.)
  ok(`photo: ${name} (idx${idx}) is a centred ORANGE heading`,
    h.found && h.text === expectedText && h.textAlign === 'center' && h.headingClass && h.color === 'rgb(243, 84, 29)' && h.offBy <= 60 && h.visible,
    JSON.stringify(h));
};
const openNitnemBani = async (id) => {
  await page.evaluate((bid) => document.querySelector(`.nitnem-page [data-remote-bani="${bid}"]`).click(), id);
  await page.waitForTimeout(1200); // loadRemote fetch + render
};

// ---- Photo 5 (first, already on the Nitnem screen): NO note line ----
// The note was the last <p class="fine muted"> on this screen. Check the
// whole screen text: all 8 Bani titles present, no note strings anywhere.
const nitnemCheck = await page.evaluate(() => {
  const txt = document.querySelector('.nitnem-page')?.textContent || '';
  const buttons = [...document.querySelectorAll('.nitnem-page [data-remote-bani]')].map(b => b.dataset.remoteBani);
  return {
    hasAll8: buttons.length === 8 && ['2', '4', '6', '9', '10', '21', '130', '23'].every(id => buttons.includes(id)),
    buttons: buttons.join(','),
    heading: txt.includes('ਨਿਤਨੇਮ'),
    intro: txt.includes('ਨਿਤਨੇਮ ਦਾ ਪਾਠ ਐਪ ਵਿੱਚ ਆਫਲਾਈਨ ਹੈ।'),
    noNotePa: !txt.includes('ਰਹਰਾਸਿ ਸਾਹਿਬ ਦਾ ਵੱਖਰਾ'),
    noNoteEn: !txt.includes('separate verified Rehras'),
    noNoteWord: !txt.includes('ਨੋਟ:') && !txt.includes('Note:'),
    noFineMutedP: !document.querySelector('.nitnem-page p.fine.muted:last-child') || true,
  };
});
ok('photo: Nitnem screen lists all 8 Banis', nitnemCheck.hasAll8, nitnemCheck.buttons);
ok('photo: Nitnem screen keeps its heading + intro', nitnemCheck.heading && nitnemCheck.intro);
ok('photo: Nitnem screen has NO note line (no "ਰਹਰਾਸਿ ਸਾਹਿਬ ਦਾ ਵੱਖਰਾ")', nitnemCheck.noNotePa);
ok('photo: Nitnem screen has NO note line (no "separate verified Rehras")', nitnemCheck.noNoteEn);
ok('photo: Nitnem screen has NO "ਨੋਟ:" / "Note:" anywhere', nitnemCheck.noNoteWord);
// Scroll to the bottom so the shot proves the list simply ends (no note).
await page.evaluate(() => window.scrollTo({ top: document.body.scrollHeight, behavior: 'instant' }));
await page.waitForTimeout(400);
await page.screenshot({ path: path.join(OUT, 'v2.2.47-photo-nitnem-no-note.png') });
await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
await page.waitForTimeout(300);

// ---- Photo 1: Kirtan Sohila "ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੪ ॥" (idx 32) ----
await openNitnemBani(23);
await assertHeadingCentred('Kirtan Sohila Raag Gauri Purbi M4', 32, 'ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੪ ॥');
// The first line of Kirtan Sohila is a VERSE, not a heading — prove it.
const sohila = await headingCentred(0);
ok('photo: Kirtan Sohila first line "ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧ ॥" is NOT a heading (no heading class, normal weight 400)',
  sohila.found && !sohila.headingClass && Number(sohila.fontWeight) <= 400, JSON.stringify(sohila));
await scrollLineToMiddle(32);
await page.screenshot({ path: path.join(OUT, 'v2.2.47-photo-raag-gauri.png') });

// ---- Photo 2: Kirtan Sohila "ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੫ ॥" (idx 43) ----
await assertHeadingCentred('Kirtan Sohila Raag Gauri Purbi M5', 43, 'ਰਾਗੁ ਗਉੜੀ ਪੂਰਬੀ ਮਹਲਾ ੫ ॥');
await page.screenshot({ path: path.join(OUT, 'v2.2.47-photo-raag-gauri-5.png') });
await backToList(); // back to the Nitnem screen

// ---- Photo 3: Anand Sahib "ਰਾਮਕਲੀ ਮਹਲਾ ੩ ਅਨੰਦੁ ॥" (idx 0) ----
await openNitnemBani(10);
await assertHeadingCentred('Anand Sahib title', 0, 'ਰਾਮਕਲੀ ਮਹਲਾ ੩ ਅਨੰਦੁ ॥');
await page.screenshot({ path: path.join(OUT, 'v2.2.47-photo-anand-title.png') });
await backToList(); // back to the Nitnem screen
await backToList(); // back to home (Nitnem -> home)

// ---- Photo 4: Akal Ustat "ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥ ਕਬਿਤ ॥" (idx 49) ----
await goCatalogFromHome();
const akalOpened = await page.evaluate(() => {
  const row = document.querySelector(`.catalog-page [data-catalog-id="119"]`);
  if (!row) return false;
  row.click();
  return true;
});
ok('photo: Akal Ustat row found in the catalog and opened', akalOpened);
await page.waitForTimeout(1200);
await assertHeadingCentred('Akal Ustat Kabit', 49, 'ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥ ਕਬਿਤ ॥');
await page.screenshot({ path: path.join(OUT, 'v2.2.47-photo-kabit.png') });

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
