/* Gurbani Saanj v2.2.27 — reader top bar: hide completely while reading
 * forward, pop out only when scrolling back to already-read content, and
 * sit below the phone status bar (battery/time) so its buttons are pressable.
 * Karamjit clarified it himself: "I want them completely hidden. When I
 * scroll [back] they come up and show, then when I start reading the page
 * down again they hide."
 * Change 1: the scroll handler tracks DIRECTION (was: show once at scrollY>60
 * and stay forever). Scroll down (to new content) hides the bar; scroll up
 * (to already-read content) shows it; tiny moves under 5px do nothing.
 * The 800ms guard after opening is kept.
 * Change 2: .gs-reading-topbar is position:sticky; its top was 0, so when
 * stuck it sat UNDER the system status bar and its buttons (Ang jump, Aa,
 * drawer) could not be pressed. Now top: max(env(safe-area-inset-top,0),24px).
 * Run: node test-v247.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.27', vj.version === '2.2.27');
ok('package.json is 2.2.27', pj.version === '2.2.27');
ok('version.json notes mention v2.2.27', vj.notes.includes('v2.2.27:'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const pt = fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8');

// ---- 1. Bar module exists (pure direction fn + show/hide + onReaderScroll) ----
ok('barScrollDecision function present', app.includes('function barScrollDecision(lastY,curY)'));
ok('showReaderBar / hideReaderBar present', app.includes('function showReaderBar(){') && app.includes('function hideReaderBar(){'));
ok('onReaderScroll present', app.includes('function onReaderScroll(){'));
ok('lastReaderScrollY baseline present', app.includes('lastReaderScrollY=0'));
ok('scroll handler calls onReaderScroll()', app.includes("closeWord();onReaderScroll();if(state.view!=='reader'"));
ok('old show-once block gone (no scrollY>60 show + stay)', !app.includes('window.scrollY>60&&Date.now()-readerOpenedAt>800){readerBarHidden=false;'));

// ---- 2. Drive the REAL onReaderScroll in a vm with fake window/document ----
const barStart = app.indexOf('let readerBarHidden=true, readerOpenedAt=0, lastReaderScrollY=0;');
const fnStart = app.indexOf('function onReaderScroll(){');
const barEnd = app.indexOf('\n', fnStart);
const barSlice = app.slice(barStart, barEnd);
ok('bar slice extracted (state + helpers + onReaderScroll)', barSlice.includes('function barScrollDecision') && barSlice.includes('function onReaderScroll'));

const win = { scrollY: 0 };
const barClasses = new Set(['gs-topbar-hidden']);
const fakeBar = {
  classList: {
    add(c) { barClasses.add(c); },
    remove(c) { barClasses.delete(c); },
    contains(c) { return barClasses.has(c); },
  },
};
const state = { view: 'reader', mode: 'scroll' };
const bctx = vm.createContext({
  window: win,
  document: { querySelector: (sel) => (sel === '.gs-reading-topbar' ? fakeBar : null) },
  state, console, Math,
});
vm.runInContext(barSlice + '\n;globalThis.__barScrollDecision=barScrollDecision;globalThis.__onReaderScroll=onReaderScroll;', bctx);
const barScrollDecision = bctx.__barScrollDecision;
const onReaderScroll = bctx.__onReaderScroll;
const getHidden = () => vm.runInContext('readerBarHidden', bctx);
const setHidden = (v) => vm.runInContext(`readerBarHidden=${v}`, bctx);
const setOpenedAt = (expr) => vm.runInContext(`readerOpenedAt=${expr}`, bctx);
const setLastY = (y) => vm.runInContext(`lastReaderScrollY=${y}`, bctx);
const resetBar = (hidden) => { setHidden(hidden); barClasses.clear(); if (hidden) barClasses.add('gs-topbar-hidden'); else barClasses.add('gs-topbar-in'); };

// ---- 2a. Pure direction function ----
ok("barScrollDecision: down 100->150 is 'hide'", barScrollDecision(100, 150) === 'hide');
ok("barScrollDecision: up 100->50 is 'show'", barScrollDecision(100, 50) === 'show');
ok('barScrollDecision: +2px is null (no flicker)', barScrollDecision(100, 102) === null);
ok('barScrollDecision: -2px is null (no flicker)', barScrollDecision(100, 98) === null);
ok("barScrollDecision: exactly -5 is 'show'", barScrollDecision(100, 95) === 'show');
ok("barScrollDecision: exactly +5 is 'hide'", barScrollDecision(100, 105) === 'hide');

// ---- 2b. Full scroll simulation (guard passes: opened 10s ago) ----
setOpenedAt('Date.now()-10000');
resetBar(true); setLastY(0); win.scrollY = 0;

// (a) scroll DOWN 0 -> 100, reading forward, bar already hidden: stays hidden.
win.scrollY = 100; onReaderScroll();
ok('(a) scroll DOWN keeps a hidden bar hidden (reading forward)', getHidden() === true && barClasses.has('gs-topbar-hidden'));

// (b) scroll UP 100 -> 50, back to already-read content: bar pops out.
win.scrollY = 50; onReaderScroll();
ok('(b) scroll UP shows the bar (back to already-read)', getHidden() === false && !barClasses.has('gs-topbar-hidden') && barClasses.has('gs-topbar-in'));

// (a again) scroll DOWN 50 -> 150, resume reading forward: bar hides again.
win.scrollY = 150; onReaderScroll();
ok('(a) scroll DOWN again hides the bar (resume reading)', getHidden() === true && barClasses.has('gs-topbar-hidden') && !barClasses.has('gs-topbar-in'));

// (e) bar is COMPLETELY hidden while reading forward (display:none rule + state).
ok('(e) bar completely hidden while reading forward (display:none)', getHidden() === true && barClasses.has('gs-topbar-hidden') && css.includes('.gs-topbar-hidden{display:none}'));

// (c) tiny scrolls do not toggle — hidden bar stays hidden on +2px.
win.scrollY = 152; onReaderScroll();
ok('(c) tiny scroll DOWN (+2px) does not toggle a hidden bar', getHidden() === true);
// show the bar, then tiny moves must not toggle it either.
win.scrollY = 100; onReaderScroll();
ok('bar shown again after scroll up 152->100', getHidden() === false);
win.scrollY = 102; onReaderScroll();
ok('(c) tiny scroll DOWN (+2px) does not hide a shown bar', getHidden() === false);
win.scrollY = 100; onReaderScroll();
ok('(c) tiny scroll UP (-2px) does not toggle a shown bar', getHidden() === false);

// (d) the 800ms guard: bar does NOT show within 800ms of opening.
setOpenedAt('Date.now()'); // just opened
resetBar(true); setLastY(100); win.scrollY = 100; onReaderScroll(); // baseline
win.scrollY = 50; onReaderScroll(); // scroll up — would show, but guard blocks
ok('(d) bar does NOT show within 800ms of opening (guard holds)', getHidden() === true && barClasses.has('gs-topbar-hidden'));
// guard is time-based, not permanent: 1000ms later the same scroll-up shows it.
setOpenedAt('Date.now()-1000');
win.scrollY = 40; onReaderScroll();
ok('(d) bar DOES show once 800ms have passed', getHidden() === false && barClasses.has('gs-topbar-in'));

// ---- 3. CSS: bar clears the system status bar ----
const topbarRule = (css.match(/\.gs-reading-topbar \{[^}]*\}/) || [''])[0];
ok('topbar sticky top clears status bar (max(safe-area,24px))', topbarRule.includes('top: max(env(safe-area-inset-top, 0px), 24px)'));
ok('topbar no longer sticks at top:0 (under battery/time)', !topbarRule.includes('top: 0;'));
ok('topbar still sticky (kept in section flow, not fixed)', topbarRule.includes('position: sticky'));
ok('.gs-topbar-hidden is display:none (completely hidden)', css.includes('.gs-topbar-hidden{display:none}'));

// ---- 4. Regression: v2.2.26 (headings, viewport, page-turn) ----
const rvSrc = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const rvCtx = vm.createContext({ window: {}, console });
vm.runInContext(rvSrc, rvCtx);
const GS = rvCtx.window.GS_VERSES;
ok('v2.2.26: "ਆਸਾ ਮਹਲਾ ੧ ॥" still a heading', GS.isBaniHeading('ਆਸਾ ਮਹਲਾ ੧ ॥') === true);
ok('v2.2.26: "ਅਸਟਪਦੀ ॥" still a heading', GS.isBaniHeading('ਅਸਟਪਦੀ ॥') === true);
ok('v2.2.26: "ਸਲੋਕੁ ॥" still a heading', GS.isBaniHeading('ਸਲੋਕੁ ॥') === true);
ok('v2.2.26: long verse line still NOT a heading', GS.isBaniHeading('ਸੁਣਿ ਵਡਾ ਆਖੈ ਸਭੁ ਕੋਇ ॥ ਕੀਮਤਿ ਪਾਇ ਨ ਕਹਿਆ ਜਾਇ ॥') === false);
ok('v2.2.26: heading renders with gs-verse-heading', GS.verseHTML({ g: 'ਆਸਾ ਮਹਲਾ ੧ ॥' }, { idx: 0, kind: 'bani', heading: true }).includes('gs-verse-heading'));
ok('v2.2.26: viewport still user-scalable=no + maximum-scale=1', html.includes('user-scalable=no') && html.includes('maximum-scale=1'));
ok('v2.2.26: page-turn min-height still present', css.includes('.gs-book-reading{min-height:calc(100dvh - 122px)}'));

// ---- 5. Regression: older versions ----
const pinchSlice = app.slice(app.indexOf('function pinchDist'), app.indexOf('function askScreen(){'));
ok('v2.2.25: A+/A- row gone (no ai-zoom-row)', !app.includes('ai-zoom-row'));
ok('v2.2.25: pinch arms on touchmove too', pinchSlice.includes('if(!pinchState&&pinchInAnswer(e))pinchState='));
ok('v2.2.25: setupPinchZoom idempotent guard', pinchSlice.includes('if(pinchWired)return;pinchWired=true;'));
ok('v2.2.25: pinch still document-level', pinchSlice.includes("document.addEventListener('touchstart'") && pinchSlice.includes("document.addEventListener('touchmove'"));
ok('v2.2.23: exactly ONE .ai-answer font-size, var(--ai-font,18px)',
  (() => {
    const blocks = [...css.matchAll(/\.ai-answer\s*\{[^}]*\}/g)].map(m => m[0]);
    const decls = blocks.flatMap(b => [...b.matchAll(/font-size\s*:\s*([^;}]+)/g)].map(m => m[1].trim()));
    return decls.length === 1 && decls[0] === 'var(--ai-font,18px)';
  })());
ok('v2.2.22: no-heard timer intact', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('v2.2.22: X restarts the mic intact', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('v2.2.21: first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.18: ai-verse highlight intact', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('v2.2.18: aiFont clamp 14-32 intact (dormant handler)', app.includes('Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))'));
ok('v2.2.15: AI language toggle intact', app.includes('data-ai-lang') && app.includes('state.aiLang=aiLang.dataset.aiLang'));
ok('v2.2.19: Bani paragraph flow in page-turn intact', pt.includes('window.GS_VERSES.groupBaniParagraphs'));
ok('v2.2.19: book text centered intact', css.includes('.gs-book-page .gs-book-flow{font-family:"Noto Serif Gurmukhi","Raavi","Nirmala UI",serif;font-size:var(--font);font-weight:550;line-height:var(--leading);overflow-wrap:anywhere;word-break:normal;text-align:center}'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
