/* Gurbani Saanj v2.2.15 — checks (node, offline).
 *  1. Hukamnama translations follow the user's settings (no longer forced on).
 *  2. AI answer language toggle (pa/EN) on the Ask screen.
 *  3. Mic button bold + obvious red pulsing listening state.
 *  4. Mic starts faster (parallel checks, cached permission, parallel listeners).
 * Run: node test-v235.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.15', vj.version === '2.2.15');
ok('package.json is 2.2.15', pj.version === '2.2.15');

// ---- 1. Hukamnama follows settings ----
ok('Hukamnama no longer forces en+pa', !app.includes('en:true,pa:true'));
ok('Hukamnama renders via verseBlock with no show override', app.includes("verseBlock(line,idx,'hukamnama')).join('')"));
ok('verseBlock still accepts a show override (harmless)', app.includes('show:extra.show||layerOpts()'));
ok('Hukamnama comment says settings, not forced', app.includes('translations follow the user'));

// ---- 2. AI answer language ----
ok('BASE has aiLang default pa', app.includes("aiLang:'pa'"));
ok('aiLang normalized to pa/en', app.includes("state.aiLang=state.aiLang==='en'?'en':'pa'"));
ok('aiLang in backup permitted list', app.includes("'aiModel','aiLang','searchHistory'"));
ok('Ask screen has pa/EN language pills', app.includes('data-ai-lang="${k}"') && app.includes("['pa','ਪੰਜਾਬੀ'],['en','English']") && app.includes('ai-lang-pills'));
ok('ai-lang click handler sets state + toggles sel', app.includes("const aiLang=e.target.closest('[data-ai-lang]')") && app.includes('state.aiLang=aiLang.dataset.aiLang'));
ok('askOpenAI answers in the chosen AI language', app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('askOpenAI no longer uses the app language for the answer', !app.includes("Answer in ${state.lang==='en'?'English':'Punjabi'}"));
ok('server path sends the chosen AI language', app.includes('language:state.aiLang'));
ok('server path no longer sends the app language', !app.includes('language:state.lang'));
ok('worker already reads body.language', worker.includes("body?.language==='pa'"));

// ---- 3. Mic bold + listening state ----
ok('mic buttons use a white SVG mic, not the faint emoji', !app.includes('Voice search\')}">🎙') && !app.includes('Ask by voice\')}">🎙') && app.includes('<svg viewBox="0 0 24 24" width="26" height="26"'));
ok('CSS: mic is a bold green circle', css.includes('#voiceBtn,#askVoiceBtn') && css.includes('background:#14532d') && css.includes('border-radius:50%') && css.includes('width:46px'));
ok('CSS: listening button turns red + pulses', css.includes('.gs-listening') && css.includes('background:#c0392b') && css.includes('gs-mic-pulse'));
ok('CSS: listening state beats the disabled fade', css.includes('#voiceBtn.gs-listening:disabled') && css.includes('opacity:1'));
ok('CSS: listening status line is large + bold', css.includes('#voiceStatus.gs-listening') && css.includes('font-weight:700'));
ok('setListeningUI helper exists', app.includes('function setListeningUI(on)'));
ok('done() clears the listening UI', app.includes("const done=(pa,en)=>{setVoiceStatus(pa,en);setListeningUI(false);"));
ok('resetVoiceNow() clears the listening UI', app.includes('clearVoiceWatchdog();searchVoiceBusy=false;setListeningUI(false);'));
ok('listening UI turns on when native start succeeds', app.includes("setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ','Listening… say a Gurbani word or line');\n    setListeningUI(true);"));
ok('listening UI turns on for the web fallback', app.includes('try{rec.start();setListeningUI(true)}'));

// ---- 4. Mic fast ----
ok('permission cache flag exists', app.includes('let voicePermGranted=false;'));
ok('availability + permission run in parallel', app.includes('Promise.all([native.available().catch(()=>null),native.checkPermissions().catch(()=>null)])'));
ok('granted permission is cached, never re-checked', app.includes('if(voicePermGranted){') && app.includes('voicePermGranted=true;'));
ok('listeners register in parallel', app.includes('const [hPartial,hListen]=await Promise.all(['));
ok('no sequential available-then-permission left', !app.includes("let avail=null;try{avail=await native.available()}catch{}\n   if(!avail||avail.available===false)throw Error('native-unavailable');\n   let perm=null;try{perm=await native.checkPermissions()}catch{}"));

// ---- Functional: setListeningUI toggles classes (vm) ----
function extractFn(src, name, endMarker){
  const start = src.indexOf('function ' + name + '(');
  if(start < 0) return '';
  const end = endMarker ? src.indexOf(endMarker, start) : src.length;
  return src.slice(start, end);
}
const listenSrc = extractFn(app, 'setListeningUI', 'async function startVoiceSearch');
const classes = { voiceBtn: new Set(), askVoiceBtn: new Set(), voiceStatus: new Set() };
const ctx = {
  $: id => ({ classList: { toggle: (c, on) => { if(on) classes[id].add(c); else classes[id].delete(c); } } }),
  voiceStatusEl: () => ({ classList: { toggle: (c, on) => { if(on) classes.voiceStatus.add(c); else classes.voiceStatus.delete(c); } } }),
  console,
};
vm.createContext(ctx);
vm.runInContext(listenSrc + '\n;globalThis.__listen=setListeningUI;', ctx);
ctx.__listen(true);
ok('setListeningUI(true): both mic buttons + status get gs-listening',
  classes.voiceBtn.has('gs-listening') && classes.askVoiceBtn.has('gs-listening') && classes.voiceStatus.has('gs-listening'));
ctx.__listen(false);
ok('setListeningUI(false): classes removed',
  !classes.voiceBtn.has('gs-listening') && !classes.askVoiceBtn.has('gs-listening') && !classes.voiceStatus.has('gs-listening'));

// ---- Functional: Ask screen language pills render (vm) ----
const askSrc = extractFn(app, 'askScreen', 'function renderQA');
const ctx2 = {
  state: { aiLang: 'pa', depth: 'detail', aiApiKey: '', aiEndpoint: '', questions: [] },
  t: k => k,
  age: (pa, en) => en,
  esc: s => String(s ?? ''),
  renderQA: () => '',
  console,
};
vm.createContext(ctx2);
vm.runInContext(askSrc + '\n;globalThis.__ask=askScreen;', ctx2);
const askHtml = ctx2.__ask();
ok('Ask screen: Punjabi pill is selected by default', askHtml.includes('data-ai-lang="pa" class="sel"'));
ok('Ask screen: English pill present, not selected', askHtml.includes('data-ai-lang="en" class=""'));
ok('Ask screen: depth pills still present', askHtml.includes('data-depth="short"') && askHtml.includes('data-depth="deep"'));
ctx2.state.aiLang = 'en';
const askHtmlEn = ctx2.__ask();
ok('Ask screen: switching aiLang selects the English pill', askHtmlEn.includes('data-ai-lang="en" class="sel"') && askHtmlEn.includes('data-ai-lang="pa" class=""'));

// ---- Regression: earlier versions intact ----
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));
ok('v2.2.14: BaniDB hukamnamas endpoint intact', app.includes('https://api.banidb.com/v2/hukamnamas/'));
ok('v2.2.14: 6 AM notification intact', fs.readFileSync(path.join(ROOT, 'src/native-updates.js'), 'utf8').includes('hour: 6, minute: 0'));
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.13: Ask shows only the latest question', app.includes('renderQA(state.questions[state.questions.length-1])'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines', app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
