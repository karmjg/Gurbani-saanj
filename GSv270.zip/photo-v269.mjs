/* Gurbani Saanj v2.2.49 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a FRESH profile
 * (945x2051) for each photo, and captures 3 photos of the Japji Sahib Mool
 * Mantar area (bani 2, idx 2-5 — the lines from his screenshot: "ਆਦਿ ਸਚੁ
 * ਜੁਗਾਦਿ ਸਚੁ ॥", "ਹੈ ਭੀ ਸਚੁ ਨਾਨਕ ਹੋਸੀ ਭੀ ਸਚੁ ॥੧॥", "ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ
 * ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥", "ਚੁਪੈ ਚੁਪ ਨ ਹੋਵਈ ਜੇ ਲਾਇ ਰਹਾ ਲਿਵ ਤਾਰ ॥"):
 *   v2.2.49-photo-japji-centred.png — show={translit:false,en:true,pa:true,arth:true}:
 *     Gurmukhi, English, Punjabi and word meanings ALL centred (his
 *     screenshot's case — was left-aligned, now in the middle).
 *   v2.2.49-photo-japji-centred-en.png — show={translit:false,en:true}:
 *     same centring, English only.
 *   v2.2.49-photo-japji-centred-translit.png — show={translit:true,en:true}:
 *     regression — still centred, Roman orange.
 * The layer toggles are seeded into localStorage (key
 * 'gurbani-saanjh-trial-v1') via addInitScript BEFORE the app boots, so
 * each photo runs with exactly the intended Bani View Preferences.
 * Live-app checks: the section carries .gs-layers-on (and .gs-translit-on
 * only when transliteration is on); computed text-align of every
 * .gs-bani-pankti block and every .verse-layer is 'center'; computed
 * border-left-width of the layers is 0px; colours unchanged (.verse-en
 * rgb(28,28,28), .verse-pa rgb(123,30,43), Roman orange rgb(243,84,29)
 * only with transliteration on).
 * Run: node photo-v269.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME,
  args: ['--disable-dev-shm-usage'] }); // /dev/shm is only 794MB — without this the renderer crashes on this heavy page

// Boot the app with exactly these Bani View Preferences (seeded into
// localStorage before the app reads it at boot).
const bootWithLayers = async (layers) => {
  const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
  await ctx.addInitScript((seed) => {
    localStorage.setItem('gurbani-saanjh-trial-v1', JSON.stringify(seed));
  }, layers);
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
  await page.goto(base, { waitUntil: 'load' });
  await page.waitForTimeout(5000); // bootData + kosh load + first render + kosh re-render settle
  return { ctx, page };
};
const openJapji = async (page) => {
  await page.evaluate(() => document.querySelector('[data-home-id="nitnem"]')?.click());
  await page.waitForTimeout(900);
  await page.evaluate(() => document.querySelector('.nitnem-page [data-remote-bani="2"]').click());
  await page.waitForTimeout(1200); // loadRemote fetch + render
};
const scrollLineToMiddle = async (page, idx) => {
  await page.evaluate((i) => {
    const el = document.querySelector(`#verses [data-line="${i}"]`);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, idx);
  await page.waitForTimeout(600);
};
// Centring check for the Mool Mantar lines (idx 2-5) in the live app.
const checkCentred = async (page, idxs) => {
  return await page.evaluate((idxs) => {
    const sec = document.querySelector('section.reading-immersive.gs-reader-bani');
    const blocks = idxs.map(i => document.querySelector(`#verses [data-line="${i}"]`));
    const layers = idxs.flatMap(i => {
      const b = document.querySelector(`#verses [data-line="${i}"]`);
      return b ? [...b.querySelectorAll('.verse-layer')] : [];
    });
    const cs = (el) => getComputedStyle(el);
    const enEl = document.querySelector(`#verses [data-line="${idxs[1]}"] .verse-en`);
    const paEl = document.querySelector(`#verses [data-line="${idxs[1]}"] .verse-pa`);
    const romanEl = document.querySelector(`#verses [data-line="${idxs[1]}"] .verse-roman`);
    const arthLayers = idxs.map(i => {
      const b = document.querySelector(`#verses [data-line="${i}"]`);
      return b ? b.querySelector('.verse-layer.verse-arth') : null;
    });
    const heading = document.querySelector('#verses [data-line="1"]');
    return {
      hasLayersOn: !!sec && sec.classList.contains('gs-layers-on'),
      hasTranslitOn: !!sec && sec.classList.contains('gs-translit-on'),
      allPankti: blocks.every(b => !!b && b.classList.contains('gs-bani-pankti')),
      panktiAlign: [...new Set(blocks.map(b => b ? cs(b).textAlign : null))],
      layerAlign: [...new Set(layers.map(l => cs(l).textAlign))],
      layerBorder: [...new Set(layers.map(l => cs(l).borderLeftWidth))],
      layerCount: layers.length,
      arthCount: arthLayers.filter(Boolean).length,
      enColor: enEl ? cs(enEl).color : null,
      paColor: paEl ? cs(paEl).color : null,
      romanColor: romanEl ? cs(romanEl).color : null,
      headingIsHeading: !!heading && heading.classList.contains('gs-verse-heading'),
    };
  }, idxs);
};

// ---- Photo 1: English + Punjabi + Arth ON, transliteration OFF (his screenshot's case) ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: false, showEn: true, showPa: true, showArth: true });
  ok('photo all: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJapji(page);
  ok('photo all: Japji Sahib reader opened', await page.evaluate(() => !!document.querySelector('#verses [data-line="3"]')));
  try { await page.waitForSelector('#verses [data-line="3"] .verse-layer.verse-arth', { timeout: 10000 }); } catch (e) { console.log('photo all: arth layer did not appear in 10s'); }
  const c = await checkCentred(page, [2, 3, 4, 5]);
  ok('photo all: section carries gs-layers-on', c.hasLayersOn, JSON.stringify(c));
  ok('photo all: section does NOT carry gs-translit-on', !c.hasTranslitOn);
  ok('photo all: all 4 Mool lines are their own .gs-bani-pankti blocks', c.allPankti, JSON.stringify(c));
  ok('photo all: every .gs-bani-pankti is text-align center', JSON.stringify(c.panktiAlign) === '["center"]', JSON.stringify(c.panktiAlign));
  ok('photo all: every .verse-layer is text-align center', JSON.stringify(c.layerAlign) === '["center"]', JSON.stringify(c.layerAlign));
  ok('photo all: every .verse-layer has no left border (0px)', JSON.stringify(c.layerBorder) === '["0px"]', JSON.stringify(c.layerBorder));
  ok('photo all: 4 .verse-arth layers (one per pankti)', c.arthCount === 4, `got ${c.arthCount}`);
  ok('photo all: English colour unchanged rgb(28, 28, 28)', c.enColor === 'rgb(28, 28, 28)', String(c.enColor));
  ok('photo all: Punjabi colour unchanged rgb(123, 30, 43)', c.paColor === 'rgb(123, 30, 43)', String(c.paColor));
  ok('photo all: "॥ ਜਪੁ ॥" heading still a heading', c.headingIsHeading);
  await scrollLineToMiddle(page, 4);
  await page.screenshot({ path: path.join(OUT, 'v2.2.49-photo-japji-centred.png') });
  await ctx.close();
}

// ---- Photo 2: English ON only, transliteration OFF ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: false, showEn: true, showPa: false, showArth: false });
  ok('photo en: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJapji(page);
  const c = await checkCentred(page, [2, 3, 4, 5]);
  ok('photo en: section carries gs-layers-on, not gs-translit-on', c.hasLayersOn && !c.hasTranslitOn, JSON.stringify(c));
  ok('photo en: every .gs-bani-pankti is text-align center', JSON.stringify(c.panktiAlign) === '["center"]', JSON.stringify(c.panktiAlign));
  ok('photo en: every .verse-layer is text-align center, no left border',
    JSON.stringify(c.layerAlign) === '["center"]' && JSON.stringify(c.layerBorder) === '["0px"]',
    JSON.stringify({ a: c.layerAlign, b: c.layerBorder }));
  ok('photo en: English colour unchanged rgb(28, 28, 28)', c.enColor === 'rgb(28, 28, 28)', String(c.enColor));
  await scrollLineToMiddle(page, 4);
  await page.screenshot({ path: path.join(OUT, 'v2.2.49-photo-japji-centred-en.png') });
  await ctx.close();
}

// ---- Photo 3: transliteration ON + English ON (regression) ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: true, showEn: true, showPa: false, showArth: false });
  ok('photo tr: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJapji(page);
  const c = await checkCentred(page, [2, 3, 4, 5]);
  ok('photo tr: section carries BOTH gs-translit-on and gs-layers-on', c.hasTranslitOn && c.hasLayersOn, JSON.stringify(c));
  ok('photo tr: every .gs-bani-pankti is text-align center', JSON.stringify(c.panktiAlign) === '["center"]', JSON.stringify(c.panktiAlign));
  ok('photo tr: Roman still orange rgb(243, 84, 29)', c.romanColor === 'rgb(243, 84, 29)', String(c.romanColor));
  await scrollLineToMiddle(page, 4);
  await page.screenshot({ path: path.join(OUT, 'v2.2.49-photo-japji-centred-translit.png') });
  await ctx.close();
}

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
