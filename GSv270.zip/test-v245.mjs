/* Gurbani Saanj v2.2.25 — A+/A- buttons removed; pinch-to-zoom made robust.
 * v2.2.24 IS installed on the user's phone, but its pinch does nothing there
 * and the A+/A- buttons are still showing (he wants them gone).
 * Change 1: the .ai-zoom-row (A-/A+) is removed from the Ask screen markup.
 * The dormant data-ai-zoom click handler stays (harmless, no buttons).
 * Change 2: pinch handlers moved to DOCUMENT level, attached ONCE at startup
 * (no more attach()/#conversation dependency), and the pinch now arms on
 * touchmove too, so a missed second-finger touchstart no longer blocks it.
 * The pinch still reuses --ai-font (theme() sets it from state.aiFont),
 * clamps 14-32, updates live, and persists on touchend/touchcancel.
 * Run: node test-v245.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.25', vj.version === '2.2.25');
ok('package.json is 2.2.25', pj.version === '2.2.25');
ok('version.json notes mention v2.2.25', vj.notes.includes('v2.2.25:'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 1. A+/A- row GONE from the Ask screen ----
ok('no ai-zoom-row anywhere in app.js', !app.includes('ai-zoom-row'));
ok('no A- button (data-ai-zoom="-2") in app.js', !app.includes('data-ai-zoom="-2"'));
ok('no A+ button (data-ai-zoom="2") in app.js', !app.includes('data-ai-zoom="2"'));
ok('data-ai-zoom appears exactly once (dormant handler)', (app.match(/data-ai-zoom/g) || []).length === 1);
ok('dormant A+/A- click handler still present', app.includes("const aiZoom=e.target.closest('[data-ai-zoom]');"));

// ---- 2. Pinch slice + document-level wiring ----
const pinchSlice = app.slice(app.indexOf('function pinchDist'), app.indexOf('function askScreen(){'));
ok('pinch slice has helpers + setup', pinchSlice.includes('function pinchDist') && pinchSlice.includes('function pinchFont') && pinchSlice.includes('function setupPinchZoom') && pinchSlice.includes('setupPinchZoom();'));
ok('pinch setup is document-level', pinchSlice.includes("document.addEventListener('touchstart'") && pinchSlice.includes("document.addEventListener('touchmove'") && pinchSlice.includes("document.addEventListener('touchend'") && pinchSlice.includes("document.addEventListener('touchcancel'"));
ok('no #conversation pinch wiring left', !pinchSlice.includes('conv.addEventListener') && !app.includes("const conv=$('conversation');"));
ok('pinch guard flag present', pinchSlice.includes('if(pinchWired)return;pinchWired=true;'));
ok('pinch arms on touchmove too', pinchSlice.includes('if(!pinchState&&pinchInAnswer(e))pinchState='));
ok('pinch gates on .ai-answer OR .qa-card', pinchSlice.includes("t.closest('.ai-answer')||t.closest('.qa-card')"));

const docH = {};
const fakeDoc = { addEventListener(t, f, o) { (docH[t] = docH[t] || []).push({ f, o }); } };
const state = { aiFont: 18 };
let themeCalls = 0, persistCalls = 0;
const bctx = vm.createContext({
  document: fakeDoc, state,
  theme() { themeCalls++; },
  persist() { persistCalls++; },
  console, Math,
});
vm.runInContext(pinchSlice + '\n;globalThis.__pinchDist=pinchDist;globalThis.__pinchFont=pinchFont;globalThis.__setupPinchZoom=setupPinchZoom;', bctx);
const pinchDist = bctx.__pinchDist, pinchFont = bctx.__pinchFont;
ok('touchstart on document (1)', (docH.touchstart || []).length === 1);
ok('touchmove on document (1)', (docH.touchmove || []).length === 1);
ok('touchend + touchcancel on document (1 each)', (docH.touchend || []).length === 1 && (docH.touchcancel || []).length === 1);
ok('touchmove is NON-passive', docH.touchmove[0].o && docH.touchmove[0].o.passive === false, `got ${JSON.stringify(docH.touchmove[0].o)}`);
ok('touchstart is passive', docH.touchstart[0].o && docH.touchstart[0].o.passive === true);
bctx.__setupPinchZoom();
ok('setupPinchZoom idempotent (still 1 per type)', docH.touchstart.length === 1 && docH.touchmove.length === 1 && docH.touchend.length === 1 && docH.touchcancel.length === 1);

// ---- 3. Helpers math ----
ok('pinchDist 3-4-5 is 5', pinchDist([{ clientX: 0, clientY: 0 }, { clientX: 3, clientY: 4 }]) === 5);
ok('pinch-out 18 x1.5 -> 27', pinchFont(18, 100, 150) === 27);
ok('pinch-in 18 x0.5 -> 14 (clamped)', pinchFont(18, 100, 50) === 14);
ok('pinch-out 18 x2 -> 32 (clamped)', pinchFont(18, 100, 200) === 32);
ok('no-scale 18 x1.0 -> 18', pinchFont(18, 100, 100) === 18);
ok('zero start distance guards to start font', pinchFont(18, 0, 100) === 18);
ok('zero current distance guards to start font', pinchFont(18, 100, 0) === 18);

// ---- 4. Behavioral ----
const mkTarget = (m) => ({ closest: (s) => (m.has(s) ? {} : null) });
const ANSWER = new Set(['.ai-answer', '.qa-card']);
const CARDONLY = new Set(['.qa-card']);
const NONE = new Set([]);
const touch = (x, y, m) => ({ clientX: x, clientY: y, target: mkTarget(m) });
const evt = (touches, m) => ({ touches, _pd: false, target: mkTarget(m), preventDefault() { this._pd = true; } });
const fire = (type, e) => { const h = docH[type]; if (h && h.length) h[0].f(e); };
const reset = (font) => { state.aiFont = font; themeCalls = 0; persistCalls = 0; };

// (c) pinch arms on touchmove when touchstart was missed
reset(18);
fire('touchstart', evt([touch(0, 0, ANSWER)], ANSWER)); // 1 finger: nothing arms
ok('1-finger touchstart does not arm the pinch', state.aiFont === 18 && themeCalls === 0);
const armMove = evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER);
fire('touchmove', armMove); // 2 fingers on move: arms at distance 100
ok('touchmove with 2 fingers arms the pinch (baseline, no change yet)', state.aiFont === 18 && armMove._pd === true, `font=${state.aiFont} pd=${armMove._pd}`);
const growMove = evt([touch(0, 0, ANSWER), touch(150, 0, ANSWER)], ANSWER);
fire('touchmove', growMove);
ok('after arming on touchmove, pinch-out grows 18 -> 27', state.aiFont === 27, `got ${state.aiFont}`);
ok('arming path calls theme() live', themeCalls === 2, `got ${themeCalls}`);
fire('touchend', {});
ok('touchend persists once after move-armed pinch', persistCalls === 1, `got ${persistCalls}`);

// (d) normal pinch: touchstart with 2 touches
reset(18);
fire('touchstart', evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER));
const mvOut = evt([touch(0, 0, ANSWER), touch(150, 0, ANSWER)], ANSWER);
fire('touchmove', mvOut);
ok('pinch-out 1.5x: aiFont 18 -> 27', state.aiFont === 27, `got ${state.aiFont}`);
ok('pinch-out calls theme() live', themeCalls === 1, `got ${themeCalls}`);
ok('pinch-out preventDefault called', mvOut._pd === true);
const mvIn = evt([touch(0, 0, ANSWER), touch(50, 0, ANSWER)], ANSWER);
fire('touchmove', mvIn);
ok('pinch-in clamps at 14', state.aiFont === 14, `got ${state.aiFont}`);
const mvMax = evt([touch(0, 0, ANSWER), touch(200, 0, ANSWER)], ANSWER);
fire('touchmove', mvMax);
ok('pinch-out clamps at 32', state.aiFont === 32, `got ${state.aiFont}`);
fire('touchend', {});
ok('touchend persists once', persistCalls === 1, `got ${persistCalls}`);
// a fresh 2-finger move after touchend starts a NEW pinch (re-arms)
const mvNew = evt([touch(0, 0, ANSWER), touch(200, 0, ANSWER)], ANSWER);
fire('touchmove', mvNew);
ok('fresh 2-finger move after touchend re-arms (font unchanged at baseline)', state.aiFont === 32 && mvNew._pd === true, `font=${state.aiFont} pd=${mvNew._pd}`);
const mvNew2 = evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER);
fire('touchmove', mvNew2);
ok('re-armed pinch shrinks 32 -> 16', state.aiFont === 16, `got ${state.aiFont}`);
fire('touchend', {});
// touchcancel also persists
reset(18);
fire('touchstart', evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER));
fire('touchmove', evt([touch(0, 0, ANSWER), touch(150, 0, ANSWER)], ANSWER));
fire('touchcancel', {});
ok('touchcancel persists once', persistCalls === 1, `got ${persistCalls}`);

// (e) single-finger scroll not intercepted
reset(20);
fire('touchstart', evt([touch(0, 0, ANSWER)], ANSWER));
const mvOne = evt([touch(0, 0, ANSWER)], ANSWER);
fire('touchmove', mvOne);
ok('single-finger move does not preventDefault', mvOne._pd === false);
ok('single-finger move does not change aiFont or call theme', state.aiFont === 20 && themeCalls === 0);

// pinch off the answer does nothing
reset(20);
fire('touchstart', evt([touch(0, 0, NONE), touch(100, 0, NONE)], NONE));
const mvOff = evt([touch(0, 0, NONE), touch(200, 0, NONE)], NONE);
fire('touchmove', mvOff);
ok('pinch off the answer does nothing', state.aiFont === 20 && mvOff._pd === false);

// pinch on .qa-card (not .ai-answer) still arms
reset(18);
fire('touchstart', evt([touch(0, 0, CARDONLY), touch(100, 0, CARDONLY)], CARDONLY));
const mvCard = evt([touch(0, 0, CARDONLY), touch(150, 0, CARDONLY)], CARDONLY);
fire('touchmove', mvCard);
ok('pinch on .qa-card arms and grows 18 -> 27', state.aiFont === 27, `got ${state.aiFont}`);
fire('touchend', {});

// ---- 5. CSS ----
const aiAnswerBlocks = [...css.matchAll(/\.ai-answer\s*\{[^}]*\}/g)].map(m => m[0]);
ok('three .ai-answer rules exist', aiAnswerBlocks.length === 3, `got ${aiAnswerBlocks.length}`);
ok('.ai-answer has touch-action:pan-y', aiAnswerBlocks.some(b => /touch-action\s*:\s*pan-y/.test(b)));
const fontSizeDecls = aiAnswerBlocks.flatMap(b => [...b.matchAll(/font-size\s*:\s*([^;}]+)/g)].map(m => m[1].trim()));
ok('exactly ONE .ai-answer font-size, still var(--ai-font,18px)', fontSizeDecls.length === 1 && fontSizeDecls[0] === 'var(--ai-font,18px)', `got ${JSON.stringify(fontSizeDecls)}`);
ok('.qa-card has touch-action:pan-y', css.includes('.qa-card{touch-action:pan-y}'));

// ---- 6. Wiring greps ----
ok('pinch persists on touchend/touchcancel (pinchState)', app.includes('const endPinch=()=>{if(pinchState){pinchState=null;persist()}}'));
ok('pinch calls theme() live, no render() per move', app.includes('pinchFont(pinchState.f,pinchState.d,pinchDist(e.touches));theme()}') && !app.includes('pinchFont(pinchState.f,pinchState.d,pinchDist(e.touches));theme();render()'));

// ---- Regression ----
ok('v2.2.24: pinch helpers present', app.includes('function pinchDist') && app.includes('function pinchFont'));
ok('v2.2.24: theme() still sets --ai-font', app.includes("html.style.setProperty('--ai-font'"));
ok('v2.2.22: no-heard timer intact', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('v2.2.22: X restarts the mic intact', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('v2.2.21: first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.18: ai-verse highlight intact', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('v2.2.18: aiFont clamp 14-32 intact (dormant handler)', app.includes('Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))'));
ok('v2.2.15: AI language toggle intact', app.includes('data-ai-lang') && app.includes('state.aiLang=aiLang.dataset.aiLang'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
