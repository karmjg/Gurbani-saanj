#!/usr/bin/env python3
"""Render the remaining v2.2.8 mockup photos: Ask, ViewPrefs, Kirtan A-Z,
Home/Sahaj, Full-screen (#15). Real app colors, real verses from the bundle.
"""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'; YELLOW = '#fff2a8'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def svg_open():
    return [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
            f'<rect width="{W}" height="{H}" fill="{BG}"/>',
            f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

def topbar():
    return [rect(0, 0, W, 116, PAPER, 0, LINE),
            f'<line x1="0" y1="116" x2="{W}" y2="116" stroke="{LINE}" stroke-width="2"/>',
            text(36, 76, '‹', 56, INK, SYM, '400'),
            text(96, 76, 'ਗੁਰਬਾਣੀ ਸਾਂਝ', 42, INK, SERIF, '750'),
            text(W - 36, 76, '⚙', 44, INK, SYM, '400', 'end')]

def bottom_nav(active):
    items = [('home', 'Home'), ('search', 'Search'), ('heart', 'Saved'), ('gear', 'Settings')]
    out = [rect(0, H - 128, W, 128, PAPER, 0, LINE),
           f'<line x1="0" y1="{H-128}" x2="{W}" y2="{H-128}" stroke="{LINE}" stroke-width="2"/>']
    cx = W / 8
    for i, (kind, label) in enumerate(items):
        x = cx + i * (W / 4)
        col = PRIMARY if label == active else MUTED
        w = '750' if label == active else '400'
        if kind == 'home':
            out.append(f'<path d="M {x-20} {H-92} l 20 -18 l 20 18 v 20 h -14 v -12 h -12 v 12 h -14 z" fill="{col}"/>')
        elif kind == 'search':
            out.append(f'<circle cx="{x}" cy="{H-88}" r="15" fill="none" stroke="{col}" stroke-width="5"/><line x1="{x+11}" y1="{H-77}" x2="{x+20}" y2="{H-68}" stroke="{col}" stroke-width="5" stroke-linecap="round"/>')
        elif kind == 'heart':
            out.append(text(x, H - 68, '♡', 46, col, SYM, '400', 'middle'))
        else:
            out.append(text(x, H - 68, '⚙', 46, col, SYM, '400', 'middle'))
        out.append(text(x, H - 34, label, 22, col, LATIN, w, 'middle'))
    return out

def save(s, name):
    s.append('</svg>')
    cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, name))
    print(name, 'done')

# ---------------- Photo A: Ask (#7, #8, #12, #13) ----------------
s = svg_open()
s += topbar()
s.append(text(36, 190, 'ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਨੂੰ ਪੁੱਛੋ', 40, INK, SERIF, '700'))
s.append(text(36, 232, 'Ask Guru Granth Sahib', 26, MUTED, LATIN, '400'))
# question box
s.append(rect(28, 258, W - 56, 96, '#ffffff', 28, LINE, 2))
s.append(text(60, 318, 'ਗੁਰੂ ਕੀ ਹੈ?', 34, INK, SERIF, '550'))
s.append(rect(W - 178, 282, 130, 48, PRIMARY, 24))
s.append(text(W - 113, 316, 'ਪੁੱਛੋ', 28, '#ffffff', SANS, '700', 'middle'))
# level pills
for i, (lb, sel) in enumerate([('Simple', True), ('Detailed', False), ('In depth', False)]):
    x = 28 + i * 170
    s.append(rect(x, 378, 156, 56, PRIMARY if sel else '#ffffff', 30, LINE if not sel else PRIMARY, 2))
    s.append(text(x + 78, 415, lb, 24, '#ffffff' if sel else INK, LATIN, '650' if sel else '400', 'middle'))
# AI status
s.append(f'<circle cx="44" cy="478" r="10" fill="#2e7d32"/>')
s.append(tspans(66, 486, [('AI online', LATIN, '400', INK), (' — ਜਵਾਬ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਤੋਂ', SANS, '400', INK)], 26))
# answer card 1
s.append(rect(28, 516, W - 56, 430, '#ffffff', 32, LINE, 2))
s.append(text(60, 576, 'ਗੁਰੂ ਕੀ ਹੈ?', 30, INK, SERIF, '700'))
s.append(text(60, 646, '“ਪਵਣੁ ਗੁਰੂ ਪਾਣੀ ਪਿਤਾ ਮਾਤਾ ਧਰਤਿ ਮਹਤੁ ॥”', 32, INK, SERIF, '550'))
s.append(text(60, 686, '[ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ, ਅੰਗ 8]', 24, MUTED, SANS, '400'))
s.append(text(60, 750, 'ਗੁਰੂ ਹਵਾ ਵਰਗਾ ਹੈ — ਹਰ ਥਾਂ, ਹਰ ਵੇਲੇ,', 30, INK, SANS, '400'))
s.append(text(60, 800, 'ਸਭ ਨੂੰ ਜੀਵਨ ਦੇਣ ਵਾਲਾ। ਜਿਵੇਂ ਹਵਾ ਤੋਂ', 30, INK, SANS, '400'))
s.append(text(60, 850, 'ਬਿਨਾਂ ਸਾਹ ਨਹੀਂ, ਉਵੇਂ ਗੁਰੂ ਤੋਂ ਬਿਨਾਂ', 30, INK, SANS, '400'))
s.append(text(60, 900, 'ਜੀਵਨ ਦਾ ਰਾਹ ਨਹੀਂ।', 30, INK, SANS, '400'))
# answer card 2 (follow-up)
s.append(rect(28, 976, W - 56, 380, '#ffffff', 32, LINE, 2))
s.append(text(60, 1036, 'ਗੁਰੂ ਮੇਰੇ ਲਈ ਕਿਉਂ ਜ਼ਰੂਰੀ ਹੈ?', 30, INK, SERIF, '700'))
s.append(text(60, 1106, '“ਗੁਰੁ ਪਉੜੀ ਬੇੜੀ ਗੁਰੂ ਗੁਰੁ ਤੁਲਹਾ ਹਰਿ ਨਾਉ ॥”', 32, INK, SERIF, '550'))
s.append(text(60, 1146, '[ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ, ਅੰਗ 17]', 24, MUTED, SANS, '400'))
s.append(text(60, 1210, 'ਗੁਰੂ ਬੇੜੀ ਵਰਗਾ ਹੈ — ਸੰਸਾਰ-ਸਮੁੰਦਰ', 30, INK, SANS, '400'))
s.append(text(60, 1260, 'ਤੋਂ ਪਾਰ ਲੈ ਜਾਂਦਾ ਹੈ।', 30, INK, SANS, '400'))
s += bottom_nav('Home')
save(s, 'v228_preview_ask.png')

# ---------------- Photo B: ViewPrefs (#10) ----------------
s = svg_open()
s += topbar()
s.append(text(36, 190, 'ਬਾਣੀ ਵੇਖਣ ਦੀਆਂ ਪਸੰਦਾਂ', 40, INK, SERIF, '700'))
s.append(text(36, 232, 'Bani View Preferences — the ONE place for these', 24, MUTED, LATIN, '400'))
s.append(text(36, 300, 'ਪਾਠ ਦੀਆਂ ਪਰਤਾਂ', 26, PRIMARY, SANS, '700'))
rows = [('Transliteration', 'ON', True), ('English Translation', 'ON', True),
        ('Punjabi Translation', 'ON', True), ('Hindi Translation', 'OFF', False),
        ('Shabad Arth', 'ON', True)]
y = 330
for label, state, on in rows:
    s.append(f'<line x1="36" y1="{y+58}" x2="{W-36}" y2="{y+58}" stroke="{LINE}" stroke-width="2"/>')
    s.append(text(36, y + 44, label, 28, INK, LATIN, '400'))
    s.append(rect(W - 150, y + 8, 114, 48, PRIMARY if on else '#ffffff', 24, PRIMARY if on else LINE, 2))
    s.append(text(W - 93, y + 42, state, 24, '#ffffff' if on else MUTED, LATIN, '700', 'middle'))
    y += 76
s.append(text(36, y + 30, 'Bani Text Size', 28, INK, LATIN, '400'))
for i, (lb, sel) in enumerate([('Normal', True), ('Large', False), ('Extra-large', False)]):
    x = 36 + [0, 142, 264][i]
    w = [130, 110, 170][i]
    s.append(rect(x, y + 52, w, 48, PRIMARY if sel else '#ffffff', 24, PRIMARY if sel else LINE, 2))
    s.append(text(x + w / 2, y + 86, lb, 22, '#ffffff' if sel else INK, LATIN, '650' if sel else '400', 'middle'))
y += 140
s.append(f'<line x1="36" y1="{y+58}" x2="{W-36}" y2="{y+58}" stroke="{LINE}" stroke-width="2"/>')
s.append(text(36, y + 100, 'Night Mode', 28, INK, LATIN, '400'))
s.append(rect(W - 150, y + 64, 114, 48, '#ffffff', 24, LINE, 2))
s.append(text(W - 93, y + 98, 'OFF', 24, MUTED, LATIN, '700', 'middle'))
s.append(text(36, y + 190, 'These settings live only here now.', 26, INK, LATIN, '700'))
s.append(text(36, y + 232, 'The Reading settings sheet (Aa) no longer', 26, MUTED, LATIN, '400'))
s.append(text(36, y + 272, 'shows them — no more duplicates.', 26, MUTED, LATIN, '400'))
s += bottom_nav('Settings')
save(s, 'v228_preview_viewprefs.png')

# ---------------- Photo C: Kirtan A-Z (#11) ----------------
s = svg_open()
s += topbar()
s.append(text(36, 190, 'ਕੀਰਤਨ ਸ਼ਬਦ', 40, INK, SERIF, '700'))
s.append(text(36, 232, 'Kirtan Shabads — A to Z in Gurmukhi order', 26, MUTED, LATIN, '400'))
s.append(text(36, 310, 'ਅ', 54, PRIMARY, SERIF, '700'))
shabads = ['ਅਸੁਮੇਧ ਜਗਨੇ ॥', 'ਅਹਿਨਿਸਿ ਜਾਗੈ ਨੀਦ ਨ ਸੋਵੈ ॥', 'ਅਹੰ ਤੋਰੋ ਮੁਖੁ ਜੋਰੋ ॥',
           'ਅਕਥਾ ਹਰਿ ਅਕਥ ਕਥਾ ਕਿਛੁ ਜਾਇ ਨ ਜਾਣੀ ਰਾਮ ॥',
           'ਅਖੀ ਪ੍ਰੇਮਿ ਕਸਾਈਆ ਹਰਿ ਹਰਿ ਨਾਮੁ ਪਿਖੰਨਿ ॥',
           'ਅਖੀ ਬਾਝਹੁ ਵੇਖਣਾ ਵਿਣੁ ਕੰਨਾ ਸੁਨਣਾ ॥',
           'ਅਗਨਿ ਨ ਦਹੈ ਪਵਨੁ ਨਹੀ ਮਗਨੈ ਤਸਕਰੁ ਨੇਰਿ ਨ ਆਵੈ ॥',
           'ਅਗਮ ਅਗੋਚਰੁ ਦਰਸੁ ਤੇਰਾ ਸੋ ਪਾਏ ਜਿਸੁ ਮਸਤਕਿ ਭਾਗੁ ॥']
y = 350
for line in shabads:
    s.append(f'<line x1="36" y1="{y+62}" x2="{W-36}" y2="{y+62}" stroke="{LINE}" stroke-width="2"/>')
    s.append(text(36, y + 42, line, 32, INK, SERIF, '550'))
    s.append(text(W - 36, y + 42, '›', 36, MUTED, SYM, '400', 'end'))
    y += 84
s.append(text(36, y + 40, '… ਫਿਰ ਸ, ਹ, ਕ, ਖ, ਗ … ੜ', 26, MUTED, SANS, '400'))
s += bottom_nav('Home')
save(s, 'v228_preview_kirtan.png')

# ---------------- Photo D: Home / Sahaj (#14) ----------------
s = svg_open()
s += topbar()
s.append(text(36, 190, 'Home', 40, INK, LATIN, '700'))
# continue card
s.append(rect(28, 220, W - 56, 150, PRIMARY, 38))
s.append(text(64, 288, 'ਸਹਿਜ ਪਾਠ ਜਾਰੀ ਰੱਖੋ', 34, '#ffffff', SANS, '700'))
s.append(tspans(64, 332, [('ਸਹਿਜ ਪਾਠ ', SANS, '400', '#cfe0d4'), ('·', SYM, '400', '#cfe0d4'), (' ਅੰਗ 205', SANS, '400', '#cfe0d4')], 26))
s.append(text(W - 64, 306, '›', 48, '#ffffff', SYM, '400', 'end'))
# divider + label
s.append(text(36, 470, 'Search opened a different Ang:', 28, PRIMARY, LATIN, '700'))
s.append(rect(28, 500, W - 56, 300, '#ffffff', 32, LINE, 2))
s.append(text(60, 566, 'ਅੰਗ 100', 26, MUTED, SANS, '700'))
s.append(text(W / 2, 660, 'ਰੇਨੁ ਸੰਤਨ ਕੀ ਮੇਰੈ ਮੁਖਿ ਲਾਗੀ ॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 720, 'ਦੁਰਮਤਿ ਬਿਨਸੀ ਕੁਬੁਧਿ ਅਭਾਗੀ ॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(36, 900, 'Sahaj Paath is still Ang 205.', 30, INK, LATIN, '700'))
s.append(text(36, 946, 'Search did not move it — the Home card', 28, MUTED, LATIN, '400'))
s.append(text(36, 988, 'still says Ang 205.', 28, MUTED, LATIN, '400'))
s += bottom_nav('Home')
save(s, 'v228_preview_sahaj.png')

# ---------------- Photo E: Full-screen (#15) ----------------
s = svg_open()
s.append(text(36, 64, 'On open — full screen, no bar', 28, PRIMARY, LATIN, '700'))
s.append(text(W / 2, 190, 'ਅੰਤਰਿ ਅਲਖੁ ਨ ਜਾਈ ਲਖਿਆ', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 248, 'ਵਿਚਿ ਪੜਦਾ ਹਉਮੈ ਪਾਈ ॥', 42, INK, SERIF, '550', 'middle'))
s.append(rect(24, 286, W - 48, 118, YELLOW, 16))
s.append(text(W / 2, 336, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 390, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 478, 'ਏਕਾ ਸੰਗਤਿ ਇਕਤੁ ਗ੍ਰਿਹਿ ਬਸਤੇ', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 536, 'ਮਿਲਿ ਬਾਤ ਨ ਕਰਤੇ ਭਾਈ ॥', 42, INK, SERIF, '550', 'middle'))
s.append(f'<line x1="32" y1="620" x2="{W-32}" y2="620" stroke="{LINE}" stroke-width="2"/>')
s.append(text(36, 684, 'After scrolling down — bar appears on top', 28, PRIMARY, LATIN, '700'))
# the bar (appears)
s.append(rect(0, 712, W, 108, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="820" x2="{W}" y2="820" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 780, 'ਅੰਗ', 30, INK, SANS, '700'))
s.append(rect(118, 738, 150, 56, '#ffffff', 14, LINE, 2))
s.append(text(193, 778, '205', 32, INK, LATIN, '400', 'middle'))
s.append(rect(284, 734, 130, 64, PRIMARY, 18))
s.append(tspans(349, 778, [('ਜਾਓ ', SANS, '650', '#ffffff'), ('›', SYM, '650', '#ffffff')], 28, 'middle'))
s.append(text(W - 32, 780, 'Aa', 32, INK, LATIN, '400', 'end'))
s.append(text(W / 2, 920, 'ਏਕ ਬਸਤੁ ਬਿਨੁ ਪੰਚ ਦੁਹੇਲੇ', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 978, 'ਓਹ ਬਸਤੁ ਅਗੋਚਰ ਠਾਈ ॥੨॥', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1066, 'ਜਿਸ ਕਾ ਗ੍ਰਿਹੁ ਤਿਨਿ ਦੀਆ ਤਾਲਾ', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1124, 'ਕੁੰਜੀ ਗੁਰ ਸਉਪਾਈ ॥', 42, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1220, 'Scroll down any time to bring the bar back.', 26, MUTED, LATIN, '400', 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_fullscreen.png'))
print('v228_preview_fullscreen.png done')
