# Gurbani Saanjh v1.9.0 — Advanced Search Trial

* Offline SGGS search now supports Gurmukhi text, first-letter (from start / anywhere), full word, Romanised transliteration and Ang number.
* Voice search uses an Android native speech recognizer plugin, with Web Speech browser fallback. A Punjabi Gurbani-specific acoustic model is NOT included. Recognition quality requires Samsung testing and may need internet depending on speech service.
* Long press a word -> Meaning now first checks bundled sample meanings, then cached meanings, then optionally looks up BaniDB Kosh (network required for words not cached). The full offline dictionary is NOT yet bundled. Missing definitions are explicitly disclosed; no definitions are invented.
* Existing complete SGGS/Sundar Gutka importer remains build-time; full 1,430 Angs is NOT present inside this source ZIP and must complete successfully in GitHub Actions.
* Offline Kirtan text lookup and saved lines are retained; Amrit Keertan full curated collection is not bundled.
* Existing optional Cloudflare AI server code remains un-deployed; generative AI only works with an authorized, configured HTTPS endpoint.
* Audio remains deferred. No third-party audio included.

Never call this a fully launched AI product or a final, independently audited corpus. Check text/licensing/variants before public use.
