# Gurbani Saanjh v2.0 — reading, search and meanings (personal trial)

This is an update to the existing Capacitor Android app. It preserves the `gurbani-saanjh-trial-v1` localStorage key, Android application ID `com.gurbanisaanjh.app`, and the signing workflow so an update should preserve reading position and app data. Never change the Android keystore between updates.

## Priority changes
- **Nitnem and other Banis**: Sundar Gutka-inspired text presentation, clearly centered pankti, consistent line height, and extra spacing only after stanza/pauri completion. Other variants (including Damdami Taksal Rehras) still need source verification. No copyrighted UI/code from the reference app is included.
- **Sri Guru Granth Sahib Ji**: iGranth-inspired distinct reader, separated original lines and clear Ang heading. Navigation by exact Ang. Ang numbers for Banis are shown only when there is explicit SGGS source metadata in the Bani source, to avoid false references.
- **Search**: offline first-letter-of-each-word (start and anywhere), phrase/word, Romanization, and Ang search. Results show exact original line + Ang. Tested with fixtures, but full runtime coverage depends on the complete offline dataset being fetched in the GitHub build.
- **Word meanings**: tap words to open popup; immediate basic Punjabi/English glossary where available; BaniDB Kosh `word_uni`/`def_uni` parser fixed; helpful line-level context shown as such (never passed off as a one-word definition); X/outside tap/Android Back close; no Listen or audio button. This is **not** yet a complete offline Gurbani dictionary.

## Build and limits
The source ZIP intentionally excludes a large scripture snapshot. GitHub Actions downloads the complete 1,430 Angs and available Sundar Gutka Banis from BaniDB at build time. Network access/source availability and full corpus correctness must be checked during the actual APK build and on device. If the build fails to fetch all Angs, it hard-fails rather than shipping missing pages. `node scripts/bundle-offline.mjs --fixture` and `node test-reader.mjs` verify the local code without downloading source material.

BaniDB is a source used for this trial, **not proof of exact identity with the Damdami Taksal Sundar Gutka text edition**, and the iGranth search interaction is independently implemented rather than using iGranth source code or its licensed API. Release only after content verification, licensing, and realistic Android-device QA.

## GitHub workflow replacement
Upload `GS_v200_source.zip` to the repo root, and update `.github/workflows/android-apk-1.yml` using the corresponding v2 workflow. Keep the four existing signing secrets and Android app ID unchanged. No app code or ZIP has been pushed to the user's GitHub repository by this work.
