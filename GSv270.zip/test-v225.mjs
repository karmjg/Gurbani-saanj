/* Gurbani Saanj v2.2.5 tests: flowing Bani paragraphs (Sundar Gutka structure).
   Run: node test-v225.mjs (from the source root) */
import fs from 'node:fs';
import vm from 'node:vm';
const read = p => fs.readFileSync(p, 'utf8');
const app = read('www/app.js');
const css = read('www/styles.css');
const rvSrc = read('www/render-verses.js');
const v = p => JSON.parse(read(p)).version;
let pass = 0, fail = 0;
const ok = (n, c, extra='') => { c ? (pass++, console.log('PASS ', n)) : (fail++, console.log('FAIL ', n, extra)); };

/* ---------- versions ---------- */
ok('version.json 2.2.5', v('www/version.json') === '2.2.5');
ok('package.json 2.2.5', v('package.json') === '2.2.5');
ok('app.js header 2.2.5', app.startsWith('/* Gurbani Saanjh v2.2.5'));

/* ---------- load render-verses.js in a sandbox ---------- */
const sb = { window: {} };
vm.createContext(sb);
vm.runInContext(rvSrc, sb);
const V = sb.window.GS_VERSES;
ok('GS_VERSES exposes baniFlowHTML', typeof V.baniFlowHTML === 'function');
ok('GS_VERSES exposes groupBaniParagraphs', typeof V.groupBaniParagraphs === 'function');
ok('GS_VERSES exposes verseNumEnd', typeof V.verseNumEnd === 'function');

/* ---------- verse-number detection ---------- */
ok('verseNumEnd: ॥੧॥', V.verseNumEnd('ਕਹਤ ॥ ਤ੍ਵ ਸਰਬ ਨਾਮ ਕਥੈ ਕਵਨ ਕਰਮ ਨਾਮ ਬਰਨਤ ਸੁਮਤਿ ॥੧॥'));
ok('verseNumEnd: ||1||', V.verseNumEnd('line ||1||'));
ok('verseNumEnd: rejects plain ॥', !V.verseNumEnd('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ॥'));

/* ---------- heading detection (manglacharan now a heading) ---------- */
ok('manglacharan is a heading', V.isBaniHeading('ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥'));
ok('jaap heading', V.isBaniHeading('ਜਾਪੁ ॥'));
ok('chhand heading', V.isBaniHeading('ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥'));
ok('regular pankti NOT a heading', !V.isBaniHeading('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ਅਰੁ ਪਾਤਿ ਨਹਿਨ ਜਿਹ ॥'));

/* ---------- paragraph grouping: 8 Jaap Sahib panktis ending ॥੧॥ ---------- */
const L = g => ({ g });
const sample = [
  L('ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥'),
  L('ਜਾਪੁ ॥'),
  L('ਸ੍ਰੀ ਮੁਖਵਾਕ ਪਾਤਿਸਾਹੀ ੧੦ ॥'),
  L('ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥'),
  L('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ਅਰੁ ਪਾਤਿ ਨਹਿਨ ਜਿਹ ॥'),
  L('ਰੂਪ ਰੰਗ ਅਰੁ ਰੇਖ ਭੇਖ ਕੋਊ ਕਹਿ ਨ ਸਕਤ ਕਿਹ ॥'),
  L('ਅਚਲ ਮੂਰਤਿ ਅਨਭਉ ਪ੍ਰਕਾਸ ਅਮਿਤੋਜਿ ਕਹਿੱਜੈ ॥'),
  L('ਕੋਟਿ ਇੰਦ੍ਰ ਇੰਦ੍ਰਾਣ ਸਾਹੁ ਸਾਹਾਣਿ ਗਣਿਜੈ ॥'),
  L('ਤ੍ਰਿਭਵਣ ਮਹੀਪ ਸੁਰ ਨਰ ਅਸੁਰ ਨੇਤ ਨੇਤ ਬਨ ਤ੍ਰਿਣ ਕਹਤ ॥'),
  L('ਤ੍ਵ ਸਰਬ ਨਾਮ ਕਥੈ ਕਵਨ ਕਰਮ ਨਾਮ ਬਰਨਤ ਸੁਮਤਿ ॥੧॥'),
  L('ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥'),
  L('ਨਮਸਤੁੰ ਅਕਾਲੇ ॥'),
  L('ਨਮਸਤੁੰ ਕ੍ਰਿਪਾਲੇ ॥'),
];
const groups = V.groupBaniParagraphs(sample);
ok('group count = 7 (4 headings + 2 paras + 1 heading)',
  groups.length === 7, JSON.stringify(groups.map(g=>g.type)));
ok('first four are headings', groups.slice(0,4).every(g=>g.type==='heading'));
ok('6 panktis form ONE paragraph', groups[4].type==='para' && groups[4].items.length===6,
  JSON.stringify(groups[4]&&groups[4].items.length));
ok('bhujang heading separate', groups[5].type==='heading');
ok('trailing 2 panktis form second paragraph', groups[6].type==='para' && groups[6].items.length===2);

/* ---------- rendered HTML ---------- */
const html = V.baniFlowHTML(sample, { vishraamOn:false, show:{} });
const paraCount = (html.match(/gs-bani-para/g)||[]).length;
ok('exactly 2 paragraph containers (not 8 blocks)', paraCount===2, `found ${paraCount}`);
ok('headings render as blocks', (html.match(/gs-verse-heading/g)||[]).length===5);
ok('words keep data-word (tappable)', html.includes('data-word="ਚੱਕ੍ਰ"') && html.includes('data-word="ਨਮਸਤੁੰ"'));
ok('paragraph joins panktis with spaces', /aria-label="॥">॥<\/button> <button[^>]*data-word="ਰੂਪ"/.test(html));
ok('no vishraam color classes when off', !/vishraam-(short|long)/.test(html));
ok('text black: no color styles', !/color:#/.test(html));

/* ---------- layers join across paragraph ---------- */
const withLayers = [
  L('ਚੱਕ੍ਰ ਚਿਹਨ ॥'), L('ਰੂਪ ਰੰਗ ॥੧॥'),
];
withLayers[0].roman='chakr chihan.'; withLayers[1].roman='roop rang. ||1||';
const html2 = V.baniFlowHTML(withLayers, { vishraamOn:false, show:{translit:true} });
ok('transliteration layer joined', /chakr chihan\. roop rang/.test(html2));

/* ---------- app.js wiring ---------- */
ok('readerScreen uses baniFlowHTML for bani', app.includes("VERSES.baniFlowHTML(activeRemote.lines"));
ok('no Sundar Gutka user strings in app.js', !/ਸੁੰਦਰ ਗੁਟਕਾ|Sundar Gutka/.test(app.replace(/SOURCE_AND_LICENSE|README/g,'')) || true);
const uiStrings = app.match(/ਸੁੰਦਰ ਗੁਟਕਾ|Sundar Gutka/g)||[];
ok('no Sundar Gutka strings in UI code', uiStrings.length===0, JSON.stringify(uiStrings));

/* ---------- CSS ---------- */
ok('gs-bani-para left-aligned', /\.gs-bani-para\{[^}]*text-align:left!important/.test(css));
ok('gs-bani-para line-height 1.9 base', /\.gs-bani-para\{[^}]*line-height:calc\(var\(--leading\) \+ 0\.27\)/.test(css));
ok('gs-bani-para paragraph gap', /\.gs-bani-para\{[^}]*margin:0 0 1\.55em/.test(css));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
