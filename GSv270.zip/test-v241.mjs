/* Gurbani Saanj v2.2.21 — search forgiving of slightly-off words (node, offline).
 * Auto mode used to return NOTHING when the spoken/typed phrase was slightly
 * off (a matra or spelling): the exact substring does not exist, the terms
 * check needs 2+ word hits, and the first-letter fallback compared the FULL
 * compacted query against the line's initials (far too long to match).
 * Now a full phrase is also tried by its first letters, so "ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ
 * ਵੇਲੇ" finds "ਬਾਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੈ ਬੋਲਿਆ" (Ang 1285) — the user's screenshot.
 * Run: node test-v241.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const searchSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const idx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));

// ---- 0. Version ----
ok('version.json is 2.2.21', vj.version === '2.2.21');
ok('package.json is 2.2.21', pj.version === '2.2.21');

// ---- Code shape ----
ok('first-letter fallback for full phrases present', searchSrc.includes('const firstSig=compact(initials(needle));') && searchSrc.includes('firstSig.length>=2&&candidate.startsWith(firstSig)'));
ok('bare first-letter path intact', searchSrc.includes("if(candidate.startsWith(signature))score=105;"));

// ---- Live search against the real index ----
const ctx = vm.createContext({
  console,
  fetch: async () => ({ ok: true, json: async () => idx }),
  window: {},
});
vm.runInContext(searchSrc, ctx);
const query = (q, mode = 'auto') => ctx.window.GS_SCRIPTURE_SEARCH.query(q, 40, mode);

// The user's screenshot case: slightly-off phrase must find Ang 1285 first.
const off = await query('ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੇ');
ok('slightly-off phrase finds Ang 1285', off.length > 0 && off[0].ang === 1285 && off[0].g.startsWith('ਬਾਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੈ ਬੋਲਿਆ'), `got ${off.length} results, first=${off[0] ? 'Ang ' + off[0].ang : 'none'}`);
ok('slightly-off phrase returns a small, sensible set', off.length >= 1 && off.length <= 40, `got ${off.length}`);

// Exact phrase still works and still ranks first.
const exact = await query('ਬਾਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੈ ਬੋਲਿਆ');
ok('exact phrase still finds Ang 1285 first', exact.length > 0 && exact[0].ang === 1285, `first=${exact[0] ? 'Ang ' + exact[0].ang : 'none'}`);

// Bare first letters (iGranth rule) unchanged.
const fl = await query('ਮਹਅਤਅ');
ok('bare first letters still find Ang 613', fl.length > 0 && fl[0].ang === 613, `first=${fl[0] ? 'Ang ' + fl[0].ang : 'none'}`);

// Voice lines still work.
const v1 = await query('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');
ok('voice line 1 still finds Ang 244', v1.length > 0 && v1[0].ang === 244, `first=${v1[0] ? 'Ang ' + v1[0].ang : 'none'}`);
const v2 = await query('ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ');
ok('voice line 2 still finds results', v2.length > 0, `got ${v2.length}`);

// Roman still works.
const rm = await query('amrit vela');
ok('roman still finds Ang 2 first', rm.length > 0 && rm[0].ang === 2, `first=${rm[0] ? 'Ang ' + rm[0].ang : 'none'}`);

// Ang search still works.
const ag = await query('1366');
ok('Ang search still finds Ang 1366', ag.length > 0 && ag[0].ang === 1366, `first=${ag[0] ? 'Ang ' + ag[0].ang : 'none'}`);

// Single-word query must NOT explode into every line starting with that letter.
const sw = await query('ਮਾਧੋ');
ok('single-word query still returns the exact line first, not a flood', sw.length > 0 && sw.length <= 40 && sw[0].g.includes('ਮਾਧੋ'), `got ${sw.length}, first=${sw[0] ? 'Ang ' + sw[0].ang : 'none'}`);

// Another slightly-off phrase (wrong matra in the middle word).
const off2 = await query('ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ');
ok('exact multi-word phrase still works', off2.length > 0 && off2[0].ang === 613, `first=${off2[0] ? 'Ang ' + off2[0].ang : 'none'}`);

// ---- Regression (grep) ----
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.19: book centered + para flow intact', css.includes('.gs-book-page .gs-book-flow') && fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8').includes('groupBaniParagraphs'));
ok('v2.2.18: AI verse bold+highlight intact', app.includes('ai-verse') && css.includes('.ai-verse{'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'"));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
