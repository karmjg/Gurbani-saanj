/* Gurbani Saanj v2.2.11 — functional checks (node, offline).
 *  1. Prompt tightening (examples rule): a real-world example is allowed ONLY
 *     to illustrate a quoted verse, and must flow from that verse itself.
 *  2. Worker default model is gemini-3.8-flash (gemini-2.0-flash is dead).
 *  3. AI failure shows the REAL error (status/message) in the toast and under
 *     the question, so the cause can be fixed instead of guessed.
 *  4. Roman questions ("Guru kon hai?") retrieve Gurmukhi Guru verses.
 * Run: node test-v231.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const setup = fs.readFileSync(path.join(ROOT, 'AI_SERVER_SETUP.md'), 'utf8');

// ---- 1. Prompt tightening: examples rule (both prompts) ----
const EXAMPLE_RULE = 'A short real-world example is allowed ONLY to illustrate what a quoted verse means';
ok('app AI prompt has the examples rule', app.includes(EXAMPLE_RULE) && app.includes('the example must flow from that verse itself, never from outside knowledge'));
ok('worker AI instructions have the examples rule', worker.includes(EXAMPLE_RULE) && worker.includes('the example must flow from that verse itself, never from outside knowledge'));
ok('three-part format still intact in both prompts',
  app.includes('Structure every answer in three parts') && worker.includes('Structure every answer in three parts')
  && app.includes('total essence') && worker.includes('total essence'));

// ---- 2. Gemini model: 3.8-flash everywhere, 2.0-flash nowhere ----
ok('worker default model is gemini-3.8-flash',
  worker.includes("const model=env.GEMINI_MODEL||'gemini-3.8-flash';"));
ok('setup doc names gemini-3.8-flash as the default', setup.includes('`gemini-3.8-flash` (the default)'));
ok('gemini-2.0-flash appears nowhere (app, worker, setup doc)',
  !app.includes('gemini-2.0-flash') && !worker.includes('gemini-2.0-flash') && !setup.includes('gemini-2.0-flash'));

// ---- 3. AI error display: real error stored + shown ----
ok('askOpenAI failure stores the error on the entry',
  app.includes("entry.aiError=String(e&&e.message||e);toast(age('AI ਜਵਾਬ ਨਹੀਂ ਮਿਲਿਆ ('+entry.aiError+')"));
ok('askOpenAI failure toast shows the error text',
  app.includes("'AI answer failed ('+entry.aiError+'); related Shabads are shown above.'"));
ok('server failure stores + shows its error too',
  app.includes("entry.aiError=String(e&&e.message||e);toast(age('AI ਸਰਵਰ ਨਹੀਂ ਜੁੜ ਸਕਿਆ ('+entry.aiError+')"));
ok('renderQA shows the stored AI error under the question',
  app.includes("v.aiError&&!v.answer") && app.includes("AI ਗਲਤੀ: ") && app.includes("AI error: "));
ok('askOpenAI still throws the HTTP status for a bad call',
  app.includes("if(!res.ok)throw Error('AI API returned '+res.status);"));

// ---- 4. Roman questions retrieve Gurmukhi verses (full Ask flow) ----
const sb2 = {
  window: {},
  fetch: async () => ({ ok: true, json: async () => JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8')) }),
};
vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8'), sb2);
const S = sb2.window.GS_SCRIPTURE_SEARCH;
const TOPIC_BRIDGE = { anxiety: 'ਚਿੰਤਾ', worry: 'ਚਿੰਤਾ', worries: 'ਚਿੰਤਾ', worried: 'ਚਿੰਤਾ', fear: 'ਡਰ', afraid: 'ਡਰ', anger: 'ਕ੍ਰੋਧ', angry: 'ਕ੍ਰੋਧ', ego: 'ਹਉਮੈ', pride: 'ਹਉਮੈ', peace: 'ਸੁਖ', death: 'ਮੌਤ', love: 'ਪ੍ਰੇਮ', patience: 'ਸਬਰ', greed: 'ਲੋਭ', sad: 'ਦੁਖ', sadness: 'ਦੁਖ', hope: 'ਆਸ', faith: 'ਸਰਧਾ', god: 'ਰਬ', stress: 'ਚਿੰਤਾ', tension: 'ਚਿੰਤਾ', guru: 'ਗੁਰੂ', waheguru: 'ਵਾਹਿਗੁਰੂ', nanak: 'ਨਾਨਕ', simran: 'ਸਿਮਰਨ', naam: 'ਨਾਮੁ', karma: 'ਕਰਮ', maya: 'ਮਾਇਆ', sewa: 'ਸੇਵਾ', satsang: 'ਸਤਸੰਗੁ', mukti: 'ਮੁਕਤਿ' };
async function askRetrieval(q) {
  const matches = await S.query(q, 12);
  const ql = q.toLocaleLowerCase();
  for (const w of Object.keys(TOPIC_BRIDGE).filter(w => ql.includes(w)).slice(0, 3)) {
    const extra = await S.query(TOPIC_BRIDGE[w], 6, 'word');
    for (const mm of extra) if (!matches.some(x => x.ang === mm.ang && x.idx === mm.idx)) matches.push(mm);
  }
  matches.splice(12);
  return matches;
}
const guruRoman = await askRetrieval('Guru kon hai?');
ok('"Guru kon hai?" retrieves Guru verses (bridge rescues the Roman question)',
  guruRoman.length > 0 && guruRoman.every(m => m.g.includes('ਗੁਰੂ')), `got ${guruRoman.length}`);
const guruWho = await askRetrieval('Who is Guru?');
ok('"Who is Guru?" retrieves Guru verses',
  guruWho.length > 0 && guruWho.every(m => m.g.includes('ਗੁਰੂ')), `got ${guruWho.length}`);
const hukam = await askRetrieval('Hukam ki hai');
ok('"Hukam ki hai" still retrieves Hukam verses', hukam.length > 0, `got ${hukam.length}`);
const guruPa = await askRetrieval('ਗੁਰੂ ਕੀ ਹੈ');
ok('"ਗੁਰੂ ਕੀ ਹੈ" retrieves Guru verses', guruPa.length > 0 && guruPa.every(m => m.g.includes('ਗੁਰੂ')), `got ${guruPa.length}`);

// ---- 5. Carry-over: Kirtan fix + first-letter search still work ----
ok('Kirtan line meaning reads the on-screen lines (v2.2.10 fix intact)',
  app.includes("const line=(activeRemote?.lines?.[idx]) ??"));
ok('first-letter search still finds Ang 613 (ਮਹਅਤਅ)',
  S.matchRows(JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8')), 'ਮਹਅਤਅ', 5, 'auto').some(r => r.ang === 613));

// ---- 6. Version ----
ok('version is 2.2.11 in package.json and version.json',
  JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8')).version === '2.2.11'
  && JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8')).version === '2.2.11');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
