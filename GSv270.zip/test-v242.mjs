/* Gurbani Saanj v2.2.22 — mic "not hearing" feedback (node, offline).
 * The user asked: when I speak the first line on the mic, I should KNOW
 * whether the mic picked it up. Until now, a run that heard nothing just sat
 * on "Listening..." for the full 15s safety window with no feedback. Now, if
 * no words arrive within 4s of listening, the status clearly says the
 * microphone is not hearing (speak louder or tap again). When words do
 * arrive, the status goes back to Listening and the words fill in live.
 * Run: node test-v242.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));

// ---- 0. Version ----
ok('version.json is 2.2.22', vj.version === '2.2.22');
ok('package.json is 2.2.22', pj.version === '2.2.22');

// ---- Code shape ----
ok('no-heard timer present', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('if(voiceRun===run&&!run.heard.gotPartial){'));
ok('no-heard message present', app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('first partial resets status to Listening', app.includes("if(!run.heard.gotPartial)setVoiceStatus('ਸੁਣ ਰਿਹਾ ਹਾਂ… ਪੰਗਤੀ ਬੋਲੋ'"));
ok('no-heard timer cleared on run end', app.includes('clearTimeout(noHeardTimer);'));
ok('X (clear) restarts the mic', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('resetVoiceNow returns the stop promise', app.includes('let stopP=null;') && app.includes('return stopP;'));
ok('v2.2.20 resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.21 first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));

// ---- VM: run the real startVoiceSearch against a fake native plugin ----
const startMark = app.indexOf('let searchVoiceBusy=false;');
const endMark = app.indexOf('// Settings "Test microphone"');
const voiceSrc = app.slice(startMark, endMark);

function fakeEl(id) {
  return {
    id, disabled: false, value: '', textContent: '',
    classList: { _s: new Set(), toggle(c, on) { on ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } },
    dispatchEvent() {},
  };
}
const els = {};
const input = fakeEl('searchInput');
const calls = [];
let listeners = {};
const fakeNative = {
  available: async () => { calls.push('available'); return { available: true }; },
  checkPermissions: async () => { calls.push('checkPermissions'); return { speechRecognition: 'granted' }; },
  requestPermissions: async () => { calls.push('requestPermissions'); return { speechRecognition: 'granted' }; },
  addListener: async (ev, fn) => { calls.push('addListener:' + ev); (listeners[ev] = listeners[ev] || []).push(fn); return { remove: async () => { calls.push('remove:' + ev); } }; },
  start: async (o) => { calls.push('start:' + o.language); },
  stop: async () => { calls.push('stop'); },
};
const emit = (ev, data) => { for (const h of (listeners[ev] || []).slice()) { try { h(data); } catch (e) { console.error('listener threw', e); } } };
const ctx = vm.createContext({
  console,
  setTimeout, clearTimeout,
  Event: class { constructor(t, o) { this.type = t; } },
  window: { GS_SPEECH: fakeNative, GS_NATIVE_UPDATES: { isNative: true } },
  $: (id) => { if (id === 'searchInput') return input; return (els[id] = els[id] || fakeEl(id)); },
  age: (pa) => pa,
});
vm.runInContext(voiceSrc + '\n;globalThis.__voice={start:startVoiceSearch,reset:resetVoiceNow};', ctx);
const start = ctx.__voice.start;
const reset = ctx.__voice.reset;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const status = () => (els['voiceStatus'] ? els['voiceStatus'].textContent : '');

// --- Scenario A: nothing heard — "not hearing" status appears after 4s ---
input.value = '';
const pA = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
ok('A1 status is Listening right after start', status().includes('ਸੁਣ ਰਿਹਾ ਹਾਂ'), `got ${JSON.stringify(status())}`);
await sleep(4500); // past the 4s no-heard timer, no partial results sent
ok('A2 "not hearing" status appears after 4s of silence', status().includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ'), `got ${JSON.stringify(status())}`);
emit('listeningState', { status: 'stopped' });
await pA;
ok('A3 run ends with nothing-heard message, input stays empty', input.value === '' && status().includes('ਕੁਝ ਸੁਣਿਆ ਨਹੀਂ'), `input=${JSON.stringify(input.value)} status=${JSON.stringify(status())}`);

// --- Scenario B: words arrive quickly — no "not hearing", input fills live ---
input.value = '';
const pB = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਲੱਖ ਖੁਸ਼ੀਆ ਪਾਤਿਸਾਹੀਆ'] });
await sleep(10);
ok('B1 words fill the input live', input.value === 'ਲੱਖ ਖੁਸ਼ੀਆ ਪਾਤਿਸਾਹੀਆ', `got ${JSON.stringify(input.value)}`);
ok('B2 status is Listening after words arrive', status().includes('ਸੁਣ ਰਿਹਾ ਹਾਂ'), `got ${JSON.stringify(status())}`);
await sleep(4500); // past 4s — the timer must NOT fire the "not hearing" message
ok('B3 no "not hearing" message when words were heard', !status().includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ'), `got ${JSON.stringify(status())}`);
emit('listeningState', { status: 'stopped' });
await pB;
ok('B4 run completes with the words', input.value === 'ਲੱਖ ਖੁਸ਼ੀਆ ਪਾਤਿਸਾਹੀਆ', `got ${JSON.stringify(input.value)}`);

// --- Scenario C: words arrive AFTER the "not hearing" message — status recovers ---
input.value = '';
const pC = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
await sleep(4500);
ok('C1 "not hearing" shows first', status().includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ'), `got ${JSON.stringify(status())}`);
emit('partialResults', { matches: ['ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ'] });
await sleep(10);
ok('C2 status goes back to Listening when words arrive', status().includes('ਸੁਣ ਰਿਹਾ ਹਾਂ'), `got ${JSON.stringify(status())}`);
ok('C3 late words still fill the input', input.value === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', `got ${JSON.stringify(input.value)}`);
emit('listeningState', { status: 'stopped' });
await pC;
ok('C4 run completes with the late words', input.value === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', `got ${JSON.stringify(input.value)}`);

// --- Scenario D: X (clear) restarts the mic — run 1, X, run 2 hears words ---
input.value = '';
const pD1 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await pD1;
ok('D1 run 1 heard its words', input.value === 'ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ', `got ${JSON.stringify(input.value)}`);
// Simulate the X button: reset, clear input, then start the mic again.
const stopP = reset();
ok('D2 reset after a clean run returns no stop (nothing to stop)', stopP === null, `got ${String(stopP)}`);
input.value = '';
const stopsBeforeD = calls.filter(c => c === 'stop').length;
const pD2 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਲੱਖ ਖੁਸ਼ੀਆ ਪਾਤਿਸਾਹੀਆ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await pD2;
ok('D3 run 2 (after X) heard its words', input.value === 'ਲੱਖ ਖੁਸ਼ੀਆ ਪਾਤਿਸਾਹੀਆ', `got ${JSON.stringify(input.value)}`);
ok('D4 X-then-mic added no stop() calls', calls.filter(c => c === 'stop').length === stopsBeforeD, `stops=${calls.filter(c => c === 'stop').length}`);

// ---- Regression (grep) ----
ok('v2.2.19: book centered + para flow intact', css.includes('.gs-book-page .gs-book-flow') && fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8').includes('groupBaniParagraphs'));
ok('v2.2.18: AI verse bold+highlight intact', app.includes('ai-verse') && css.includes('.ai-verse{'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'"));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
