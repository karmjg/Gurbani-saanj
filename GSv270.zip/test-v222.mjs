/* Gurbani Saanjh v2.2.2 verification suite (node, offline).
 * Run: node test-v222.mjs
 * Verifies the user's explicit removal orders: no Vishraam toggle UI, no kosh
 * orange highlight (tap still works), no Sundar Gutka card/mentions, Nitnem
 * dedup, catalog = only full-text Banis, visible word-meaning language toggle.
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`PASS  ${name}`); }
  else { fail++; console.log(`FAIL  ${name} ${extra}`); }
};
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');
const app = read('www/app.js');
const catalogSrc = read('www/catalog.js');

/* ---------- 1. No user-facing Sundar Gutka mentions ---------- */
{
  const ui = app + '\n' + catalogSrc;
  ok('1a no "Sundar Gutka" in UI code', !/Sundar Gutka/.test(ui));
  ok('1b no "ਸੁੰਦਰ ਗੁਟਕਾ" in UI code', !/ਸੁੰਦਰ ਗੁਟਕਾ/.test(ui));
  ok('1c no gutka home card/route', !/gutkaScreen/.test(app) && !/data-gutka=/.test(app) && !/t\('gutka'\)/.test(app));
  ok('1d attribution kept in README/SOURCE_AND_LICENSE only',
    /Sundar Gutka/.test(read('README.md')) || /Sundar Gutka/.test(read('SOURCE_AND_LICENSE.md')));
}

/* ---------- 2. Vishraam toggle UI removed; default OFF ---------- */
{
  ok('2a no toggle card/action/strings in UI', !/vishraam-switch-card/.test(app) && !/toggle-vishraam/.test(app) && !/vishraamSwitch/.test(app));
  ok('2b default OFF', /vishraams:false/.test(app) && /state\.vishraams=false;/.test(app));
  ok('2c data file still bundled', fs.existsSync(path.join(ROOT, 'www/offline/vishraam.json')));
  // render path still gates on vishraamOn (data layer intact), default false
  const sb = { window: {} };
  vm.createContext(sb);
  vm.runInContext(read('www/render-verses.js'), sb, { filename: 'render-verses.js' });
  const V = sb.window.GS_VERSES;
  const html = V.verseHTML({ g: 'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ॥' }, { idx: 0, kind: 'bani', vishraamOn: false, marks: { 0: 's' }, koshHas: () => false, show: {} });
  ok('2d vishraam OFF renders plain black (no color classes)', !/vishraam-(short|long)/.test(html));
}

/* ---------- 3. No kosh orange highlight; tap still works ---------- */
{
  const sb = { window: {} };
  vm.createContext(sb);
  vm.runInContext(read('www/render-verses.js'), sb, { filename: 'render-verses.js' });
  const V = sb.window.GS_VERSES;
  const html = V.verseHTML({ g: 'ਸਤਿ ਨਾਮੁ ਕਰਤਾ' }, { idx: 0, kind: 'bani', vishraamOn: false, marks: null, koshHas: () => true, show: {} });
  ok('3a kosh-word class never applied', !/kosh-word/.test(html));
  ok('3b every word still a tap button', (html.match(/data-word=/g) || []).length === 3);
  ok('3c tap handler wired in app', app.includes("closest('[data-word]')"));
}

/* ---------- 4. Nitnem dedup: Nitnem Banis only in Nitnem section ---------- */
{
  const NITNEM_IDS = [2, 4, 6, 9, 10, 21, 23];
  const sb = { window: {} };
  vm.createContext(sb);
  vm.runInContext(catalogSrc, sb, { filename: 'catalog.js' });
  const cat = sb.window.GS_CATALOG;
  ok('4a catalog has 22 entries', cat.length === 22, `got ${cat.length}`);
  ok('4b no Nitnem ids in catalog', !cat.some(e => NITNEM_IDS.includes(Number(e.id))));
  ok('4c all catalog ids numeric (direct open)', cat.every(e => Number.isInteger(Number(e.id)) && Number(e.id) > 0));
}

/* ---------- 5. Every catalog Bani has full bundled text ---------- */
{
  const sb = { window: {} };
  vm.createContext(sb);
  vm.runInContext(catalogSrc, sb, { filename: 'catalog.js' });
  const cat = sb.window.GS_CATALOG;
  const missing = cat.filter(e => {
    const p = path.join(ROOT, 'www/offline/bani', `${e.id}.json`);
    if (!fs.existsSync(p)) return true;
    try { return !(JSON.parse(fs.readFileSync(p, 'utf8')).lines || []).length; }
    catch { return true; }
  });
  ok('5a every catalog Bani has a non-empty text file', missing.length === 0, JSON.stringify(missing.map(e => e.id)));
}

/* ---------- 6. Light theme pure white by default ---------- */
{
  const css = read('www/styles.css');
  const lightRule = css.match(/html\[data-tone="light"\]\{([^}]*)\}/);
  ok('6a light theme rule pure white', !!lightRule && /--bg:#ffffff/.test(lightRule[1]) && /--paper:#ffffff/.test(lightRule[1]));
  ok('6b BASE theme default is light', /theme:'light'/.test(app));
  ok('6c invalid stored theme falls back to light', /\['light','sepia','dark','charcoal'\]\.includes\(state\.theme\)\?state\.theme:'light'/.test(app));
}

/* ---------- 7. Word meaning language toggle ---------- */
{
  ok('7a visible toggle in Reading settings', /choice\('meaningLang',\[\['pa','ਪੰਜਾਬੀ'\],\['en','English'\]\]\)/.test(app));
  ok('7b default Punjabi', /meaningLang:'pa'/.test(app));
  ok('7c popup uses meaningLang with fallback', /wantLang=state\.meaningLang/.test(app) && /otherLang=wantLang==='en'\?'pa':'en'/.test(app));
}

/* ---------- 8. Version 2.2.2 everywhere ---------- */
{
  ok('8a version.json', JSON.parse(read('www/version.json')).version === '2.2.2');
  ok('8b package.json', JSON.parse(read('package.json')).version === '2.2.2');
  ok('8c native-build-config', /version:'2\.2\.2'/.test(read('www/native-build-config.js')));
  ok('8d index.html meta', /app-version" content="2\.2\.2"/.test(read('www/index.html')));
  ok('8e CHANGELOG', /^## v2\.2\.2/m.test(read('CHANGELOG.md')));
}

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail ? 1 : 0);
