/* Gurbani Saanj v2.2.44 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a fresh profile
 * (945x2051), and captures 4 photos:
 *   v2.2.44-photo-search-885.png — "ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ" → Ang 885 first
 *   v2.2.44-photo-search-451.png — "ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ" → Ang 451 first
 *   v2.2.44-photo-save-heart.png — search results with ♡ visible; first
 *     row tapped so it shows ♥, proving the toggle works on screen
 *   v2.2.44-photo-history-delete.png — history box open: Clear all button
 *     + an × on each item
 * Also asserts in the live app: save persists + lists in the Saved tab,
 * unsave removes it, Clear-all empties history, single × removes one item.
 * Run: node photo-v264.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME });
const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
await page.goto(base, { waitUntil: 'load' });
await page.waitForTimeout(2500); // bootData + kosh load + first render

// Go to the search screen.
const goSearch = async () => {
  await page.evaluate(() => {
    const b = [...document.querySelectorAll('[data-view]')].find(x => x.dataset.view === 'search');
    if (b) b.click();
  });
  await page.waitForTimeout(800);
};
const typeSearch = async (q) => {
  // The input is readonly in Punjabi-keyboard mode (default), so set it
  // directly and dispatch the input event — the same event the voice fill
  // dispatches, which is what the app listens to.
  await page.click('#searchInput');
  await page.evaluate((qq) => {
    const inp = document.querySelector('#searchInput');
    inp.value = qq;
    inp.dispatchEvent(new Event('input', { bubbles: true }));
  }, q);
  await page.waitForTimeout(1200); // input event -> showOfflineResults (async load)
};
const firstResultAng = () => page.evaluate(() => {
  const r = document.querySelector('#searchResults [data-found-ang]');
  return r ? Number(r.dataset.foundAng) : null;
});

await goSearch();
await typeSearch('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');
const ang885 = await firstResultAng();
ok('photo: "ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ" → Ang 885 first in the live app', ang885 === 885, `got ${ang885}`);
await page.screenshot({ path: path.join(OUT, 'v2.2.44-photo-search-885.png') });

await typeSearch('ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ');
const ang451 = await firstResultAng();
ok('photo: "ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ" → Ang 451 first in the live app', ang451 === 451, `got ${ang451}`);
await page.screenshot({ path: path.join(OUT, 'v2.2.44-photo-search-451.png') });

// Save (♡): count the hearts, tap the first one (Ang 885 row). The save
// handler calls render(), which rebuilds the search screen empty (known
// pre-existing behaviour), so re-run the search to see the ♥ on screen.
await typeSearch('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');
const hearts = await page.evaluate(() => [...document.querySelectorAll('#searchResults [data-save-hit]')].map(b => b.textContent.trim()));
ok('photo: ♡ button on EVERY search result row', hearts.length >= 5 && hearts.every(h => h === '♡'), JSON.stringify(hearts.slice(0, 6)));
await page.evaluate(() => document.querySelector('#searchResults [data-save-hit]').click());
await page.waitForTimeout(600);
const savedInfo = await page.evaluate(() => {
  const raw = localStorage.getItem('gurbani-saanjh-trial-v1') || '';
  let n = -1; try { n = (JSON.parse(raw).savedVerses || []).length; } catch {}
  return { savedCount: n, rawHas885: raw.includes('"ang":885') };
});
ok('photo: save persists to localStorage (1 saved verse, Ang 885)', savedInfo.savedCount === 1 && savedInfo.rawHas885, JSON.stringify(savedInfo));
await typeSearch('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');
const afterTap = await page.evaluate(() => [...document.querySelectorAll('#searchResults [data-save-hit]')].map(b => b.textContent.trim()));
ok('photo: tapping ♡ turns the first row to ♥ (saved)', afterTap[0] === '♥' && afterTap.slice(1).every(h => h === '♡'), JSON.stringify(afterTap.slice(0, 4)));
await page.screenshot({ path: path.join(OUT, 'v2.2.44-photo-save-heart.png') });
// Saved tab lists it.
await page.evaluate(() => {
  const b = [...document.querySelectorAll('[data-view]')].find(x => x.dataset.view === 'bookmarks');
  if (b) b.click();
});
await page.waitForTimeout(800);
const savedTab = await page.evaluate(() => document.querySelector('.bookmarks-page')?.textContent || '');
ok('photo: Saved tab lists the saved shabad (Ang 885)', savedTab.includes('ਕੋਈ ਬੋਲੈ ਰਾਮ ਰਾਮ') && savedTab.includes('885'), savedTab.slice(0, 120));
// Unsave via the ♥ toggle on the search result (the Saved tab rows only
// open the verse; the remove button lives on the ♥ toggle and on the Kirtan
// screen's Saved list — pre-existing design, unchanged by v2.2.44).
await goSearch();
await typeSearch('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');
const heartBefore = await page.evaluate(() => document.querySelector('#searchResults [data-save-hit]')?.textContent.trim());
ok('photo: saved row shows ♥ before unsave', heartBefore === '♥', JSON.stringify(heartBefore));
await page.evaluate(() => document.querySelector('#searchResults [data-save-hit]').click());
await page.waitForTimeout(600);
await page.evaluate(() => {
  const b = [...document.querySelectorAll('[data-view]')].find(x => x.dataset.view === 'bookmarks');
  if (b) b.click();
});
await page.waitForTimeout(800);
const savedTabAfter = await page.evaluate(() => document.querySelector('.bookmarks-page')?.textContent || '');
ok('photo: tap ♥ on the search result removes it (Saved tab empty again)', !savedTabAfter.includes('ਕੋਈ ਬੋਲੈ ਰਾਮ ਰਾਮ'), savedTabAfter.slice(0, 120));

// History delete: run 3 searches, open the history box, photo it.
await goSearch();
await typeSearch('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');
await page.keyboard.press('Enter');
await page.waitForTimeout(400);
await typeSearch('ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ');
await page.keyboard.press('Enter');
await page.waitForTimeout(400);
await typeSearch('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');
await page.keyboard.press('Enter');
await page.waitForTimeout(400);
await page.evaluate(() => document.querySelector('#iconHistory')?.click());
await page.waitForTimeout(600);
const hist = await page.evaluate(() => ({
  clear: !!document.querySelector('#searchHistoryBox [data-clear-history]'),
  clearLabel: document.querySelector('#searchHistoryBox [data-clear-history]')?.textContent?.trim() || '',
  rows: [...document.querySelectorAll('#searchHistoryBox .history-row')].length,
  dels: [...document.querySelectorAll('#searchHistoryBox [data-remove-history]')].length,
  boxVisible: !document.querySelector('#searchHistoryBox')?.classList.contains('hidden'),
}));
ok('photo: history box open with Clear all button', hist.boxVisible && hist.clear, JSON.stringify(hist));
ok('photo: × on each history item (3 rows, 3 ×)', hist.rows === 3 && hist.dels === 3, JSON.stringify(hist));
// The history box sits below the results — scroll it into view so the
// photo actually shows it.
await page.evaluate(() => document.querySelector('#searchHistoryBox')?.scrollIntoView({ block: 'start' }));
await page.waitForTimeout(400);
await page.screenshot({ path: path.join(OUT, 'v2.2.44-photo-history-delete.png') });
// × removes only that one item.
await page.evaluate(() => document.querySelector('#searchHistoryBox [data-remove-history]')?.click());
await page.waitForTimeout(500);
const histAfterDel = await page.evaluate(() => ({
  rows: [...document.querySelectorAll('#searchHistoryBox .history-row')].length,
  texts: [...document.querySelectorAll('#searchHistoryBox [data-history-q]')].map(b => b.textContent.trim()),
}));
ok('photo: × removes ONLY that item (2 rows left)', histAfterDel.rows === 2, JSON.stringify(histAfterDel));
// Clear all empties it.
await page.evaluate(() => document.querySelector('#searchHistoryBox [data-clear-history]')?.click());
await page.waitForTimeout(500);
const histAfterClear = await page.evaluate(() => ({
  rows: [...document.querySelectorAll('#searchHistoryBox .history-row')].length,
  clear: !!document.querySelector('#searchHistoryBox [data-clear-history]'),
  text: document.querySelector('#searchHistoryList')?.textContent?.trim() || '',
}));
ok('photo: Clear all empties history (no rows, no Clear-all button, no-history message)',
  histAfterClear.rows === 0 && !histAfterClear.clear, JSON.stringify(histAfterClear));

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
