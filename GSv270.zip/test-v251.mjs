/* Gurbani Saanj v2.2.31 — three changes.
 * 1. Cloud AI by default: the shared Cloudflare Worker (gurbani-ai) is the
 *    default AI server, so Play Store users need no API key. The user's own
 *    API key (direct path) keeps priority; a user-set private server wins
 *    over the cloud default. "AI is online" shows by default; the
 *    "add an API key" text no longer shows when the cloud applies.
 * 2. AI elaborates MORE: after each quoted verse the AI explains what the
 *    verse teaches, why it matters, how it answers the question, and how
 *    it applies to a person's life; the total essence is a fuller
 *    synthesis. Token limits raised (detail 900, deep 1500; short 250).
 * 3. Dasam Granth in AI: the AI may now answer from Dasam Granth Banis
 *    too, cited as [Dasam Granth — Bani name]; SGGS still [Ang N]. The
 *    worker accepts Bani verses (no longer drops them); the direct path
 *    already passed Bani matches through.
 * Run: node test-v251.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.31', vj.version === '2.2.31');
ok('package.json is 2.2.31', pj.version === '2.2.31');
ok('version notes mention all three v2.2.31 changes',
  vj.notes.includes('v2.2.31:') && vj.notes.includes('cloud server by default')
  && vj.notes.includes('elaborate more') && vj.notes.includes('Dasam Granth Banis too'),
  vj.notes.slice(-200));

// ---- 1. Change 1: cloud defaults present ----
ok('AI_CLOUD_ENDPOINT constant is the worker URL',
  app.includes("const AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev';"));
const tokMatch = app.match(/const AI_CLOUD_TOKEN='([^']+)';/);
ok('AI_CLOUD_TOKEN constant is defined (32+ chars, not empty)',
  !!tokMatch && tokMatch[1].length >= 32, tokMatch ? `len=${tokMatch[1].length}` : 'missing');

// ---- 1. Change 1: server-path fallback logic (real assignments, run in vm) ----
const epLine = app.split('\n').find(l => l.includes('const legacyEndpoint='));
const tkLine = app.split('\n').find(l => l.includes('const legacyToken='));
ok('legacyEndpoint + legacyToken assignments exist', !!epLine && !!tkLine);
function evalFallback(stateObj) {
  const ctx = vm.createContext({
    state: stateObj,
    AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev',
    AI_CLOUD_TOKEN: 'CLOUDTOKEN',
  });
  vm.runInContext(epLine + '\n' + tkLine + '\nthis.__ep=legacyEndpoint; this.__tk=legacyToken;', ctx);
  return { ep: ctx.__ep, tk: ctx.__tk };
}
let r = evalFallback({ aiEndpoint: '', aiAccessToken: '' });
ok('(b) no endpoint/token set -> cloud endpoint + cloud token',
  r.ep === 'https://gurbani-ai.karmjguber.workers.dev' && r.tk === 'CLOUDTOKEN', JSON.stringify(r));
r = evalFallback({ aiEndpoint: 'https://my-server.example/ask', aiAccessToken: 'mytoken' });
ok('(b) user endpoint/token set -> theirs is used, cloud NOT used',
  r.ep === 'https://my-server.example/ask' && r.tk === 'mytoken', JSON.stringify(r));
r = evalFallback({ aiEndpoint: '', aiAccessToken: 'onlytoken' });
ok('(b) only a token set -> cloud endpoint, own token kept',
  r.ep === 'https://gurbani-ai.karmjguber.workers.dev' && r.tk === 'onlytoken', JSON.stringify(r));
ok('direct path (own key) is checked BEFORE the server/cloud path',
  (() => { const a = app.indexOf('if(apiKey&&entry.matches.length)'); const b = app.indexOf('else if(legacyEndpoint'); return a > 0 && b > a; })());
ok('server path fetch uses legacyEndpoint + legacyToken',
  app.includes('fetch(legacyEndpoint,') && app.includes("'Authorization':'Bearer '+legacyToken"));
ok('server path still requires matches (no cloud call with zero matches)',
  (() => { const l = app.split('\n').find(x => x.includes('else if(legacyEndpoint')); return !!l && l.includes('entry.matches.length'); })());
ok('server answer source says cloud AI when the cloud is used',
  app.includes("age('ਕਲਾਉਡ AI','cloud AI')"));

// ---- 1. Change 1: "AI is online" + needs-key with cloud fallback ----
ok('status line includes cloud fallback in its online check',
  app.includes("||AI_CLOUD_ENDPOINT)?age('AI ਔਨਲਾਈਨ ਹੈ"));
ok('renderQA needs-key check includes cloud fallback',
  app.includes('&&!AI_CLOUD_ENDPOINT?'));
function evalStatusCond(stateObj) {
  const i = app.indexOf('id="aiStatusLine"');
  const seg = app.slice(i, i + 500);
  const m = seg.match(/\$\{\((.*?)\)\?age\('/s);
  if (!m) return { found: false };
  const ctx = vm.createContext({
    state: stateObj,
    AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev',
    age: (a) => a,
  });
  vm.runInContext('this.__c=(' + m[1] + ');', ctx);
  return { found: true, cond: !!ctx.__c };
}
let sc = evalStatusCond({ aiApiKey: '', aiEndpoint: '' });
ok('(c) status condition is ONLINE with no key and no endpoint (cloud fallback)',
  sc.found && sc.cond === true, JSON.stringify(sc));
sc = evalStatusCond({ aiApiKey: 'k', aiEndpoint: '' });
ok('(c) status condition is ONLINE with a key set', sc.found && sc.cond === true);
function evalNeedsKey(stateObj, vObj) {
  const line = app.split('\n').find(l => l.includes("t('aiNeedsKey')"));
  const m = line.match(/\$\{([^`]*?)\?`/);
  if (!m) return { found: false };
  const ctx = vm.createContext({ state: stateObj, v: vObj, AI_CLOUD_ENDPOINT: 'https://gurbani-ai.karmjguber.workers.dev' });
  vm.runInContext('this.__c=(' + m[1] + ');', ctx);
  return { found: true, cond: !!ctx.__c };
}
let nk = evalNeedsKey({ aiApiKey: '', aiEndpoint: '' }, { answer: '', aiPending: false });
ok('(c) needs-key message does NOT show with no key and no endpoint (cloud applies)',
  nk.found && nk.cond === false, JSON.stringify(nk));

// ---- 2+3. Prompts: app AI_SYSTEM_PROMPT ----
const promptLine = app.split('\n').find(l => l.startsWith('const AI_SYSTEM_PROMPT='));
ok('app prompt line found', !!promptLine);
const appPhrases = [
  'what the verse teaches', 'why it matters', 'how it answers the user',
  'applies to a person', 'full synthesis',
  'Dasam Granth — Bani name', 'never cite a Guru Granth Sahib verse as Dasam Granth',
  'Sri Guru Granth Sahib Ji, Ang N', 'never from any other scripture, author, book',
  'Never fabricate a verse, an Ang number, or a Bani name',
];
for (const p of appPhrases) ok(`app prompt contains: "${p}"`, promptLine.includes(p));
ok('app prompt no longer restricts to Gurbani passages only (old wording gone)',
  !promptLine.includes('Answer ONLY from the provided Gurbani passages'));
ok('app prompt says passages may come from SGGS or Dasam Granth',
  promptLine.includes('which may come from Sri Guru Granth Sahib Ji or from Dasam Granth Banis'));

// ---- 2+3. Prompts: worker instructions ----
const instrLine = worker.split('\n').find(l => l.trim().startsWith('const instructions='));
ok('worker instructions line found', !!instrLine);
const wkPhrases = [
  'what the verse teaches', 'why it matters', "how it answers the user's question",
  "how it applies to a person's life", 'full synthesis',
  'Dasam Granth — Bani name', 'never cite a Guru Granth Sahib verse as Dasam Granth',
  'Sri Guru Granth Sahib Ji, Ang N', 'never from any other scripture, author, book',
  'never fabricate a verse, an Ang number, or a Bani name',
];
for (const p of wkPhrases) ok(`worker prompt contains: "${p}"`, instrLine.includes(p));
ok('worker prompt no longer says "using ONLY N numbers in input" (old GGS-only citation)',
  !instrLine.includes('using ONLY N numbers in input'));
ok('worker prompt cites Dasam Granth with Bani titles from the input',
  instrLine.includes('using ONLY the Bani titles in the input'));

// ---- 3. Worker accepts Bani verses (real mapping, run in vm) ----
const versesLine = worker.split('\n').find(l => l.trim().startsWith('const verses='));
ok('worker verses line found', !!versesLine);
function evalVerses(bodyObj) {
  const ctx = vm.createContext({ body: bodyObj });
  vm.runInContext(versesLine + '\nthis.__v=verses;', ctx);
  return ctx.__v;
}
let vs = evalVerses({ verses: [
  { ang: 8, idx: 1, g: 'sggs line' },
  { src: 'bani', baniId: 4, baniTitle: 'Jaap Sahib', group: 'dasam', idx: 10, g: 'bani line' },
  { src: 'bani', baniId: 112, baniTitle: 'Sukhmani Sahib', group: 'sggs', idx: 5, g: 'nitnem line' },
] });
ok('(e) worker keeps SGGS + both Bani verses (3 total)',
  Array.isArray(vs) && vs.length === 3, JSON.stringify(vs));
ok('(e) Bani verse keeps baniId/baniTitle/group',
  vs[1] && vs[1].src === 'bani' && vs[1].baniId === 4 && vs[1].baniTitle === 'Jaap Sahib' && vs[1].group === 'dasam');
ok('(e) SGGS verse keeps ang', vs[0] && vs[0].src === 'sggs' && vs[0].ang === 8);
ok('(e) Bani titlePa fallback works',
  (() => { const v2 = evalVerses({ verses: [{ src: 'bani', baniId: 9, titlePa: 'Chaupai Sahib', idx: 2, g: 'x' }] }); return v2.length === 1 && v2[0].baniTitle === 'Chaupai Sahib'; })());
ok('(e) empty-g verses dropped (SGGS + Bani)',
  evalVerses({ verses: [{ ang: 8, g: '' }, { src: 'bani', baniId: 4, baniTitle: 'Jaap', g: '' }, { ang: 8, g: 'ok' }] }).length === 1);
ok('(e) out-of-range Ang + no-source verses dropped',
  evalVerses({ verses: [{ ang: 2000, g: 'x' }, { ang: 0, g: 'x' }, { idx: 1, g: 'x' }, { ang: 1430, g: 'ok' }] }).length === 1);
ok('(e) worker still requires at least one verse (400 check present)',
  worker.includes("if(!question||!verses.length)return reply(400,{error:'Question and verified source verses are required'});"));

// ---- 3. Direct path: Bani matches reach the AI context ----
ok('entry.matches maps Bani hits (baniId/baniTitle/group)',
  app.includes("m.src==='bani'?{src:'bani',baniId:m.baniId,baniTitle:m.baniTitle"));
const ctxLine = app.split('\n').find(l => l.includes('const context=matches.map('));
ok('direct-path context line found', !!ctxLine);
function evalContext(matches) {
  const ctx = vm.createContext({ matches });
  vm.runInContext(ctxLine + '\nthis.__c=context;', ctx);
  return ctx.__c;
}
const c = evalContext([
  { src: 'sggs', ang: 8, idx: 1, g: 'sggs line' },
  { src: 'bani', baniId: 4, baniTitle: 'Jaap Sahib', group: 'dasam', idx: 10, g: 'bani line' },
]);
ok('direct-path context labels SGGS [Ang 8] + [Dasam Granth — Jaap Sahib]',
  c.includes('[Ang 8] sggs line') && c.includes('[Dasam Granth — Jaap Sahib] bani line'), c);

// ---- 2. Worker token limits ----
ok('(f) worker token limits: short 250 / detail 900 / deep 1500',
  worker.includes("depth==='short'?250:depth==='detail'?900:1500"));
ok('(f) old token limits 650/1100 are gone',
  !worker.includes("depth==='detail'?650:1100"));

// ---- (g) Regressions v2.2.30 -> v2.2.15 ----
ok('regression v2.2.30: no showHi in app.js', !app.includes('showHi'));
ok('regression v2.2.30: no verse-hi in render-verses.js', !rv.includes('verse-hi'));
ok('regression v2.2.30: English under search results (gs-result-en)', app.includes('gs-result-en'));
ok('regression v2.2.30: font slider present (vpFontSlider)', app.includes('vpFontSlider'));
ok('regression v2.2.28: Dasam Granth source label present', app.includes('gs-result-dasam-tag'));
ok('regression v2.2.27: barScrollDecision present', app.includes('barScrollDecision'));
ok('regression v2.2.26: isBaniHeading with Mehla pattern', rv.includes('ਮਹਲਾ'));
ok('regression v2.2.26: pinch Ask-only (pinchInAnswer + viewport)', app.includes('pinchInAnswer') && html.includes('user-scalable=no'));
ok('regression voice: ensureVoiceListeners + noHeardTimer', app.includes('ensureVoiceListeners') && app.includes('noHeardTimer'));
ok('regression search: first-letter fallback (firstSig)', ss.includes('firstSig'));
ok('regression v2.2.15: AI language pills present', app.includes('data-ai-lang'));
ok('regression v2.2.18: aiAnswerHTML + ai-verse', app.includes('aiAnswerHTML') && css.includes('.ai-verse'));
// Behavioral: Hindi still absent in a real render (v2.2.30 proof)
const rvCtx = vm.createContext({ window: {}, console });
vm.runInContext(rv, rvCtx);
const VERSES = rvCtx.window.GS_VERSES;
const hiLine = { g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', roman: 'mil mere preetamaa jeeo tudh bin kharee nimaanee |', en: 'Meet me, O my Beloved; without You, I am totally miserable.', pa: 'ਹੇ ਮੇਰੇ ਪਿਆਰੇ ਪ੍ਰਭੂ! ਮੈਨੂੰ ਮਿਲ।', hi: 'मिल मेरे प्रीतम जीउ तुध बिन खरी निमाणी ॥' };
const vHtml = VERSES.verseHTML(hiLine, { idx: 33, kind: 'ang', show: { translit: true, en: true, pa: true, hi: true, arth: true }, arth: [{ word: 'ਪ੍ਰੀਤਮਾ', meaning: 'beloved' }], koshHas: () => false });
ok('regression v2.2.30: verse with hi renders NO Hindi layer',
  !vHtml.includes('verse-hi') && !vHtml.includes('मिल मेरे') && !vHtml.includes('lang="hi"'));

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
