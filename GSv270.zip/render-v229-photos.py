#!/usr/bin/env python3
"""v2.2.9 photos: (A) page-mode reader WITH the new top bar (SGGS + Bani),
(B) viewprefs with the NEW letter-size row. Real app colors, real verses."""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'; YELLOW = '#fff2a8'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

def save(s, name):
    svg = '\n'.join(s + ['</svg>'])
    cairosvg.svg2png(bytestring=svg.encode('utf-8'), write_to=os.path.join(OUT, name))
    print('wrote', name)

def bottom_nav(active):
    items = [('⌂', 'Home'), ('🔍', 'Search'), ('♡', 'Saved'), ('⚙', 'Settings')]
    out = [rect(0, H - 108, W, 108, PAPER, 0, LINE),
           f'<line x1="0" y1="{H-108}" x2="{W}" y2="{H-108}" stroke="{LINE}" stroke-width="2"/>']
    for i, (ic, lb) in enumerate(items):
        cx = W * (i + 0.5) / 4
        on = lb == active
        out.append(text(cx, H - 56, ic, 34, PRIMARY if on else MUTED, SYM, '400', 'middle'))
        out.append(text(cx, H - 22, lb, 20, PRIMARY if on else MUTED, LATIN, '700' if on else '400', 'middle'))
    return out

# ---------------- Photo A: page-mode top bar ----------------
s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>',
     f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']
s.append(text(32, 64, 'Page mode — top bar is back', 26, PRIMARY, LATIN, '700'))
s.append(text(32, 100, 'SGGS — Ang jump + Aa, above the book page', 24, MUTED, LATIN, '400'))
# SGGS top bar
s.append(rect(0, 124, W, 108, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="232" x2="{W}" y2="232" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 192, 'ਅੰਗ', 30, INK, SANS, '700'))
s.append(rect(118, 150, 150, 56, '#ffffff', 14, LINE, 2))
s.append(text(193, 190, '205', 32, INK, LATIN, '400', 'middle'))
s.append(rect(284, 146, 130, 64, PRIMARY, 18))
s.append(tspans(349, 190, [('ਜਾਓ ', SANS, '650', '#ffffff'), ('›', SYM, '650', '#ffffff')], 28, 'middle'))
s.append(text(W - 32, 192, 'Aa', 32, INK, LATIN, '400', 'end'))
# SGGS book page
s.append(rect(48, 268, W - 96, 420, '#ffffff', 12, LINE, 2))
s.append(text(W / 2, 350, 'ਸਿਰੀਰਾਗੁ ਮਹਲਾ ੧ ॥', 30, MUTED, SERIF, '550', 'middle'))
s.append(text(W / 2, 440, 'ਅੰਤਰਿ ਅਲਖੁ ਨ ਜਾਈ ਲਖਿਆ', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 494, 'ਵਿਚਿ ਪੜਦਾ ਹਉਮੈ ਪਾਈ ॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 548, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 602, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(88, 660, '‹', 44, MUTED, SYM, '400'))
s.append(text(W - 88, 660, '›', 44, MUTED, SYM, '400', 'end'))
s.append(text(W / 2, 660, 'ਅੰਗ 205', 24, MUTED, SANS, '400', 'middle'))
# divider + Bani
s.append(f'<line x1="32" y1="760" x2="{W-32}" y2="760" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 820, 'Bani — drawer + title + Aa', 26, PRIMARY, LATIN, '700'))
s.append(text(32, 856, 'Page mode had no bar at all before — now it does', 24, MUTED, LATIN, '400'))
s.append(rect(0, 884, W, 108, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="992" x2="{W}" y2="992" stroke="{LINE}" stroke-width="2"/>')
s.append(text(32, 952, '☰', 40, INK, SYM, '400'))
s.append(text(96, 952, 'ਜਪੁਜੀ ਸਾਹਿਬ', 36, INK, SERIF, '700'))
s.append(text(W - 32, 952, 'Aa', 32, INK, LATIN, '400', 'end'))
# Bani book page
s.append(rect(48, 1028, W - 96, 420, '#ffffff', 12, LINE, 2))
s.append(text(W / 2, 1110, 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥', 32, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1200, 'ਜਪੁ ਤਪ ਕਾ ਬੰਧੁ ਬੇੜੁਲਾ', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1254, 'ਜਿਤੁ ਲੰਘਹਿ ਵਹੁ ਪਾਰਿ ॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1308, 'ਨਾਨਕੁ ਆਖੈ ਇਕੁ ਨਾਮੁ', 38, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 1362, 'ਜਿਤੁ ਪਾਵਹਿ ਪਾਰਿ ॥੩੭॥', 38, INK, SERIF, '550', 'middle'))
s.append(text(88, 1420, '‹', 44, MUTED, SYM, '400'))
s.append(text(W - 88, 1420, '›', 44, MUTED, SYM, '400', 'end'))
s.append(text(W / 2, 1420, 'ਪਉੜੀ 37', 24, MUTED, SANS, '400', 'middle'))
s.append(text(32, 1500, 'Scroll mode still opens full-screen —', 26, INK, LATIN, '700'))
s.append(text(32, 1540, 'the bar appears when you scroll down.', 26, MUTED, LATIN, '400'))
s += bottom_nav('Home')
save(s, 'v229_preview_pagetopbar.png')

# ---------------- Photo B: viewprefs + letter size ----------------
s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>',
     f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']
s.append(rect(0, 0, W, 116, PAPER, 0, LINE))
s.append(f'<line x1="0" y1="116" x2="{W}" y2="116" stroke="{LINE}" stroke-width="2"/>')
s.append(text(36, 76, '‹', 56, INK, SYM, '400'))
s.append(text(96, 76, 'ਗੁਰਬਾਣੀ ਸਾਂਝ', 42, INK, SERIF, '750'))
s.append(text(W - 36, 76, '⚙', 44, INK, SYM, '400', 'end'))
s.append(text(36, 190, 'ਬਾਣੀ ਵੇਖਣ ਦੀਆਂ ਪਸੰਦਾਂ', 40, INK, SERIF, '700'))
s.append(text(36, 232, 'Bani View Preferences — the ONE place for these', 24, MUTED, LATIN, '400'))
# NEW letter-size row (highlighted)
s.append(rect(24, 262, W - 48, 190, '#eef3ec', 20))
s.append(text(36, 316, 'ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ', 30, PRIMARY, SANS, '700'))
s.append(text(36, 352, 'Letter size — for all scripture text  (NEW)', 24, MUTED, LATIN, '400'))
for i, (lb, sel) in enumerate([('18', False), ('24', True), ('30', False), ('36', False)]):
    x = 36 + i * 118
    s.append(rect(x, 372, 100, 56, PRIMARY if sel else '#ffffff', 28, PRIMARY if sel else LINE, 2))
    s.append(text(x + 50, 410, lb, 26, '#ffffff' if sel else INK, LATIN, '700' if sel else '400', 'middle'))
s.append(text(36, 510, 'ਪਾਠ ਦੀਆਂ ਪਰਤਾਂ', 26, PRIMARY, SANS, '700'))
rows = [('Transliteration', 'ON', True), ('English Translation', 'ON', True),
        ('Punjabi Translation', 'ON', True), ('Hindi Translation', 'OFF', False),
        ('Shabad Arth', 'ON', True)]
y = 540
for label, state, on in rows:
    s.append(f'<line x1="36" y1="{y+58}" x2="{W-36}" y2="{y+58}" stroke="{LINE}" stroke-width="2"/>')
    s.append(text(36, y + 44, label, 28, INK, LATIN, '400'))
    s.append(rect(W - 150, y + 8, 114, 48, PRIMARY if on else '#ffffff', 24, PRIMARY if on else LINE, 2))
    s.append(text(W - 93, y + 42, state, 24, '#ffffff' if on else MUTED, LATIN, '700', 'middle'))
    y += 76
s.append(text(36, y + 30, 'Bani Text Size', 28, INK, LATIN, '400'))
for i, (lb, sel) in enumerate([('Normal', True), ('Large', False), ('Extra-large', False)]):
    x = 36 + [0, 142, 264][i]
    w = [130, 110, 170][i]
    s.append(rect(x, y + 52, w, 48, PRIMARY if sel else '#ffffff', 24, PRIMARY if sel else LINE, 2))
    s.append(text(x + w / 2, y + 86, lb, 22, '#ffffff' if sel else INK, LATIN, '650' if sel else '400', 'middle'))
y += 140
s.append(f'<line x1="36" y1="{y+58}" x2="{W-36}" y2="{y+58}" stroke="{LINE}" stroke-width="2"/>')
s.append(text(36, y + 100, 'Night Mode', 28, INK, LATIN, '400'))
s.append(rect(W - 150, y + 64, 114, 48, '#ffffff', 24, LINE, 2))
s.append(text(W - 93, y + 98, 'OFF', 24, MUTED, LATIN, '700', 'middle'))
s.append(text(36, y + 190, 'Aa opens this page from inside the reader,', 26, INK, LATIN, '700'))
s.append(text(36, y + 232, 'in both scroll and page mode.', 26, MUTED, LATIN, '400'))
s += bottom_nav('Settings')
save(s, 'v229_preview_viewprefs.png')
