/* Gurbani Saanj v2.2.19 — page-turn matches scroll (node, offline).
 *  The Bani paragraph flow in page-turn is run in a VM against real
 *  Jaap Sahib namastun lines: verses of one paragraph flow together
 *  (no line break between them), one para-break between paragraphs,
 *  headings their own block. SGGS/Kirtan stay one-verse-per-line.
 * Run: node test-v239.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const pt = fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.19', vj.version === '2.2.19');
ok('package.json is 2.2.19', pj.version === '2.2.19');

// ---- 1. Book flow centered (was left-aligned, "on one side") ----
ok('book flow is centered', css.includes('.gs-book-page .gs-book-flow{') && /\.gs-book-page \.gs-book-flow\{[^}]*text-align:center/.test(css));
ok('Bani para-break is the minimal scroll gap (.22em)', css.includes('.gs-book-para-break{display:block;height:.22em;}'));

// ---- 2. Re-measure after layout/fonts settle (full page) ----
ok('BookReader has refresh()', pt.includes('refresh(){'));
ok('refresh re-runs makePages + renderPage', pt.includes('this.makePages();this.renderPage();this.remember();'));
ok('re-measure on requestAnimationFrame', pt.includes("requestAnimationFrame(()=>{if(!this.destroyed)this.refresh();});"));
ok('re-measure on document.fonts.ready', pt.includes('document.fonts.ready.then(()=>{if(!this.destroyed)this.refresh();})'));
ok('onResize uses refresh()', pt.includes('this.resizeTimer=setTimeout(()=>{if(!this.destroyed)this.refresh();},220);'));
ok('Bani paragraph path uses GS_VERSES.groupBaniParagraphs', pt.includes("window.GS_VERSES?.groupBaniParagraphs"));

// ---- VM: tokensFor — Bani paragraph flow vs SGGS one-per-line ----
// Load render-verses.js for GS_VERSES (needs a window).
const win = { GS_VERSES: null };
const ctx = vm.createContext({ window: win, console });
vm.runInContext(rv + '\n;globalThis.__GS=window.GS_VERSES;', ctx);
const GS = ctx.__GS;
ok('GS_VERSES.groupBaniParagraphs available in VM', typeof GS.groupBaniParagraphs === 'function');

// Extract tokensFor + stanzaEnds from page-turn.js.
const escSrc = "const escapeHTML = value => String(value??'').replace(/[&<>\"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',\"'\":'&#39;'}[c]));";
const seSrc = pt.slice(pt.indexOf('const stanzaEnds='), pt.indexOf('const reducedMotion='));
const tfStart = pt.indexOf('function tokensFor(lines,settings){');
const tfEnd = pt.indexOf('class BookReader{');
const tfSrc = pt.slice(tfStart, tfEnd);
const ctx2 = vm.createContext({ window: { GS_VERSES: GS }, console });
vm.runInContext(escSrc + '\n' + seSrc + '\n' + tfSrc + '\n;globalThis.__tf=tokensFor;', ctx2);
const tf = ctx2.__tf;

// Jaap Sahib namastun lines (from the user's screenshot).
const baniLines = [
  { g: 'ਨਮਸਤੁੰ ਅਲੇਖੇ ॥' }, { g: 'ਨਮਸਤੁੰ ਅਸੇਖੇ ॥੧੨॥' },
  { g: 'ਨਮਸਤੁੰ ਨ੍ਰਿਤਾਪੇ ॥' }, { g: 'ਨਮਸਤੁੰ ਅਥਾਪੇ ॥' },
  { g: 'ਨਮਸਤੁੰ ਤ੍ਰਿਮਾਨੇ ॥' }, { g: 'ਨਮਸਤੁੰ ਨਿਧਾਨੇ ॥੧੩॥' },
];
const baniTok = tf(baniLines, { kind: 'bani', readingScript: 'gurmukhi', vishraams: false, meanings: false });
const baniHtml = baniTok.map(t => t.html).join('');
const paraBreaks = (baniHtml.match(/gs-book-para-break/g) || []).length;
const lineBreaks = (baniHtml.match(/gs-book-line-break/g) || []).length;
ok('Bani: two paragraphs get two para-breaks', paraBreaks === 2, `got ${paraBreaks}`);
ok('Bani: no per-verse line break inside a paragraph', lineBreaks === 0, `got ${lineBreaks}`);
ok('Bani: verses of one paragraph flow together (no break between alekhe and asekhe)',
  baniHtml.indexOf('ਅਲੇਖੇ') < baniHtml.indexOf('ਅਸੇਖੇ') &&
  baniHtml.indexOf('ਅਸੇਖੇ') < baniHtml.indexOf('gs-book-para-break'));
ok('Bani: second paragraph flows together (nritape..nidhane before 2nd para-break)',
  baniHtml.indexOf('ਨ੍ਰਿਤਾਪੇ') < baniHtml.indexOf('ਨਿਧਾਨੇ') &&
  baniHtml.lastIndexOf('gs-book-para-break') > baniHtml.indexOf('ਨਿਧਾਨੇ'));
ok('Bani: every word is kept, in order',
  ['ਅਲੇਖੇ', 'ਅਸੇਖੇ', 'ਨ੍ਰਿਤਾਪੇ', 'ਅਥਾਪੇ', 'ਤ੍ਰਿਮਾਨੇ', 'ਨਿਧਾਨੇ'].every(w => baniHtml.includes(w)));

// SGGS: one verse per line, stanza break after verse-number lines.
const sggsLines = [
  { g: 'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥' },
  { g: 'ਚੁਪੈ ਚੁਪ ਨ ਹੋਵਈ ਜੇ ਲਾਇ ਰਹਾ ਲਿਵ ਤਾਰ ॥੧॥' },
  { g: 'ਭੁਖਿਆ ਭੁਖ ਨ ਉਤਰੀ ਜੇ ਬੰਨਾ ਪੁਰੀਆ ਭਾਰ ॥' },
];
const sggsTok = tf(sggsLines, { kind: 'ang', readingScript: 'gurmukhi', vishraams: false, meanings: false });
const sggsHtml = sggsTok.map(t => t.html).join('');
ok('SGGS: one line-break per verse', (sggsHtml.match(/gs-book-line-break/g) || []).length === 3);
ok('SGGS: verse-number line gets the stanza break', sggsHtml.includes('gs-book-stanza-break'));
ok('SGGS: no para-break (paragraph flow is Bani-only)', !sggsHtml.includes('gs-book-para-break'));

// Bani fallback (no GS_VERSES): still one-verse-per-line, nothing dropped.
const ctx3 = vm.createContext({ window: {}, console });
vm.runInContext(escSrc + '\n' + seSrc + '\n' + tfSrc + '\n;globalThis.__tf=tokensFor;', ctx3);
const tfNoGS = ctx3.__tf;
const fbTok = tfNoGS(baniLines, { kind: 'bani', readingScript: 'gurmukhi', vishraams: false, meanings: false });
const fbHtml = fbTok.map(t => t.html).join('');
ok('Bani fallback (no GS_VERSES): one line-break per verse, nothing dropped',
  (fbHtml.match(/gs-book-line-break/g) || []).length === 6 &&
  ['ਅਲੇਖੇ', 'ਅਸੇਖੇ', 'ਨ੍ਰਿਤਾਪੇ', 'ਅਥਾਪੇ', 'ਤ੍ਰਿਮਾਨੇ', 'ਨਿਧਾਨੇ'].every(w => fbHtml.includes(w)));

// ---- Regression ----
ok('v2.2.18: Bani scroll spacing still minimal', css.includes('.gs-reader-bani #verses .gs-bani-para{margin-bottom:.22em!important;}'));
ok('v2.2.18: ai-verse bold+highlight intact', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('v2.2.18: AI zoom intact', app.includes("data-ai-zoom=") && app.includes('state.aiFont'));
ok('v2.2.17: voice persistent listeners intact', app.includes('let voiceRun=null;') && app.includes('async function ensureVoiceListeners(){'));
ok('v2.2.16: original emoji mic kept', app.includes('Voice search\')}">🎙</button>'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'"));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){'));
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
