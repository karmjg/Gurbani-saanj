/* Gurbani Saanj v2.2.26 — Bani headings centered; pinch only on Ask; page-turn full screen.
 * Karamjit's screenshot: "ਆਸਾ ਮਹਲਾ ੧" sits at the LEFT edge while verses flow
 * centered. His 3 asks:
 *  1. Bani section headings (Raag+Mehla, Ashtpadi, Salok) CENTERED in Nitnem +
 *     ALL Banis. SGGS (Ang reader) has its own system — untouched.
 *  2. Pinch-to-zoom ONLY on the Ask (AI answer) screen. The pinch he sees
 *     "everywhere" is the NATIVE WebView pinch (viewport had no user-scalable=no);
 *     on Ask the app pinch intercepted touches but v2.2.24's was broken, so
 *     nothing happened there. Fix: viewport user-scalable=no + maximum-scale=1
 *     kills native zoom everywhere; the app pinch (v2.2.25, document-level,
 *     gate .ai-answer/.qa-card) stays and is Ask-only.
 *  3. Page-turn book page fills the FULL screen, not half: the page-mode
 *     section gets a viewport-filling min-height so .gs-book-stage flex:1
 *     has full height to measure.
 * Run: node test-v246.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.26', vj.version === '2.2.26');
ok('package.json is 2.2.26', pj.version === '2.2.26');
ok('version.json notes mention v2.2.26', vj.notes.includes('v2.2.26:'));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const pt = fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8');

// ---- 1. isBaniHeading detects the new headers ----
// Load render-verses.js in a VM (pure renderer, no DOM).
const rvSrc = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const rvCtx = vm.createContext({ window: {}, console });
vm.runInContext(rvSrc, rvCtx);
const GS = rvCtx.window.GS_VERSES;
ok('GS_VERSES loaded (isBaniHeading + groupBaniParagraphs + verseHTML)',
  typeof GS.isBaniHeading === 'function' && typeof GS.groupBaniParagraphs === 'function' && typeof GS.verseHTML === 'function');

ok('heading: "ਆਸਾ ਮਹਲਾ ੧ ॥" detected', GS.isBaniHeading('ਆਸਾ ਮਹਲਾ ੧ ॥') === true);
ok('heading: "ਸਿਰੀਰਾਗੁ ਮਹਲਾ ੧ ॥" detected', GS.isBaniHeading('ਸਿਰੀਰਾਗੁ ਮਹਲਾ ੧ ॥') === true);
ok('heading: "ਆਸਾ ਮਹਲਾ ੫ ॥" detected', GS.isBaniHeading('ਆਸਾ ਮਹਲਾ ੫ ॥') === true);
ok('heading: "ਅਸਟਪਦੀ ॥" detected', GS.isBaniHeading('ਅਸਟਪਦੀ ॥') === true);
ok('heading: "ਸਲੋਕੁ ॥" detected', GS.isBaniHeading('ਸਲੋਕੁ ॥') === true);
// Existing patterns still work
ok('heading (old): fully-wrapped "॥ ਸਲੋਕੁ ॥" detected', GS.isBaniHeading('॥ ਸਲੋਕੁ ॥') === true);
ok('heading (old): "ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥" detected', GS.isBaniHeading('ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥') === true);
ok('heading (old): "ਜਾਪੁ ॥" detected', GS.isBaniHeading('ਜਾਪੁ ॥') === true);
// NOT headings: regular verse lines must stay panktis
ok('not a heading: regular verse "ਸੁਣਿ ਵਡਾ ਆਖੈ ਸਭੁ ਕੋਇ ॥"',
  GS.isBaniHeading('ਸੁਣਿ ਵਡਾ ਆਖੈ ਸਭੁ ਕੋਇ ॥') === false);
ok('not a heading: long line with ਮਹਲਾ mid-verse (9 words, ends in verse number)',
  GS.isBaniHeading('ਸੋ ਪਾਤਿਸਾਹੁ ਸਾਹਾ ਪਾਤਿਸਾਹਿਬੁ ਮਹਲਾ ਨਾਨਕ ਰਹਣੁ ਰਜਾਈ ॥੧॥') === false);
ok('not a heading: long line ending in Mehla number but 8 words',
  GS.isBaniHeading('ਕਰਿ ਕਰਿ ਦੇਖੈ ਕੀਤਾ ਆਪਣਾ ਜਿਉ ਤਿਸ ਦੀ ਮਹਲਾ ੧ ॥') === false);
ok('not a heading: empty string', GS.isBaniHeading('') === false);

// ---- 2. groupBaniParagraphs + heading rendering ----
const lines = [
  { g: 'ਆਸਾ ਮਹਲਾ ੧ ॥' },
  { g: 'ਸੁਣਿ ਵਡਾ ਆਖੈ ਸਭੁ ਕੋਇ ॥' },
  { g: 'ਕੇਵਡੁ ਵਡਾ ਡੀਠਾ ਹੋਇ ॥' },
  { g: 'ਕੀਮਤਿ ਪਾਇ ਨ ਕਹਿਆ ਜਾਇ ॥੧॥' },
  { g: 'ਅਸਟਪਦੀ ॥' },
  { g: 'ਸਲੋਕੁ ॥' },
];
const groups = GS.groupBaniParagraphs(lines);
ok('header is its own {type:heading} group (first)', groups[0] && groups[0].type === 'heading' && groups[0].items[0].line.g === 'ਆਸਾ ਮਹਲਾ ੧ ॥', JSON.stringify(groups.map(g => g.type)));
ok('verses after the header group into a para', groups[1] && groups[1].type === 'para' && groups[1].items.length === 3, JSON.stringify(groups.map(g => g.type + ':' + g.items.length)));
ok('Ashtpadi header is its own heading group', groups.some(g => g.type === 'heading' && g.items[0].line.g === 'ਅਸਟਪਦੀ ॥'));
ok('Salok header is its own heading group', groups.some(g => g.type === 'heading' && g.items[0].line.g === 'ਸਲੋਕੁ ॥'));
const headHTML = GS.verseHTML({ g: 'ਆਸਾ ਮਹਲਾ ੧ ॥' }, { heading: true, idx: 0, kind: 'bani' });
ok('heading renders with gs-verse-heading class', headHTML.includes('gs-verse-heading'), headHTML.slice(0, 120));
ok('heading CSS centers it (.gs-verse-heading .verse-text{text-align:center})',
  css.includes('.gs-verse-heading .verse-text { text-align: center; font-weight: 700; }'));
// SGGS path untouched: isBaniHeading is only used for Bani grouping
ok('page-turn Bani path still uses groupBaniParagraphs (headings stay centered blocks)',
  pt.includes("settings.kind==='bani'&&window.GS_VERSES?.groupBaniParagraphs"));
ok('no SGGS/kirtan heading change (isBaniHeading only called in groupBaniParagraphs)',
  (rvSrc.match(/isBaniHeading\(/g) || []).length === 2, `calls=${(rvSrc.match(/isBaniHeading\(/g) || []).length}`);

// ---- 3. Viewport kills native pinch zoom everywhere ----
ok('viewport has user-scalable=no', html.includes('user-scalable=no'));
ok('viewport has maximum-scale=1', html.includes('maximum-scale=1'));
ok('viewport keeps width/device-width + initial-scale=1 + viewport-fit=cover',
  html.includes('width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,viewport-fit=cover'));
ok('exactly one viewport meta', (html.match(/<meta name="viewport"/g) || []).length === 1);
ok('stale app-version meta untouched (2.2.2, as before)', html.includes('<meta name="app-version" content="2.2.2">'));

// ---- 4. Pinch gate is still Ask-only (document-level, unchanged handlers) ----
const pinchSlice = app.slice(app.indexOf('function pinchDist'), app.indexOf('function askScreen(){'));
ok('pinch slice has helpers + setup', pinchSlice.includes('function pinchDist') && pinchSlice.includes('function pinchFont') && pinchSlice.includes('function setupPinchZoom') && pinchSlice.includes('setupPinchZoom();'));
ok('pinch setup is document-level', pinchSlice.includes("document.addEventListener('touchstart'") && pinchSlice.includes("document.addEventListener('touchmove'") && pinchSlice.includes("document.addEventListener('touchend'") && pinchSlice.includes("document.addEventListener('touchcancel'"));
ok('pinch gates on .ai-answer OR .qa-card', pinchSlice.includes("t.closest('.ai-answer')||t.closest('.qa-card')"));
ok('.qa-card appears only in renderQA (Ask screen)', (app.match(/qa-card/g) || []).length === 3, `occurrences=${(app.match(/qa-card/g) || []).length}`);

const docH = {};
const fakeDoc = { addEventListener(t, f, o) { (docH[t] = docH[t] || []).push({ f, o }); } };
const state = { aiFont: 18 };
let themeCalls = 0, persistCalls = 0;
const bctx = vm.createContext({
  document: fakeDoc, state,
  theme() { themeCalls++; },
  persist() { persistCalls++; },
  console, Math,
});
vm.runInContext(pinchSlice + '\n;globalThis.__pinchDist=pinchDist;globalThis.__pinchFont=pinchFont;globalThis.__pinchInAnswer=pinchInAnswer;globalThis.__setupPinchZoom=setupPinchZoom;', bctx);
const pinchInAnswer = bctx.__pinchInAnswer;
const mkTarget = (m) => ({ closest: (s) => (m.has(s) ? {} : null) });
const ANSWER = new Set(['.ai-answer', '.qa-card']);
const CARDONLY = new Set(['.qa-card']);
const READER = new Set([]); // a reader verse: closest() matches nothing
const touch = (x, y, m) => ({ clientX: x, clientY: y, target: mkTarget(m) });
const evt = (touches, m) => ({ touches, target: mkTarget(m), preventDefault() { this._pd = true; } });
ok('pinchInAnswer TRUE inside .ai-answer', pinchInAnswer(evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER)) === true);
ok('pinchInAnswer TRUE inside .qa-card', pinchInAnswer(evt([touch(0, 0, CARDONLY), touch(100, 0, CARDONLY)], CARDONLY)) === true);
ok('pinchInAnswer FALSE on a reader verse (no .ai-answer/.qa-card)',
  pinchInAnswer(evt([touch(0, 0, READER), touch(100, 0, READER)], READER)) === false);
ok('pinchInAnswer FALSE with a single touch off the answer',
  pinchInAnswer(evt([touch(0, 0, READER)], READER)) === false);
// Behavioral: pinch on a reader verse does nothing (Ask-only in practice)
const fire = (type, e) => { const h = docH[type]; if (h && h.length) h[0].f(e); };
state.aiFont = 20; themeCalls = 0; persistCalls = 0;
fire('touchstart', evt([touch(0, 0, READER), touch(100, 0, READER)], READER));
const mvReader = evt([touch(0, 0, READER), touch(200, 0, READER)], READER);
fire('touchmove', mvReader);
ok('2-finger move on a reader verse does nothing (no font change, no preventDefault)',
  state.aiFont === 20 && mvReader._pd !== true && themeCalls === 0, `font=${state.aiFont} pd=${mvReader._pd} theme=${themeCalls}`);
// And on the Ask answer it still works
state.aiFont = 18; themeCalls = 0;
fire('touchstart', evt([touch(0, 0, ANSWER), touch(100, 0, ANSWER)], ANSWER));
const mvAsk = evt([touch(0, 0, ANSWER), touch(150, 0, ANSWER)], ANSWER);
fire('touchmove', mvAsk);
ok('2-finger pinch on the Ask answer still grows 18 -> 27', state.aiFont === 27, `got ${state.aiFont}`);
fire('touchend', {});

// ---- 5. Page-turn full screen CSS ----
ok('.gs-book-reading has viewport-filling min-height',
  css.includes('.gs-book-reading{min-height:calc(100dvh - 122px)}'));
ok('.gs-book-reading.gs-has-topbar is flex column',
  css.includes('.gs-book-reading.gs-has-topbar{display:flex;flex-direction:column}'));
ok('.gs-book-stage is flex:1 + min-height:0 in has-topbar',
  css.includes('.gs-book-reading.gs-has-topbar .gs-book-stage{flex:1;min-height:0;height:auto}'));
ok('section height:100dvh rule still present (reading-open)',
  css.includes('html.reading-open .reading.gs-book-reading{padding:calc(48px + env(safe-area-inset-top)) 13px calc(17px + env(safe-area-inset-bottom));height:100dvh;'));
ok('makePages still measures node.clientHeight', pt.includes('Math.round(node.clientHeight)'));
ok('refresh() re-measure still present (rAF + fonts.ready)',
  pt.includes("requestAnimationFrame(()=>{if(!this.destroyed)this.refresh();})") && pt.includes("document.fonts.ready.then(()=>{if(!this.destroyed)this.refresh();})"));

// ---- Regression ----
ok('v2.2.25: A+/A- row gone (no ai-zoom-row)', !app.includes('ai-zoom-row'));
ok('v2.2.25: pinch arms on touchmove too', pinchSlice.includes('if(!pinchState&&pinchInAnswer(e))pinchState='));
ok('v2.2.25: setupPinchZoom idempotent guard', pinchSlice.includes('if(pinchWired)return;pinchWired=true;'));
ok('v2.2.23: exactly ONE .ai-answer font-size, var(--ai-font,18px)',
  (() => {
    const blocks = [...css.matchAll(/\.ai-answer\s*\{[^}]*\}/g)].map(m => m[0]);
    const decls = blocks.flatMap(b => [...b.matchAll(/font-size\s*:\s*([^;}]+)/g)].map(m => m[1].trim()));
    return decls.length === 1 && decls[0] === 'var(--ai-font,18px)';
  })());
ok('v2.2.22: no-heard timer intact', app.includes('noHeardTimer=setTimeout(()=>{') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ — ਉੱਚੀ ਬੋਲੋ ਜਾਂ ਦੁਬਾਰਾ ਦਬਾਓ'));
ok('v2.2.22: X restarts the mic intact', app.includes("clear.onclick=async()=>{const p=resetVoiceNow();input.value='';$('searchResults').innerHTML='';try{await p}catch{};startVoiceSearch(input)}"));
ok('v2.2.21: first-letter fallback intact', fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes('const firstSig=compact(initials(needle));'));
ok('v2.2.20: resetVoiceNow guard intact', app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('v2.2.18: ai-verse highlight intact', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('v2.2.18: aiFont clamp 14-32 intact (dormant handler)', app.includes('Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))'));
ok('v2.2.15: AI language toggle intact', app.includes('data-ai-lang') && app.includes('state.aiLang=aiLang.dataset.aiLang'));
ok('v2.2.19: Bani paragraph flow in page-turn intact', pt.includes("window.GS_VERSES.groupBaniParagraphs"));
ok('v2.2.19: book text centered intact', css.includes('.gs-book-page .gs-book-flow{font-family:"Noto Serif Gurmukhi","Raavi","Nirmala UI",serif;font-size:var(--font);font-weight:550;line-height:var(--leading);overflow-wrap:anywhere;word-break:normal;text-align:center}'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
