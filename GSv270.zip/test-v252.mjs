/* Gurbani Saanj v2.2.32 — TWO changes (includes ALL of v2.2.31).
 * (1) AI answer language now follows the app language automatically:
 * Punjabi app -> Punjabi AI answers, English app -> English answers.
 * The Ask-screen Punjabi/English pills stay as an override: an explicit
 * pill tap wins (remembered via state.aiLangManual) until the app language
 * is changed, which re-syncs the AI language. A stored 'en' AI language
 * from an older version is treated as an explicit pick on upgrade (the
 * default was 'pa', so 'en' could only have come from a tap). The verses
 * stay in Gurmukhi either way; only the explanation language follows.
 * The worker does NOT change for this (it already reads `language`).
 * (2) Search results now show the Roman transliteration under the Gurmukhi
 * pangti (above the English translation), when Transliteration is on
 * (state.showTranslit, default ON) — SGGS and Bani results alike. The
 * search index already carries the roman string; prepareChunk now keeps
 * it raw (roman) alongside the normalized trans, the match return passes
 * it through, and scriptureResultsMarkup renders it as .gs-result-roman.
 * Run: node test-v252.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.32', vj.version === '2.2.32');
ok('package.json is 2.2.32', pj.version === '2.2.32');
ok('version notes mention v2.2.32 + AI language follows app language',
  vj.notes.includes('v2.2.32:') && vj.notes.includes('follows the app language'),
  vj.notes.slice(-160));

// ---- 1. Flag + sync wiring present ----
ok('BASE has aiLangManual:false', app.includes("aiLang:'pa',aiLangManual:false,"));
ok('startup sync line present (manual migration + sync to lang)',
  app.includes("state.aiLangManual=state.aiLangManual===true||(stored.aiLangManual===undefined&&stored.aiLang==='en');if(!state.aiLangManual)state.aiLang=state.lang;"));
ok('lang-pa handler clears manual + syncs aiLang to pa',
  app.includes("case'lang-pa':state.lang='pa';state.aiLangManual=false;state.aiLang='pa';"));
ok('lang-en handler clears manual + syncs aiLang to en',
  app.includes("case'lang-en':state.lang='en';state.aiLangManual=false;state.aiLang='en';"));
ok('pill handler sets aiLangManual=true on explicit tap',
  app.includes("state.aiLang=aiLang.dataset.aiLang;state.aiLangManual=true;"));
ok('importBackup preserves aiLangManual', app.includes("'aiLangManual'"));
ok('importBackup normalizes + re-syncs aiLang after restore',
  app.includes("state.aiLang=state.aiLang==='en'?'en':'pa';state.aiLangManual=state.aiLangManual===true;if(!state.aiLangManual)state.aiLang=state.lang;persist();closeSettings();"));

// ---- 2. Startup sync logic (real assignments, run in vm) ----
const syncLine = app.split('\n').find(l => l.includes("stored.aiLangManual===undefined&&stored.aiLang==='en'"));
ok('startup sync line found for vm', !!syncLine);
function evalSync(storedObj) {
  // Mimic the merge + normalization order: lang normalized first, then aiLang.
  const state = {
    lang: storedObj.lang === 'en' ? 'en' : 'pa',
    aiLang: storedObj.aiLang === 'en' ? 'en' : 'pa',
    aiLangManual: storedObj.aiLangManual,
  };
  const ctx = vm.createContext({ state, stored: storedObj });
  vm.runInContext("state.aiLang=state.aiLang==='en'?'en':'pa';\n" + syncLine + "\nthis.__s=state;", ctx);
  return ctx.__s;
}
let s = evalSync({ lang: 'pa', aiLang: 'pa' });
ok('(a) app pa + no explicit pick -> AI pa, manual false',
  s.aiLang === 'pa' && s.aiLangManual === false, JSON.stringify(s));
s = evalSync({ lang: 'en', aiLang: 'pa' });
ok('(b) app en + no explicit pick -> AI en, manual false',
  s.aiLang === 'en' && s.aiLangManual === false, JSON.stringify(s));
s = evalSync({ lang: 'en', aiLang: 'en', aiLangManual: false });
ok('(b) app en + aiLang en, no manual -> AI en, manual false',
  s.aiLang === 'en' && s.aiLangManual === false, JSON.stringify(s));
s = evalSync({ lang: 'pa', aiLang: 'en' });
ok('(migration) stored en AI pick + app pa -> manual true, AI stays en',
  s.aiLang === 'en' && s.aiLangManual === true, JSON.stringify(s));
s = evalSync({ lang: 'pa', aiLang: 'en', aiLangManual: true });
ok('(manual) explicit en pick + app pa -> AI stays en, manual true',
  s.aiLang === 'en' && s.aiLangManual === true, JSON.stringify(s));
s = evalSync({ lang: 'en', aiLang: 'pa', aiLangManual: true });
ok('(manual) explicit pa pick + app en -> AI stays pa, manual true',
  s.aiLang === 'pa' && s.aiLangManual === true, JSON.stringify(s));

// ---- 3. Pill handler = explicit override (run in vm with fakes) ----
const pillLine = app.split('\n').find(l => l.includes("e.target.closest('[data-ai-lang]')"));
ok('pill handler line found for vm', !!pillLine);
function evalPill(stateObj, pick) {
  const state = { ...stateObj };
  let persisted = false;
  const ctx = vm.createContext({
    state,
    e: { target: { closest: (sel) => (sel === '[data-ai-lang]' ? { dataset: { aiLang: pick } } : null) } },
    persist: () => { persisted = true; },
    document: { querySelectorAll: () => [] },
  });
  vm.runInContext('(function(){' + pillLine + '})();\nthis.__s=state;', ctx);
  return { s: ctx.__s, persisted };
}
let p = evalPill({ lang: 'pa', aiLang: 'pa', aiLangManual: false }, 'en');
ok('(c) tap English pill with app pa -> AI en, manual true, persisted',
  p.s.aiLang === 'en' && p.s.aiLangManual === true && p.persisted, JSON.stringify(p));
p = evalPill({ lang: 'en', aiLang: 'en', aiLangManual: false }, 'pa');
ok('(d) tap Punjabi pill with app en -> AI pa, manual true, persisted',
  p.s.aiLang === 'pa' && p.s.aiLangManual === true && p.persisted, JSON.stringify(p));

// ---- 4. App-language change re-syncs (run the case statements in vm) ----
function evalLangCase(which, stateObj) {
  const line = app.split('\n').find(l => l.includes(`case'lang-${which}':`));
  const body = line.replace(/^ case'lang-(pa|en)':/, '').replace(/break;$/, '');
  const calls = [];
  const ctx = vm.createContext({
    state: { ...stateObj },
    persist: () => calls.push('persist'),
    render: () => calls.push('render'),
    refreshReader: () => calls.push('refreshReader'),
  });
  vm.runInContext(body + '\nthis.__s=state;', ctx);
  return { s: ctx.__s, calls };
}
let lc = evalLangCase('en', { lang: 'pa', aiLang: 'en', aiLangManual: true, view: 'ask' });
ok('(e) app lang pa->en with explicit override -> re-sync: AI en, manual false',
  lc.s.lang === 'en' && lc.s.aiLang === 'en' && lc.s.aiLangManual === false && lc.calls.includes('persist') && lc.calls.includes('render'), JSON.stringify(lc));
lc = evalLangCase('pa', { lang: 'en', aiLang: 'en', aiLangManual: true, view: 'ask' });
ok('(e) app lang en->pa with explicit override -> re-sync: AI pa, manual false',
  lc.s.lang === 'pa' && lc.s.aiLang === 'pa' && lc.s.aiLangManual === false, JSON.stringify(lc));
lc = evalLangCase('pa', { lang: 'en', aiLang: 'pa', aiLangManual: false, view: 'reader' });
ok('(e) app lang en->pa, reader view -> refreshReader (not render), AI pa',
  lc.s.lang === 'pa' && lc.s.aiLang === 'pa' && lc.calls.includes('refreshReader') && !lc.calls.includes('render'), JSON.stringify(lc));

// ---- 5. Pills render reflects the synced aiLang ----
ok('Ask pills render the selected pill from state.aiLang',
  app.includes("data-ai-lang=\"${k}\" class=\"${state.aiLang===k?'sel':''}\""));

// ---- 6. (f) Direct path sends the right language word (real template, run in vm) ----
const directLine = app.split('\n').find(l => l.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('direct-path content line found', !!directLine);
function evalDirect(aiLang) {
  const ctx = vm.createContext({ state: { aiLang }, question: 'Q?', level: 'detail', context: '[Ang 8] line' });
  vm.runInContext('this.__m=' + directLine.trim() + ';', ctx);
  return ctx.__m.content;
}
ok('(f) direct path says "Answer in English" when aiLang is en',
  evalDirect('en').includes('Answer in English.'));
ok('(f) direct path says "Answer in Punjabi" when aiLang is pa',
  evalDirect('pa').includes('Answer in Punjabi.'));

// ---- 7. (g) Server/cloud path sends language: aiLang (real body, run in vm) ----
const srvLine = app.split('\n').find(l => l.includes('language:state.aiLang'));
ok('server-path fetch line found', !!srvLine);
const bodyMatch = srvLine.match(/JSON\.stringify\(\{question:q,depth:state\.depth,language:state\.aiLang,verses:entry\.matches,history\}\)/);
ok('server-path body expression found', !!bodyMatch);
function evalSrvBody(aiLang) {
  const ctx = vm.createContext({ q: 'Q?', state: { depth: 'detail', aiLang }, entry: { matches: [{ ang: 8, g: 'x' }] }, history: [] });
  vm.runInContext('this.__b=' + bodyMatch[0] + ';', ctx);
  return JSON.parse(ctx.__b);
}
ok('(g) server path sends language "en" when aiLang is en',
  evalSrvBody('en').language === 'en');
ok('(g) server path sends language "pa" when aiLang is pa',
  evalSrvBody('pa').language === 'pa');

// ---- 8. Regressions v2.2.31 -> v2.2.15 ----
ok('regression v2.2.31: cloud defaults present (endpoint + token)',
  app.includes("const AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev';") && app.includes('const AI_CLOUD_TOKEN='));
ok('regression v2.2.31: status is online with no key and no endpoint (cloud)',
  app.includes("||AI_CLOUD_ENDPOINT)?age('AI ਔਨਲਾਈਨ ਹੈ"));
ok('regression v2.2.31: elaborate prompt (what the verse teaches)',
  app.includes('what the verse teaches') && worker.includes('what the verse teaches'));
ok('regression v2.2.31: Dasam Granth citation in prompts',
  app.includes('Dasam Granth — Bani name') && worker.includes('Dasam Granth — Bani name'));
ok('regression v2.2.31: worker token limits 250/900/1500',
  worker.includes("depth==='short'?250:depth==='detail'?900:1500"));
const versesLine = worker.split('\n').find(l => l.trim().startsWith('const verses='));
function evalVerses(bodyObj) {
  const ctx = vm.createContext({ body: bodyObj });
  vm.runInContext(versesLine + '\nthis.__v=verses;', ctx);
  return ctx.__v;
}
ok('regression v2.2.31: worker keeps SGGS + Bani verses',
  (() => { const v = evalVerses({ verses: [{ ang: 8, g: 'sggs' }, { src: 'bani', baniId: 4, baniTitle: 'Jaap Sahib', group: 'dasam', g: 'bani' }] }); return v.length === 2 && v[1].baniTitle === 'Jaap Sahib'; })());
ok('regression v2.2.30: no showHi in app.js', !app.includes('showHi'));
ok('regression v2.2.30: no verse-hi in render-verses.js', !rv.includes('verse-hi'));
ok('regression v2.2.30: English under search results (gs-result-en)', app.includes('gs-result-en'));
ok('regression v2.2.30: font slider present (vpFontSlider)', app.includes('vpFontSlider'));
ok('regression v2.2.28: Dasam Granth source label present', app.includes('gs-result-dasam-tag'));
ok('regression v2.2.27: barScrollDecision present', app.includes('barScrollDecision'));
ok('regression v2.2.26: isBaniHeading with Mehla pattern', rv.includes('ਮਹਲਾ'));
ok('regression v2.2.26: pinch Ask-only (pinchInAnswer + viewport)', app.includes('pinchInAnswer') && html.includes('user-scalable=no'));
ok('regression voice: ensureVoiceListeners + noHeardTimer', app.includes('ensureVoiceListeners') && app.includes('noHeardTimer'));
ok('regression search: first-letter fallback (firstSig)', ss.includes('firstSig'));
ok('regression v2.2.15: AI language pills present', app.includes('data-ai-lang'));
ok('regression v2.2.18: aiAnswerHTML + ai-verse', app.includes('aiAnswerHTML') && css.includes('.ai-verse'));
// Behavioral: Hindi still absent in a real render (v2.2.30 proof)
const rvCtx = vm.createContext({ window: {}, console });
vm.runInContext(rv, rvCtx);
const VERSES = rvCtx.window.GS_VERSES;
const hiLine = { g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', roman: 'mil mere preetamaa jeeo tudh bin kharee nimaanee |', en: 'Meet me, O my Beloved; without You, I am totally miserable.', pa: 'ਹੇ ਮੇਰੇ ਪਿਆਰੇ ਪ੍ਰਭੂ! ਮੈਨੂੰ ਮਿਲ।', hi: 'मिल मेरे प्रीतम जीउ तुध बिन खरी निमाणी ॥' };
const vHtml = VERSES.verseHTML(hiLine, { idx: 33, kind: 'ang', show: { translit: true, en: true, pa: true, hi: true, arth: true }, arth: [{ word: 'ਪ੍ਰੀਤਮਾ', meaning: 'beloved' }], koshHas: () => false });
ok('regression v2.2.30: verse with hi renders NO Hindi layer',
  !vHtml.includes('verse-hi') && !vHtml.includes('मिल मेरे') && !vHtml.includes('lang="hi"'));

// ---- 9. (2) Roman transliteration in search results ----
// Static wiring
ok('search: prepareChunk keeps raw roman on the object', ss.includes("roman:String(roman||'')"));
ok('search: fallback prepared object keeps raw roman', ss.includes("trans:norm(roman),roman:String(roman||'')"));
ok('search: match return passes roman for Bani + SGGS', ss.includes("roman:x.roman,score"));
ok('search: matching logic unchanged (trans/initials still used)', ss.includes('trans:norm(roman)') && ss.includes('romanInitial:compact(initials(roman))'));
ok('markup: roman line rendered between pangti and English, gated on showTranslit',
  app.includes("state.showTranslit&&String(v.roman||'').trim()") && app.includes('class="gs-result-roman" lang="en-Latn"'));
ok('markup: return template puts ${romanHtml} between the pangti and ${enHtml}',
  app.includes('<strong lang="pa">${esc(v.g)}</strong>${romanHtml}${enHtml}'));
ok('css: .gs-result-roman sub-line rule present', css.includes('.gs-result-roman{display:block;font-size:13px'));
ok('regression: English translation line still rendered (v2.2.30)', app.includes('class="gs-result-en"'));

// (a) Real query in vm with stubbed fetch: Roman query -> matches carry roman
const sggsRows = [[8, 0, 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', 'Meet me, O my Beloved; without You, I am totally miserable.', 'ਹੇ ਮੇਰੇ ਪਿਆਰੇ ਪ੍ਰਭੂ! ਮੈਨੂੰ ਮਿਲ।', 'mil mere preetamaa jeeo tudh bin kharee nimaanee']];
for (let i = 1; i < 1005; i++) sggsRows.push([8 + (i % 100), i, 'ਪੰਕਤੀ ' + i, 'English ' + i, 'ਪੰਜਾਬੀ ' + i, 'pankatee ' + i]);
const baniRows = [[4, 0, 'ਜਾਪੁ ਸਾਹਿਬ ਦੀ ਪੰਕਤੀ', 'Jaap Sahib line', 'ਜਾਪੁ ਸਾਹਿਬ ਪੰਜਾਬੀ', 'jaap saahib dee pankatee', 'ਜਾਪੁ ਸਾਹਿਬ', 'Jaap Sahib', 'dasam']];
for (let i = 1; i < 105; i++) baniRows.push([4, i, 'ਬਾਣੀ ਪੰਕਤੀ ' + i, 'Bani English ' + i, 'ਬਾਣੀ ਪੰਜਾਬੀ ' + i, 'baanee pankatee ' + i, 'ਜਾਪੁ ਸਾਹਿਬ', 'Jaap Sahib', 'dasam']);
const ssCtx = vm.createContext({
  window: {}, console,
  fetch: async (url) => ({ ok: true, json: async () => (String(url).includes('bani-search') ? baniRows : sggsRows) }),
});
vm.runInContext(ss, ssCtx);
const GS = ssCtx.window.GS_SCRIPTURE_SEARCH;
ok('search vm: GS_SCRIPTURE_SEARCH loaded', !!GS && typeof GS.query === 'function');
const romanHits = await GS.query('mil mere', 40);
ok('(a) Roman query returns a match carrying the raw roman string',
  romanHits.length >= 1 && romanHits[0].src === 'sggs' && romanHits[0].ang === 8 &&
  romanHits[0].roman === 'mil mere preetamaa jeeo tudh bin kharee nimaanee', JSON.stringify(romanHits[0]));
const baniHits = await GS.query('jaap saahib', 40);
ok('(a) Roman query on a Bani line returns a Bani match carrying roman',
  baniHits.length >= 1 && baniHits[0].src === 'bani' && baniHits[0].baniId === 4 &&
  baniHits[0].roman === 'jaap saahib dee pankatee', JSON.stringify(baniHits[0]));
ok('(a) every returned match carries a non-empty roman field',
  [...romanHits, ...baniHits].every(m => typeof m.roman === 'string' && m.roman.trim().length > 0));

// (b)(c)(d) Real markup in vm with fakes: extract the real function, run it
function extractFn(src, name) {
  const start = src.indexOf('function ' + name + '(');
  const paren = src.indexOf(')', start); // end of the parameter list (params may contain { })
  let i = src.indexOf('{', paren), depth = 0, j = i; // body open brace
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) break; }
  }
  return src.slice(start, j + 1);
}
const markupSrc = extractFn(app, 'scriptureResultsMarkup');
ok('markup: scriptureResultsMarkup extracted for vm', markupSrc.length > 500 && markupSrc.includes('gs-result-roman'));
const mState = { lang: 'pa', showTranslit: true, savedVerses: [] };
const mCtx = vm.createContext({
  state: mState,
  esc: (s) => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'),
  age: (pa, en) => (mState.lang === 'pa' ? pa : en),
  console,
});
vm.runInContext(markupSrc + ';\nthis.__markup=scriptureResultsMarkup;', mCtx);
const markup = mCtx.__markup;
const sggsHtml = markup([{ src: 'sggs', ang: 8, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', roman: 'mil mere preetamaa jeeo' }]);
ok('(b) SGGS markup: roman line directly after the Gurmukhi pangti, before the English line',
  sggsHtml.includes('class="gs-result-roman" lang="en-Latn">mil mere preetamaa jeeo</span>') &&
  sggsHtml.indexOf('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ') < sggsHtml.indexOf('mil mere preetamaa jeeo') &&
  sggsHtml.indexOf('mil mere preetamaa jeeo') < sggsHtml.indexOf('gs-result-en'), sggsHtml);
const baniHtml = markup([{ src: 'bani', baniId: 4, idx: 0, g: 'ਜਾਪੁ ਸਾਹਿਬ ਦੀ ਪੰਕਤੀ', en: 'Jaap Sahib line', roman: 'jaap saahib dee pankatee', baniTitle: 'ਜਾਪੁ ਸਾਹਿਬ', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam' }]);
ok('(d) Bani markup: roman line after the pangti, before the English translation, Dasam tag kept',
  baniHtml.includes('class="gs-result-roman" lang="en-Latn">jaap saahib dee pankatee</span>') &&
  baniHtml.indexOf('ਜਾਪੁ ਸਾਹਿਬ ਦੀ ਪੰਕਤੀ') < baniHtml.indexOf('jaap saahib dee pankatee') &&
  baniHtml.indexOf('jaap saahib dee pankatee') < baniHtml.indexOf('Jaap Sahib line') &&
  baniHtml.includes('Dasam Granth'), baniHtml);
mState.showTranslit = false;
const offHtml = markup([{ src: 'sggs', ang: 8, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', roman: 'mil mere preetamaa jeeo' }]);
ok('(c) showTranslit OFF: no transliteration line in the markup',
  !offHtml.includes('gs-result-roman') && !offHtml.includes('mil mere preetamaa jeeo'), offHtml);
mState.showTranslit = true;
const emptyHtml = markup([{ src: 'sggs', ang: 8, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', roman: '' }]);
ok('(c) empty roman string: no transliteration line, no crash', !emptyHtml.includes('gs-result-roman'));
const noRomanHtml = markup([{ src: 'sggs', ang: 8, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ' }]);
ok('(c) missing roman field: no transliteration line, no crash', !noRomanHtml.includes('gs-result-roman'));

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
