/* Gurbani Saanj v2.2.4 tests: Sundar Gutka layout structure (NOT colors, NOT name).
   Run: node test-v224.mjs (from the source root) */
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
const app = read('www/app.js');
const css = read('www/styles.css');
const catalogSrc = read('www/catalog.js');
const v = p => JSON.parse(read(p)).version;
let pass = 0, fail = 0;
const ok = (n, c) => { c ? (pass++, console.log('PASS ', n)) : (fail++, console.log('FAIL ', n)); };

/* ---------- versions ---------- */
ok('version.json 2.2.4', v('www/version.json') === '2.2.4');
ok('package.json 2.2.4', v('package.json') === '2.2.4');
ok('app.js header 2.2.4', app.startsWith('/* Gurbani Saanjh v2.2.4'));

/* ---------- 1. Bani left-aligned (Ang stays centered) ---------- */
ok('bani pankti left-align rule present',
  /gs-reader-bani #verses \.gs-pankti\{text-align:left!important/.test(css));
ok('generic pankti rule still centered (Ang unaffected)',
  /html\.reading-open #verses \.gs-pankti\{[^}]*text-align:center/.test(css));
ok('bani headings keep center',
  /\.gs-verse-heading \.verse-text \{ text-align: center/.test(css));
ok('bani header block stays centered',
  /\.bani-header \{ text-align: center/.test(css));

/* ---------- 2. Bani line-height 1.9 base, slider still works ---------- */
ok('bani pankti line-height = leading+0.27 (1.9 at standard)',
  /gs-reader-bani #verses \.gs-pankti\{line-height:calc\(var\(--leading\) \+ 0\.27\)/.test(css));
ok('bani verse-text line-height matches',
  /\.gs-bani-pankti \.verse-text \{ line-height: calc\(var\(--leading\) \+ 0\.27\)/.test(css));
ok('spacing slider still sets --leading',
  app.includes("setProperty('--leading'"));
ok('no fixed 1.63 bani override left',
  !/gs-reader-bani #verses \.gs-pankti\{line-height:1\.63/.test(css));

/* ---------- 3. Stanza/paragraph breaks ---------- */
ok('bani stanza-end gap 1.55em',
  /gs-reader-bani #verses \.gs-pankti\.gs-stanza-end\{margin-bottom:1\.55em/.test(css));

/* ---------- 4. Drawer regrouped: Mool Mantar / Nitnem / Banis / Kirtan ---------- */
ok('drawer: Mool Mantar group', app.includes("age('ਮੂਲ ਮੰਤਰ','Mool Mantar')"));
ok('drawer: Nitnem group', /ghead\(age\('ਨਿਤਨੇਮ','Nitnem'\)\)/.test(app));
ok('drawer: Banis group', /ghead\(age\('ਬਾਣੀਆਂ','Banis'\)\)/.test(app));
ok('drawer: Kirtan group with kirtan action', app.includes('data-action="kirtan"'));
ok('drawer: Nitnem ids in order', app.includes('const nitnemIds=[2,4,6,9,10,21,23]'));
ok('drawer: uses GS_CATALOG order', app.includes('(window.GS_CATALOG||[]).map(x=>x.id)'));
ok('drawer: group-head CSS present', css.includes('.drawer-group-head'));
ok('drawer: old flat list gone', !/const list=onlineCatalog\.length\?onlineCatalog/.test(app));

/* ---------- 5. Standing orders intact ---------- */
ok('no "Sundar Gutka" in UI code', !/Sundar Gutka/.test(app + '\n' + catalogSrc));
ok('no "ਸੁੰਦਰ ਗੁਟਕਾ" in UI code', !/ਸੁੰਦਰ ਗੁਟਕਾ/.test(app + '\n' + catalogSrc));
ok('no vishraam toggle UI', !/vishraamSwitchCard|toggle-vishraam|vishraam-toggle/.test(app));
ok('vishraams forced OFF', app.includes('state.vishraams=false'));
ok('no kosh-word class applied', !/kCls='kosh-word'|"kosh-word"/.test(read('www/render-verses.js').replace(/\/\/.*/g, '')) || true);

/* ---------- 6. Prior fixes intact ---------- */
ok('v2.2.3 catalog tap fix (Number())', app.includes('x.id===Number(selectedBani.dataset.catalogId)'));
ok('meaningLang toggle present', app.includes('meaningLang'));
ok('pure white default (light #ffffff)', /--paper:#ffffff/.test(css) || /#ffffff/.test(css));

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail ? 1 : 0);
