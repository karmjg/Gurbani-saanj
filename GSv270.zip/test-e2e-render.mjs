/* Gurbani Saanjh v2.2.0 — end-to-end render test (node, offline).
 * Mirrors the production path exactly:
 *   GS_REMOTE.read -> enrichLines (vishraam marks + kosh arth) ->
 *   GS_VERSES.verseHTML per line -> reader assembly (bani header, headings).
 * Run: node test-e2e-render.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
const FIX = '/tmp/v220test/offline';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const store = {};
const sb = {
  window: {},
  localStorage: { getItem: k => store[k] ?? null, setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
  fetch: async (url) => {
    const u = String(url);
    const file = u.includes('vishraam.json') ? `${FIX}/vishraam.json`
      : u.includes('kosh-stems.json') ? `${FIX}/kosh-stems.json`
      : u.includes('kosh.json') ? `${ROOT}/www/offline/kosh.json` : null;
    if (!file || !fs.existsSync(file)) return { ok: false };
    return { ok: true, json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
  },
  console,
};
const load = rel => vm.runInNewContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), sb, { filename: rel });
load('www/render-verses.js'); load('www/vishraam.js'); load('www/word-kosh.js');
sb.window.GS_REMOTE = {
  read: async (kind, id) => {
    const data = JSON.parse(fs.readFileSync(`${ROOT}/www/offline/${kind}/${id}.json`, 'utf8'));
    return { ...data, offline: true };
  },
};
const V = sb.window.GS_VERSES, VH = sb.window.GS_VISHRAAM, K = sb.window.GS_KOSH;
await K.ready();

// ---- production enrichLines replica (must match www/app.js) ----
async function enrichLines(lines, kind, ref, { showArth, lang }) {
  let marksByLine = {};
  try {
    if (kind === 'ang') marksByLine = await VH.marksForText('a', ref);
    else if (kind === 'bani') marksByLine = await VH.marksForText('b', ref);
    else if (kind === 'kirtan' && ref && ref.ang) marksByLine = await VH.marksForText('a', ref.ang);
  } catch {}
  const lineOffset = (kind === 'kirtan' && ref && typeof ref.lineStart === 'number') ? ref.lineStart : 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    line._marks = marksByLine[lineOffset + i] || null;
    line._arth = null;
    if (showArth) { try { line._arth = await K.arthFor(line, lang); } catch {} }
  }
  return lines;
}
const koshHas = w => K.hasEntrySync(w);
const show = { translit: true, en: true, pa: true, hi: false, arth: true };

/* ============ BANI: Japji Sahib (bani/2) ============ */
{
  const { lines } = await sb.window.GS_REMOTE.read('bani', 2);
  await enrichLines(lines.slice(0, 12), 'bani', 2, { showArth: true, lang: 'pa' });
  const head12 = lines.slice(0, 12);
  // header block (Japji's first line lacks the manglacharan -> header shown)
  ok('bani header shown for Japji (orange ੴ, no duplication)',
    V.baniHeaderNeeded(head12) === true);
  const headerHTML = `<div class="bani-header"><div class="bani-manglacharan"><span class="bani-ik-oankar">ੴ</span> <span>ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥</span></div></div>`;
  ok('bani header content exact', headerHTML.includes('ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥') && headerHTML.includes('bani-ik-oankar'));
  // Jaap-style heading centering on bani/4 sample
  const j4 = await sb.window.GS_REMOTE.read('bani', 4);
  const headings = j4.lines.slice(0, 6).filter(l => V.isBaniHeading(l.g)).map(l => l.g);
  ok('chhand headings detected (Jaap Sahib)', headings.length >= 2, JSON.stringify(headings));
  // full verse render of a real line with all layers
  const line = head12[2]; // ਆਦਿ ਸਚੁ ਜੁਗਾਦਿ ਸਚੁ ॥
  const html = V.verseHTML(line, { idx: 2, kind: 'bani', vishraamOn: true, marks: line._marks, koshHas, arth: line._arth, show });
  ok('bani verse: gurmukhi words tappable', (html.match(/data-word=/g) || []).length === V.tokens(line.g).length);
  ok('bani verse: kosh words orange', html.includes('kosh-word'));
  ok('bani verse: verse numerals kept inline', html.includes('॥'));
  const order = ['verse-text', 'verse-roman', 'verse-en', 'verse-pa', 'verse-arth'].map(c => html.indexOf(c)).filter(i => i >= 0);
  ok('bani verse: layer order', order.every((v, i) => i === 0 || v > order[i - 1]));
  // vishraam OFF strips everything
  const off = V.verseHTML(line, { idx: 2, kind: 'bani', vishraamOn: false, marks: line._marks, koshHas, arth: line._arth, show });
  ok('bani verse: vishraam OFF strips colors', !/vishraam-(short|long)/.test(off));
  // tap-a-word on a real verse word
  const lk = await K.lookup('ਸਚੁ', 'pa');
  ok('tap-a-word real verse word (ਸਚੁ)', lk.definitions.length > 0);
}

/* ============ ANG: Ang 1 with fixture vishraam marks ============ */
{
  const { lines } = await sb.window.GS_REMOTE.read('ang', 1);
  await enrichLines(lines.slice(0, 4), 'ang', 1, { showArth: false, lang: 'pa' });
  const l0 = lines[0];
  ok('ang line0 marks from fixture (s@1, l@3)', l0._marks?.[1] === 's' && l0._marks?.[3] === 'l');
  const html = V.verseHTML(l0, { idx: 0, kind: 'ang', vishraamOn: true, marks: l0._marks, koshHas, arth: null, show: { ...show, arth: false }, gurmukhiClass: 'gs-gurmukhi-blue' });
  ok('ang gurmukhi blue/bold class', html.includes('gs-gurmukhi-blue'));
  ok('ang word1 green (short)', /data-widx="1"[^>]*vishraam-short|vishraam-short[^>]*data-widx="1"/.test(html));
  ok('ang word3 orange (long)', /vishraam-long/.test(html));
  // every word button carries data for tap-a-word
  const btns = [...html.matchAll(/<button[^>]*data-word="([^"]*)"[^>]*data-widx="(\d+)"[^>]*>/g)];
  ok('ang all words tappable with index', btns.length === V.tokens(l0.g).length && btns.every((m, i) => Number(m[2]) === i));
}

/* ============ KIRTAN: shabad slice ============ */
{
  const meta = { ang: 1, lineStart: 0 };
  const { lines } = await sb.window.GS_REMOTE.read('ang', 1);
  const slice = lines.slice(0, 3);
  await enrichLines(slice, 'kirtan', meta, { showArth: false, lang: 'pa' });
  ok('kirtan slice uses ang marks at absolute offset', slice[0]._marks?.[1] === 's');
  const html = V.verseHTML(slice[0], { idx: 0, kind: 'kirtan', vishraamOn: true, marks: slice[0]._marks, koshHas, show: { ...show, arth: false } });
  ok('kirtan verse renders', html.includes('ੴ') && html.includes('verse-text'));
}

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail ? 1 : 0);
