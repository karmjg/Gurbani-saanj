// Build the offline Bani search index from the bundled Bani files.
// Run: node scripts/build-bani-search.mjs
// Reads www/offline/bani/*.json (29 Banis, 9,452 lines) + Bani titles from
// www/catalog.js (22 catalog Banis) + the 7 Nitnem titles (mirror of
// NITNEM_LIST in www/app.js) and writes www/offline/bani-search.json as
// [baniId, lineIdx, g, en, pa, roman, titlePa, titleEn, group] tuples —
// the same tuple shape as offline/search.json ([ang, idx, g, en, pa, roman])
// plus titles and the catalog group ('sggs' / 'dasam' / 'tradition'), so a
// result can say whether its Bani is from Dasam Granth.
// The index is loaded by www/scripture-search.js alongside search.json, so
// typed + voice search cover every Bani in the app (SGGS, Nitnem, Dasam
// Granth, any type). Re-run this script whenever a Bani file changes.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';

const ROOT = path.resolve(import.meta.dirname, '..');

// --- Bani titles from the catalog (22 Banis) ---
const catSrc = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
const catCtx = { window: {} };
vm.runInNewContext(catSrc, catCtx);
const titles = new Map();
for (const c of (catCtx.window.GS_CATALOG || [])) {
  titles.set(Number(c.id), { titlePa: String(c.titlePa || ''), titleEn: String(c.titleEn || ''), group: String(c.group || 'sggs') });
}

// --- Nitnem titles (mirror of NITNEM_LIST in www/app.js) ---
// Nitnem Banis are not in the catalog; their group is fixed here — Jaap,
// Tav-Prasad Savaiye and Chaupai are Dasam Granth, the rest are SGGS.
const nitnem = [
  [2, 'ਜਪੁਜੀ ਸਾਹਿਬ', 'Japji Sahib', 'sggs'],
  [4, 'ਜਾਪੁ ਸਾਹਿਬ', 'Jaap Sahib', 'dasam'],
  [6, 'ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ', 'Tav-Prasad Savaiye', 'dasam'],
  [9, 'ਚੌਪਈ ਸਾਹਿਬ', 'Chaupai Sahib', 'dasam'],
  [10, 'ਅਨੰਦੁ ਸਾਹਿਬ', 'Anand Sahib', 'sggs'],
  [21, 'ਰਹਰਾਸਿ ਸਾਹਿਬ', 'Rehras Sahib', 'sggs'],
  [23, 'ਕੀਰਤਨ ਸੋਹਿਲਾ', 'Kirtan Sohila', 'sggs'],
];
for (const [id, pa, en, group] of nitnem) {
  if (!titles.has(id)) titles.set(id, { titlePa: pa, titleEn: en, group: group || 'sggs' });
}

const dir = path.join(ROOT, 'www/offline/bani');
const out = [];
const ids = [];
for (const f of fs.readdirSync(dir).sort()) {
  const id = Number(f.replace(/\.json$/i, ''));
  if (!Number.isInteger(id)) continue;
  const data = JSON.parse(fs.readFileSync(path.join(dir, f), 'utf8'));
  const t = titles.get(id) || { titlePa: 'Bani ' + id, titleEn: 'Bani ' + id, group: 'sggs' };
  ids.push(id);
  (data.lines || []).forEach((line, idx) => {
    const g = String(line.g || '').trim();
    if (!g) return;
    out.push([id, idx, g, String(line.en || ''), String(line.pa || ''), String(line.roman || ''), t.titlePa, t.titleEn, t.group]);
  });
}

const outPath = path.join(ROOT, 'www/offline/bani-search.json');
fs.writeFileSync(outPath, JSON.stringify(out));
console.log(`bani-search.json: ${out.length} lines across ${ids.length} Banis (${ids.join(',')})`);
