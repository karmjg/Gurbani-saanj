/**
 * Gurbani Saanjh: BUILD-TIME ONLY scripture snapshot for a PRIVATE, NON-PROFIT trial.
 * No network calls from the installed Android reader.
 * BaniDB content is distributed under NPOSL 3.0; see SOURCE_AND_LICENSE.md.
 * Hard fail on missing Ang / missing selected Nitnem Bani, to avoid silently shipping fragments.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
const BASE='https://api.banidb.com/v2';
const OUT=path.resolve('www/offline');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const containsG=s=>/[\u0A00-\u0A7F]/u.test(String(s||''));
const pickString=(...xs)=>xs.find(x=>typeof x==='string'&&x.trim())||'';
const toName=x=>typeof x==='string'?x:(x&&typeof x==='object'?pickString(x.unicode,x.gurmukhi,x.english,x.en,x.pa,x.punjabi,x.text,x.value):'');
function translation(v,lang){
 for(const source of [v,v?.verse,v?.data,v?.verse?.verse]){
  const t=source?.steek||source?.translation||source?.translations||{};
  const d=t[lang]||(lang==='pu'?t.pa:undefined);
  if(typeof d==='string')return d;
  if(d&&typeof d==='object'){
   for(const k of lang==='pu'?['ss','ms','bdb','ft']:['bdb','ssk','ss','ms','ft']){
    const q=d[k];if(typeof q==='string'&&q!=='None')return q;
    const str=toName(q);if(str&&str!=='None')return str;
   }
   const str=toName(d);if(str&&str!=='None')return str;
  }
 }
 return '';
}
function roman(v){
 for(const source of [v,v?.verse,v?.data]){
  const t=source?.translit||source?.transliteration||source?.transliterations||source?.roman||{};
  if(typeof t==='string')return t;
  if(t&&typeof t==='object'){
   const r=pickString(t.en,t.english,t.en?.bdb,t.en?.ss,t.en?.unicode,t.roman);
   if(r)return r;
  }
 }
 return '';
}
function pause(v){
 const o={};
 const arr=v?.visraam?.sttm||v?.verse?.visraam?.sttm||v?.verse?.verse?.visraam?.sttm||[];
 if(Array.isArray(arr))for(const item of arr){const i=Number(item.p);if(Number.isInteger(i)&&i>=0){if(item.t==='y')o[i]='short';else if(item.t==='v')o[i]='long'}}
 return o;
}
function normalize(raw){
 const arr=Array.isArray(raw)?raw:
  Array.isArray(raw?.verses)?raw.verses:
  Array.isArray(raw?.page)?raw.page:
  Array.isArray(raw?.data?.verses)?raw.data.verses:
  Array.isArray(raw?.data)?raw.data:
  Array.isArray(raw?.shabads)?raw.shabads.flatMap(x=>x.verses||[]):[];
 return arr.map((item,i)=>{
  // Actual BaniDB records can contain verse.verse.unicode, not only verse.unicode.
  const v=item?.line||item;
  const original=v?.verse?.verse||v?.verse||v;
  const g=pickString(
   original?.unicode,original?.gurmukhiUni,original?.unicodeVerse,original?.gurmukhiUnicode,
   v?.unicode,v?.gurmukhiUni,typeof original==='string'?original:'',
   // gurmukhi can be Latin legacy font encoding; reject unless really Unicode Gurmukhi.
   containsG(original?.gurmukhi)?original.gurmukhi:'',
   containsG(v?.gurmukhi)?v.gurmukhi:'').trim();
  const source=pickString(v?.sourceID,v?.sourceId,v?.source,original?.sourceID,original?.sourceId,original?.source,v?.verse?.sourceID);
  const rawAng=v?.pageNo??v?.ang??v?.verse?.pageNo??v?.verse?.ang??original?.pageNo??original?.ang;
  const ang=Number(rawAng);
  return {id:String(v?.verse_id||v?.verseId||v?.id||v?.verse?.verseId||i),g,
   roman:roman(v),en:translation(v,'en'),pa:translation(v,'pu'),vishraam:pause(v),
   ...(source==='G'&&Number.isInteger(ang)&&ang>=1&&ang<=1430?{source:'G',ang}:{})};
 }).filter(x=>x.g&&containsG(x.g));
}
function index(raw){
 // Accept BaniDB index arrays, numeric-key dictionaries, and nested metadata.
 // Do not infer numeric IDs from array positions (IDs are not guaranteed contiguous).
 const found=new Map();
 const seen=new Set();
 function read(node,key='',depth=0){
  if(!node||depth>7||typeof node!=='object'||seen.has(node))return;
  seen.add(node);
  const source=node?.baniInfo||node?.bani||node?.info||node;
  const val=source.baniID??source.baniId??source.BaniID??source.bani_id??source.id??source.ID??( /^\d+$/.test(key)?key:undefined);
  const id=Number(val);
  const titlePa=toName(source.unicodeBaniName||source.gurmukhiUni||source.gurmukhi||source.titlePa||source.pa||source.namePa||source.baniNameGurmukhi);
  const titleEn=toName(source.baniName||source.englishBaniName||source.name||source.titleEn||source.english||source.en||source.transliterations?.en||source.transliterations?.english);
  if(Number.isInteger(id)&&id>0&&(titlePa||titleEn)){
   const old=found.get(id)||{};
   found.set(id,{id,titlePa:titlePa||old.titlePa||'',titleEn:titleEn||old.titleEn||''});
  }
  if(Array.isArray(node))node.forEach(x=>read(x,'',depth+1));
  else for(const [k,v] of Object.entries(node))if(v&&typeof v==='object')read(v,k,depth+1);
 }
 read(raw);
 return [...found.values()].sort((a,b)=>a.id-b.id);
}
function shape(x){
 if(Array.isArray(x))return `array(length=${x.length}, first=${shape(x[0])})`;
 if(x&&typeof x==='object')return `object(keys=${Object.keys(x).slice(0,12).join(',')})`;
 return typeof x;
}
async function request(uri){
 let last;
 for(let n=1;n<=7;n++){
  const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),45000);
  try{const resp=await fetch(BASE+uri,{signal:ctrl.signal,headers:{Accept:'application/json','User-Agent':'Gurbani-Saanjh-Private-Trial/1.6.1'}});
   if(!resp.ok)throw Error(`HTTP ${resp.status}`);
   return await resp.json();
  }catch(e){last=e;if(n<7)await sleep(Math.min(20000,(n*n*500)+Math.floor(Math.random()*800)))}
  finally{clearTimeout(timer)}
 }
 throw Error(`BaniDB ${uri} unavailable after retries: ${last}`);
}
async function save(kind,id,lines){await fs.mkdir(path.join(OUT,kind),{recursive:true});await fs.writeFile(path.join(OUT,kind,`${id}.json`),JSON.stringify({lines,origin:`${BASE}/${kind==='ang'?'angs/'+id+'/G':'banis/'+id}`,fetchedAt:new Date().toISOString()}));}
async function pool(items,limit,fn){let next=0,errors=[];await Promise.all(Array.from({length:limit},async()=>{while(next<items.length){const item=items[next++];try{await fn(item)}catch(e){errors.push(`${item}: ${e.message}`)}}}));if(errors.length)throw Error(`${errors.length} scripture requests failed:\n${errors.slice(0,20).join('\n')}`)}
async function main(){
 await fs.rm(OUT,{recursive:true,force:true});await fs.mkdir(OUT,{recursive:true});
 const rawList=await request('/banis');
 const all=index(rawList);
 if(all.length<20)throw Error(`Bani index only parsed ${all.length} entries (response: ${shape(rawList)}). No incomplete APK will be built. Check the BaniDB response schema / network content.`);
 const ids=[...new Set(all.map(x=>x.id))];
 // The seven Nitnem IDs already present in the application must exist in this snapshot.
 const nitnem=[2,4,6,9,10,21,23];for(const id of nitnem)if(!ids.includes(id))throw Error(`Nitnem Bani ID ${id} missing from source list`);
 const concurrency=Math.min(10,Math.max(1,Number(process.env.GS_FETCH_CONCURRENCY)||6));
 console.log(`Downloading all 1,430 SGGS Angs and ${ids.length} available Sundar Gutka Banis. Concurrency ${concurrency}`);
 let angTotal=0,baniTotal=0;const searchRows=[];
 await pool(Array.from({length:1430},(_,i)=>i+1),concurrency,async id=>{const lines=normalize(await request(`/angs/${id}/G`));if(!lines.length)throw Error('no Unicode Gurmukhi lines parsed from API response'); await save('ang',id,lines);for(let idx=0;idx<lines.length;idx++){const v=lines[idx];searchRows.push([id,idx,v.g,v.en||'',v.pa||'',v.roman||''])}angTotal++;if(angTotal%100===0)console.log(`Angs ${angTotal}/1430`)});
 await pool(ids,concurrency,async id=>{const lines=normalize(await request(`/banis/${id}`));if(!lines.length)throw Error('no Unicode Gurmukhi lines parsed from API response');await save('bani',id,lines);baniTotal++});
 if(searchRows.length<20000)throw Error(`Only ${searchRows.length} SGGS verses indexed: incomplete corpus or unexpected response schema`);
 searchRows.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
 await fs.writeFile(path.join(OUT,'search.json'),JSON.stringify(searchRows));
 for(const id of nitnem){const x=JSON.parse(await fs.readFile(path.join(OUT,'bani',`${id}.json`),'utf8'));if(!x.lines.length)throw Error(`Nitnem ${id} incomplete`)}
 const manifest={source:'BaniDB',license:'NPOSL-3.0',licenseUrl:'https://banidb.com',version:'1.6.1',angCount:angTotal,baniCount:baniTotal,searchVerseCount:searchRows.length,banis:all.filter(x=>ids.includes(x.id)),builtAt:new Date().toISOString()};
 await fs.writeFile(path.join(OUT,'manifest.json'),JSON.stringify(manifest));
 await fs.copyFile('SOURCE_AND_LICENSE.md',path.join(OUT,'SOURCE_AND_LICENSE.md'));
 console.log(`SUCCESS: ${angTotal} / 1430 Angs, ${baniTotal} Sundar Gutka Banis, ${searchRows.length} searchable lines packaged for offline reading.`);
}
if(process.argv.includes('--fixture')){
 const flat={verses:[{verse_id:1,verse:'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ॥',steek:{en:{bdb:'One creator.'},pu:{ss:{unicode:'ਇੱਕ ਪ੍ਰਭੂ ਹੈ।'}}},translit:{en:'Ik Oankaar Sat Naam'}}]};
 const nested={verses:[{verse:{verseId:2,verse:{unicode:'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ॥',gurmukhi:'socY soc n hoveI'},visraam:{sttm:[{p:0,t:'y'}]},translation:{en:{bdb:'Thinking alone is insufficient.'}},transliteration:{en:'Sochai soch na hovai'}}}]};
 const names=index({banis:[{baniID:2,unicodeBaniName:'ਜਪੁਜੀ ਸਾਹਿਬ',baniName:'Japji Sahib'},{baniID:4,unicodeBaniName:'ਜਾਪੁ ਸਾਹਿਬ',baniName:'Jaap Sahib'}]});
 const names2=index({data:{banis:{'2':{unicodeBaniName:'ਜਪੁਜੀ ਸਾਹਿਬ',baniName:'Japji Sahib'},'4':{unicodeBaniName:'ਜਾਪੁ ਸਾਹਿਬ',baniName:'Jaap Sahib'}}}});
 const lines=normalize(flat),nestedLines=normalize(nested);
 if(names.length!==2||names[0].id!==2||names2.length!==2||lines.length!==1||!lines[0].g.includes('ੴ')||lines[0].en!=='One creator.'||lines[0].pa!=='ਇੱਕ ਪ੍ਰਭੂ ਹੈ।'||!lines[0].roman||nestedLines.length!==1||!nestedLines[0].g.includes('ਸੋਚੈ')||nestedLines[0].vishraam[0]!=='short')throw Error('Offline importer fixture failed');
 console.log('Offline importer fixtures passed: flat and nested verse records, array and dictionary Bani indexes');
}else await main().catch(e=>{console.error(e);process.exit(1)});
