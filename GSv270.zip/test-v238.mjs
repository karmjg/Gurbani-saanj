/* Gurbani Saanj v2.2.18 — scroll Bani spacing minimum + AI answer verse
 * bold/highlight + zoom (node, offline).
 *  The aiAnswerHTML verse detection is run in a VM against real interleaved
 *  AI answers: verse lines (Ang number / verse-number marker) get the
 *  ai-verse span; explanation lines do not.
 * Run: node test-v238.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.18', vj.version === '2.2.18');
ok('package.json is 2.2.18', pj.version === '2.2.18');

// ---- 1. Scroll Bani spacing minimum ----
ok('Bani scroll paragraph gap is minimal', css.includes('.gs-reader-bani #verses .gs-bani-para{margin-bottom:.22em!important;}'));
ok('Bani scroll paragraph line-height is tight', css.includes('.gs-reader-bani #verses .gs-bani-para .verse-text{line-height:1.38!important;}'));

// ---- 2. AI answer verse bold/highlight + zoom ----
ok('aiAnswerHTML helper exists', app.includes('function aiAnswerHTML(answer){'));
ok('renderQA uses aiAnswerHTML', app.includes('<p class="ai-answer">${aiAnswerHTML(v.answer)}</p>'));
ok('ai-verse CSS: bold + highlighted', css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
ok('ai-answer font is zoomable (--ai-font)', css.includes('.ai-answer{white-space:pre-wrap;line-height:1.7;font-size:var(--ai-font,18px);'));
ok('aiFont state default 18 + normalized 14-32', app.includes("aiFont:18") && app.includes("state.aiFont=Math.min(32,Math.max(14,Number(state.aiFont)||18))"));
ok('aiFont in backup permitted list', app.includes("'aiFont','searchHistory'"));
ok('--ai-font set in theme()', app.includes("html.style.setProperty('--ai-font',(Number(state.aiFont)||18)+'px');"));
ok('Ask screen has A-/A+ zoom buttons', app.includes('data-ai-zoom="-2"') && app.includes('data-ai-zoom="2"'));
ok('zoom click handler adjusts aiFont + persists', app.includes("const aiZoom=e.target.closest('[data-ai-zoom]');") && app.includes('state.aiFont=Math.min(32,Math.max(14,(Number(state.aiFont)||18)+Number(aiZoom.dataset.aiZoom)))'));

// ---- VM: aiAnswerHTML on real interleaved answers ----
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const start = app.indexOf('function aiAnswerHTML(answer){');
const end = app.indexOf('function renderQA(v){');
const src = app.slice(start, end);
const ctx = vm.createContext({ esc, console });
vm.runInContext(src + '\n;globalThis.__ai=aiAnswerHTML;', ctx);
const ai = ctx.__ai;

const ans1 = `ਗੁਰੁ ਈਸਰੁ ਗੁਰੁ ਗੋਰਖੁ ਬਰਮਾ ਗੁਰੁ ਪਾਰਬਤੀ ਮਾਈ ॥ (Ang 2)
ਗੁਰੂ ਸਭ ਕੁਝ ਹੈ — ਉਹ ਈਸਰ, ਗੋਰਖ ਅਤੇ ਬ੍ਰਹਮਾ ਵਰਗਾ ਹੈ।
ਸਤਿਗੁਰੁ ਸਿਖ ਕਉ ਨਾਮ ਧਨੁ ਦੇਇ ॥ (Ang 286)
ਗੁਰੂ ਸਿੱਖ ਨੂੰ ਨਾਮ ਦਾ ਧਨ ਦਿੰਦਾ ਹੈ।
ਸਾਰ: ਗੁਰੂ ਤੋਂ ਬਿਨਾਂ ਗਿਆਨ ਨਹੀਂ ਮਿਲਦਾ।`;
const out1 = ai(ans1);
ok('verse line with Ang number is wrapped', out1.includes('<span class="ai-verse">ਗੁਰੁ ਈਸਰੁ ਗੁਰੁ ਗੋਰਖੁ ਬਰਮਾ ਗੁਰੁ ਪਾਰਬਤੀ ਮਾਈ ॥ (Ang 2)</span>'));
ok('second verse line is wrapped', out1.includes('<span class="ai-verse">ਸਤਿਗੁਰੁ ਸਿਖ ਕਉ ਨਾਮ ਧਨੁ ਦੇਇ ॥ (Ang 286)</span>'));
ok('Punjabi explanation is NOT wrapped', out1.includes('ਗੁਰੂ ਸਭ ਕੁਝ ਹੈ — ਉਹ ਈਸਰ, ਗੋਰਖ ਅਤੇ ਬ੍ਰਹਮਾ ਵਰਗਾ ਹੈ।') && !out1.includes('<span class="ai-verse">ਗੁਰੂ ਸਭ ਕੁਝ ਹੈ'));
ok('saar line is NOT wrapped', out1.includes('ਸਾਰ: ਗੁਰੂ ਤੋਂ ਬਿਨਾਂ ਗਿਆਨ ਨਹੀਂ ਮਿਲਦਾ।') && !out1.includes('<span class="ai-verse">ਸਾਰ:'));

const ans2 = `ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥੧॥
Thinking a hundred thousand times does not bring understanding.
This is an English explanation line.`;
const out2 = ai(ans2);
ok('verse line with ||N|| marker is wrapped', out2.includes('<span class="ai-verse">ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥੧॥</span>'));
ok('English explanation is NOT wrapped', out2.includes('Thinking a hundred thousand times does not bring understanding.') && !out2.includes('<span class="ai-verse">Thinking'));
ok('HTML in the answer is escaped, not injected', !ai('<script>alert(1)</script>').includes('<script>alert'));

// ---- Regression ----
ok('v2.2.17: voice persistent listeners intact', app.includes('let voiceRun=null;') && app.includes('async function ensureVoiceListeners(){'));
ok('v2.2.17: sawStarted guard intact', app.includes("if(run.sawStarted)run.finish()"));
ok('v2.2.16: original emoji mic kept', app.includes('Voice search\')}">🎙</button>'));
ok('v2.2.16: green-ring listening kept', css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{box-shadow:0 0 0 2px #14532d'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'") && app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('v2.2.15: Hukamnama follows settings', !app.includes('en:true,pa:true'));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){'));
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines', app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
