/* Gurbani Saanj v2.2.44 — SIX changes (includes ALL of v2.2.43).
 * (1) Typo fixed: two lines said ਪੁਬ where ਪ੍ਰਭ belongs (Ang 1396 + Ang 1405,
 * Gurmukhi + transliteration, reader + search). ਪੁਬਿ/ਪੁਬਲੀ are real words
 * and stay untouched.
 * (2) Voice search finds the right line even when mispronounced: matra-
 * tolerant skeleton matching (score 115) + longest-consecutive-words run
 * (up to 112), so the intended pangti ranks FIRST. All 5 spec queries pass.
 * (3) Mic listeners register at app startup, so the FIRST tap works.
 * (4) Mic segment restart no longer waits for the native 'started' event —
 * beginSegment marks sawStarted after startOnce() succeeds, so the mic
 * keeps listening past a few words and never misses anything.
 * (5) The ♡ save button now shows on the MAIN search results (it was only
 * on the Kirtan screen's search) — tap ♡ to save, ♥ again to remove.
 * (6) Delete search history: a Clear all button in the history box and an
 * × on each item; tapping a query still re-runs the search.
 * Run: node test-v264.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.44', vj.version === '2.2.44');
ok('package.json is 2.2.44', pj.version === '2.2.44');
ok('version notes mention v2.2.33 + continuous listening + X stops mic',
  vj.notes.includes('v2.2.33:') && vj.notes.includes('listens continuously') && vj.notes.includes('stops the mic for real'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.35 + the 3 changes',
  vj.notes.includes('v2.2.35:') && vj.notes.includes('#fdfcf9') && vj.notes.includes('Noto Serif Gurmukhi') && vj.notes.includes('pack tight') && vj.notes.includes('Font size is unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.36 + centred search line',
  vj.notes.includes('v2.2.36:') && vj.notes.includes('middle of the screen') && vj.notes.includes('Page-turn, home and Kirtan jumps are unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.37 + brand language + Muse-style Stop',
  vj.notes.includes('v2.2.37:') && vj.notes.includes('Gurbani Saanjh') && vj.notes.includes('Stop button') && vj.notes.includes('keeps listening until you press Stop'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.38 + compact Hukamnama card',
  vj.notes.includes('v2.2.38:') && vj.notes.includes('more compact') && vj.notes.includes('21px') && vj.notes.includes('All card content is kept'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.39 + AnmolUni + weight 400',
  vj.notes.includes('v2.2.39:') && vj.notes.includes('AnmolUni') && vj.notes.includes('weight 400'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.40 + mic-as-Stop + iGranth transliteration colours',
  vj.notes.includes('v2.2.40:') && vj.notes.includes('Stop sign') && vj.notes.includes('#0d0445') && vj.notes.includes('#f3541d') && vj.notes.includes('transliteration OFF'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.41 + pairs two-per-line like iGranth',
  vj.notes.includes('v2.2.41:') && vj.notes.includes('pair two-per-line') && vj.notes.includes('ਨਮਸਤੁੰ') && vj.notes.includes('fills the width'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.41 + font-colour option Blue/Black + auto-blue removed',
  vj.notes.includes('font-colour option') && vj.notes.includes('Blue / Black') && vj.notes.includes('auto-blue') && vj.notes.includes('#202a26'),
  vj.notes.slice(-200));

ok('version notes mention v2.2.42 + mic auto-stop on result tap + Roman bigger + one layer-size control',
  vj.notes.includes('v2.2.42:') && vj.notes.includes('stops by itself') && vj.notes.includes('80%') &&
  vj.notes.includes('ONE size control') && vj.notes.includes('default 80%'));

ok('version notes mention v2.2.43 + hidden AI settings in Play Store build + cloud still default',
  vj.notes.includes('v2.2.43:') && vj.notes.includes('hidden in the Play Store build') &&
  vj.notes.includes('GS_HIDE_AI_SETTINGS') && vj.notes.includes('Ask still works'));

ok('version notes mention v2.2.44 + all six changes',
  vj.notes.includes('v2.2.44:') && vj.notes.includes('ਪੁਬ where ਪ੍ਰਭ belongs') &&
  vj.notes.includes('Ang 1396 and Ang 1405') && vj.notes.includes('mispronounced') &&
  vj.notes.includes('first tap works') && vj.notes.includes('never misses anything') &&
  vj.notes.includes('♡ save button') && vj.notes.includes('Clear all') &&
  vj.notes.includes('× on each item'));

// ---- 1. Static wiring for the fix ----
ok('voiceStopRequested flag exists', app.includes('let voiceStopRequested=false;'));
ok('partial listener accumulates into heard.seg/parts',
  app.includes('run.heard.seg') && app.includes('run.heard.parts') && app.includes('run.heard.text=[...run.heard.parts,run.heard.seg]'));
ok('listener ends a SEGMENT on stop (no run.finish)', app.includes('run.endSegment()') && !app.includes('run.finish()'));
ok('beginSegment + auto-restart loop present',
  app.includes('const beginSegment=async()=>') && app.includes('if(!(await beginSegment()))break;'));
ok('resetVoiceNow flags manual stop', app.includes('voiceStopRequested=true;') && app.includes('if(run)run.manualStopped=true;'));
ok('runEnded guard checks safety+manual+flag+current',
  app.includes('const runEnded=()=>run.safetyStopped||run.manualStopped||voiceStopRequested||voiceRun!==run;'));
ok('v2.2.37: no 15s cap left (no 15000 timer anywhere)', !app.includes('},15000);'));
ok('4s no-heard timer still present', app.includes('noHeardTimer') && app.includes('},4000);'));
ok('pa-IN -> en-US fallback still present', app.includes("native.start(opts('pa-IN'))") && app.includes("native.start(opts('en-US'))"));
ok('maxResults:5 + partialResults:true unchanged', app.includes('maxResults:5') && app.includes('partialResults:true'));
ok('X handler no longer restarts the mic', (() => {
  const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick'));
  return !!l && !l.includes('startVoiceSearch');
})());
ok('web fallback restarts on onend + accumulates',
  app.includes('rec.onend=()=>{') && app.includes("try{rec.start();}catch(e){finish(best);}"));
ok('web fallback respects manual stop (dead() checks voiceStopRequested + run sequence)',
  app.includes('const dead=()=>voiceStopRequested||mySeq!==voiceRunSeq;') && app.includes('if(finished||dead())return;'));

// ---- 1b. Static wiring for the v2.2.33 stale-event fix ----
ok('stale fix: resetVoiceNow returns a teardown promise (600ms backstop)',
  app.includes('voiceStopPromise=new Promise') && app.includes('to=setTimeout(finish,600);'));
ok('stale fix: teardown resolves on the old run\'s stopped event',
  app.includes('voiceStoppingRun') && app.includes("run._stopResolve=finish;"));
ok('stale fix: startVoiceSearch awaits the old run teardown before starting',
  app.includes('if(searchVoiceBusy){await resetVoiceNow();}'));
ok('stale fix: partialResults guard requires current + started + not manually stopped',
  app.includes('if(!run.started||run.manualStopped||voiceStopRequested)return;'));
ok('stale fix: listeningState guard requires started before endSegment',
  app.includes('if(run.sawStarted&&run.started)run.endSegment();'));
ok('stale fix: new voice run clears the search results area',
  app.includes("if(input.id==='searchInput'){const out=$('searchResults');if(out)out.innerHTML='';}"));
ok('stale fix: run sequence invalidates a dead run (voiceRunSeq)',
  app.includes('let voiceRunSeq=0;') && app.includes('const mySeq=++voiceRunSeq;') && app.includes('if(mySeq!==voiceRunSeq)return;'));
ok('stale fix: dead run cannot fill or set Review status',
  app.includes('if(mySeq===voiceRunSeq){\n     if(!heard.text.trim())throw Error'));
ok('stale fix: dead run finally cannot clear the new run state',
  app.includes('if(mySeq===voiceRunSeq){clearVoiceWatchdog();searchVoiceBusy=false;}'));

// ---- 2. Voice VM harness (fake clock + stubbed recognizers) ----
const _voiceLines = app.split('\n');
const _voiceStart = _voiceLines.findIndex(l => l.startsWith('let searchVoiceBusy=false;'));
const _voiceEnd = _voiceLines.findIndex((l, i) => i > _voiceStart && l.startsWith('// Settings "Test microphone"'));
const voiceSlice = _voiceLines.slice(_voiceStart, _voiceEnd).join('\n');
ok('voice slice extracted (searchVoiceBusy..startVoiceSearch)',
  voiceSlice.includes('async function startVoiceSearch') && voiceSlice.includes('function resetVoiceNow'));

function makeClock() {
  let now = 0, next = 1; const timers = new Map();
  const setTimeout = (fn, ms, ...args) => { const id = next++; timers.set(id, { fn, at: now + Math.max(0, ms || 0), args }); return id; };
  const clearTimeout = id => { timers.delete(id); };
  const advance = ms => {
    const end = now + ms; let guard = 0;
    while (guard++ < 20000) {
      let best = null, bestAt = Infinity;
      for (const [id, t] of timers) { if (t.at <= end && t.at < bestAt) { best = id; bestAt = t.at; } }
      if (best === null) break;
      now = bestAt; const t = timers.get(best); timers.delete(best); t.fn(...t.args);
    }
    now = end;
  };
  return { setTimeout, clearTimeout, advance, pending: () => timers.size, get now() { return now; } };
}
async function drive(clock, ms, step = 15) {
  const target = clock.now + ms;
  while (clock.now < target) {
    clock.advance(Math.min(step, target - clock.now));
    await new Promise(r => setImmediate(r));
    await new Promise(r => setImmediate(r));
  }
}
function fakeEl() {
  const classes = new Set();
  return {
    disabled: false, textContent: '', value: '',
    classList: {
      toggle(c, f) { if (f === undefined) { if (classes.has(c)) classes.delete(c); else classes.add(c); } else if (f) classes.add(c); else classes.delete(c); },
      add(c) { classes.add(c); },
      remove(c) { classes.delete(c); },
      contains(c) { return classes.has(c); },
    },
    dispatchEvent() {},
  };
}

// Stub native recognizer. script: array of utterances; each is an array of
// growing partial strings, or {delay, partials} for a late utterance.
// A start() with no scripted utterance emits 'started' and stays listening.
// stop() models a real recognizer: it cancels any pending partial/'stopped'
// timers for that run (a stopped recognizer emits no more events for it) and
// confirms 'stopped' asynchronously (stopDelay ms later), so the teardown
// promise resolves on the event, not on the stop() call. emit() lets a test
// inject a stale event from an old run after a new run started.
function makeStubNative(clock, script, opts = {}) {
  const listeners = {};
  const calls = { start: [], stop: 0, startAt: [], addListener: {} };
  let startCount = 0;
  let pending = [];
  const emit = (ev, data) => { (listeners[ev] || []).forEach(cb => { try { cb(data); } catch (e) { console.error('listener error', e); } }); };
  const stub = {
    available: async () => ({ available: true }),
    checkPermissions: async () => ({ speechRecognition: opts.perm || 'granted' }),
    requestPermissions: async () => ({ speechRecognition: opts.requestPerm || 'granted' }),
    addListener: (ev, cb) => { calls.addListener[ev] = (calls.addListener[ev] || 0) + 1; (listeners[ev] = listeners[ev] || []).push(cb); return Promise.resolve(); },
    start: async (o) => {
      calls.start.push(o && o.language);
      calls.startAt.push(clock.now);
      const idx = startCount++;
      if (opts.failPaIN && o && o.language === 'pa-IN') throw new Error('pa-IN unavailable');
      const raw = script[idx] || [];
      const delay = Array.isArray(raw) ? 0 : (raw.delay || 0);
      const utt = Array.isArray(raw) ? raw : (raw.partials || []);
      // v2.2.44: opts.noStarted simulates Karamjit's phone — the native
      // 'started' event does NOT fire on a restarted segment. The segment
      // loop must still restart (beginSegment marks sawStarted itself).
      if (!opts.noStarted) pending.push(clock.setTimeout(() => emit('listeningState', { status: 'started' }), 5));
      utt.forEach((p, i) => { pending.push(clock.setTimeout(() => emit('partialResults', { matches: [p] }), delay + 10 + i * 15)); });
      if (utt.length) pending.push(clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), delay + 10 + utt.length * 15 + 10));
      return;
    },
    stop: () => {
      calls.stop++;
      pending.forEach(id => clock.clearTimeout(id)); pending = [];
      clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), opts.stopDelay ?? 50);
      return Promise.resolve();
    },
    emit,
    _calls: calls,
  };
  return stub;
}

function makeNativeCtx(script, opts = {}) {
  const clock = makeClock();
  const stub = makeStubNative(clock, script, opts);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(),  };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { GS_SPEECH: stub, GS_NATIVE_UPDATES: { isNative: true } },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, stub, input, els, state, sandbox };
}
function readRun(ctx) {
  vm.runInContext('this.__r={run:voiceRun,busy:searchVoiceBusy,stopReq:voiceStopRequested};', ctx);
  return ctx.__r;
}

// Fake Web SpeechRecognition (for the fallback path). One instance; start()
// is called repeatedly on it, each call playing script[idx].
function makeFakeSR(clock, script) {
  const shared = { instances: [] };
  class FakeSR {
    constructor() { this.lang = ''; this.interimResults = false; this.maxAlternatives = 0; this.onresult = null; this.onerror = null; this.onend = null; this._n = 0; shared.instances.push(this); }
    start() {
      const idx = this._n++;
      const utt = script[idx] || [];
      utt.forEach((p, i) => { clock.setTimeout(() => { if (this.onresult) this.onresult({ results: [[{ transcript: p }]] }); }, 10 + i * 15); });
      if (utt.length) clock.setTimeout(() => { if (this.onend) this.onend(); }, 10 + utt.length * 15 + 10);
    }
    stop() { clock.setTimeout(() => { if (this.onend) this.onend(); }, 5); }
  }
  return { FakeSR, shared };
}
function makeWebCtx(script) {
  const clock = makeClock();
  const sr = makeFakeSR(clock, script);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(),  };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { SpeechRecognition: sr.FakeSR },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, sr, input, els, state, sandbox };
}

// ---- 3. Behavioral voice tests (async, fake clock) ----
let p;
// (a) Auto-restart accumulates ALL words across segments (the reported bug)
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(a) auto-restart: all 6 words in the input after 2 segments',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(a) auto-restart: recognizer started 3 times (initial + 2 restarts)',
    t.stub._calls.start.length === 3, JSON.stringify(t.stub._calls.start));
  // v2.2.37: no 15s cap — the run must still be listening long past it.
  await drive(t.clock, 30000);
  ok('(a) v2.2.37: no 15s cap — still listening after 30s (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(a) v2.2.37: no restart storm while waiting (start count stays 3)',
    t.stub._calls.start.length === 3, `starts=${t.stub._calls.start.length}`);
  // Stop ends it right away, words intact.
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(a) v2.2.37: Stop settles the run with the 6 words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(a) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r.run === null && r.busy === false, JSON.stringify(r));
}
// (b) Manual stop (X / resetVoiceNow) — no restart after it
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(b) before stop: 3 words heard, recognizer restarted once',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ' && t.stub._calls.start.length === 2,
    `value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  vm.runInContext('resetVoiceNow()', t.ctx);
  const startsAtStop = t.stub._calls.start.length;
  await drive(t.clock, 3000);
  ok('(b) manual stop: no restart after X (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(b) manual stop: the 3 words stay in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
  await drive(t.clock, 2000);
  ok('(b) v2.2.37: run resolves promptly after manual stop (Stop ends the wait, no safety timer)',
    settled === true, `settled=${settled}`);
}
// (c) v2.2.37: NO 15s cap — the run keeps listening past 15s and past 30s,
// and only Stop ends it.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1000);
  const r1 = readRun(t.ctx);
  ok('(c) run listening after the first segment (voiceRun set, busy)',
    r1.run !== null && r1.busy === true, JSON.stringify({ run: !!r1.run, busy: r1.busy }));
  await drive(t.clock, 30000);
  ok('(c) v2.2.37: still listening after 30s — no 15s cap (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(c) v2.2.37: no restart while waiting (start count stays 2)',
    t.stub._calls.start.length === 2, `starts=${t.stub._calls.start.length}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(c) v2.2.37: Stop ends the run with the words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  const r2 = readRun(t.ctx);
  ok('(c) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r2.run === null && r2.busy === false, JSON.stringify(r2));
}
// (d) 4s no-heard notice, then recovery when words arrive
{
  const t = makeNativeCtx([
    { delay: 5000, partials: ['ਸਤਿਨਾਮੁ'] },
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 4500);
  ok('(d) 4s no-heard notice fires when nothing is heard',
    t.els.voiceStatus.textContent.includes('not hearing'),
    JSON.stringify(t.els.voiceStatus.textContent));
  await drive(t.clock, 1500);
  ok('(d) status returns to Listening when words arrive',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(d) the word is captured after the notice',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (e) Permission denied + pa-IN -> en-US fallback
{
  const t = makeNativeCtx([], { perm: 'denied', requestPerm: 'denied' });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 500);
  ok('(e1) permission denied: status explains it',
    t.els.voiceStatus.textContent.includes('permission was denied'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(e1) permission denied: recognizer never started',
    t.stub._calls.start.length === 0, `starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(e1) permission denied: mic button re-enabled, not busy',
    r.busy === false && t.els.voiceBtn.disabled === false, JSON.stringify({ busy: r.busy, disabled: t.els.voiceBtn.disabled }));
}
{
  const t = makeNativeCtx([[], ['ਸਤਿਨਾਮੁ']], { failPaIN: true });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 800);
  ok('(e2) pa-IN fails -> en-US fallback is tried',
    t.stub._calls.start[0] === 'pa-IN' && t.stub._calls.start[1] === 'en-US',
    JSON.stringify(t.stub._calls.start));
  ok('(e2) fallback run hears words on the en-US start',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) Web Speech fallback accumulates across onend restarts
{
  const t = makeWebCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(f) web fallback: all 6 words after 2 onend restarts',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(f) web fallback: recognizer started 3 times',
    t.sr.shared.instances[0]._n === 3, `starts=${t.sr.shared.instances[0]._n}`);
  // v2.2.37: no 15s cap on the web path either.
  await drive(t.clock, 30000);
  ok('(f) v2.2.37: web fallback still listening after 30s (not settled)',
    settled === false && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(f) v2.2.37: web fallback Stop settles the run with the 6 words',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// (g) v2.2.40: the mic button ITSELF becomes the Stop sign while listening
// (no separate Stop button) and stops right away when tapped.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  ok('(g) mic button shows the Stop sign while listening (⏹, not 🎙)',
    t.els.voiceBtn.textContent === '⏹',
    JSON.stringify(t.els.voiceBtn.textContent));
  ok('(g) mic button has the listening class while listening',
    t.els.voiceBtn.classList.contains('gs-listening') === true,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  ok('(g) status shows Listening while listening',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(g) mic button itself is not disabled while listening (it IS the Stop button)',
    t.els.voiceBtn.disabled === false,
    JSON.stringify(t.els.voiceBtn.disabled));
  const startsAtStop = t.stub._calls.start.length;
  vm.runInContext('stopVoiceSearch()', t.ctx);
  // Immediate: the listening UI turns off synchronously with the Stop tap.
  ok('(g) Stop turns the mic back to the mic icon at once (⏹ -> 🎙)',
    t.els.voiceBtn.textContent === '🎙',
    JSON.stringify(t.els.voiceBtn.textContent));
  ok('(g) Stop turns the listening class off at once',
    t.els.voiceBtn.classList.contains('gs-listening') === false,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  await drive(t.clock, 2000);
  ok('(g) Stop settles the run right away',
    settled === true, `settled=${settled}`);
  ok('(g) no restart after Stop (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(g) Stop keeps the spoken words in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
}
// (h) v2.2.40: after a re-render (fresh button elements), the mic button
// still shows Stop while a run is listening.
{
  const t = makeNativeCtx([['ਸਤਿਨਾਮੁ']]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  // Simulate a re-render: the mic button is recreated with the plain 🎙 icon.
  t.els.voiceBtn = fakeEl(); t.els.voiceBtn.textContent = '🎙';
  t.els.askVoiceBtn = fakeEl(); t.els.askVoiceBtn.textContent = '🎙';
  ok('(h) fresh mic button shows the mic icon before sync',
    t.els.voiceBtn.textContent === '🎙' && t.els.voiceBtn.classList.contains('gs-listening') === false,
    JSON.stringify(t.els.voiceBtn.textContent));
  vm.runInContext('syncVoiceStopUI()', t.ctx);
  ok('(h) sync restores the Stop sign on the fresh mic button while listening',
    t.els.voiceBtn.textContent === '⏹' && t.els.voiceBtn.classList.contains('gs-listening') === true,
    JSON.stringify(t.els.voiceBtn.textContent));
  vm.runInContext('stopVoiceSearch()', t.ctx);
  ok('(h) Stop after re-render turns the mic back to 🎙 at once',
    t.els.voiceBtn.textContent === '🎙',
    JSON.stringify(t.els.voiceBtn.textContent));
  await drive(t.clock, 2000);
  ok('(h) Stop after re-render settles the run with the word intact',
    settled === true && t.input.value.includes('ਸਤਿਨਾਮੁ'),
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// ---- 4. v2.2.32 regressions (static — the full suite also runs in test-v252) ----
ok('regression v2.2.32: AI language follows app language (aiLangManual sync)',
  app.includes('aiLangManual') && app.includes("if(!state.aiLangManual)state.aiLang=state.lang;"));
ok('regression v2.2.32: transliteration in search results',
  app.includes('gs-result-roman') && ss.includes("roman:String(roman||'')"));
ok('regression v2.2.32: cloud AI by default',
  app.includes("AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev'"));
ok('regression v2.2.31: elaborate prompt + Dasam Granth in worker',
  worker.includes('Dasam Granth') && worker.includes('1500') && worker.includes('total essence'));
ok('regression v2.2.30: Hindi absent, English in search results, font slider',
  !app.includes('showHi') && app.includes('gs-result-en') && app.includes('fontSlider'));
ok('regression v2.2.28: search source labels',
  app.includes('gs-result-bani-tag') && app.includes('Dasam Granth'));
ok('regression v2.2.27: reader top bar hide/show',
  app.includes('barScrollDecision') && app.includes('readerBarHidden'));
ok('regression v2.2.26: centered Bani headings, pinch Ask-only',
  css.includes('text-align:center') && app.includes('pinchFont') && app.includes('pinchDist'));
ok('regression: voice permission flow (fast path + listeners once)',
  app.includes('voicePermGranted') && app.includes('ensureVoiceListeners'));

// ---- 5. v2.2.33 stale-event fix (behavioral) ----
// Helper: drive 1ms at a time until a voice run exists (voiceRun set).
// Catches the window after a new run is created but before its 'started'
// event fires (5ms after start()).
async function waitForRun(t, maxMs = 300) {
  for (let i = 0; i < maxMs; i++) {
    if (readRun(t.ctx).run) return true;
    await drive(t.clock, 1, 1);
  }
  return !!readRun(t.ctx).run;
}
// (a) Delayed partial from run A arriving after run B started is IGNORED
{
  const t = makeNativeCtx([
    { delay: 300, partials: ['WORD1'] },
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 100);
  // X: reset stops run A (its pending partial at 310ms is cancelled) + start B.
  vm.runInContext('resetVoiceNow()', t.ctx);
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(a) stale partial: run B keeps ONLY its own words (WORD1 never appears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(a) stale partial: WORD1 never appears even after the full run',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
}
// (a2) Guard: a partial injected after run B is created but before its
// 'started' event is ignored (the started check).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(a2) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale partial from run A right now (run B not started yet).
  t.stub.emit('partialResults', { matches: ['WORD1'] });
  await drive(t.clock, 600);
  ok('(a2) guard: stale partial before started is ignored',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (b) Delayed 'stopped' from run A arriving after run B started does NOT
// end run B's segment (run B keeps listening).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(b) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale 'stopped' from run A right now (run B not started yet).
  t.stub.emit('listeningState', { status: 'stopped' });
  await drive(t.clock, 600);
  const r = readRun(t.ctx);
  ok('(b) stale stopped: run B keeps listening and hears its own words',
    t.input.value === 'WORD2' && r.run !== null && r.busy === true,
    `value=${JSON.stringify(t.input.value)} run=${!!r.run} busy=${r.busy}`);
  await drive(t.clock, 17000);
}
// (c) X -> tap mic -> speak word 2 gives ONLY word 2's results
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  ok('(c) word 1 heard first', t.input.value === 'WORD1', JSON.stringify(t.input.value));
  // X: reset + clear the input (what the X handler does).
  vm.runInContext('resetVoiceNow()', t.ctx);
  t.input.value = '';
  // Tap the mic again and speak word 2.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(c) X -> mic -> word 2: ONLY word 2 in the input (word 1 never reappears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(c) X -> mic -> word 2: word 1 still absent after the full run',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
}
// (d) v2.2.37: a run that hears nothing does NOT end by itself — it keeps
// listening until Stop; Stop settles it and the mic button is re-enabled.
{
  const t = makeNativeCtx([[]]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 20000);
  ok('(d) v2.2.37: nothing heard yet the run keeps listening (not settled)',
    settled === false && readRun(t.ctx).run !== null,
    `settled=${settled}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d) v2.2.37: Stop settles the empty run',
    settled === true, `settled=${settled}`);
  const r = readRun(t.ctx);
  ok('(d) v2.2.37: mic button re-enabled, not busy, run cleaned up after Stop',
    r.busy === false && r.run === null && t.els.voiceBtn.disabled === false,
    `settled=${settled} busy=${r.busy} run=${!!r.run} disabled=${t.els.voiceBtn.disabled}`);
  ok('(d) v2.2.37: input stays empty after Stop with nothing heard',
    t.input.value === '', JSON.stringify(t.input.value));
}
// (e) Starting a new voice run clears the previous search results.
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  // The results area (not in the default els) — add it so the clear is visible.
  t.els.searchResults = { innerHTML: '' };
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  // Simulate run A's search results sitting in the results area.
  t.els.searchResults.innerHTML = '<div>old results for WORD1</div>';
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 600);
  ok('(e) new voice run clears the previous search results',
    t.els.searchResults.innerHTML === '', JSON.stringify(t.els.searchResults.innerHTML));
  ok('(e) new run still hears its own words',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) A mic tap while busy waits for the old run to fully stop before the
// new run starts (serialized, no overlap).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  const tapAt = t.clock.now;
  const startsBeforeTap = t.stub._calls.start.length;
  // Mic tap while run A is busy — must wait for run A to fully stop.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  // Run B's first start is the one after the tap. It must be after the
  // teardown ('stopped' 50ms after stop() at the tap) — no overlap.
  ok('(f) serialized: new run starts only after the old run stopped',
    t.stub._calls.startAt.length > startsBeforeTap && t.stub._calls.startAt[startsBeforeTap] >= tapAt + 50,
    `startAt=${JSON.stringify(t.stub._calls.startAt)} tapAt=${tapAt} startsBeforeTap=${startsBeforeTap}`);
  ok('(f) serialized: new run hears its own words, not the old run\'s',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}


// ---- 6. v2.2.35 white Bani bg + tight Jaap pairs + Noto Serif Gurmukhi ----
const fs2 = fs;
const fontsDir = path.join(ROOT, 'www/assets/fonts');
// (v2.2.35a) The cream bug: NO #fdfcf9 anywhere, Bani reader is pure white.
ok('v235: no #fdfcf9 anywhere in the CSS (the missed cream hex is gone)',
  !/#fdfcf9/i.test(css));
ok('v235: Bani reader background is pure white (#ffffff)',
  css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }'));
ok('v235: no near-cream background left in the Bani reader path',
  // Cream = R>=245, G>=240, B>=235 but not pure white. The night-mode dark
  // background #0b0e0c is intentional and must not fail this check.
  ![...css.matchAll(/\.gs-reader-bani[^\{]*\{([^}]*)\}/g)]
    .some(m => [...m[1].matchAll(/background\s*:\s*#([0-9a-f]{6})/gi)]
      .some(h => { const v = parseInt(h[1], 16);
        return v !== 0xffffff && ((v >> 16) & 255) >= 245 && ((v >> 8) & 255) >= 240 && (v & 255) >= 235; })));
// (v2.2.35b) The ::after strut is gone for Bani blocks (SGGS keeps it).
ok('v235: Bani ::after strut override present (content:none, Bani only)',
  css.includes('.gs-reader-bani #verses .verse-block:after{content:none!important;}'));
ok('v235: SGGS still gets the compact ::after strut (Japji unchanged)',
  css.includes('.verse-list .verse-block:after{content:" ";white-space:pre}'));
ok('v235: pair margin-bottom is 0 (was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}') && !css.includes('margin-bottom:0.25em'));
ok('v235: no +0.15 line-height extra left anywhere',
  !/var\(--leading\)\s*\+\s*0\.15/.test(css));
ok('v235: Bani reader widened to Sundar Gutka side margins (720px / 16px)',
  css.includes('.gs-reader-bani .reading{max-width:720px;padding-left:16px;padding-right:16px;}'));
// (v2.2.35c) Noto Serif Gurmukhi bundled, first in stacks; Tiro kept as fallback.
const tiroG = path.join(fontsDir, 'tiro-gurmukhi-400-gurmukhi.woff2');
const tiroL = path.join(fontsDir, 'tiro-gurmukhi-400-latin.woff2');
const notoG = path.join(fontsDir, 'noto-serif-gurmukhi-400-gurmukhi.woff2');
const notoL = path.join(fontsDir, 'noto-serif-gurmukhi-400-latin.woff2');
const notoG7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-gurmukhi.woff2');
const notoL7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-latin.woff2');
ok('v235: Noto Serif 400 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG) && fs2.statSync(notoG).size > 10000 &&
  fs2.existsSync(notoL) && fs2.statSync(notoL).size > 10000);
ok('v235: Noto Serif 700 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG7) && fs2.statSync(notoG7).size > 10000 &&
  fs2.existsSync(notoL7) && fs2.statSync(notoL7).size > 10000);
ok('v235: Noto Serif woff2 files are real woff2 bytes',
  fs2.readFileSync(notoG).subarray(0, 4).toString() === 'wOF2' &&
  fs2.readFileSync(notoG7).subarray(0, 4).toString() === 'wOF2');
ok('v235: @font-face for Noto Serif 400 + 700 references the bundled files',
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:400;') &&
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:700;') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-700-gurmukhi.woff2)'));
ok('v235: Tiro files still present as fallback (not deleted)',
  fs2.existsSync(tiroG) && fs2.existsSync(tiroL));
// (a) Background #FFFFFF in the default theme: every :root fallback AND the
// light-tone rule that actually wins (html[data-tone="light"]).
for (const [name, re] of [
  ['default :root (line 1)', /:root\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
  ['v0.6 :root', /:root\{--bg:#ffffff;--paper:#ffffff;/],
  ['v1.0 :root', /:root \{--bg:#ffffff;--paper:#ffffff;/],
  ['light tone rule', /html\[data-tone="light"\]\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
]) ok(`bg: ${name} is #FFFFFF`, re.test(css));
ok('bg: sepia tone untouched (#f4eddf)', css.includes('html[data-tone="sepia"]{color-scheme:light;--bg:#f4eddf;--paper:#f4eddf;'));
ok('bg: charcoal tone untouched (#242729)', css.includes('html[data-tone="charcoal"]{color-scheme:dark;--bg:#242729;--paper:#242729;'));
ok('bg: dark theme untouched (#151e19)', css.includes('.dark{color-scheme:dark;--bg:#151e19;--paper:#151f1a;'));
ok('bg: no other default --bg/--paper left behind',
  // Only the --bg/--paper variables must be white. The home screen keeps its
  // own cream surfaces (.home-v10, .home-tile, .home-list-item, .hero-temple,
  // .daily-card) by design, so #fbf7ef/#fffdfa as a `background:` value is fine.
  !/--(?:bg|paper):#(eeeee9|fcfbf8|f2f0e9|faf9f5|f3eee5|fbf7ef)/.test(css));
ok('home: home screen unchanged (cream, per Karamjit)',
  css.includes('.home-v10{padding:0 17px 22px;background:#fbf7ef}') &&
  (css.match(/background:#fffdfa/g) || []).length === 2 &&
  css.includes('linear-gradient(0deg,#fbf7ef 0%,transparent 20%)') &&
  css.includes('background:linear-gradient(130deg,#f2f7ef,#fcfaf3)'));
// (b) Leading + block margin.
ok('gaps: base --leading is 1.5', css.includes('--font:25px;--leading:1.5;'));
ok('gaps: verse-block margin is 8px', css.includes('.verse-block{margin:0 0 8px}'));
ok('gaps: font size still 25px', css.includes('--font:25px;'));
ok('gaps: line-layout leading tightened (compact 1.35 / standard 1.5 / spacious 1.65)',
  css.includes('html[data-line-layout="compact"]{--leading:1.35;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="standard"]{--leading:1.5;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="spacious"]{--leading:1.65;--verse-gap:0px;}'));
ok('gaps: theme() map tightened to match', app.includes("const ls={compact:[1.35,'0px'],standard:[1.5,'0px'],spacious:[1.65,'0px']}"));
ok('gaps: Bani para margin tightened to .3em, no +0.15 line-height extra',
  css.includes('.gs-bani-para{display:block!important;text-align:center!important;line-height:var(--leading)!important;margin:0 0 .3em!important;'));
ok('gaps: Bani stanza-end margin tightened to .3em', css.includes('html.reading-open .gs-reader-bani #verses .gs-pankti.gs-stanza-end{margin-bottom:.3em!important;}'));
ok('gaps: Bani pankti line-height is var(--leading) (no +0.15 extra)',
  css.includes('.gs-bani-pankti .verse-text { line-height: var(--leading); }'));
// (c) Bundled Tiro Gurmukhi font.
ok('font: gurmukhi woff2 bundled', fs2.existsSync(tiroG) && fs2.statSync(tiroG).size > 10000);
ok('font: latin woff2 bundled', fs2.existsSync(tiroL) && fs2.statSync(tiroL).size > 10000);
ok('font: gurmukhi woff2 is real woff2 bytes', fs2.readFileSync(tiroG).subarray(0, 4).toString() === 'wOF2');
ok('font: latin woff2 is real woff2 bytes', fs2.readFileSync(tiroL).subarray(0, 4).toString() === 'wOF2');
ok('font: @font-face references the bundled files',
  css.includes('@font-face{font-family:"Tiro Gurmukhi"') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-latin.woff2)'));
ok('font: AnmolUni is first in every serif Gurmukhi stack (v2.2.39)',
  (css.match(/"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi"/g) || []).length >= 15 &&
  // No Noto-first STACK left: a stack has a comma after the family name;
  // @font-face declarations end with a semicolon and must not count.
  !/font-family:"Noto Serif Gurmukhi",/.test(css) &&
  !/font-family:"Tiro Gurmukhi",/.test(css));
ok('font: serif data-font override uses AnmolUni first (v2.2.39)',
  css.includes('html[data-font="serif"] .verse-text,html[data-font="serif"] .word,html[data-font="serif"] .daily-quote{font-family:"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi","Raavi","Nirmala UI",serif}'));
ok('font: sans/system data-font overrides keep their stacks (no Noto Serif forced)',
  css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Sans Gurmukhi","Mukta Mahee","Nirmala UI",sans-serif}') &&
  !css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Serif Gurmukhi"'));
ok('font: no external/webfont link anywhere (offline)',
  !css.includes('fonts.googleapis') && !css.includes('fonts.gstatic') &&
  !html.includes('fonts.googleapis') && !html.includes('fonts.gstatic') &&
  !app.includes('fonts.googleapis') && !app.includes('fonts.gstatic'));
ok('font: vishraam colours unchanged (green/orange still in CSS)',
  css.includes('.vishraam-short') && css.includes('.vishraam-long'));


// ---- 7. v2.2.35 transliteration per line (iGranth) + Jaap Sahib pairs ----
const vm2 = vm;
const sandbox7 = {window:{}, console};
vm2.runInNewContext(rv, sandbox7);
const V7 = sandbox7.window.GS_VERSES;
const jaapLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/4.json'), 'utf8')).lines;
const anandLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/10.json'), 'utf8')).lines;
// Anand opening: "ਅਨੰਦੁ ਭਇਆ ਮੇਰੀ ਮਾਏ ਸਤਿਗੁਰੂ ਮੈ ਪਾਇਆ ॥" + next pankti.
const anandPara = anandLines.slice(2, 4);
const htmlOn = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{translit:true}, foundIdx:-1});
const htmlOff = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{}, foundIdx:-1});
// (a) Translit ON: one roman block per pankti, directly under its own line.
const romanTexts = [...htmlOn.matchAll(/<div class="verse-layer verse-roman"[^>]*>([^<]*)<\/div>/g)].map(m => m[1]);
ok('translit: one roman block per pankti', romanTexts.length === anandPara.length, `got ${romanTexts.length}, want ${anandPara.length}`);
ok('translit: first roman is that pankti only (not joined)',
  romanTexts[0] === 'anand bheaa meree maae; satiguroo. mai paaeaa |', JSON.stringify(romanTexts[0]));
ok('translit: second roman is that pankti only (not joined)',
  romanTexts[1] === 'satigur. ta paaeaa sehaj setee; man vajeea vaadhaaeea |', JSON.stringify(romanTexts[1]));
ok('translit: each roman sits inside its own pankti block, right after its verse-text',
  [...htmlOn.matchAll(/<div class="verse-block gs-pankti[^>]*><div class="verse-text"[^>]*>[\s\S]*?<\/div><div class="verse-layer verse-roman"/g)].length === anandPara.length);
ok('translit: every word still a tappable button',
  (htmlOn.match(/<button type="button" class="word"/g) || []).length >= 10);
ok('translit: no joined paragraph roman (no single block holding both romans)',
  !romanTexts.some(t => t.includes('anand bheaa') && t.includes('satigur. ta paaeaa')));
// (b) Translit OFF: flowing paragraph unchanged — one verse-text holds the
// whole paragraph's words, no roman at all.
ok('translit off: one flowing verse-text holds the whole paragraph',
  (htmlOff.match(/<div class="verse-block gs-bani-para"/g) || []).length === 1 &&
  htmlOff.includes('ਅਨੰਦੁ') && htmlOff.includes('ਵਾਧਾਈਆ'));
ok('translit off: no roman blocks', !htmlOff.includes('verse-roman'));
// (c) Jaap Sahib pair mode: short "ਨਮਸਤੁੰ" panktis pair two-per-block after
// the "ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥" heading, and render as tight pair blocks.
const jaapGroups = V7.groupBaniParagraphs(jaapLines.slice(2, 30));
const pairGroups = jaapGroups.filter(g => g.type === 'pair');
ok('jaap: short namastun panktis pair two-per-block',
  pairGroups.filter(g => g.items.length === 2).length >= 8,
  `pairs=${pairGroups.length} full=${pairGroups.filter(g => g.items.length === 2).length}`);
const jaapHtml = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{}, foundIdx:-1});
ok('jaap: pair blocks render as gs-bani-para gs-bani-pair',
  (jaapHtml.match(/class="verse-block gs-bani-para gs-bani-pair"/g) || []).length >= 8);
ok('jaap: pair block holds both short panktis on one tight block',
  (jaapHtml.match(/<div class="verse-block gs-bani-para gs-bani-pair"[^>]*>[\s\S]*?<\/div><\/div>/g) || [])
    .some(b => { const t = b.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '); return t.includes('ਨਮਸਤ੍ਵੰ ਅਕਾਲੇ') && t.includes('ਨਮਸਤ੍ਵੰ ਕ੍ਰਿਪਾਲੇ'); }));
ok('jaap: pair/para margin is tight (.3em, not the old .6em)',
  css.includes('margin:0 0 .3em!important;') && !css.includes('margin:0 0 .6em!important;'));
ok('jaap: pair margin-bottom is 0 (tight, was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}'));
// (d) Ang reader untouched: verseHTML still puts roman under each line.
const angLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1.json'), 'utf8')).lines;
const angHtml = angLines.slice(0, 3).map((line, i) => V7.verseHTML(line, {idx:i, kind:'ang', vishraamOn:false, show:{translit:true}})).join('');
ok('ang: roman still per line under its own pankti',
  (angHtml.match(/verse-roman/g) || []).length === 3);


// ---- 8. v2.2.36 centred search line (ONE change) ----
// (a) SGGS scroll-mode resume: the line's centre lands at innerHeight/2.
const resumeLine = app.split('\n').find(l => l.includes('state.readView') && l.includes('state.mode') && l.includes('scroll') && l.includes('getBoundingClientRect'));
ok('v2.2.36: SGGS resume scroll centres the line (r.top + r.height/2 - innerHeight/2)',
  !!resumeLine && resumeLine.includes('r.top+r.height/2-window.innerHeight/2') && resumeLine.includes('Math.max(0,y)'),
  resumeLine ? resumeLine.slice(0, 200) : 'resume line not found');
ok('v2.2.36: SGGS resume scroll has no -73 top offset left',
  !app.includes('getBoundingClientRect().top-73'));
ok('v2.2.36: SGGS resume still keeps the user scroll progress (verseOffset)',
  !!resumeLine && resumeLine.includes('+state.verseOffset'));
// (b) Bani/remote jump (search tap, saved verse, resume): block:'center'.
const jumpLine = app.split('\n').find(l => l.includes('highlightLine') && l.includes('scrollIntoView'));
ok('v2.2.36: remote line jump uses scrollIntoView block center',
  !!jumpLine && jumpLine.includes("scrollIntoView({block:'center'})"),
  jumpLine ? jumpLine.slice(-160) : 'jump line not found');
ok('v2.2.36: remote line jump no longer uses block start',
  !!jumpLine && !jumpLine.includes("block:'start'"));
// (c) Out of scope — unchanged: page-turn, home, Kirtan alphabet jump.
ok('v2.2.36: page-turn still scrolls to top (turn() unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes('function turn(dir)')); return !!l && l.includes('window.scrollTo({top:0,behavior:'); })());
ok('v2.2.36: leaving the reader still scrolls home to top (go() unchanged)',
  app.includes("if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});"));
ok('v2.2.36: Kirtan alphabet jump still block start (list row, not a pangti)',
  app.includes("row.scrollIntoView({block:'start'})"));
ok('v2.2.36: Kirtan shabad open still scrolls to top',
  (() => { const i = app.indexOf('async function openKirtanShabad'); const seg = app.slice(i, i + 1500); return seg.includes('window.scrollTo({top:0,behavior:'); })());
// (d) The search tap still sets highlightLine and opens with progress.
ok('v2.2.36: search tap still sets highlightLine + openAng/openBani with preserveProgress',
  app.includes('highlightLine=Number(found.dataset.foundIdx') && app.includes('openAng(Number(found.dataset.foundAng') && app.includes('openBani(Number(foundBani.dataset.foundBani'));

// ---- 6. v2.2.37: brand follows language + Muse-style Stop button ----
// (a) Brand.
ok('v2.2.37: top-bar brand follows the app language (render uses age)',
  app.includes("$('brand').textContent=age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh');"));
ok('v2.2.37: home hero brand follows the app language',
  app.includes("<h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: search header follows the app language',
  app.includes("<div class=\"search-darkhead\"><h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: no "Saanj" without H left in app.js',
  !/Saanj(?!h)/.test(app));
ok('v2.2.37: settings subtitle left alone (version line, not a brand)',
  app.includes("ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}"));
// (b) v2.2.40: the mic button ITSELF is the Stop sign — the separate Stop
// button (v2.2.37) is gone at Karamjit's request ("mic nu hi Stop sign bana
// de"). The v2.2.37 Stop-button assertions are superseded by these.
ok('v2.2.40: no separate Stop button anywhere (voiceStopBtn/askVoiceStopBtn gone)',
  !app.includes('voiceStopBtn') && !app.includes('askVoiceStopBtn') && !app.includes('gs-voice-stop'));
ok('v2.2.40: no gs-show Stop-button CSS left',
  !css.includes('.gs-voice-stop') && !css.includes('gs-show'));
ok('v2.2.40: setListeningUI swaps the mic icon to ⏹ while listening, 🎙 when idle',
  app.includes("b.textContent=on?'⏹':'🎙'") && app.includes("for(const id of ['voiceBtn','askVoiceBtn'])"));
ok('v2.2.40: listening mic looks like a Stop button (red bg + red ⏹, dark-mode variant)',
  css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{background:#fbe9e7;color:#b3261e;') &&
  css.includes('.dark #voiceBtn.gs-listening,.dark #askVoiceBtn.gs-listening{background:#4a2622;color:#f6c9c4;'));
ok('v2.2.40: mic tap stops while listening, starts while idle (no separate Stop wiring)',
  app.includes('if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(input);') &&
  app.includes('if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(qi)') &&
  !app.includes('vsb.onclick') && !app.includes('avs.onclick'));
ok('v2.2.40: mic buttons are never disabled (stays tappable as Stop)',
  !app.includes('if(btn)btn.disabled=true;') && !app.includes('if(btn)btn.disabled=false') &&
  !app.includes("const b=$('voiceBtn');if(b)b.disabled=false;") &&
  !app.includes("const a=$('askVoiceBtn');if(a)a.disabled=false;"));
ok('v2.2.37: stopVoiceSearch stops the mic without clearing the search',
  app.includes('function stopVoiceSearch(){resetVoiceNow();}'));
ok('v2.2.40: syncVoiceStopUI re-applies the mic-as-Stop state after every render (attach calls it)',
  app.includes('function syncVoiceStopUI(){') && app.includes('syncVoiceStopUI();') &&
  app.includes("b.textContent=voiceListeningOn?'⏹':'🎙'"));
// (c) Listen until Stop.
ok('v2.2.37: watchdog is the 2-minute per-segment backstop (120000)',
  app.includes('},120000);'));
ok('v2.2.37: watchdog re-armed per segment (native + web restarts)',
  (app.match(/armVoiceWatchdog\(btn\);/g) || []).length >= 3);
ok('v2.2.37: resetVoiceNow wakes the run loop at once (endSegment)',
  app.includes('if(run)run.endSegment();'));
ok('v2.2.37: web fallback recognizer stopped right away (voiceWebRec)',
  app.includes('let voiceWebRec=null;') && app.includes('voiceWebRec=rec;') && app.includes('if(voiceWebRec){try{voiceWebRec.stop()}catch{}voiceWebRec=null;}'));
ok('v2.2.37: X still clears search + stops mic (unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick')); return !!l && l.includes('resetVoiceNow()') && l.includes("input.value=''") && l.includes("innerHTML=''"); })());

// ---- v2.2.38: Daily Hukamnama card is more compact (Home) ----
ok('v2.2.38: hukam-hero padding is compact (8px 14px 7px)',
  css.includes('padding:8px 14px 7px;') && !css.includes('padding:12px 16px 11px;'));
ok('v2.2.38: hukam-hero margins tightened (8px 0 5px)',
  css.includes('.hukam-hero{display:block;width:100%;text-align:center;border:0;cursor:pointer;') &&
  /\.hukam-hero\{[^}]*margin:8px 0 5px;/.test(css));
ok('v2.2.38: hukam-hero title smaller (21px, was 26px)',
  css.includes('.hukam-hero-title{display:block;font-size:21px;') && !css.includes('.hukam-hero-title{display:block;font-size:26px;'));
ok('v2.2.38: hukam-hero kicker/date/meta tightened to 12px with 2px gaps',
  css.includes('.hukam-hero-kicker{display:block;font-size:12px;') && css.includes('margin-bottom:2px;}') &&
  css.includes('.hukam-hero-date{display:block;font-size:12px;') && css.includes('margin-top:2px;}') &&
  css.includes('.hukam-hero-meta{display:block;font-size:12px;'));
ok('v2.2.38: hukam-hero preview slimmer (16px, line-height 1.35, margin-top 5px)',
  css.includes('.hukam-hero-preview{display:block;font-size:16px;line-height:1.35;margin-top:5px;') &&
  !css.includes('.hukam-hero-preview{display:block;font-size:18px;line-height:1.5;margin-top:8px;'));
ok('v2.2.38: hukam-hero chevron smaller with tighter gap (16px, margin-top 3px)',
  css.includes('.hukam-hero-go{display:block;font-size:16px;line-height:1;color:#e6c25a;margin-top:3px;}'));
ok('v2.2.38: hukam-hero keeps its green-and-gold card (gradient + radius + shadow)',
  css.includes('background:linear-gradient(180deg,#14532d,#0b3d20);color:#fdf6e3;border-radius:14px;') &&
  css.includes('box-shadow:0 4px 14px rgba(11,61,32,.25);}'));
ok('v2.2.38: no Hukamnama card content removed (kicker/title/date/meta/preview/sub/chevron all rendered)',
  app.includes('hukam-hero-kicker') && app.includes('hukam-hero-title') && app.includes('hukam-hero-date') &&
  app.includes('hukam-hero-meta') && app.includes('hukam-hero-preview') && app.includes('hukam-hero-sub') && app.includes('hukam-hero-go'));
ok('v2.2.38: hero untouched (premium-hero still 274px)',
  css.includes(".premium-hero{position:relative;margin:0 -17px 10px;background:linear-gradient(180deg,#fffaf0,#fcf4e6 74%,#faf4e9);height:274px;"));
ok('v2.2.38: Continue card untouched (home-v10 min-height 65px)',
  css.includes('.home-v10 .continue-card{min-height:65px;'));
ok('v2.2.38: library tiles untouched (tile-3d still min-height 164px)',
  css.includes('.home-v7 .home-tile.tile-3d{min-height:164px;'));


// ---- 10. v2.2.39 AnmolUni font from iGranth + verse-text weight 400 ----
const anmol = path.join(fontsDir, 'AnmolUni.ttf');
const anmolBuf = fs.existsSync(anmol) ? fs.readFileSync(anmol) : Buffer.alloc(0);
ok('v239: AnmolUni.ttf bundled (143,256 bytes)', fs.existsSync(anmol) && fs.statSync(anmol).size === 143256);
ok('v239: AnmolUni.ttf is real TTF bytes (00 01 00 00 magic)',
  anmolBuf.length > 4 && anmolBuf[0] === 0x00 && anmolBuf[1] === 0x01 && anmolBuf[2] === 0x00 && anmolBuf[3] === 0x00);
ok('v239: AnmolUni.ttf is the verified file (MD5 pins the Unicode build)',
  crypto.createHash('md5').update(anmolBuf).digest('hex') === '1b7dab4c4e610f9fcaa89b00b3f7bde9');
ok('v239: @font-face for AnmolUni references the bundled file',
  css.includes('@font-face{font-family:"AnmolUni"') &&
  css.includes('url(assets/fonts/AnmolUni.ttf)') &&
  css.includes('format("truetype")'));
ok('v239: AnmolUni is first in all 15 Gurmukhi stacks',
  (css.match(/"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi"/g) || []).length === 15);
ok('v239: verse-text weight is 400, no 550 left (was rounding up to Bold 700)',
  !css.includes('font-weight:550') &&
  /\.verse-text\{[^}]*font-weight:400;/.test(css) &&
  /\.gs-book-page \.gs-book-flow\{[^}]*font-weight:400;/.test(css));
ok('v239: Ang + Bani reader verse-text rules are weight 400 too',
  /#verses \.gs-pankti \.verse-text\{[^}]*font-weight:400;/.test(css) &&
  /#verses \.gs-bani-para \.verse-text\{[^}]*font-weight:400;/.test(css));
ok('v239: Noto Serif + Tiro files still present as fallback (not deleted)',
  fs.existsSync(notoG) && fs.existsSync(notoL) && fs.existsSync(notoG7) && fs.existsSync(notoL7) &&
  fs.existsSync(tiroG) && fs.existsSync(tiroL));
ok('v239: heading/UI weights unchanged (brand still 750, hero h1 still 700)',
  /\.brand\{[^}]*font-weight:750;/.test(css) &&
  /\.hero h1\{[^}]*font-weight:700;/.test(css));
ok('v239: font size still 25px (his job via A-/slider/A+)',
  css.includes('--font:25px;'));

// ---- 11. v2.2.40 iGranth-style transliteration layout (Bani reader, translit ON only) ----
// The section carries .gs-translit-on only for a Bani reader with transliteration on.
ok('v240: Bani reader section gets gs-translit-on only when Bani + showTranslit',
  app.includes("kind==='bani'&&state.showTranslit?' gs-translit-on':''") &&
  !app.includes("gs-reader-sggs gs-translit-on"));
ok('v240: translit-ON Bani pankti is centred (beats the left-align rule)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}'));
ok('v240: translit-ON does NOT auto-blue the Bani Gurmukhi (v2.2.41 reverts the v2.2.40 misreading)',
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}') &&
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}'));
ok('v240: translit-ON Bani Roman is orange #f3541d, centred, no left border',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('v240: translit-ON Bani headings are orange #f3541d (the heading rule carries #verses, so it still wins over the Blue option)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-verse-heading .verse-text{color:#f3541d;}'));
ok('v240: translit-ON rules are Bani-only (no gs-reader-sggs translit-on rule anywhere)',
  !css.includes('.gs-reader-sggs.gs-translit-on') && !css.includes('.gs-sggs-pankti .verse-text{color:#0d0445'));
ok('v240: translit OFF unchanged — base roman still red #b3261e, base verse-text still --ink, Bani paras still centred',
  css.includes('.verse-roman { color: #b3261e; }') &&
  /\.verse-text\{[^}]*color:var\(--ink\);/.test(css) &&
  css.includes('.gs-bani-para{display:block!important;text-align:center!important;'));
ok('v240: Ang/SGGS reader still uses gs-gurmukhi-blue for its Gurmukhi (unchanged)',
  app.includes("gurmukhiClass:kind==='ang'?'gs-gurmukhi-blue':''") &&
  css.includes('.gs-gurmukhi-blue { color: #1a3fa0; font-weight: 700; }'));
ok('v240: Bani reader background still pure white, font still AnmolUni weight 400',
  css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }') &&
  !css.includes('font-weight:550'));

// ---- 12. v2.2.41 translit-ON pairs two-per-line, exactly like iGranth ----
// v2.2.40 centred each short "ਨਮਸਤੁੰ" line on its own row, wasting the
// sides of the page; Karamjit rejected it ("Follow this, don't use ur
// logic"). Now a pair group renders as ONE block even with transliteration
// ON: two Gurmukhi on one line, two Romans on the next line under the pair.
const jaapOn = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{translit:true}, foundIdx:-1});
const jaapOff41 = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{}, foundIdx:-1});
const pairBlocksOn = jaapOn.match(/<div class="verse-block gs-bani-para gs-bani-pair"[^>]*>[\s\S]*?<\/div>(?=<div class="verse-block|$)/g) || [];
const stripTags = s => s.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
ok('v241: translit ON still renders the pairs as pair blocks (not per-pankti)',
  pairBlocksOn.length >= 8, `pairs=${pairBlocksOn.length}`);
ok('v241: translit ON first pair has TWO Gurmukhi on ONE line',
  pairBlocksOn.length > 0 && stripTags(pairBlocksOn[0]).includes('ਨਮਸਤ੍ਵੰ ਅਕਾਲੇ ॥ ਨਮਸਤ੍ਵੰ ਕ੍ਰਿਪਾਲੇ ॥'),
  pairBlocksOn.length ? stripTags(pairBlocksOn[0]).slice(0, 80) : 'no pair block');
ok('v241: translit ON first pair has TWO Romans on the NEXT line under the pair',
  pairBlocksOn.length > 0 && /<div class="verse-text"[^>]*>[\s\S]*?<\/div><div class="verse-layer verse-roman"[^>]*>namasatvan akaale \| namasatvan kripaale \|<\/div>/.test(pairBlocksOn[0]),
  pairBlocksOn.length ? stripTags(pairBlocksOn[0]).slice(0, 120) : 'no pair block');
ok('v241: translit ON second pair follows the same way',
  pairBlocksOn.length > 1 && stripTags(pairBlocksOn[1]).includes('ਨਮਸਤੰ ਅਰੂਪੇ ॥ ਨਮਸਤੰ ਅਨੂਪੇ ॥੨॥') &&
  stripTags(pairBlocksOn[1]).includes('namasatan aroope | namasatan anoope |2|'),
  pairBlocksOn.length > 1 ? stripTags(pairBlocksOn[1]).slice(0, 120) : 'no second pair');
ok('v241: translit ON has NO single-namastun pankti block left (one-per-line is gone)',
  ![...jaapOn.matchAll(/<div class="verse-block gs-pankti gs-bani-pankti"[^>]*><div class="verse-text"[^>]*>([\s\S]*?)<\/div>/g)]
    .some(m => /ਨਮਸ/.test(stripTags(m[1]))));
ok('v241: translit ON long non-pair lines still render one-per-line with their own Roman',
  [...jaapOn.matchAll(/<div class="verse-block gs-pankti gs-bani-pankti"[^>]*>([\s\S]*?)<\/div>(?=<div class="verse-block|$)/g)]
    .some(b => { const t = stripTags(b[1]); return t.includes('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ') && t.includes('chakr chihan'); }));
ok('v241: translit OFF pairs unchanged (same pair blocks, no Roman)',
  (jaapOff41.match(/class="verse-block gs-bani-para gs-bani-pair"/g) || []).length >= 8 &&
  !jaapOff41.includes('verse-roman'));
ok('v241: pair blocks carry data-line (first item) so the search-jump still lands on them',
  (jaapOn.match(/gs-bani-para gs-bani-pair"[^>]*data-line="\d+"/g) || []).length >= 8);
ok('v241: app.js jump falls back to data-lines when data-line is not found',
  app.includes("find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))"));
ok('v241: CSS does NOT auto-blue the translit-ON pair Gurmukhi (revert of the v2.2.40 misreading)',
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}'));
ok('v241: CSS colours the translit-ON pair Roman orange #f3541d, centred, no left border',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pair .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('v241: CSS centres the translit-ON pair block itself',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pair{text-align:center!important;}'));
ok('v241: v2.2.40 per-pankti translit centring/orange Roman unchanged (only the auto-blue is gone)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}') &&
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;') &&
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}'));

// ---- 13. v2.2.41 font-colour option (Blue/Black, whole reading, default Black) ----
// (a) Default Gurmukhi is black #202a26 even with translit ON.
ok('v241c: default Gurmukhi is black — base verse-text colour is var(--ink) and --ink is #202a26',
  /\.verse-text\{[^}]*color:var\(--ink\);/.test(css) && css.includes('--ink:#202a26'));
ok('v241c: no auto-blue rule anywhere for verse-text (translit ON cannot blue it by itself)',
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}') &&
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}') &&
  !/\.gs-translit-on[^}]*\.verse-text\{color:#0d0445/.test(css));
// (b) Blue option applies #0d0445 to Bani AND Ang verse text and persists.
ok('v241c: Blue option CSS sets ALL verse-text (Bani + Ang) to #0d0445',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="blue"] .verse-text{color:#0d0445;}'));
ok('v241c: theme() applies the option as html[data-gurmukhi-color]',
  app.includes("html.dataset.gurmukhiColor=state.fontColor==='blue'?'blue':'black';"));
ok('v241c: fontColor defaults to black in state and is normalised to blue/black',
  app.includes("fontColor:'black'") && app.includes("state.fontColor=state.fontColor==='blue'?'blue':'black';"));
ok('v241c: fontColor survives backup/restore (in the permitted list)',
  app.includes("'baniTextSize','fontColor','layerScale','aiApiKey'"));
ok('v241c: Bani View Preferences has the Blue/Black choice next to the font size',
  app.includes("choice('fontColor',[['black',t('fontBlack')],['blue',t('fontBlue')]])"));
ok('v241c: font-colour labels exist in both languages',
  app.includes("fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ'") && app.includes("fontColor:'Text colour'") &&
  app.includes("fontBlack:'ਕਾਲਾ'") && app.includes("fontBlue:'ਨੀਲਾ'"));
// (c) Black option restores #202a26 (including the Ang reader, whose
// gs-gurmukhi-blue used to force #1a3fa0).
ok('v241c: Black option restores #202a26 on the Ang reader (overrides gs-gurmukhi-blue #1a3fa0)',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="black"] .gs-gurmukhi-blue{color:#202a26;}'));
ok('v241c: colour rules are scoped to the light theme (dark theme keeps readable text)',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="blue"]') &&
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="black"]'));

// ---- 14. v2.2.42: mic auto-stop on result tap + Roman bigger + one layer-size control ----
// (a) Mic: tapping a search result (or a saved verse) to open it stops the
// mic FIRST — Karamjit's video showed the mic still listening after he came
// back from the reader, so he had to press Stop again himself.
ok('v242a: result tap (Ang) calls stopVoiceSearch() before openAng',
  /\[data-found-ang\],\[data-open-saved-ang\]\'\);if\(found\)\{stopVoiceSearch\(\);/.test(app));
ok('v242a: result tap (Bani) calls stopVoiceSearch() before openBani',
  /\[data-found-bani\],\[data-open-saved-bani\]\'\);if\(foundBani\)\{stopVoiceSearch\(\);/.test(app));
ok('v242a: stopVoiceSearch keeps the spoken words + results (it only resets the run)',
  app.includes('function stopVoiceSearch(){resetVoiceNow();}') &&
  !/function stopVoiceSearch\(\)\{[^}]*searchInput/.test(app));
ok('v242a: only verse-open taps stop the mic (save/bookmark taps do not call stopVoiceSearch)',
  !app.includes("data-save-hit") || !/data-save-hit[^}]*stopVoiceSearch/.test(app.split('[data-found-ang]')[0]));
// (b) Roman bigger via the single layer scale (Change 2 is now the control's default).
ok('v242b: .verse-layer uses the single --layer-scale (default .8), not the old fixed .62',
  css.includes('.verse-layer { font-size: calc(var(--font) * var(--layer-scale, .8));') &&
  !css.includes('.verse-layer { font-size: calc(var(--font) * .62);'));
ok('v242b: no fixed layer sizes left (.68/.74/.88/.95 banisize overrides are gone)',
  !/\.verse-layer[^}]*\* \.(68|74|88|95)\)/.test(css) && !css.includes('.verse-layer.verse-roman { font-size:'));
ok('v242b: Roman colour unchanged (base #b3261e; translit-ON Bani still orange #f3541d)',
  css.includes('.verse-roman { color: #b3261e; }') &&
  css.includes('.gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;'));
ok('v242b: Gurmukhi verse size unchanged (still var(--font), weight 400, AnmolUni first)',
  /\.verse-text\{[^}]*font-size:var\(--font\);/.test(css) &&
  css.includes('font-family:"AnmolUni","Noto Serif Gurmukhi"'));
// (c) ONE size control for Roman + English + Punjabi (Change 3).
ok('v242c: layerScale state exists, default 0.8, clamped to 0.7–1.0',
  app.includes("layerScale:0.8") &&
  app.includes("state.layerScale=Math.min(1,Math.max(0.7,Number(state.layerScale)||0.8));"));
ok('v242c: theme() publishes the scale as --layer-scale',
  app.includes("html.style.setProperty('--layer-scale',String(state.layerScale));"));
ok('v242c: Bani View Preferences has ONE layer-size slider + A-/A+ next to the font size',
  app.includes('id="vpLayerSlider"') && app.includes('min="0.7" max="1" step="0.05"') &&
  app.includes('id="vpLayerMinus"') && app.includes('id="vpLayerPlus"') && app.includes('id="vpLayerValue"'));
ok('v242c: layer-size slider wiring updates state + theme + persists (mirrors the font slider)',
  app.includes('const setVpLayer=') && app.includes("ls.addEventListener('input',()=>setVpLayer(ls.value))") &&
  app.includes("lm.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)-0.05)") &&
  app.includes("lp.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)+0.05)"));
ok('v242c: layer-size label exists in both languages',
  app.includes("layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ'") && app.includes("layerSize:'Roman + translation size'"));
ok('v242c: layerScale survives backup/restore (in the permitted list)',
  app.includes("'baniTextSize','fontColor','layerScale','aiApiKey'"));
ok('v242c: all three under-line layers share the ONE scale (no per-language size rule)',
  (() => { const cssNoHukam = css.replace(/\.hukam-verses[^{]*\{[^}]*\}/g, '');
    return !/\.verse-en\{[^}]*font-size/.test(cssNoHukam) && !/\.verse-pa\{[^}]*font-size/.test(cssNoHukam) &&
    css.includes('.verse-layer { font-size: calc(var(--font) * var(--layer-scale, .8));') &&
    css.includes('.verse-meaning{font-size:calc(var(--font)*var(--layer-scale,.8));'); })());
ok('v242c: Gurmukhi size is NOT affected by the layer control (verse-text has no layer-scale)',
  !/\.verse-text\{[^}]*layer-scale/.test(css));

// ---- 15. v2.2.43: Play Store build hides the AI settings; AI itself untouched ----
// The AI section lives in Bani View Preferences (viewprefsScreen), NOT in
// settingsHTML (reader settings) — gating the wrong screen was caught and fixed.
const bw = fs.readFileSync(path.join(ROOT, 'scripts/build-web.mjs'), 'utf8');
ok('v243: build-web.mjs reads GS_HIDE_AI_SETTINGS and writes hideAiSettings into GS_BUILD',
  bw.includes("process.env.GS_HIDE_AI_SETTINGS==='1'") && bw.includes('hideAiSettings') &&
  bw.includes('hideAiSettings})') && bw.includes('window.GS_BUILD='));
ok('v243: viewprefsScreen gates the AI section on window.GS_BUILD.hideAiSettings',
  app.includes('const hideAI=!!(window.GS_BUILD&&window.GS_BUILD.hideAiSettings);') &&
  app.includes('const aiSection=hideAI?\'\':`<div class="menu-group-label">AI</div>') &&
  app.includes('${aiSection}'));
ok('v243: AI heading occurs exactly once (inside aiSection only)',
  (app.match(/menu-group-label">AI/g) || []).length === 1);
ok('v243: aiKeyInput occurs exactly twice (aiSection + change handler), never in the main template',
  (app.match(/aiKeyInput/g) || []).length === 2);
ok('v243: aiSection lives in viewprefsScreen, not in settingsHTML (wrong-screen guard)',
  (() => { const vp = app.slice(app.indexOf('function viewprefsScreen(){'),
      app.indexOf('/* ---- Menu / daily ---- */'));
    const sh = app.slice(app.indexOf('function settingsHTML(){'),
      app.indexOf('function openSettings()'));
    return vp.includes('const aiSection=') && vp.includes('${aiSection}') &&
      !sh.includes('aiSection') && !sh.includes('hideAI'); })());
ok('v243: AI rows are only inside aiSection (the main return template has no AI inputs)',
  (() => { const vp = app.slice(app.indexOf('function viewprefsScreen(){'),
      app.indexOf('/* ---- Menu / daily ---- */'));
    const mainReturn = vp.slice(vp.indexOf('return `'));
    return !mainReturn.includes('aiKeyInput') && !mainReturn.includes('aiModelInput') &&
      !mainReturn.includes('aiAccessInput') && vp.includes('aiKeyInput'); })());
// Workflows live next to this repo (~/workspace/gurbani/), not inside the zip:
// in the clean room they are absent, so these two checks only run when present.
const aabPath = path.join(ROOT, '..', 'android-aab-v263.yml');
const apkPath = path.join(ROOT, '..', 'android-apk-1-v264.yml');
if (fs.existsSync(aabPath) && fs.existsSync(apkPath)) {
  const aab = fs.readFileSync(aabPath, 'utf8');
  const apk = fs.readFileSync(apkPath, 'utf8');
  ok('v243: AAB workflow sets GS_HIDE_AI_SETTINGS=1 on the build:web step (and never zipaligns)',
    aab.includes("GS_HIDE_AI_SETTINGS: '1'") && aab.includes('npm run build:web') &&
    aab.includes('bundleRelease') && !aab.includes('zipalign"'));
  ok('v243: APK workflow does NOT set the flag (APK build keeps the AI settings)',
    !apk.includes('GS_HIDE_AI_SETTINGS') && apk.includes('assembleRelease'));
} else {
  console.log('SKIP  workflow checks (android-aab-v263.yml / android-apk-1-v264.yml not in this tree)');
}
// (c) Ask / cloud AI logic unchanged.
ok('v243c: cloud AI still the default (endpoint falls back to AI_CLOUD_ENDPOINT)',
  app.includes("const AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev';") &&
  app.includes("String(state.aiEndpoint||'').trim()||AI_CLOUD_ENDPOINT"));
ok('v243c: Ask screen + answer logic untouched',
  app.includes('function askScreen(){') && app.includes('function aiAnswerHTML(answer){') &&
  app.includes('function answerQuestion()'));
// ---- Runtime: render Bani View Preferences in a vm sandbox, both flag states ----
const vpSrc = app.slice(app.indexOf('function viewprefsScreen(){'),
  app.indexOf('/* ---- Menu / daily ---- */')).trim();
ok('v243r: viewprefsScreen source extractable', vpSrc.startsWith('function viewprefsScreen(){') && vpSrc.endsWith('}'));
const AI_IDS = ['aiKeyInput', 'aiApiEndpointInput', 'aiModelInput', 'aiEndpointInput', 'aiAccessInput'];
const runViewprefs = (hide) => {
  const sandbox = {
    window: hide === undefined ? {} : { GS_BUILD: { hideAiSettings: hide } },
    state: { tone: 0, theme: 'light', font: 25, uiScale: 1.12, raisedHeadings: true,
      lineLayout: 'compact', margin: 'normal', mode: 'scroll', pageTurnSpeed: 'slow',
      showTranslit: true, showEn: false, showPa: false, showArth: false, layerScale: 0.8,
      baniTextSize: 'normal', fontColor: 'black', nightMode: false,
      aiApiKey: '', aiApiEndpoint: '', aiModel: 'gemini-3.5-flash-lite', aiEndpoint: '', aiAccessToken: '' },
    t: (k) => ({ aiKey: 'AI API key', aiEndpoint: 'AI endpoint', aiModel: 'AI model' }[k] || k),
    age: (pa, en) => en,
    esc: (s) => String(s ?? ''),
    AI_DEFAULT_ENDPOINT: 'https://api.openai.com/v1/chat/completions',
  };
  vm.createContext(sandbox);
  return vm.runInContext(vpSrc + '\nviewprefsScreen();', sandbox);
};
const htmlHidden = runViewprefs(true);
const htmlShown = runViewprefs(false);
const htmlNoFlag = runViewprefs(undefined);
ok('v243r: flag ON — no AI heading in Bani View Preferences',
  !htmlHidden.includes('<div class="menu-group-label">AI</div>'));
ok('v243r: flag ON — none of the 5 AI inputs render',
  AI_IDS.every((id) => !htmlHidden.includes('id="' + id + '"')));
ok('v243r: flag ON — no AI text anywhere (key / endpoint / model / private server / access code)',
  !/AI API key|AI endpoint|AI model|Private AI server|AI access code/i.test(htmlHidden));
ok('v243r: flag ON — rest of the screen intact (Voice, mic test, font + layer sliders, no gap)',
  htmlHidden.includes('micTestStatus') && htmlHidden.includes('id="vpFontSlider"') &&
  htmlHidden.includes('id="vpLayerSlider"') && htmlHidden.includes('Voice') &&
  htmlHidden.trim().endsWith('</section>'));
ok('v243r: flag OFF — AI heading + all 5 AI inputs render',
  htmlShown.includes('<div class="menu-group-label">AI</div>') &&
  AI_IDS.every((id) => htmlShown.includes('id="' + id + '"')));
ok('v243r: flag OFF — AI section matches v2.2.42 (same 5 rows, same labels)',
  ['AI API key', 'AI endpoint', 'AI model', 'Private AI server', 'AI access code']
    .every((label) => htmlShown.includes(label)));
ok('v243r: flag ABSENT (no GS_BUILD) — AI section renders (APK default)',
  htmlNoFlag.includes('<div class="menu-group-label">AI</div>') &&
  AI_IDS.every((id) => htmlNoFlag.includes('id="' + id + '"')));

// ---- 16. v2.2.44 (1)-(4): typo + mispronunciation-tolerant search + mic ----
// (16a) Typo: Ang 1396 + Ang 1405 read ਪ੍ਰਭ (Gurmukhi + transliteration) in
// search.json and both ang files; ਪੁਬਿ/ਪੁਬਲੀ untouched.
const searchRows = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
const searchRaw = fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8');
const ang1396 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1396.json'), 'utf8'));
const ang1405 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1405.json'), 'utf8'));
const line1396 = searchRows.find(r => r[0] === 1396 && String(r[2]).includes('ਸੇਵਾ ਕਰੀਆ'));
const line1405 = searchRows.find(r => r[0] === 1405 && String(r[2]).includes('ਸੁਦਾਮਾ'));
ok('v244 typo: Ang 1396 line reads ਪ੍ਰਭ in search.json (Gurmukhi)',
  !!line1396 && line1396[2].includes('ਪ੍ਰਭ ਜਿਨਹੁ ਸੇਵਾ ਕਰੀਆ'), JSON.stringify(line1396));
ok('v244 typo: Ang 1396 roman reads prabh in search.json',
  !!line1396 && String(line1396[5]).includes('prabh jinahu sevaa kareea'), JSON.stringify(line1396 && line1396[5]));
ok('v244 typo: Ang 1405 line reads ਪ੍ਰਭ in search.json (Gurmukhi)',
  !!line1405 && line1405[2].includes('ਪ੍ਰਭ ਭਗਤ ਹਰਿ ਕੇ ਜੁ ਗਣੰ'), JSON.stringify(line1405));
ok('v244 typo: Ang 1405 roman reads prabh in search.json',
  !!line1405 && String(line1405[5]).includes('prabh bhagat har ke ju ganan'), JSON.stringify(line1405 && line1405[5]));
ok('v244 typo: only ਪੁਬਿ/ਪੁਬਲੀ left in search.json — no standalone ਪੁਬ anywhere',
  (searchRaw.match(/ਪੁਬ/g) || []).length === 3 &&
  (searchRaw.match(/ਪੁਬਿ/g) || []).length === 2 &&
  (searchRaw.match(/ਪੁਬਲੀ/g) || []).length === 1,
  `ਪੁਬ=${(searchRaw.match(/ਪੁਬ/g) || []).length}`);
ok('v244 typo: ang/1396.json line reads ਪ੍ਰਭ, zero ਪੁਬ in the file',
  JSON.stringify(ang1396).includes('ਪ੍ਰਭ ਜਿਨਹੁ ਸੇਵਾ') && !(JSON.stringify(ang1396).match(/ਪੁਬ/g) || []).length);
ok('v244 typo: ang/1405.json line reads ਪ੍ਰਭ, zero ਪੁਬ in the file',
  JSON.stringify(ang1405).includes('ਪ੍ਰਭ ਭਗਤ') && !(JSON.stringify(ang1405).match(/ਪੁਬ/g) || []).length);

// (16b) Search: the REAL scripture-search.js + real data in a vm, fetch
// stubbed to the bundled JSON files. The 5 spec queries must return the
// expected Ang FIRST in mode 'auto'.
const searchSandbox = {
  window: {},
  console,
  fetch: async (url) => {
    const file = String(url).includes('bani-search') ? 'www/offline/bani-search.json' : 'www/offline/search.json';
    return { ok: true, json: async () => JSON.parse(fs.readFileSync(path.join(ROOT, file), 'utf8')) };
  },
};
vm.createContext(searchSandbox);
vm.runInContext(ss, searchSandbox);
const GS = searchSandbox.window.GS_SCRIPTURE_SEARCH;
ok('v244 search: GS_SCRIPTURE_SEARCH loads with the real index', !!GS && typeof GS.query === 'function');
const specQueries = [
  ['ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', 244, 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ'],
  ['ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ', 451, 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ'],
  ['ਮੈ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੇ ਨਾਲ', 588, 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ ਨਾਲਿ'],
  ['ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ', 885, 'ਕੋਈ ਬੋਲੈ ਰਾਮ ਰਾਮ ਕੋਈ ਖੁਦਾਇ'],
  ['ਗੁਣ ਗਾਵਾ ਨਿਤ', 163, 'ਹਉ ਹਰਿ ਗੁਣ ਗਾਵਾ ਨਿਤ'],
];
for (const [q, wantAng, wantStart] of specQueries) {
  const res = await GS.query(q, 40, 'auto');
  ok(`v244 search: "${q}" → Ang ${wantAng} FIRST`,
    res.length > 0 && res[0].src === 'sggs' && res[0].ang === wantAng && String(res[0].g).includes(wantStart),
    res.length ? `got Ang ${res[0].ang} "${String(res[0].g).slice(0, 50)}"` : 'no results');
}
// Exact match still wins whenever it applies, and every mode still works.
{
  const exact = await GS.query('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', 40, 'auto');
  ok('v244 search: exact phrase still ranks first (Ang 244, exact line)',
    exact.length > 0 && exact[0].ang === 244 && String(exact[0].g).startsWith('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ'));
  const first = await GS.query('ਮਮਪਜ', 40, 'first');
  ok("v244 search: mode 'first' still works (Ang 244 first)", first.length > 0 && first[0].ang === 244, `got ${first[0] ? first[0].ang : 'none'}`);
  const anyFirst = await GS.query('ਮਮਪਜ', 40, 'any-first');
  ok("v244 search: mode 'any-first' still works (Ang 244 in results)", anyFirst.length > 0 && anyFirst.some(r => r.ang === 244));
  const roman = await GS.query('mil mere preetama', 40, 'roman');
  ok("v244 search: mode 'roman' still works (Ang 244 first)", roman.length > 0 && roman[0].ang === 244, `got ${roman[0] ? roman[0].ang : 'none'}`);
  const word = await GS.query('ਮਿਲੁ', 40, 'word');
  ok("v244 search: mode 'word' still works", word.length > 0 && word.some(r => r.ang === 244));
  const ang = await GS.query('244', 40, 'ang');
  ok("v244 search: mode 'ang' still works (all results Ang 244)", ang.length > 0 && ang.every(r => r.ang === 244));
}
// Static: the two new scoring layers sit below exact (120) and above the old fallbacks.
ok('v244 search: skeleton phrase scores 115 (below exact 120, above the run)',
  ss.includes('skelNeedle.length>=2') && ss.includes('score=115'));
ok('v244 search: longest consecutive run scores min(112, 106+run) for run>=2',
  ss.includes('if(run>=2)score=Math.min(112,106+run)'));
ok('v244 search: skeletons precomputed in prepareChunk (skel + skelTokens)',
  ss.includes('skel:stripMatras') && ss.includes('skelTokens:skelWords(g)'));

// (16c) Mic: listeners at app boot (first tap must work).
ok('v244 mic: listeners registered at startup, right after render()',
  (() => { const i = app.indexOf('bindGlobals();bootData();render();'); if (i === -1) return false;
    const j = app.indexOf('ensureVoiceListeners();', i); return j !== -1 && j - i < 600; })());
ok('v244 mic: attach() also registers the listeners (idempotent backstop)',
  app.includes('ensureVoiceListeners();\n syncVoiceStopUI();'));
ok('v244 mic: promise guard — concurrent calls share one registration',
  app.includes('if(voiceListenersPromise)return voiceListenersPromise;') &&
  app.includes('if(voiceListenersReady)return;'));
ok('v244 mic: guard resets on failure so a later call retries',
  app.includes('voiceListenersPromise=null;throw e;'));
ok('v244 mic: beginSegment marks sawStarted after startOnce succeeds',
  (() => { const i = app.indexOf('run.started=true;'); if (i === -1) return false;
    const seg = app.slice(i, app.indexOf('setListeningUI(true);', i)); return seg.includes('run.sawStarted=true;'); })());
ok('v244 mic: stopped handler still ends the segment only for a started run',
  app.includes("if(run){run.stopped=true;if(run.sawStarted&&run.started)run.endSegment();}"));

// (16d) Mic restart, tested extra hard (Karamjit: "I want the mic perfect").
// The stub simulates his phone: 'stopped' WITHOUT a preceding 'started'.
{
  // (d1) Boot: two concurrent ensureVoiceListeners() calls register once.
  const t = makeNativeCtx([[]]);
  const p1 = vm.runInContext('ensureVoiceListeners()', t.ctx);
  const p2 = vm.runInContext('ensureVoiceListeners()', t.ctx);
  await Promise.all([p1, p2]);
  ok('(d1) boot: two concurrent ensureVoiceListeners() calls register each listener ONCE',
    t.stub._calls.addListener.partialResults === 1 && t.stub._calls.addListener.listeningState === 1,
    JSON.stringify(t.stub._calls.addListener));
  await vm.runInContext('ensureVoiceListeners()', t.ctx);
  ok('(d1) boot: a later call after ready registers nothing more',
    t.stub._calls.addListener.partialResults === 1 && t.stub._calls.addListener.listeningState === 1,
    JSON.stringify(t.stub._calls.addListener));
}
{
  // (d2) FIRST TAP: listeners already registered at boot, so the very first
  // mic tap after launch hears words — no warm-up tap needed.
  const t = makeNativeCtx([['ਸੋ ਸਤਿਗੁਰੁ']]);
  await vm.runInContext('ensureVoiceListeners()', t.ctx);
  const p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(d2) first tap: mic hears on the VERY FIRST tap after boot',
    t.input.value === 'ਸੋ ਸਤਿਗੁਰੁ', JSON.stringify(t.input.value));
  ok('(d2) first tap: run keeps listening until Stop (no early cut-off)',
    settled === false && readRun(t.ctx).run !== null, `settled=${settled}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d2) first tap: Stop settles with the words intact',
    settled === true && t.input.value === 'ਸੋ ਸਤਿਗੁਰੁ', `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}
{
  // (d3) Restart without 'started': 2 segments, words accumulate, no hang.
  const t = makeNativeCtx([
    ['ਕੋਈ', 'ਕੋਈ ਬੋਲੇ'],
    ['ਰਾਮ', 'ਰਾਮ ਰਾਮ'],
  ], { noStarted: true });
  await vm.runInContext('ensureVoiceListeners()', t.ctx);
  const p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok("(d3) no-started: segment restarts after 'stopped' without 'started' (2+ starts)",
    t.stub._calls.start.length >= 2, `starts=${t.stub._calls.start.length}`);
  ok('(d3) no-started: words from BOTH segments accumulate',
    t.input.value === 'ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ', JSON.stringify(t.input.value));
  ok('(d3) no-started: run keeps listening — never hangs mid-line',
    settled === false && readRun(t.ctx).run !== null, `settled=${settled}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d3) no-started: Stop settles the run with words intact',
    settled === true && t.input.value === 'ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ', `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}
{
  // (d4) LONG LINE: 11 words across 3 segments, 'started' never fires —
  // nothing lost, never hangs, partials fill the input live.
  const longSegs = [
    ['ਸੋ', 'ਸੋ ਸਤਿਗੁਰੁ', 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ', 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ'],
    ['ਨਾਲਿ', 'ਨਾਲਿ ਹੈ', 'ਨਾਲਿ ਹੈ ਜਿਥੈ', 'ਨਾਲਿ ਹੈ ਜਿਥੈ ਕਿਥੈ'],
    ['ਮੈਨੋ', 'ਮੈਨੋ ਲਏ', 'ਮੈਨੋ ਲਏ ਛਡਾਈ'],
  ];
  const wantLong = 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ ਨਾਲਿ ਹੈ ਜਿਥੈ ਕਿਥੈ ਮੈਨੋ ਲਏ ਛਡਾਈ';
  const t = makeNativeCtx(longSegs, { noStarted: true });
  await vm.runInContext('ensureVoiceListeners()', t.ctx);
  const p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 900);
  ok('(d4) long line: 11 words across 3 segments, NOTHING lost',
    t.input.value === wantLong, JSON.stringify(t.input.value));
  ok('(d4) long line: restarted after every segment (3+ starts)',
    t.stub._calls.start.length >= 3, `starts=${t.stub._calls.start.length}`);
  ok('(d4) long line: run still listening until Stop — never cuts off early',
    settled === false && readRun(t.ctx).run !== null, `settled=${settled}`);
  ok('(d4) long line: partials filled the input LIVE (input events dispatched)',
    t.input.events >= 10, `events=${t.input.events}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d4) long line: Stop settles with the full 11-word line intact',
    settled === true && t.input.value === wantLong, `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}
{
  // (d5) CONTROL: the same 3-segment long line WITH 'started' events (the
  // normal path) still works — the fix did not break the healthy path.
  const longSegs = [
    ['ਸੋ', 'ਸੋ ਸਤਿਗੁਰੁ', 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ', 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ'],
    ['ਨਾਲਿ', 'ਨਾਲਿ ਹੈ', 'ਨਾਲਿ ਹੈ ਜਿਥੈ', 'ਨਾਲਿ ਹੈ ਜਿਥੈ ਕਿਥੈ'],
    ['ਮੈਨੋ', 'ਮੈਨੋ ਲਏ', 'ਮੈਨੋ ਲਏ ਛਡਾਈ'],
  ];
  const wantLong = 'ਸੋ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ ਨਾਲਿ ਹੈ ਜਿਥੈ ਕਿਥੈ ਮੈਨੋ ਲਏ ਛਡਾਈ';
  const t = makeNativeCtx(longSegs);
  await vm.runInContext('ensureVoiceListeners()', t.ctx);
  const p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 900);
  ok('(d5) control: long line across 3 segments still works with started events',
    t.input.value === wantLong && t.stub._calls.start.length >= 3,
    `value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d5) control: Stop settles with the full line intact',
    settled === true && t.input.value === wantLong, `settled=${settled}`);
}

// ---- 17. v2.2.44 (5): ♡ save button on the MAIN search results ----
ok('v244 save: main search run() passes save=true',
  app.includes("const run=()=>showOfflineResults(input.value,'searchResults',true);"));
ok('v244 save: history-tap re-run passes save=true',
  app.includes("showOfflineResults(inp.value,'searchResults',true)"));
ok('v244 save: Kirtan call unchanged (still save=true)',
  app.includes("showOfflineResults(kirtanQuery,'kirtanResults',true)"));
ok('v244 save: Ask-screen related passages still render without save (out of scope)',
  app.includes('scriptureResultsMarkup(v.matches)'));
ok('v244 save: ♡/♥ button renders from the saved state (saved → ♥, else ♡)',
  app.includes('data-save-hit="${saveKey}"') && app.includes("${saved?'♥':'♡'}"));
// Behavioral: the REAL scriptureResultsMarkup + bookmarksScreen + save toggle
// branch, extracted from app.js and run in a vm.
const _appLines = app.split('\n');
function extractFn(lines, startPrefix) {
  const s = lines.findIndex(l => l.startsWith(startPrefix));
  if (s === -1) return '';
  let e = s;
  while (e < lines.length && lines[e] !== '}') e++;
  return lines.slice(s, e + 1).join('\n');
}
const markupSrc = extractFn(_appLines, 'function scriptureResultsMarkup(');
const bookmarksLine = _appLines.find(l => l.startsWith('function bookmarksScreen(){'));
const saveBranch = _appLines.find(l => l.includes("const save=e.target.closest('[data-save-hit],[data-remove-saved]');"));
ok('v244 save: markup + Saved screen + toggle branch extractable from app.js',
  markupSrc.includes('data-save-hit') && !!bookmarksLine && !!saveBranch);
const escFn = V7.esc || ((s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])));
const saveState = { lang: 'pa', showTranslit: true, savedVerses: [] };
let savePersist = 0, saveRender = 0;
const saveSandbox = {
  state: saveState,
  age: (pa, en) => saveState.lang === 'pa' ? pa : en,
  esc: escFn,
  t: (k) => ({ kirtan: 'Kirtan' }[k] || k),
  persist: () => { savePersist++; },
  render: () => { saveRender++; },
  window: { GS_SCRIPTURE_SEARCH: {
    lookup: (ang, idx) => (ang === 244 && idx === 0) ? { g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥' } : null,
    lookupBani: (baniId, idx) => (baniId === 4 && idx === 0) ? { g: 'ਜਾਪੁ ਸਾਹਿਬ ਪਹਿਲੀ ਲਾਈਨ', baniTitle: 'Jaap Sahib', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam' } : null,
  } },
  console,
};
vm.createContext(saveSandbox);
vm.runInContext(markupSrc + '\n' + bookmarksLine + '\nfunction __saveTap(e){' + saveBranch + '}', saveSandbox);
const sggsRow = [{ src: 'sggs', ang: 244, idx: 0, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', roman: 'mil mere preetamaa jeeo', en: '' }];
const baniRow = [{ src: 'bani', group: 'dasam', baniId: 4, idx: 0, g: 'ਜਾਪੁ ਸਾਹਿਬ ਪਹਿਲੀ ਲਾਈਨ', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', en: 'x', roman: 'jaap' }];
saveSandbox.__rows = sggsRow;
const mUnsaved = vm.runInContext('scriptureResultsMarkup(__rows,{save:true})', saveSandbox);
ok('v244 save: ♡ button present on a main-search result (save=true)',
  mUnsaved.includes('data-save-hit="244:0"') && mUnsaved.includes('♡'), mUnsaved.slice(0, 200));
const mNoSave = vm.runInContext('scriptureResultsMarkup(__rows,{save:false})', saveSandbox);
ok('v244 save: NO ♡ when save=false (Ask/Kirtan-off path unchanged)',
  !mNoSave.includes('data-save-hit'));
saveSandbox.__rows = baniRow;
const mBani = vm.runInContext('scriptureResultsMarkup(__rows,{save:true})', saveSandbox);
ok('v244 save: ♡ button present on a Bani result too (bani:4:0)',
  mBani.includes('data-save-hit="bani:4:0"') && mBani.includes('♡'));
// Toggle: tap ♡ → saved; Saved tab lists it; tap ♥ → removed.
const fakeSaveEvent = (key, field) => ({ target: { closest: (sel) => (sel.includes('data-save-hit') || sel.includes('data-remove-saved')) ? { dataset: { [field]: key } } : null } });
saveSandbox.__ev = fakeSaveEvent('244:0', 'saveHit');
vm.runInContext('__saveTap(__ev)', saveSandbox);
ok('v244 save: tap ♡ adds the shabad to savedVerses + persists',
  saveState.savedVerses.length === 1 && saveState.savedVerses[0].ang === 244 && saveState.savedVerses[0].idx === 0 && savePersist === 1,
  JSON.stringify(saveState.savedVerses));
saveSandbox.__rows = sggsRow;
const mSaved = vm.runInContext('scriptureResultsMarkup(__rows,{save:true})', saveSandbox);
ok('v244 save: already-saved result shows ♥ (filled)',
  mSaved.includes('data-save-hit="244:0"') && mSaved.includes('♥'));
const bm = vm.runInContext('bookmarksScreen()', saveSandbox);
ok('v244 save: Saved tab lists the saved shabad (Ang 244)',
  bm.includes('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ') && bm.includes('244'), bm.slice(0, 300));
saveSandbox.__ev = fakeSaveEvent('244:0', 'saveHit');
vm.runInContext('__saveTap(__ev)', saveSandbox);
ok('v244 save: tap ♥ again removes it (unsave toggle)',
  saveState.savedVerses.length === 0 && savePersist === 2, JSON.stringify(saveState.savedVerses));
// Bani save via lookupBani.
saveSandbox.__ev = fakeSaveEvent('bani:4:0', 'saveHit');
vm.runInContext('__saveTap(__ev)', saveSandbox);
ok('v244 save: tap ♡ on a Bani result saves it via lookupBani',
  saveState.savedVerses.length === 1 && saveState.savedVerses[0].src === 'bani' && saveState.savedVerses[0].baniId === 4,
  JSON.stringify(saveState.savedVerses));
const bmBani = vm.runInContext('bookmarksScreen()', saveSandbox);
ok('v244 save: Saved tab lists the saved Bani (Dasam Granth — Jaap Sahib)',
  bmBani.includes('ਜਾਪੁ ਸਾਹਿਬ') && bmBani.includes('Dasam Granth'), bmBani.slice(0, 300));

// ---- 18. v2.2.44 (6): delete search history — Clear all + × per item ----
ok('v244 hist: Clear-all button in the history box (next to the History heading)',
  app.includes('data-clear-history') && app.includes("age('ਸਭ ਸਾਫ਼ ਕਰੋ','Clear all')"));
ok('v244 hist: each history row has a × delete button (data-remove-history)',
  app.includes('data-remove-history') && app.includes('class="history-del"'));
ok('v244 hist: history box renders via one searchHistoryBoxHTML() (heading + list together)',
  app.includes('function searchHistoryBoxHTML(){') && app.includes('${searchHistoryBoxHTML()}'));
ok('v244 hist: box re-renders as a whole on open, Clear-all and single delete (3 sites)',
  (app.match(/box\.innerHTML=searchHistoryBoxHTML\(\)/g) || []).length === 3);
ok('v244 hist: delete branches run BEFORE the query-tap branch (× never re-runs the search)',
  (() => { const i = app.indexOf('[data-clear-history]'); const j = app.indexOf('[data-remove-history]'); const k = app.indexOf('[data-history-q]'); return i !== -1 && j !== -1 && k !== -1 && i < k && j < k; })());
ok('v244 hist: pushSearchHistory still caps at 12 + dedupes to front',
  app.includes('state.searchHistory=[q,...state.searchHistory.filter(x=>x!==q)].slice(0,12);'));
ok('v244 hist: history-row CSS exists (row flex + × button)',
  css.includes('.history-row{display:flex;align-items:center;border-bottom:1px solid var(--line)}') &&
  css.includes('.history-del{') && css.includes('.history-row .catalog-row{flex:1;min-width:0;border-bottom:0}'));
// Behavioral: the REAL history functions + handler branches in a vm.
const histFnsSrc = extractFn(_appLines, 'function searchHistoryBoxHTML(){') + '\n' +
  extractFn(_appLines, 'function searchHistoryHTML(){') + '\n' +
  extractFn(_appLines, 'function pushSearchHistory(');
const chBranch = _appLines.find(l => l.includes("const ch=e.target.closest('[data-clear-history]');"));
const rhBranch = _appLines.find(l => l.includes("const rh=e.target.closest('[data-remove-history]');"));
const hqBranch = _appLines.find(l => l.includes("const hq=e.target.closest('[data-history-q]');"));
ok('v244 hist: history functions + handler branches extractable from app.js',
  histFnsSrc.includes('searchHistoryBoxHTML') && !!chBranch && !!rhBranch && !!hqBranch);
const histState = { lang: 'pa', searchHistory: [] };
let histPersist = 0; const showCalls = [];
const histBox = { innerHTML: '' };
const histInput = { value: '' };
const histSandbox = {
  state: histState,
  age: (pa, en) => histState.lang === 'pa' ? pa : en,
  esc: escFn,
  t: (k) => ({ history: 'History', noHistory: 'No history yet' }[k] || k),
  persist: () => { histPersist++; },
  $: (id) => id === 'searchHistoryBox' ? histBox : id === 'searchInput' ? histInput : null,
  showOfflineResults: (q, target, save) => { showCalls.push([q, target, save]); },
  console,
};
vm.createContext(histSandbox);
vm.runInContext(histFnsSrc + '\nfunction __histTap(e){' + chBranch + rhBranch + hqBranch + '}', histSandbox);
vm.runInContext("pushSearchHistory('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');pushSearchHistory('ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ');pushSearchHistory('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ');", histSandbox);
const boxHtml = vm.runInContext('searchHistoryBoxHTML()', histSandbox);
ok('v244 hist: box shows Clear all + an × on EACH item (3 items)',
  boxHtml.includes('data-clear-history') && (boxHtml.match(/data-remove-history/g) || []).length === 3 &&
  (boxHtml.match(/class="history-row"/g) || []).length === 3, boxHtml.slice(0, 300));
const fakeHistEvent = (kind, value) => ({ target: { closest: (sel) => {
  if (kind === 'clear' && sel === '[data-clear-history]') return { dataset: {} };
  if (kind === 'remove' && sel === '[data-remove-history]') return { dataset: { removeHistory: value } };
  if (kind === 'query' && sel === '[data-history-q]') return { dataset: { historyQ: value } };
  return null;
} } });
const persistBeforeDelete = histPersist;
histSandbox.__ev = fakeHistEvent('remove', 'ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ');
vm.runInContext('__histTap(__ev)', histSandbox);
ok('v244 hist: × removes ONLY that item (others stay)',
  histState.searchHistory.length === 2 && !histState.searchHistory.includes('ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ') &&
  histState.searchHistory.includes('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ') && histState.searchHistory.includes('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ'),
  JSON.stringify(histState.searchHistory));
ok('v244 hist: single delete persists exactly once + re-renders the box WITHOUT re-running a search',
  histPersist === persistBeforeDelete + 1 && histBox.innerHTML.includes('ਕੋਈ ਬੋਲੇ ਰਾਮ ਰਾਮ') && !histBox.innerHTML.includes('ਹਰ ਜੁਗ ਜੁਗ ਭਗਤਿ') && showCalls.length === 0,
  `persist=${histPersist} showCalls=${showCalls.length}`);
histSandbox.__ev = fakeHistEvent('query', 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');
vm.runInContext('__histTap(__ev)', histSandbox);
ok('v244 hist: tapping the query text still re-runs the search (save=true, no regression)',
  showCalls.length === 1 && showCalls[0][0] === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ' && showCalls[0][1] === 'searchResults' && showCalls[0][2] === true &&
  histInput.value === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', JSON.stringify(showCalls));
histSandbox.__ev = fakeHistEvent('clear');
vm.runInContext('__histTap(__ev)', histSandbox);
ok('v244 hist: Clear all empties the history',
  histState.searchHistory.length === 0, JSON.stringify(histState.searchHistory));
ok('v244 hist: empty box shows the no-history message and NO Clear-all button',
  histBox.innerHTML.includes('No history yet') && !histBox.innerHTML.includes('data-clear-history'),
  histBox.innerHTML.slice(0, 200));
for (let i = 0; i < 13; i++) vm.runInContext(`pushSearchHistory('qq${i}');`, histSandbox);
ok('v244 hist: 12-item cap still works (13 pushes → 12 kept, newest first)',
  histState.searchHistory.length === 12 && histState.searchHistory[0] === 'qq12' && !histState.searchHistory.includes('qq0'),
  JSON.stringify(histState.searchHistory));
vm.runInContext("pushSearchHistory('qq12');", histSandbox);
ok('v244 hist: re-adding an existing query dedupes to front (no duplicate)',
  histState.searchHistory.length === 12 && histState.searchHistory[0] === 'qq12' &&
  histState.searchHistory.filter(x => x === 'qq12').length === 1);

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
