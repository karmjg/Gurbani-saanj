/* Gurbani Saanjh personal-trial content.
   Test Vishraam positions (only on a1-5) derived from a referenced Santhiya teaching example:
   https://discoversikhism.com/learn_gurbani/japji_sahib_visram_test.html
   These are explanatory annotations ONLY, not changes to the original scripture.
   Do not automatically generate positions for other lines.

   IMPORTANT: These are SELECTED EXCERPTS, not a complete Ang or complete Shabad.
   Meanings are working paraphrases, not approved/licensed translations or teeka.
   Source checks before publication: https://www.srigranth.org/
   Replace demo data with an authorized, reviewed full corpus for a real release.
*/
window.GS_DATA = {
  reader: {
    id:'sggs', titlePa:'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ', titleEn:'Sri Guru Granth Sahib Ji',
    sections: [
      {id:'ang-1',ang:1, labelPa:'ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ',labelEn:'Japji Sahib Ji',complete:false,
       lines:[
        {id:'a1-1',roman:'IkOankar Sat Naam Kartaa Purakh Nirbhau Nirvair Akaal Moorat Ajoonee Saibhang Gur Prasaad ||',g:'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥',pa:'ਇੱਕ ਪਰਮਾਤਮਾ ਹੈ। ਉਹ ਸੱਚਾ, ਸਿਰਜਣਹਾਰ, ਨਿਰਭਉ, ਨਿਰਵੈਰ, ਅਕਾਲ, ਜਨਮ ਤੋਂ ਰਹਿਤ ਅਤੇ ਆਪਣੇ ਆਪ ਤੋਂ ਪ੍ਰਕਾਸ਼ਮਾਨ ਹੈ। ਗੁਰੂ ਦੀ ਕਿਰਪਾ ਨਾਲ ਉਸ ਦੀ ਸਮਝ ਮਿਲਦੀ ਹੈ।',en:'There is One Divine Reality: true, creator, without fear or enmity, timeless, beyond birth, self-existent, and realized by the Guru’s grace.'},
        {id:'a1-2',roman:'|| Jap ||',g:'॥ ਜਪੁ ॥',pa:'ਇੱਥੋਂ ਜਪੁਜੀ ਸਾਹਿਬ ਜੀ ਦੀ ਬਾਣੀ ਸ਼ੁਰੂ ਹੁੰਦੀ ਹੈ।',en:'This heading introduces Japji Sahib Ji.'},
        {id:'a1-3',roman:'Aad Sach Jugaad Sach ||',g:'ਆਦਿ ਸਚੁ ਜੁਗਾਦਿ ਸਚੁ ॥',pa:'ਪਰਮਾਤਮਾ ਸ਼ੁਰੂ ਤੋਂ ਸੱਚ ਹੈ ਅਤੇ ਯੁੱਗਾਂ ਤੋਂ ਸੱਚ ਹੈ।',en:'The Divine has been true from the beginning and through the ages.'},
        {id:'a1-4',roman:'Hai Bhee Sach Nanak Hosee Bhee Sach ||1||',g:'ਹੈ ਭੀ ਸਚੁ ਨਾਨਕ ਹੋਸੀ ਭੀ ਸਚੁ ॥੧॥',pa:'ਉਹ ਹੁਣ ਵੀ ਸੱਚ ਹੈ ਅਤੇ ਅੱਗੇ ਵੀ ਸੱਚ ਰਹੇਗਾ।',en:'The Divine is true now and will remain true.'},
        {id:'a1-5',vishraam:{0:'short',3:'long'},roman:'Sochai Soch Na Hovaee Je Sochee Lakh Vaar ||',g:'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥',pa:'ਕੇਵਲ ਬਾਹਰੀ ਸੁੱਚ ਜਾਂ ਲੱਖ ਵਾਰ ਸੋਚਣ ਨਾਲ ਹੀ ਆਤਮਕ ਸੁੱਚ ਨਹੀਂ ਆਉਂਦੀ। ਟੀਕਿਆਂ ਵਿੱਚ ਇਸ ਪੰਗਤੀ ਦੇ ਸ਼ਬਦਾਂ ਦੀ ਵੱਖ-ਵੱਖ ਵਿਆਖਿਆ ਮਿਲਦੀ ਹੈ।',en:'Outer purification or thinking repeatedly does not alone bring inner purity. Commentaries discuss the wording in different ways.'},
        {id:'a1-6',roman:'Chupai Chup Na Hovaee Je Laae Rahaa Liv Taar ||',g:'ਚੁਪੈ ਚੁਪ ਨ ਹੋਵਈ ਜੇ ਲਾਇ ਰਹਾ ਲਿਵ ਤਾਰ ॥',pa:'ਲਗਾਤਾਰ ਚੁੱਪ ਰਹਿਣ ਨਾਲ ਹੀ ਮਨ ਦੀ ਅਸਲ ਚੁੱਪ ਨਹੀਂ ਮਿਲਦੀ।',en:'Remaining outwardly silent does not alone create inner stillness.'},
        {id:'a1-7',roman:'Bhukhiaa Bhukh Na Utree Je Bannaa Pureeaa Bhaar ||',g:'ਭੁਖਿਆ ਭੁਖ ਨ ਉਤਰੀ ਜੇ ਬੰਨਾ ਪੁਰੀਆ ਭਾਰ ॥',pa:'ਬਹੁਤ ਕੁਝ ਇਕੱਠਾ ਕਰਨ ਨਾਲ ਵੀ ਮਨ ਦੀ ਅੰਦਰਲੀ ਤ੍ਰਿਸ਼ਨਾ ਨਹੀਂ ਮੁੱਕਦੀ।',en:'Even immense possessions cannot satisfy inward craving.'},
        {id:'a1-8',roman:'Sahas Siaanapaa Lakh Hohi Ta Ik Na Chalai Naal ||',g:'ਸਹਸ ਸਿਆਣਪਾ ਲਖ ਹੋਹਿ ਤ ਇਕ ਨ ਚਲੈ ਨਾਲਿ ॥',pa:'ਅਣਗਿਣਤ ਚਤੁਰਾਈਆਂ ਆਤਮਕ ਸੱਚ ਤੱਕ ਪਹੁੰਚਣ ਲਈ ਕਾਫ਼ੀ ਨਹੀਂ।',en:'Countless clever devices do not bring spiritual realization.'},
        {id:'a1-9',roman:'Kiv Sachiaaraa Hoeeai Kiv Koorrai Tutai Paal ||',g:'ਕਿਵ ਸਚਿਆਰਾ ਹੋਈਐ ਕਿਵ ਕੂੜੈ ਤੁਟੈ ਪਾਲਿ ॥',pa:'ਮਨੁੱਖ ਸੱਚਿਆਰਾ ਕਿਵੇਂ ਬਣ ਸਕਦਾ ਹੈ ਅਤੇ ਅੰਦਰਲੇ ਝੂਠ ਦੀ ਕੰਧ ਕਿਵੇਂ ਟੁੱਟ ਸਕਦੀ ਹੈ?',en:'How can a person become truthful, and how can the wall of falsehood be broken?'},
        {id:'a1-10',roman:'Hukam Rajaaee Chalnaa Nanak Likhiaa Naal ||1||',g:'ਹੁਕਮਿ ਰਜਾਈ ਚਲਣਾ ਨਾਨਕ ਲਿਖਿਆ ਨਾਲਿ ॥੧॥',pa:'ਗੁਰੂ ਨਾਨਕ ਸਾਹਿਬ ਸਿੱਖਾਉਂਦੇ ਹਨ ਕਿ ਪਰਮਾਤਮਾ ਦੇ ਹੁਕਮ ਅਨੁਸਾਰ ਜੀਵਨ ਜਿਊਣਾ ਹੈ।',en:'Guru Nanak teaches living in harmony with Divine Hukam.'}
       ]}
    ]
  },
  kirtan: [
    {id:'kirtan-lakh',titlePa:'ਲਖ ਖੁਸੀਆ ਪਾਤਿਸਾਹੀਆ',titleEn:'Lakh Khushia Patshahia',ang:44,descriptionPa:'ਸਿਰੀਰਾਗੁ ਮਹਲਾ ੫',descriptionEn:'Siri Raag, Fifth Mehl',
     lines:[{id:'k1',g:'ਲਖ ਖੁਸੀਆ ਪਾਤਿਸਾਹੀਆ ਜੇ ਸਤਿਗੁਰੁ ਨਦਰਿ ਕਰੇਇ ॥',pa:'ਜੇ ਸਤਿਗੁਰੂ ਮਿਹਰ ਦੀ ਨਿਗਾਹ ਕਰੇ ਤਾਂ ਉਹ ਬਖ਼ਸ਼ਿਸ਼ ਲੱਖਾਂ ਪਾਤਸ਼ਾਹੀਆਂ ਦੀਆਂ ਖ਼ੁਸ਼ੀਆਂ ਵਰਗੀ ਹੈ।',en:'The True Guru’s gracious glance is like the joy of countless kingdoms.'}],complete:false},
    {id:'kirtan-thakur',titlePa:'ਤੂ ਠਾਕੁਰੁ ਤੁਮ ਪਹਿ ਅਰਦਾਸਿ',titleEn:'Tu Thakur Tum Peh Ardaas',ang:268,descriptionPa:'ਸੁਖਮਨੀ ਸਾਹਿਬ ਜੀ',descriptionEn:'Sukhmani Sahib Ji',
     lines:[{id:'k2',g:'ਤੂ ਠਾਕੁਰੁ ਤੁਮ ਪਹਿ ਅਰਦਾਸਿ ॥',pa:'ਹੇ ਪ੍ਰਭੂ, ਤੂੰ ਮਾਲਕ ਹੈਂ ਅਤੇ ਤੇਰੇ ਅੱਗੇ ਹੀ ਅਰਦਾਸ ਹੈ।',en:'You are the Master; to You I offer my prayer.'}],complete:false}
  ],
  words:{
    'ਸੋਚੈ':{pa:'ਸੋਚੈ — ਇਸ ਦਾ ਭਾਵ ਪੂਰੀ ਪੰਗਤੀ ਅਤੇ ਟੀਕੇ ਦੇ ਸੰਦਰਭ ਵਿੱਚ ਸਮਝਣਾ ਚਾਹੀਦਾ ਹੈ।',en:'ਸੋਚੈ — interpret in the context of the full line and an authoritative commentary.'},
    'ਹੁਕਮਿ':{pa:'ਹੁਕਮਿ — ਹੁਕਮ ਅਨੁਸਾਰ; ਇੱਥੇ ਪੂਰੇ ਸ਼ਬਦ ਦਾ ਪ੍ਰਸੰਗ ਮਹੱਤਵਪੂਰਨ ਹੈ।',en:'ਹੁਕਮਿ — in accordance with Hukam; the whole passage supplies context.'},
    'ਨਾਨਕ':{pa:'ਨਾਨਕ — ਗੁਰੂ ਨਾਨਕ ਸਾਹਿਬ ਜੀ ਦੀ ਬਾਣੀ ਵਿੱਚ ਵਰਤਿਆ ਨਾਮ।',en:'ਨਾਨਕ — the name used by Guru Nanak Sahib Ji in Gurbani.'},
    'ਸਤਿਗੁਰੁ':{pa:'ਸਤਿਗੁਰੁ — ਸੱਚਾ ਗੁਰੂ।',en:'ਸਤਿਗੁਰੁ — the True Guru.'}
  }
};
