/* Gurbani Saanjh v2.2.0 — Kirtan Shabad book (offline).
 * Loads www/offline/kirtan-shabads.json:
 *   {"version":"2.2.0","source":"...","count":N,
 *    "shabads":[{"id":"k1","firstLine":"...","raag":"...","mahla":"...",
 *                 "ang":123,"lineStart":5,"lineCount":8}]}
 * Each shabad's full text is sliced from the already-bundled
 * www/offline/ang/{n}.json lines array (lineStart, 0-based, lineCount lines).
 * No scripture is fabricated: every line comes from the bundled Ang files.
 * If the file is missing, list() resolves to [] and the Kirtan section shows
 * its existing state (corpus search + saved) — never a crash.
 */
(()=>{
'use strict';
let listCache=null,listLoading=null;
async function list(){
 if(listCache!==null)return listCache;
 if(!listLoading)listLoading=fetch('offline/kirtan-shabads.json',{cache:'force-cache'}).then(async r=>{
  if(!r.ok)throw Error('kirtan-shabads.json missing');
  const data=await r.json();
  const arr=Array.isArray(data?.shabads)?data.shabads:[];
  listCache=arr.filter(s=>s&&typeof s.id==='string'&&Number.isInteger(Number(s.ang))&&Number(s.ang)>=1&&Number(s.ang)<=1430).map(s=>({
   id:String(s.id),
   firstLine:String(s.firstLine||''),
   raag:String(s.raag||''),
   mahla:String(s.mahla||''),
   ang:Number(s.ang),
   lineStart:Math.max(0,Number(s.lineStart)||0),
   lineCount:Math.max(1,Math.min(60,Number(s.lineCount)||8)),
  }));
  return listCache;
 }).catch(()=>{listCache=[];return listCache});
 return listLoading;
}
async function shabad(id){
 const items=await list();
 const meta=items.find(s=>s.id===String(id));
 if(!meta)throw Error('Shabad not in book');
 const data=await window.GS_REMOTE.read('ang',meta.ang);
 const lines=(data.lines||[]).slice(meta.lineStart,meta.lineStart+meta.lineCount);
 if(!lines.length)throw Error('Shabad lines unavailable');
 return {meta,lines};
}
window.GS_KIRTAN={list,shabad};
})();
