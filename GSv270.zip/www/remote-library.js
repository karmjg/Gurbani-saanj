/* No runtime internet access. All 1,430 Angs and available Sundar Gutka Banis are INCLUDED by build-time importer. */
(()=>{'use strict';
let manifestP=null;
async function manifest(){if(!manifestP)manifestP=fetch('offline/manifest.json',{cache:'force-cache'}).then(r=>{if(!r.ok)throw Error('Offline Gurbani library missing from APK');return r.json()});return manifestP}
async function read(kind,id){if(!['ang','bani'].includes(kind))throw Error('Invalid scripture source');const n=Number(id);if(!Number.isInteger(n)||n<1)throw Error('Invalid reference');await manifest();
 const r=await fetch(`offline/${kind}/${n}.json`,{cache:'force-cache'});if(!r.ok)throw Error('This text is not in the offline source catalogue');const data=await r.json();if(!data.lines?.length)throw Error('Unusable text data');return {...data,offline:true};}
async function list(){return (await manifest()).banis;}
window.GS_REMOTE={read,list};
})();
