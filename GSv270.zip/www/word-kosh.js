/* Gurbani Saanjh v2.2.0 — tap-a-word meanings (fully offline).
 * Lookup chain (exact, never invented):
 *   1. exact match (basic gloss + bundled kosh)
 *   2. strip kosh-stems.json suffixes, longest-first, and retry
 *   3. strip trailing/leading ॥ । punctuation and numerals, retry
 *   4. give up silently (no popup content, word not orange)
 * Never generates unverified definitions. No network fallback.
 */
(()=>{'use strict';
const GLOSS={
 'ਸਤਿ':['ਸੱਚ; ਸਦੀਵੀ ਸੱਚ','truth; eternal truth'],
 'ਨਾਮੁ':['ਨਾਮ; ਪਰਮਾਤਮਾ ਦਾ ਨਾਮ','name; the Divine Name'],
 'ਕਰਤਾ':['ਸਿਰਜਣਹਾਰ; ਰਚਣ ਵਾਲਾ','creator'],
 'ਪੁਰਖੁ':['ਹਸਤੀ; ਵਿਅਕਤੀ (ਪ੍ਰਸੰਗ ਅਨੁਸਾਰ)','being; person (depending on context)'],
 'ਨਿਰਭਉ':['ਜਿਸ ਨੂੰ ਕੋਈ ਡਰ ਨਹੀਂ','fearless; without fear'],
 'ਨਿਰਵੈਰੁ':['ਜਿਸ ਦਾ ਕਿਸੇ ਨਾਲ ਵੈਰ ਨਹੀਂ','without enmity'],
 'ਅਕਾਲ':['ਸਮੇਂ ਤੋਂ ਪਰੇ','timeless; beyond time'],
 'ਮੂਰਤਿ':['ਸਰੂਪ','form; manifestation'],
 'ਅਜੂਨੀ':['ਜਨਮ-ਮਰਨ ਤੋਂ ਪਰੇ','beyond birth and death'],
 'ਸੈਭੰ':['ਆਪਣੇ ਆਪ ਤੋਂ ਪ੍ਰਕਾਸ਼ਮਾਨ','self-existent'],
 'ਗੁਰ':['ਗੁਰੂ','Guru'],
 'ਪ੍ਰਸਾਦਿ':['ਕਿਰਪਾ ਰਾਹੀਂ','by grace'],
 'ਆਦਿ':['ਆਰੰਭ; ਸ਼ੁਰੂ','beginning; from the beginning'],
 'ਸਚੁ':['ਸੱਚ','truth; true'],
 'ਨਾਨਕ':['ਗੁਰੂ ਨਾਨਕ ਸਾਹਿਬ ਜੀ ਦਾ ਨਾਮ','Nanak (Guru Nanak)'],
 'ਹੁਕਮਿ':['ਹੁਕਮ ਅਨੁਸਾਰ','according to the Divine order'],
 'ਰਜਾਈ':['ਰਜ਼ਾ; ਇੱਛਾ ਅਨੁਸਾਰ','in accordance with the will'],
 'ਚਲਣਾ':['ਤੁਰਨਾ; ਜੀਵਨ ਬਿਤਾਉਣਾ','to walk; to conduct one’s life'],
 'ਸੋਚਿ':['ਸੋਚ; ਵਿਚਾਰ ਜਾਂ ਸੁੱਚ (ਪ੍ਰਸੰਗ ਅਨੁਸਾਰ)','thought or purification (context-dependent)'],
 'ਭੁਖ':['ਭੁੱਖ; ਇੱਛਾ ਜਾਂ ਤ੍ਰਿਸ਼ਨਾ','hunger; longing'],
 'ਜੇ':['ਜੇਕਰ','if'],
 'ਲਖ':['ਲੱਖ; 100,000','one hundred thousand'],
 'ਵਾਰ':['ਵਾਰੀ; ਮੌਕਾ','times; occasions'],
 'ਤੂੰ':['ਤੂੰ; ਤੇਰਾ ਸੰਬੋਧਨ','you'],
 'ਤੁਮ':['ਤੂੰ; ਤੁਸੀਂ','you'],
 'ਠਾਕੁਰੁ':['ਮਾਲਕ; ਪ੍ਰਭੂ','Lord; master'],
 'ਅਰਦਾਸਿ':['ਬੇਨਤੀ; ਪ੍ਰਾਰਥਨਾ','prayer; supplication'],
};
const clean=s=>String(s||'').normalize('NFC').trim().replace(/[॥।੦-੯,;.!?]+/gu,'');
// Punctuation/numeral strip used at step 3 of the chain (display keeps originals).
const stripPunct=s=>String(s||'').normalize('NFC').trim().replace(/^[॥।,;!?(){}\[\]"'“”‘’]+|[॥।,;!?(){}\[\]"'“”‘’]+$/gu,'').replace(/[੦-੯0-9]+/gu,'').trim();
let index=null; // Map<word, Array<{meaning,lang}>>
let stems=[];   // suffix strings, longest-first
let readyP=null;
function addDef(map,word,meaning,lang){
 word=clean(word);meaning=String(meaning||'').trim();
 if(!word||!meaning||word===meaning)return;
 lang=lang==='en'?'en':'pa';
 if(!map.has(word))map.set(word,[]);
 const arr=map.get(word);
 if(!arr.some(d=>d.meaning===meaning&&d.lang===lang))arr.push({meaning,lang});
}
function ingestKosh(map,raw){
 if(!raw||typeof raw!=='object')return;
 // Shape A (v2.1/v2.2): {headword: [{word,meaning,lang}, ...]}
 // Shape B: {words:[{word,meaning,lang}...]} or a bare array of the same.
 const buckets=Array.isArray(raw)?[raw]:Array.isArray(raw.words)?[raw.words]:Object.values(raw);
 for(const bucket of buckets){
  if(!Array.isArray(bucket))continue;
  for(const d of bucket){
   if(!d||typeof d!=='object')continue;
   const w=d.word_uni||d.wordUnicode||d.gurmukhi||d.unicode||d.headword||d.word||'';
   const m=d.def_uni||d.definitionUnicode||d.meaning||d.definition||d.arth||d.description||'';
   if(typeof w==='string'&&typeof m==='string')addDef(map,w,m,d.lang);
   else for(const lang of ['pa','en'])if(typeof d[lang]==='string')addDef(map,w||'',d[lang],lang);
  }
 }
}
function ready(){
 if(readyP)return readyP;
 readyP=(async()=>{
  index=new Map();stems=[];
  try{
   const r=await fetch('offline/kosh.json',{cache:'force-cache'});
   if(r.ok)ingestKosh(index,await r.json());
  }catch{}
  try{
   const r=await fetch('offline/kosh-stems.json',{cache:'force-cache'});
   if(r.ok){
    const data=await r.json();
    const arr=Array.isArray(data?.suffixes)?data.suffixes:[];
    stems=arr.filter(s=>typeof s==='string'&&s.trim()).map(s=>s.normalize('NFC').trim())
     .sort((a,b)=>[...b].length-[...a].length||(a<b?-1:1));
   }
  }catch{}
  return true;
 })();
 return readyP;
}
function exactDefs(q,lang){
 const out=[];
 const g=GLOSS[q];
 if(g)out.push({word:q,meaning:lang==='en'?g[1]:g[0],lang});
 const arr=index?.get(q);
 if(arr)for(const d of arr)if(d.lang===lang)out.push({word:q,meaning:d.meaning,lang});
 return out;
}
// Step 2: strip inflectional suffixes, longest-first, retry exact lookup.
function stemmed(q){
 const nq=q.normalize('NFC');
 const out=[];
 for(const suf of stems){
  if(nq.length>suf.length+1&&nq.endsWith(suf)){
   const cand=clean(nq.slice(0,nq.length-suf.length));
   if(cand&&cand!==q)out.push(cand);
  }
 }
 return out;
}
async function lookup(word,lang='pa'){
 const q=clean(word);lang=lang==='en'?'en':'pa';
 if(!q)return {source:'none',definitions:[]};
 await ready();
 let defs=exactDefs(q,lang);
 if(defs.length)return {source:defs[0].word&&GLOSS[q]?'basic-gloss':'offline-kosh',definitions:defs.slice(0,3)};
 for(const cand of stemmed(q)){
  defs=exactDefs(cand,lang);
  if(defs.length)return {source:'offline-kosh-stem',definitions:defs.slice(0,3)};
 }
 const stripped=stripPunct(q);
 if(stripped&&stripped!==q){
  defs=exactDefs(stripped,lang);
  if(defs.length)return {source:'offline-kosh',definitions:defs.slice(0,3)};
  for(const cand of stemmed(stripped)){
   defs=exactDefs(cand,lang);
   if(defs.length)return {source:'offline-kosh-stem',definitions:defs.slice(0,3)};
  }
 }
 return {source:'not-found',definitions:[]};
}
// Synchronous orange-marking check (only valid after ready()).
function hasEntrySync(word){
 if(!index)return false;
 const q=clean(word);if(!q)return false;
 if(index.has(q)||GLOSS[q])return true;
 for(const cand of stemmed(q))if(index.has(cand)||GLOSS[cand])return true;
 const stripped=stripPunct(q);
 if(stripped&&stripped!==q){
  if(index.has(stripped)||GLOSS[stripped])return true;
  for(const cand of stemmed(stripped))if(index.has(cand)||GLOSS[cand])return true;
 }
 return false;
}
// Word-by-word decode of one verse for the Shabad Arth layer.
async function arthFor(line,lang='pa'){
 await ready();
 const parts=String(line?.g||'').trim().split(/\s+/).filter(Boolean);
 const seen=new Set(),out=[];
 for(const part of parts){
  const key=clean(part);
  if(!key||seen.has(key))continue;
  const r=await lookup(part,lang);
  const d=r.definitions?.[0];
  if(d&&d.meaning){seen.add(key);out.push({word:key,meaning:d.meaning})}
  if(out.length>=24)break;
 }
 return out;
}
function parse(x,out=[],depth=0){ // kept for compatibility with older callers
 if(!x||depth>7||out.length>100)return out;
 if(Array.isArray(x)){x.forEach(v=>parse(v,out,depth+1));return out}
 if(typeof x!=='object')return out;
 const word=x.word_uni||x.wordUnicode||x.gurmukhi||x.unicode||x.headword||x.word||'';
 const meaning=x.def_uni||x.definitionUnicode||x.meaning||x.definition||x.arth||x.description||'';
 if(typeof word==='string'&&typeof meaning==='string'&&word.trim()&&meaning.trim())out.push({word:clean(word),meaning:meaning.trim(),lang:'pa'});
 for(const v of Object.values(x))if(v&&typeof v==='object')parse(v,out,depth+1);
 return out;
}
window.GS_KOSH={lookup,parse,clean,ready,hasEntrySync,arthFor,get stems(){return stems.slice()}};
})();
