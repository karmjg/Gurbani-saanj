/* Gurbani Saanjh v2.2.0 — Vishraam pause marks (offline).
 * Loads www/offline/vishraam.json:
 *   {"version":"2.2.0","source":"...","marks":{"a1:0:3":"s","b9:12:5":"l"}}
 * Key: "a{ang}:{lineIdx}:{wordIdx}" or "b{baniId}:{lineIdx}:{wordIdx}".
 * lineIdx = 0-based index into the lines array of ang/{n}.json or
 * bani/{id}.json. wordIdx = 0-based index into g.trim().split(/\s+/) tokens
 * (INCLUDING numeral tokens — tokenized exactly that way in render-verses.js).
 * "s" = short pause (GREEN), "l" = long pause (ORANGE). Absent key = no color.
 * Marks are NEVER invented: only keys present in the file are applied.
 * If the file is missing or empty, marksFor() returns null and the reader
 * renders plain text (no crash).
 */
(()=>{
'use strict';
let cache=null; // Map<string,'s'|'l'> | null (null = unavailable)
let loading=null;
let meta={version:'',source:''};
async function load(){
 if(cache!==null)return cache;
 if(!loading)loading=fetch('offline/vishraam.json',{cache:'force-cache'}).then(async r=>{
  if(!r.ok)throw Error('vishraam.json missing');
  const data=await r.json();
  meta={version:String(data?.version||''),source:String(data?.source||'')};
  const marks=(data&&data.marks&&typeof data.marks==='object')?data.marks:{};
  const map=new Map();
  for(const [k,v] of Object.entries(marks)){
   if((v==='s'||v==='l')&&/^[ab]\d+:\d+:\d+$/.test(k))map.set(k,v);
  }
  cache=map;return cache;
 }).catch(()=>{cache=new Map();return cache});
 return loading;
}
// kind: 'a' (ang) or 'b' (bani). ref: ang number or bani id. lineIdx: 0-based.
async function marksFor(kind,ref,lineIdx){
 const map=await load();
 const prefix=`${kind}${ref}:${lineIdx}:`;
 const out={};let found=false;
 for(const [k,v] of map){
  if(k.startsWith(prefix)){
   const w=Number(k.slice(prefix.length));
   if(Number.isInteger(w)&&w>=0){out[w]=v;found=true}
  }
 }
 return found?out:null;
}
// Whole-text marks in ONE pass: {lineIdx: {wordIdx:'s'|'l'}}.
async function marksForText(kind,ref){
 const map=await load();
 const prefix=`${kind}${ref}:`;
 const out={};
 for(const [k,v] of map){
  if(!k.startsWith(prefix))continue;
  const rest=k.slice(prefix.length).split(':');
  if(rest.length!==2)continue;
  const li=Number(rest[0]),w=Number(rest[1]);
  if(!Number.isInteger(li)||!Number.isInteger(w)||li<0||w<0)continue;
  (out[li]||(out[li]={}))[w]=v;
 }
 return out;
}
function info(){return {...meta}}
window.GS_VISHRAAM={load,marksFor,marksForText,info,tokens:g=>String(g||'').trim().split(/\s+/).filter(Boolean)};
})();
