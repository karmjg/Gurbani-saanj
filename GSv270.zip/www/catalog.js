/* Anek Baniyaan catalogue — ONLY Banis with full bundled offline text.
   Nitnem Banis live in the Nitnem section only (never duplicated here).
   Generated from offline/manifest.json; ids match offline/bani/<id>.json. */
window.GS_CATALOG = [
  {
    "id": 112,
    "group": "sggs",
    "titlePa": "ਸੁਖਮਨੀ ਸਾਹਿਬ",
    "titleEn": "Sukhmani Sahib"
  },
  {
    "id": 113,
    "group": "sggs",
    "titlePa": "ਆਸਾ ਦੀ ਵਾਰ",
    "titleEn": "Asa Di Vaar"
  },
  {
    "id": 115,
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਮਹਲਾ ੯",
    "titleEn": "Salok Mahalla 9"
  },
  {
    "id": 116,
    "group": "sggs",
    "titlePa": "ਸ਼ਬਦ ਹਜ਼ਾਰੇ",
    "titleEn": "Shabad Hazare"
  },
  {
    "id": 120,
    "group": "sggs",
    "titlePa": "ਬਾਵਨ ਅਖਰੀ",
    "titleEn": "Bavan Akhri"
  },
  {
    "id": 121,
    "group": "sggs",
    "titlePa": "ਸਿਧ ਗੋਸਟਿ",
    "titleEn": "Sidh Gosht"
  },
  {
    "id": 122,
    "group": "sggs",
    "titlePa": "ਦਖਣੀ ਓਅੰਕਾਰ",
    "titleEn": "Dakhni Oankar"
  },
  {
    "id": 123,
    "group": "sggs",
    "titlePa": "ਬਾਰਹ ਮਾਹਾ",
    "titleEn": "Barah Maha"
  },
  {
    "id": 128,
    "group": "sggs",
    "titlePa": "ਰਾਮਕਲੀ ਸਦੁ",
    "titleEn": "Ramkali Sadd"
  },
  {
    "id": 129,
    "group": "sggs",
    "titlePa": "ਅਲਾਹਣੀਆਂ",
    "titleEn": "Alahnia"
  },
  {
    "id": 125,
    "group": "sggs",
    "titlePa": "ਲਾਵਾਂ",
    "titleEn": "Laavan"
  },
  {
    "id": 109,
    "group": "sggs",
    "titlePa": "ਆਰਤੀ",
    "titleEn": "Aarti"
  },
  {
    "id": 126,
    "group": "sggs",
    "titlePa": "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ (ਮੁੰਦਾਵਣੀ)",
    "titleEn": "Sri Guru Granth Sahib Paath Bhog (Mundavnni)"
  },
  {
    "id": 127,
    "group": "sggs",
    "titlePa": "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ (ਰਾਗਮਾਲਾ)",
    "titleEn": "Sri Guru Granth Sahib Paath Bhog (Ragmala)"
  },
  {
    "id": 117,
    "group": "dasam",
    "titlePa": "ਸ਼ਬਦ ਹਜ਼ਾਰੇ ਪਾਤਿਸ਼ਾਹੀ ੧੦",
    "titleEn": "Shabad Hazare Patshahi 10"
  },
  {
    "id": 118,
    "group": "dasam",
    "titlePa": "ਤ੍ਵ ਪ੍ਰਸਾਦਿ ਸਵੱਯੇ (ਦੀਨਨ ਕੀ)",
    "titleEn": "Tav Prasad Savaiye (Deenan Ki)"
  },
  {
    "id": 119,
    "group": "dasam",
    "titlePa": "ਅਕਾਲ ਉਸਤਤਿ",
    "titleEn": "Akal Ustat"
  },
  {
    "id": 124,
    "group": "dasam",
    "titlePa": "ਚੰਡੀ ਦੀ ਵਾਰ",
    "titleEn": "Chandi Di Var"
  },
  {
    "id": 114,
    "group": "tradition",
    "titlePa": "ਅਰਦਾਸ",
    "titleEn": "Ardas"
  },
  {
    "id": 110,
    "group": "tradition",
    "titlePa": "ਵੱਡੀ ਆਰਤੀ",
    "titleEn": "Aarti (Longer)"
  },
  {
    "id": 106,
    "group": "tradition",
    "titlePa": "ਅਨੰਦੁ ਸਾਹਿਬ (੬ ਪਉੜੀਆਂ ਅਤੇ ਸਲੋਕੁ)",
    "titleEn": "Anand Sahib (6 Pauris and Salok)"
  },
  {
    "id": 107,
    "group": "tradition",
    "titlePa": "ਰਹਰਾਸਿ ਸਾਹਿਬ (ਸੰਖੇਪ)",
    "titleEn": "Rehras Sahib (Short)"
  }
];
