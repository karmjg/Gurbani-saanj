/* Gurbani Saanj v2.2.28 — unified search: SGGS + ALL 29 Banis.
 * Karamjit approved: every Bani — catalog, Guru Granth Sahib, Nitnem,
 * Dasam Granth, any type — must be searchable by speaking or typing.
 * Change: a build script (scripts/build-bani-search.mjs) reads all 29 Bani
 * files and writes www/offline/bani-search.json (9,452 lines, each with the
 * Bani id, line index, g/en/pa/roman, titles and the catalog group);
 * scripture-search.js loads BOTH indexes and query() returns merged SGGS +
 * Bani results with the same scoring; results show their source CLEARLY —
 * SGGS shows Ang N, a Dasam Granth Bani shows "Dasam Granth" + the Bani
 * name, other Banis show the Bani name; tapping a Bani result opens that
 * Bani at the line; save/bookmark works for Bani hits too.
 * Voice search needs no separate change — it calls the same query.
 * Run: node test-v248.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.28', vj.version === '2.2.28');
ok('package.json is 2.2.28', pj.version === '2.2.28');
ok('version.json notes mention v2.2.28 + Dasam label', vj.notes.includes('v2.2.28:') && vj.notes.includes("labelled 'Dasam Granth'"));

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');

// ---- 1. The Bani index (a) ----
const baniPath = path.join(ROOT, 'www/offline/bani-search.json');
ok('bani-search.json exists', fs.existsSync(baniPath));
const baniIdx = JSON.parse(fs.readFileSync(baniPath, 'utf8'));
ok('bani-search.json has 9,452 lines', baniIdx.length === 9452, `got ${baniIdx.length}`);
const baniIds = [...new Set(baniIdx.map(r => r[0]))].sort((a, b) => a - b);
ok('bani-search.json covers all 29 Bani IDs', baniIds.length === 29 && JSON.stringify(baniIds) === JSON.stringify([2, 4, 6, 9, 10, 21, 23, 106, 107, 109, 110, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 124, 125, 126, 127, 128, 129]), `got ${baniIds.join(',')}`);
ok('every Bani line has g + roman', baniIdx.every(r => r[2] && r[5]));
ok('every Bani line has titles + group', baniIdx.every(r => r[6] && r[7] && ['sggs', 'dasam', 'tradition'].includes(r[8])));
const dasamIds = [...new Set(baniIdx.filter(r => r[8] === 'dasam').map(r => r[0]))].sort((a, b) => a - b);
ok('Dasam Granth Banis are exactly 4,6,9,117,118,119,124', JSON.stringify(dasamIds) === JSON.stringify([4, 6, 9, 117, 118, 119, 124]), `got ${dasamIds.join(',')}`);
ok('build script exists and is the index source', fs.existsSync(path.join(ROOT, 'scripts/build-bani-search.mjs')) && fs.readFileSync(path.join(ROOT, 'scripts/build-bani-search.mjs'), 'utf8').includes('GS_CATALOG'));

// ---- 2. Unified search (real code + real indexes) ----
const sggsIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
const sctx = vm.createContext({
  window: {}, console,
  fetch: async (url) => {
    if (String(url).includes('bani-search')) return { ok: true, json: async () => baniIdx };
    return { ok: true, json: async () => sggsIdx };
  },
});
vm.runInContext(ss, sctx);
const S = sctx.window.GS_SCRIPTURE_SEARCH;
await S.load();
const q = (query, mode = 'auto') => S.query(query, 40, mode);

// (b) known SGGS line still finds its Ang
let r = await q('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');
ok('(b) SGGS line finds Ang 244 first', r[0] && r[0].src === 'sggs' && r[0].ang === 244, JSON.stringify(r[0]));

// (c) known Dasam Granth Bani line finds the Bani, labelled Dasam
r = await q('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ');
const jaap = r[0];
ok("(c) Jaap Sahib line finds Bani 4 first", jaap && jaap.src === 'bani' && jaap.baniId === 4, JSON.stringify(jaap));
ok("(c) Jaap result has group 'dasam' + title", jaap && jaap.group === 'dasam' && jaap.baniTitle === 'ਜਾਪੁ ਸਾਹਿਬ' && jaap.titleEn === 'Jaap Sahib', JSON.stringify(jaap));
r = await q('ਉਤਾਰ ਖਾਸੇ ਦਸਖਤ ਕਾ');
ok('(c) Akal Ustat line finds Bani 119, group dasam', r[0] && r[0].src === 'bani' && r[0].baniId === 119 && r[0].group === 'dasam', JSON.stringify(r[0]));

// (d) known Nitnem Bani lines find the Bani
r = await q('ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ');
const japji = r.find(x => x.src === 'bani' && x.baniId === 2);
ok('(d) Japji Sahib line finds Bani 2', !!japji && japji.group === 'sggs', JSON.stringify(japji));
r = await q('ਹਮਰੀ ਕਰੋ ਹਾਥ ਦੈ ਰੱਛਾ');
ok('(d) Chaupai Sahib line finds Bani 9, group dasam', r[0] && r[0].src === 'bani' && r[0].baniId === 9 && r[0].group === 'dasam', JSON.stringify(r[0]));

// (e) known Sukhmani Sahib line finds Bani 112 (SGGS group)
r = await q('ਸੁਖਮਨੀ ਸੁਖ ਅੰਮ੍ਰਿਤ ਪ੍ਰਭ ਨਾਮੁ');
const sukh = r.find(x => x.src === 'bani' && x.baniId === 112);
ok('(e) Sukhmani Sahib line finds Bani 112', !!sukh && sukh.idx === 18 && sukh.group === 'sggs', JSON.stringify(sukh));

// (f) first-letter search works for a Bani line
r = await q('ਸਸਅਪਨ');
ok('(f) first letters find the Sukhmani Bani line', r.some(x => x.src === 'bani' && x.baniId === 112 && x.idx === 18), JSON.stringify(r.slice(0, 3)));

// (g) a roman query finds a Bani line
r = await q('sukhamanee', 'roman');
ok('(g) roman query finds the Sukhmani Bani line', r.some(x => x.src === 'bani' && x.baniId === 112 && x.idx === 18), JSON.stringify(r.slice(0, 3)));

// (h) Ang mode stays SGGS-only
r = await q('1366');
ok('(h) "1366" returns only SGGS Ang 1366 (no Bani rows)', r.length > 0 && r.every(x => x.src === 'sggs' && x.ang === 1366), `got ${r.length} rows, first ${JSON.stringify(r[0])}`);

// (i) voice-style slightly-off phrase still finds its line
r = await q('ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੇ');
ok('(i) off-word phrase finds Ang 1285 first', r[0] && r[0].src === 'sggs' && r[0].ang === 1285, JSON.stringify(r[0]));

// lookup works for both sources
ok('lookupBani(4,4) resolves the Jaap line with group', (() => { const m = S.lookupBani(4, 4); return m && m.g.includes('ਚੱਕ੍ਰ') && m.group === 'dasam'; })());
ok('lookup(244,33) still resolves the SGGS line', (() => { const m = S.lookup(244, 33); return m && m.g.includes('ਮਿਲੁ'); })());

// ---- 3. Result markup: source label prominent on every result ----
// Extract the real scriptureResultsMarkup from app.js and run it in a vm.
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const mStart = app.indexOf('function scriptureResultsMarkup');
const mEnd = app.indexOf('\n}\n', mStart) + 3;
const mctx = vm.createContext({ state: { lang: 'pa', savedVerses: [] }, age: (p, e) => p, esc, console });
vm.runInContext(app.slice(mStart, mEnd), mctx);
const markup = (arr, opts) => mctx.scriptureResultsMarkup(arr, opts);
const jaapRes = { src: 'bani', baniId: 4, baniTitle: 'ਜਾਪੁ ਸਾਹਿਬ', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam', idx: 4, g: 'ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ਅਰੁ ਪਾਤਿ ਨਹਿਨ ਜਿਹ ॥' };
const sukhRes = { src: 'bani', baniId: 112, baniTitle: 'ਸੁਖਮਨੀ ਸਾਹਿਬ', titlePa: 'ਸੁਖਮਨੀ ਸਾਹਿਬ', titleEn: 'Sukhmani Sahib', group: 'sggs', idx: 18, g: 'ਸੁਖਮਨੀ ਸੁਖ ਅੰਮ੍ਰਿਤ ਪ੍ਰਭ ਨਾਮੁ ॥' };
const sggsRes = { src: 'sggs', ang: 244, idx: 33, g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥' };
const hJaap = markup([jaapRes], { save: true });
ok('Dasam result shows "Dasam Granth" + "Jaap Sahib"', hJaap.includes('Dasam Granth') && hJaap.includes('Jaap Sahib') && hJaap.includes('ਜਾਪੁ ਸਾਹਿਬ'));
ok('Dasam result carries data-found-bani + Bani title', hJaap.includes('data-found-bani="4"') && hJaap.includes('data-found-idx="4"') && hJaap.includes('data-bani-title="ਜਾਪੁ ਸਾਹਿਬ"'));
ok('Dasam result save key is bani:4:4', hJaap.includes('data-save-hit="bani:4:4"'));
const hSukh = markup([sukhRes], { save: true });
ok('Sukhmani result shows the Bani name, NOT "Dasam Granth"', hSukh.includes('ਸੁਖਮਨੀ ਸਾਹਿਬ') && !hSukh.includes('Dasam Granth'));
const hSggs = markup([sggsRes], { save: true });
ok('SGGS result still shows "Ang 244"', hSggs.includes('ਅੰਗ 244') && hSggs.includes('data-found-ang="244"') && !hSggs.includes('Dasam Granth'));

// ---- 4. Tap handler: Bani result opens the right Bani (j) ----
// Extract the two found/foundBani handler lines and run them in a vm.
const tapStart = app.indexOf("const found=e.target.closest('[data-found-ang]");
const tapLineEnd = app.indexOf('\n', app.indexOf("const foundBani=e.target.closest('[data-found-bani]"));
const tapCode = app.slice(tapStart, tapLineEnd);
let openAngCalls = [], openBaniCalls = [];
const tapCtx = vm.createContext({
  console, highlightLine: -1,
  openAng: (ang, preserve) => { openAngCalls.push([ang, preserve]); },
  openBani: (id, title, preserve) => { openBaniCalls.push([id, title, preserve]); },
});
vm.runInContext(`function handleTap(e){\n${tapCode}\n}`, tapCtx);
const fakeTarget = (el) => ({ closest: (sel) => (sel.includes('data-found-bani') ? (el.kind === 'bani' ? el : null) : (el.kind === 'sggs' ? el : null)) });
tapCtx.handleTap({ target: fakeTarget({ kind: 'bani', dataset: { foundBani: '4', foundIdx: '4', baniTitle: 'ਜਾਪੁ ਸਾਹਿਬ' } }) });
ok('(j) tapping a Jaap result calls openBani(4, "ਜਾਪੁ ਸਾਹਿਬ", true)', openBaniCalls.length === 1 && openBaniCalls[0][0] === 4 && openBaniCalls[0][1] === 'ਜਾਪੁ ਸਾਹਿਬ' && openBaniCalls[0][2] === true, JSON.stringify(openBaniCalls));
ok('(j) Bani tap sets highlightLine to the line index', tapCtx.highlightLine === 4, `got ${tapCtx.highlightLine}`);
tapCtx.handleTap({ target: fakeTarget({ kind: 'sggs', dataset: { foundAng: '244', foundIdx: '33' } }) });
ok('(j) tapping an SGGS result still calls openAng(244, true)', openAngCalls.length === 1 && openAngCalls[0][0] === 244 && openAngCalls[0][1] === true, JSON.stringify(openAngCalls));
ok('(j) SGGS tap sets highlightLine to the line index', tapCtx.highlightLine === 33, `got ${tapCtx.highlightLine}`);

// ---- 5. Save handler: Bani refs save + remove, SGGS unchanged ----
// Extract the save handler line and run it in a vm.
const saveStart = app.indexOf("const save=e.target.closest('[data-save-hit]");
const saveEnd = app.indexOf('\n', saveStart);
const saveCode = app.slice(saveStart, saveEnd);
const saveCtx = vm.createContext({
  console, state: { savedVerses: [] }, persist: () => {}, render: () => {},
  window: { GS_SCRIPTURE_SEARCH: S },
});
vm.runInContext(`function handleSave(e){\n${saveCode}\n}`, saveCtx);
const fakeSaveTarget = (dataset) => ({ closest: () => ({ dataset }) });
saveCtx.handleSave({ target: fakeSaveTarget({ saveHit: 'bani:4:4' }) });
ok('saving a Jaap result stores a Bani entry with group dasam', saveCtx.state.savedVerses.length === 1 && saveCtx.state.savedVerses[0].src === 'bani' && saveCtx.state.savedVerses[0].baniId === 4 && saveCtx.state.savedVerses[0].idx === 4 && saveCtx.state.savedVerses[0].group === 'dasam' && saveCtx.state.savedVerses[0].g.includes('ਚੱਕ੍ਰ'), JSON.stringify(saveCtx.state.savedVerses));
saveCtx.handleSave({ target: fakeSaveTarget({ saveHit: 'bani:4:4' }) });
ok('tapping save again removes the Bani entry', saveCtx.state.savedVerses.length === 0);
saveCtx.handleSave({ target: fakeSaveTarget({ saveHit: '244:33' }) });
ok('saving an SGGS result still stores {ang,idx,g}', saveCtx.state.savedVerses.length === 1 && saveCtx.state.savedVerses[0].ang === 244 && saveCtx.state.savedVerses[0].idx === 33, JSON.stringify(saveCtx.state.savedVerses));

// ---- 6. Ask wiring: matches keep group; Dasam cited in AI context ----
ok('Ask entry.matches preserves src + baniId + group', app.includes("matches:matches.map(m=>m.src==='bani'?{src:'bani',baniId:m.baniId,baniTitle:m.baniTitle||m.titlePa,titlePa:m.titlePa,titleEn:m.titleEn,group:m.group||'sggs',idx:m.idx,g:m.g}:{src:'sggs',ang:m.ang,idx:m.idx,g:m.g})"));
ok('Ask AI context cites "Dasam Granth — <Bani>" for Dasam verses', app.includes("`[${m.group==='dasam'?'Dasam Granth — ':''}${m.baniTitle||m.titlePa||'Bani'}] ${m.g}`"));
ok('Ask TOPIC_BRIDGE dedupe is source-aware (no wrong Bani dedupe)', app.includes("'bani:'+x.baniId+':'+x.idx") && app.includes("'ang:'+x.ang+':'+x.idx"));
ok('Ask prompt GGS-only rule untouched', app.includes("Answer ONLY from the provided Gurbani passages") && app.includes('never from any other scripture, author, book, or your own general knowledge'));

// ---- 7. CSS: prominent Bani + Dasam labels ----
ok('CSS has .gs-result-bani label styles', css.includes('.gs-result-bani{display:flex') && css.includes('.gs-result-bani-name{font-size:15px'));
ok('CSS has distinct Dasam tag style', css.includes('.gs-result-dasam-tag{background:#b45309}'));

// ---- 8. Regression checks (v2.2.27 -> v2.2.15) ----
ok('v2.2.27 barScrollDecision + show/hide + onReaderScroll', app.includes('function barScrollDecision(lastY,curY)') && app.includes('function showReaderBar(){') && app.includes('function hideReaderBar(){') && app.includes('function onReaderScroll(){'));
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');

ok('v2.2.27 sticky top clears the status bar', css.includes('top: max(env(safe-area-inset-top, 0px), 24px)'));
ok('v2.2.26 Bani headings detected (Raag+Mehla)', rv.includes('ਮਹਲਾ') && rv.includes('gs-verse-heading'));
ok('v2.2.26 viewport disables native pinch (Ask-only pinch)', html.includes('user-scalable=no'));
ok('v2.2.26 page-turn fills the screen', css.includes('min-height:calc(100dvh - 122px)'));
ok('v2.2.25 A+/A- buttons gone from Ask', !app.includes('ai-zoom-row'));
ok('v2.2.25 document-level pinch survives re-renders', app.includes('function setupPinchZoom()') && app.includes('pinchWired'));
ok('v2.2.23 exactly one .ai-answer font-size, var(--ai-font,18px)', (css.match(/\.ai-answer\{[^}]*font-size/g) || []).length === 1 && css.includes('font-size:var(--ai-font,18px)') && !css.includes('font-size: 14px'));
ok('v2.2.22 not-hearing feedback after 4s', app.includes('noHeardTimer') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ'));
ok('v2.2.22 X restarts the mic (await stop, then start)', app.includes('const p=resetVoiceNow();') && app.includes('startVoiceSearch(input)'));
ok('v2.2.21 first-letter phrase fallback kept', ss.includes('firstSig') && ss.includes('firstSig.length>=2'));
ok('v2.2.20 guarded stop in resetVoiceNow', app.includes('run.started&&!run.stopped&&!run.safetyStopped'));
ok('v2.2.18 ai-verse bold/highlight + font clamp 14-32', app.includes('ai-verse') && app.includes('Math.min(32,Math.max(14'));
ok('v2.2.15 AI language toggle kept', app.includes('aiLang') && app.includes('data-ai-lang'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
