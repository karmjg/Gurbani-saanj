import fs from 'node:fs';
import vm from 'node:vm';
const searchJS=fs.readFileSync('www/scripture-search.js','utf8');
const fixture=[
 [1,0,'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ॥','The eternal truth','','Ik Oankaar Sat Naam Karta Purakh'],
 [1,1,'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥','Not by thinking','','Sochai soch na hovaee'],
 [2,0,'ਹੁਕਮਿ ਰਜਾਈ ਚਲਣਾ ਨਾਨਕ ਲਿਖਿਆ ਨਾਲਿ ॥੧॥','Walk in the Divine will','','Hukam razai chalna'],
 ...Array.from({length:1001},(_,i)=>[i+3,0,'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ','Thinking thoughts','',''])
];
const sandbox={window:{},fetch:async()=>({ok:true,json:async()=>fixture})};
vm.runInNewContext(searchJS,sandbox);
const api=sandbox.window.GS_SCRIPTURE_SEARCH;
const first=await api.query('ਸਨਕਪ',10,'first');
if(first[0]?.ang!==1||first[0]?.idx!==0)throw Error('Gurmukhi first-letter search failed');
const middle=await api.query('ਨਕਪ',10,'any-first');
if(middle[0]?.ang!==1||middle[0]?.idx!==0)throw Error('any-position initial search failed');
const auto=await api.query('ਸਨਕਪ');
if(auto[0]?.idx!==0)throw Error('auto-mode first-letter search failed');
const phrase=await api.query('ਹੁਕਮਿ ਰਜਾਈ');
if(phrase[0]?.ang!==2)throw Error('full phrase search failed');
const ang=await api.query('Ang 2',10,'ang');
if(ang[0]?.ang!==2)throw Error('Ang navigation search failed');
const roman=await api.query('hukam',10,'roman');
if(roman[0]?.ang!==2)throw Error('Romanized search failed');
if(api.lookup(2,0)?.g!==fixture[2][2])throw Error('search result lookup failed');
const app=fs.readFileSync('www/app.js','utf8'),styles=fs.readFileSync('www/styles.css','utf8');
const verses=fs.readFileSync('www/render-verses.js','utf8');
const typography=app+verses;
if(!typography.includes('gs-bani-pankti')||!typography.includes('gs-sggs-pankti')||!typography.includes('gs-stanza-end'))throw Error('separate Bani / SGGS typography missing');
if(!app.includes('data-close-word')||!app.includes('openLineMeaning(word)')||!app.includes('lineMeaningLine'))throw Error('line meaning popup close/tap/context missing');
// v2.2.8: Punjabi/English keyboard toggle (gear gone), instant mic reset,
// searched-line highlight, sticky Ang jump, no Read tab, A-Z Kirtan sort,
// translation toggles only in Bani View Preferences (not the settings sheet).
if(app.includes("id=\"searchOptions\""))throw Error('gear settings button still in search bar');
if(!app.includes('id="kbToggle"')||!app.includes('resetVoiceNow()')||!app.includes('kbLang'))throw Error('keyboard toggle / instant mic reset missing');
if(!app.includes('found:idx===highlightLine')||!verses.includes('gs-found'))throw Error('searched-line highlight missing');
if(!app.includes('angJumpInput')||!app.includes('angJumpGo'))throw Error('Ang jump bar missing');
const html=fs.readFileSync('www/index.html','utf8');
if(html.includes('nav-reader'))throw Error('Read tab still in bottom nav');
if(!app.includes('GS_ALPHA')||!app.includes('gsAlphaKey'))throw Error('Kirtan A-Z sort missing');
if(app.includes("choice('showTranslit'"))throw Error('translation toggles still duplicated in settings sheet');
if(!app.includes("short:'Simple'")||!app.includes('aiStatusLine'))throw Error('AI level / online status missing');
if(!styles.includes('.gs-reader-bani')||!styles.includes('.gs-reader-sggs'))throw Error('reader styles missing');
const page=fs.readFileSync('www/page-turn.js','utf8');
if(!page.includes('gs-book-stanza-break')||!page.includes('slow:1250'))throw Error('page-turn stanza spacing missing');
const koshJS=fs.readFileSync('www/word-kosh.js','utf8');
const koshContext={window:{},localStorage:{getItem:()=>null},navigator:{onLine:false},fetch:async()=>({ok:false,json:async()=>({})})};
vm.runInNewContext(koshJS,koshContext);
const meaning=await koshContext.window.GS_KOSH.lookup('ਨਾਮੁ','en',false);
if(meaning.definitions?.[0]?.meaning!=='name; the Divine Name')throw Error('English word gloss not found');
const parsed=koshContext.window.GS_KOSH.parse([{word_uni:'ਅਕਥ',def_uni:'ਜੋ ਬਿਆਨ ਨਾ ਕੀਤਾ ਜਾ ਸਕੇ'}]);
if(parsed[0]?.word!=='ਅਕਥ'||!parsed[0]?.meaning)throw Error('BaniDB Kosh response shape not parsed');
if(app.includes('data-pop="listen"')||app.includes('data-pop="meaning"'))throw Error('old popup actions remain');
console.log('PASS: first-letter from start / anywhere, auto, romanized, full phrase, Ang, results, Bani/SGGS layout, popup dismiss, Punjabi Kosh parser, English gloss, no audio button');
