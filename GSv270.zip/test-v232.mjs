/* Gurbani Saanj v2.2.12 — functional checks (node, offline).
 *  1. Ang jump sticks: reader jump box + Library picker pass sahaj=true, so
 *     the saved position moves; search/saved opens stay detours.
 *  2. Kirtan first-letter search: same bare-first-letter rule as GGS search,
 *     Punjabi + roman initials; matra queries stay substring-only.
 *  3. A-Z side index on the Kirtan book + vowel sort fix (ਆ/ਏ/ਐ/ਓ/ਔ→ਅ, ਈ→ਇ, ਊ→ਉ).
 * Run: node test-v232.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const kirtanData = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/kirtan-shabads.json'), 'utf8'));
const shabads = kirtanData.shabads || kirtanData;

// ---- 0. Version ----
ok('version.json is 2.2.12', vj.version === '2.2.12');
ok('package.json is 2.2.12', pj.version === '2.2.12');

// ---- 1. Ang jump sticks ----
ok('reader Ang-jump box passes sahaj=true',
  app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('Library Ang picker passes sahaj=true',
  app.includes("openAng($('angPicker')?.value||displayAng(),false,true)"));
ok('loadRemote only moves state.ang when extra.sahaj',
  app.includes("if(kind==='ang'){if(extra.sahaj){state.ang=Number(id);"));
ok('search/saved opens stay detours (no sahaj arg)',
  app.includes("openAng(Number(found.dataset.foundAng||found.dataset.openSavedAng),true)"));

// ---- Extract the Kirtan helpers from app.js and run them ----
const helperSrc = app.slice(app.indexOf('const kirtanWords='), app.indexOf("const gsAlphaKey="));
const alphaSrc = app.slice(app.indexOf("const gsAlphaKey="), app.indexOf("function kirtanBookRows()"));
const ctx = {};
vm.createContext(ctx);
vm.runInContext(helperSrc + '\n' + alphaSrc + '\n;globalThis.__k={kirtanInitials,kirtanRomanInitials,kirtanFoldFirst,gsAlphaKey,GS_ALPHA,KIRTAN_ROMAN_FIRST};', ctx);
const { kirtanInitials, kirtanRomanInitials, kirtanFoldFirst, gsAlphaKey, GS_ALPHA } = ctx.__k;
const hasMatra = q => /[\p{M}]/u.test(q);

// ---- 2. First-letter helpers ----
ok('initials: ਡੰਡਉਤਿ ਬੰਦਨ ਅਨਿਕ ਬਾਰ ਸਰਬ ਕਲਾ ਸਮਰਥ -> ਡਬਅਬਸਕਸ',
  kirtanInitials('ਡੰਡਉਤਿ ਬੰਦਨ ਅਨਿਕ ਬਾਰ ਸਰਬ ਕਲਾ ਸਮਰਥ') === 'ਡਬਅਬਸਕਸ');
ok('initials: ਸਤਿਗੁਰੁ ਮੇਰਾ ਸਦਾ ਸਦਾ -> ਸਮਸਸ',
  kirtanInitials('ਸਤਿਗੁਰੁ ਮੇਰਾ ਸਦਾ ਸਦਾ') === 'ਸਮਸਸ');
ok('roman initials: ਡੰਡਉਤਿ… -> dbabsks',
  kirtanRomanInitials('ਡੰਡਉਤਿ ਬੰਦਨ ਅਨਿਕ ਬਾਰ ਸਰਬ ਕਲਾ ਸਮਰਥ') === 'dbabsks');
ok('matra rule: ਸਤਿਗੁਰ and ਜਪੁ are full words (have matras)',
  hasMatra('ਸਤਿਗੁਰ') && hasMatra('ਜਪੁ'));
ok('matra rule: ਮਹਅਤਅ and ਸਸ are bare initials (no matras)',
  !hasMatra('ਮਹਅਤਅ') && !hasMatra('ਸਸ'));

// Filter simulation — same predicate as kirtanBookRows in app.js.
function kirtanFilter(list, qRaw) {
  const q = qRaw.trim().toLocaleLowerCase();
  return list.filter(s => {
    if (!q) return true;
    const fl = (s.firstLine || '').toLocaleLowerCase(), rg = (s.raag || '').toLocaleLowerCase();
    // v2.2.12: a single bare letter behaves like the A-Z index — initials only.
    if (qRaw.length === 1 && !/[\p{M}]/u.test(qRaw)) {
      const ch = kirtanFoldFirst(Array.from(q)[0] || '');
      if ((s._initial || '').startsWith(ch)) return true;
      if (/[a-z]/.test(q) && (s._romanInitial || '').startsWith(q)) return true;
      return false;
    }
    if (fl.includes(q) || rg.includes(q)) return true;
    if (!/[\p{M}]/u.test(qRaw)) {
      const sig = Array.from(q.replace(/[^\p{L}]/gu, '')).map(kirtanFoldFirst).join('');
      if (sig.length >= 1 && (s._initial || '').startsWith(sig)) return true;
      if (/[a-z]/.test(q)) {
        const rsig = q.replace(/[^a-z]/g, '');
        if (rsig.length >= 1 && (s._romanInitial || '').startsWith(rsig)) return true;
      }
    }
    return false;
  });
}
for (const s of shabads) { s._initial = kirtanInitials(s.firstLine); s._romanInitial = kirtanRomanInitials(s.firstLine); }
ok('kirtan list has 1,618 Shabads', shabads.length === 1618);

const dba = kirtanFilter(shabads, 'ਡਬਅ');
ok("first-letter query 'ਡਬਅ' finds k1 (ਡੰਡਉਤਿ ਬੰਦਨ…)", dba.some(s => s.id === 'k1'), `got ${dba.length} rows`);
ok("first-letter query 'ਡਬਅ' is selective (<20 rows)", dba.length < 20, `got ${dba.length}`);
const dbaRoman = kirtanFilter(shabads, 'dba');
ok("roman first-letter query 'dba' finds k1", dbaRoman.some(s => s.id === 'k1'), `got ${dbaRoman.length} rows`);
const subCount = shabads.filter(s => (s.firstLine || '').includes('ਸਤਿਗੁਰ')).length;
const satgur = kirtanFilter(shabads, 'ਸਤਿਗੁਰ');
ok("full-word query 'ਸਤਿਗੁਰ' does NOT flood (count == substring count)",
  satgur.length === subCount, `filter ${satgur.length} vs substring ${subCount}`);
const sa = kirtanFilter(shabads, 'ਸ');
ok("single-letter query 'ਸ' returns only ਸ-initial Shabads",
  sa.length > 0 && sa.every(s => kirtanFoldFirst(Array.from(s.firstLine.trim())[0]) === 'ਸ'), `got ${sa.length}`);
const fullWord = kirtanFilter(shabads, 'ਸਤਿਗੁਰੁ ਮੇਰਾ');
ok("full phrase 'ਸਤਿਗੁਰੁ ਮੇਰਾ' still works via substring",
  fullWord.length > 0 && fullWord.every(s => s.firstLine.includes('ਸਤਿਗੁਰੁ ਮੇਰਾ')));

// ---- 3. Sort + A-Z index ----
const sorted = [...shabads].sort((a, b) => {
  const ka = gsAlphaKey(a.firstLine), kb = gsAlphaKey(b.firstLine);
  return ka < kb ? -1 : ka > kb ? 1 : 0;
});
const foldedFirst = s => kirtanFoldFirst(Array.from(String(s.firstLine || '').trim())[0] || '');
const lastA = Math.max(...sorted.map((s, i) => foldedFirst(s) === 'ਅ' ? i : -1));
const firstSa = sorted.findIndex(s => foldedFirst(s) === 'ਸ');
ok('vowel-initial Shabads sort with their base letter (all ਅ before ਸ)',
  lastA >= 0 && firstSa > lastA, `last ਅ at ${lastA}, first ਸ at ${firstSa}`);
const aInitial = sorted.filter(s => Array.from(s.firstLine.trim())[0] === 'ਆ');
ok('ਆ-initial Shabads sit inside the ਅ block, not at the end',
  aInitial.length > 0 && sorted.indexOf(aInitial[aInitial.length - 1]) < firstSa, `ਆ count ${aInitial.length}`);

// Alpha index — same construction as kirtanBookRows in app.js.
const ROMAN = ctx.__k.KIRTAN_ROMAN_FIRST;
const alphaIndex = {};
sorted.forEach((s, i) => {
  const first = Array.from(String(s.firstLine || '').trim())[0] || '';
  const pa = kirtanFoldFirst(first), en = ROMAN[first] || '';
  if (pa && !(pa in alphaIndex)) alphaIndex[pa] = i;
  if (en) { const k = 'en:' + en.toUpperCase(); if (!(k in alphaIndex)) alphaIndex[k] = i; }
});
const paLetters = Object.keys(alphaIndex).filter(k => !k.startsWith('en:'));
const expectedPa = Array.from(GS_ALPHA).filter(l => paLetters.includes(l));
ok('Punjabi strip letters follow traditional Gurmukhi order',
  JSON.stringify(paLetters) === JSON.stringify(expectedPa), `got ${paLetters.join('')}`);
const enLetters = Object.keys(alphaIndex).filter(k => k.startsWith('en:')).map(k => k.slice(3)).sort();
ok('English strip letters are A-Z sorted', JSON.stringify(enLetters) === JSON.stringify([...enLetters].sort()));
ok("index['ਸ'] points at the first ਸ Shabad",
  sorted[alphaIndex['ਸ']] && foldedFirst(sorted[alphaIndex['ਸ']]) === 'ਸ');
ok("index['en:S'] points at the same row as index['ਸ']",
  alphaIndex['en:S'] === alphaIndex['ਸ']);
ok("index['ਅ'] points at the first ਅ/ਆ Shabad",
  sorted[alphaIndex['ਅ']] && foldedFirst(sorted[alphaIndex['ਅ']]) === 'ਅ');
ok('every strip letter maps to a row starting with it',
  paLetters.every(l => foldedFirst(sorted[alphaIndex[l]]) === l));

// ---- Strip wiring + CSS (static) ----
ok('renderKirtanAlpha hides the strip while filtering',
  app.includes('if(kirtanBookFilter.trim()||!letters.length)'));
ok('strip wired for tap and drag (click + touchmove)',
  app.includes("strip.addEventListener('click',pick)") && app.includes("strip.addEventListener('touchmove'"));
ok('kirtan screen contains the strip container',
  app.includes('id="kirtanAlpha"'));
ok('CSS has the strip styles',
  css.includes('.kirtan-alpha{') && css.includes('.kirtan-alpha-letter') && css.includes('.kirtan-alpha-flash'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
