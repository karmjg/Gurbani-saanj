/* Gurbani Saanj v2.2.48 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a FRESH profile
 * (945x2051) for each photo, and captures 3 photos of the Jaap Sahib Chhap
 * Chhand stanza (bani 4, idx 4-9; heading idx 3 "ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥"
 * before it, heading idx 10 "ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥" after it):
 *   v2.2.48-photo-jaap-perline-en.png — show={translit:false,en:true}:
 *     each Gurmukhi pankti on its own line, ITS OWN English directly
 *     beneath it, NO joined English paragraph (like his reference shot).
 *   v2.2.48-photo-jaap-perline-pa.png — show={translit:false,pa:true}:
 *     same per-line layout for Punjabi.
 *   v2.2.48-photo-jaap-perline-translit.png — show={translit:true,en:true}:
 *     regression — still per-line, Roman + English under each pankti.
 * The layer toggles are seeded into localStorage (key
 * 'gurbani-saanjh-trial-v1') via addInitScript BEFORE the app boots, so
 * each photo runs with exactly the intended Bani View Preferences.
 * Live-app checks: each pankti idx 4-9 is its own .gs-bani-pankti block
 * (no .gs-bani-para holding data-lines="4,5,6,7,8,9"), each block's layer
 * holds ONLY that pankti's meaning, and the Chhap heading is still a
 * centred heading.
 * Run: node photo-v268.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME,
  args: ['--disable-dev-shm-usage'] }); // /dev/shm is only 794MB — without this the renderer crashes on this heavy page

// Boot the app with exactly these Bani View Preferences (seeded into
// localStorage before the app reads it at boot).
const bootWithLayers = async (layers) => {
  const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
  await ctx.addInitScript((seed) => {
    localStorage.setItem('gurbani-saanjh-trial-v1', JSON.stringify(seed));
  }, layers);
  const page = await ctx.newPage();
  page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
  await page.goto(base, { waitUntil: 'load' });
  await page.waitForTimeout(5000); // bootData + kosh load + first render + kosh re-render settle
  return { ctx, page };
};
const openJaap = async (page) => {
  await page.evaluate(() => document.querySelector('[data-home-id="nitnem"]')?.click());
  await page.waitForTimeout(900);
  await page.evaluate(() => document.querySelector('.nitnem-page [data-remote-bani="4"]').click());
  await page.waitForTimeout(1200); // loadRemote fetch + render
};
const scrollLineToMiddle = async (page, idx) => {
  await page.evaluate((i) => {
    const el = document.querySelector(`#verses [data-line="${i}"]`);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, idx);
  await page.waitForTimeout(600);
};
// Per-line layout check for the Chhap stanza (idx 4-9) in the live app.
const checkStanzaPerLine = async (page, layerCls, firstMeaning, secondMeaningFragment) => {
  return await page.evaluate(({ layerCls, firstMeaning, secondMeaningFragment }) => {
    const blocks = [4, 5, 6, 7, 8, 9].map(i => document.querySelector(`#verses [data-line="${i}"]`));
    const para = document.querySelector('#verses [data-lines="4,5,6,7,8,9"]');
    const layers = [...document.querySelectorAll(`#verses .verse-layer.${layerCls}`)]
      .filter(el => { const b = el.closest('[data-line]'); return b && [4, 5, 6, 7, 8, 9].includes(Number(b.dataset.line)); })
      .map(el => el.textContent.trim());
    const firstBlock = blocks[0];
    const firstLayer = firstBlock ? firstBlock.querySelector(`.verse-layer.${layerCls}`)?.textContent.trim() : null;
    const heading = document.querySelector('#verses [data-line="3"]');
    return {
      allSixBlocks: blocks.every(b => !!b && b.classList.contains('gs-bani-pankti')),
      noJoinedPara: !para,
      layerCount: layers.length,
      firstLayerExact: firstLayer === firstMeaning,
      firstLayerText: firstLayer,
      firstHasNoSecond: firstLayer ? !firstLayer.includes(secondMeaningFragment) : false,
      headingIsHeading: !!heading && heading.classList.contains('gs-verse-heading'),
      headingText: heading ? heading.querySelector('.verse-text')?.textContent.trim() : null,
    };
  }, { layerCls, firstMeaning, secondMeaningFragment });
};

// ---- Photo 1: English ON, transliteration OFF (his screenshot's case) ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: false, showEn: true, showPa: false });
  ok('photo en: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJaap(page);
  ok('photo en: Jaap Sahib reader opened', await page.evaluate(() => !!document.querySelector('#verses [data-line="4"]')));
  const c = await checkStanzaPerLine(page, 'verse-en',
    'He who is without mark or sign, He who is without caste or line.', 'without colour or form');
  ok('photo en: all 6 Chhap panktis are their own .gs-bani-pankti blocks', c.allSixBlocks, JSON.stringify(c));
  ok('photo en: NO joined .gs-bani-para holds data-lines="4,5,6,7,8,9"', c.noJoinedPara);
  ok('photo en: 6 .verse-en layers (one per pankti)', c.layerCount === 6, `got ${c.layerCount}`);
  ok('photo en: first pankti English is ONLY its own line', c.firstLayerExact, JSON.stringify(c.firstLayerText));
  ok('photo en: first English does NOT contain the second line\'s meaning', c.firstHasNoSecond);
  ok('photo en: Chhap heading is still a centred heading', c.headingIsHeading && c.headingText === 'ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥', JSON.stringify(c.headingText));
  await scrollLineToMiddle(page, 6);
  await page.screenshot({ path: path.join(OUT, 'v2.2.48-photo-jaap-perline-en.png') });
  await ctx.close();
}

// ---- Photo 2: Punjabi ON, transliteration OFF ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: false, showEn: false, showPa: true });
  ok('photo pa: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJaap(page);
  const c = await checkStanzaPerLine(page, 'verse-pa',
    'ਜਿਸ ਦਾ ਕੋਈ ਚਿੰਨ੍ਹ, ਚਕ੍ਰ, ਵਰਨ, ਜਾਤਿ ਅਤੇ ਗੋਤ ਨਹੀਂ ਹੈ,', 'ਰੂਪ, ਰੰਗ');
  ok('photo pa: all 6 Chhap panktis are their own .gs-bani-pankti blocks', c.allSixBlocks, JSON.stringify(c));
  ok('photo pa: NO joined .gs-bani-para holds data-lines="4,5,6,7,8,9"', c.noJoinedPara);
  ok('photo pa: 6 .verse-pa layers (one per pankti)', c.layerCount === 6, `got ${c.layerCount}`);
  ok('photo pa: first pankti Punjabi is ONLY its own line', c.firstLayerExact, JSON.stringify(c.firstLayerText));
  await scrollLineToMiddle(page, 6);
  await page.screenshot({ path: path.join(OUT, 'v2.2.48-photo-jaap-perline-pa.png') });
  await ctx.close();
}

// ---- Photo 3: transliteration ON + English ON (regression) ----
{
  const { ctx, page } = await bootWithLayers({ showTranslit: true, showEn: true, showPa: false });
  ok('photo tr: app booted, home tiles present', await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]')));
  await openJaap(page);
  const c = await checkStanzaPerLine(page, 'verse-en',
    'He who is without mark or sign, He who is without caste or line.', 'without colour or form');
  ok('photo tr: still per-line with translit ON (6 pankti blocks, 6 en)', c.allSixBlocks && c.layerCount === 6, JSON.stringify(c));
  const romanCount = await page.evaluate(() => [...document.querySelectorAll('#verses .verse-layer.verse-roman')]
    .filter(el => { const b = el.closest('[data-line]'); return b && [4, 5, 6, 7, 8, 9].includes(Number(b.dataset.line)); }).length);
  ok('photo tr: 6 .verse-roman layers (one per pankti)', romanCount === 6, `got ${romanCount}`);
  await scrollLineToMiddle(page, 6);
  await page.screenshot({ path: path.join(OUT, 'v2.2.48-photo-jaap-perline-translit.png') });
  await ctx.close();
}

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
