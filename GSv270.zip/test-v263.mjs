/* Gurbani Saanj v2.2.43 — TWO changes (includes ALL of v2.2.42).
 * (1) Play Store build hides the AI settings (Karamjit: "they don't need to
 * see it"): a build-time flag GS_HIDE_AI_SETTINGS=1, set only by the AAB
 * workflow, is written into window.GS_BUILD.hideAiSettings by
 * scripts/build-web.mjs; Bani View Preferences (viewprefsScreen) skips the
 * whole AI section (AI API key, AI endpoint, AI model, Private AI server,
 * AI access code) when the flag is set — no heading, no rows, no gap. The
 * APK workflow never sets the flag, so the APK build keeps the settings.
 * (2) The AI itself is NOT hidden: Ask still works for everyone via the
 * shared cloud server by default (no key needed); the cloud endpoint,
 * Ask screen and answer logic are untouched.
 * Run: node test-v263.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const worker = fs.readFileSync(path.join(ROOT, 'ai-server/cloudflare-worker.mjs'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.43', vj.version === '2.2.43');
ok('package.json is 2.2.43', pj.version === '2.2.43');
ok('version notes mention v2.2.33 + continuous listening + X stops mic',
  vj.notes.includes('v2.2.33:') && vj.notes.includes('listens continuously') && vj.notes.includes('stops the mic for real'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.35 + the 3 changes',
  vj.notes.includes('v2.2.35:') && vj.notes.includes('#fdfcf9') && vj.notes.includes('Noto Serif Gurmukhi') && vj.notes.includes('pack tight') && vj.notes.includes('Font size is unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.36 + centred search line',
  vj.notes.includes('v2.2.36:') && vj.notes.includes('middle of the screen') && vj.notes.includes('Page-turn, home and Kirtan jumps are unchanged'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.37 + brand language + Muse-style Stop',
  vj.notes.includes('v2.2.37:') && vj.notes.includes('Gurbani Saanjh') && vj.notes.includes('Stop button') && vj.notes.includes('keeps listening until you press Stop'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.38 + compact Hukamnama card',
  vj.notes.includes('v2.2.38:') && vj.notes.includes('more compact') && vj.notes.includes('21px') && vj.notes.includes('All card content is kept'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.39 + AnmolUni + weight 400',
  vj.notes.includes('v2.2.39:') && vj.notes.includes('AnmolUni') && vj.notes.includes('weight 400'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.40 + mic-as-Stop + iGranth transliteration colours',
  vj.notes.includes('v2.2.40:') && vj.notes.includes('Stop sign') && vj.notes.includes('#0d0445') && vj.notes.includes('#f3541d') && vj.notes.includes('transliteration OFF'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.41 + pairs two-per-line like iGranth',
  vj.notes.includes('v2.2.41:') && vj.notes.includes('pair two-per-line') && vj.notes.includes('ਨਮਸਤੁੰ') && vj.notes.includes('fills the width'),
  vj.notes.slice(-200));
ok('version notes mention v2.2.41 + font-colour option Blue/Black + auto-blue removed',
  vj.notes.includes('font-colour option') && vj.notes.includes('Blue / Black') && vj.notes.includes('auto-blue') && vj.notes.includes('#202a26'),
  vj.notes.slice(-200));

ok('version notes mention v2.2.42 + mic auto-stop on result tap + Roman bigger + one layer-size control',
  vj.notes.includes('v2.2.42:') && vj.notes.includes('stops by itself') && vj.notes.includes('80%') &&
  vj.notes.includes('ONE size control') && vj.notes.includes('default 80%'));

ok('version notes mention v2.2.43 + hidden AI settings in Play Store build + cloud still default',
  vj.notes.includes('v2.2.43:') && vj.notes.includes('hidden in the Play Store build') &&
  vj.notes.includes('GS_HIDE_AI_SETTINGS') && vj.notes.includes('Ask still works'));

// ---- 1. Static wiring for the fix ----
ok('voiceStopRequested flag exists', app.includes('let voiceStopRequested=false;'));
ok('partial listener accumulates into heard.seg/parts',
  app.includes('run.heard.seg') && app.includes('run.heard.parts') && app.includes('run.heard.text=[...run.heard.parts,run.heard.seg]'));
ok('listener ends a SEGMENT on stop (no run.finish)', app.includes('run.endSegment()') && !app.includes('run.finish()'));
ok('beginSegment + auto-restart loop present',
  app.includes('const beginSegment=async()=>') && app.includes('if(!(await beginSegment()))break;'));
ok('resetVoiceNow flags manual stop', app.includes('voiceStopRequested=true;') && app.includes('if(run)run.manualStopped=true;'));
ok('runEnded guard checks safety+manual+flag+current',
  app.includes('const runEnded=()=>run.safetyStopped||run.manualStopped||voiceStopRequested||voiceRun!==run;'));
ok('v2.2.37: no 15s cap left (no 15000 timer anywhere)', !app.includes('},15000);'));
ok('4s no-heard timer still present', app.includes('noHeardTimer') && app.includes('},4000);'));
ok('pa-IN -> en-US fallback still present', app.includes("native.start(opts('pa-IN'))") && app.includes("native.start(opts('en-US'))"));
ok('maxResults:5 + partialResults:true unchanged', app.includes('maxResults:5') && app.includes('partialResults:true'));
ok('X handler no longer restarts the mic', (() => {
  const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick'));
  return !!l && !l.includes('startVoiceSearch');
})());
ok('web fallback restarts on onend + accumulates',
  app.includes('rec.onend=()=>{') && app.includes("try{rec.start();}catch(e){finish(best);}"));
ok('web fallback respects manual stop (dead() checks voiceStopRequested + run sequence)',
  app.includes('const dead=()=>voiceStopRequested||mySeq!==voiceRunSeq;') && app.includes('if(finished||dead())return;'));

// ---- 1b. Static wiring for the v2.2.33 stale-event fix ----
ok('stale fix: resetVoiceNow returns a teardown promise (600ms backstop)',
  app.includes('voiceStopPromise=new Promise') && app.includes('to=setTimeout(finish,600);'));
ok('stale fix: teardown resolves on the old run\'s stopped event',
  app.includes('voiceStoppingRun') && app.includes("run._stopResolve=finish;"));
ok('stale fix: startVoiceSearch awaits the old run teardown before starting',
  app.includes('if(searchVoiceBusy){await resetVoiceNow();}'));
ok('stale fix: partialResults guard requires current + started + not manually stopped',
  app.includes('if(!run.started||run.manualStopped||voiceStopRequested)return;'));
ok('stale fix: listeningState guard requires started before endSegment',
  app.includes('if(run.sawStarted&&run.started)run.endSegment();'));
ok('stale fix: new voice run clears the search results area',
  app.includes("if(input.id==='searchInput'){const out=$('searchResults');if(out)out.innerHTML='';}"));
ok('stale fix: run sequence invalidates a dead run (voiceRunSeq)',
  app.includes('let voiceRunSeq=0;') && app.includes('const mySeq=++voiceRunSeq;') && app.includes('if(mySeq!==voiceRunSeq)return;'));
ok('stale fix: dead run cannot fill or set Review status',
  app.includes('if(mySeq===voiceRunSeq){\n     if(!heard.text.trim())throw Error'));
ok('stale fix: dead run finally cannot clear the new run state',
  app.includes('if(mySeq===voiceRunSeq){clearVoiceWatchdog();searchVoiceBusy=false;}'));

// ---- 2. Voice VM harness (fake clock + stubbed recognizers) ----
const _voiceLines = app.split('\n');
const _voiceStart = _voiceLines.findIndex(l => l.startsWith('let searchVoiceBusy=false;'));
const _voiceEnd = _voiceLines.findIndex((l, i) => i > _voiceStart && l.startsWith('// Settings "Test microphone"'));
const voiceSlice = _voiceLines.slice(_voiceStart, _voiceEnd).join('\n');
ok('voice slice extracted (searchVoiceBusy..startVoiceSearch)',
  voiceSlice.includes('async function startVoiceSearch') && voiceSlice.includes('function resetVoiceNow'));

function makeClock() {
  let now = 0, next = 1; const timers = new Map();
  const setTimeout = (fn, ms, ...args) => { const id = next++; timers.set(id, { fn, at: now + Math.max(0, ms || 0), args }); return id; };
  const clearTimeout = id => { timers.delete(id); };
  const advance = ms => {
    const end = now + ms; let guard = 0;
    while (guard++ < 20000) {
      let best = null, bestAt = Infinity;
      for (const [id, t] of timers) { if (t.at <= end && t.at < bestAt) { best = id; bestAt = t.at; } }
      if (best === null) break;
      now = bestAt; const t = timers.get(best); timers.delete(best); t.fn(...t.args);
    }
    now = end;
  };
  return { setTimeout, clearTimeout, advance, pending: () => timers.size, get now() { return now; } };
}
async function drive(clock, ms, step = 15) {
  const target = clock.now + ms;
  while (clock.now < target) {
    clock.advance(Math.min(step, target - clock.now));
    await new Promise(r => setImmediate(r));
    await new Promise(r => setImmediate(r));
  }
}
function fakeEl() {
  const classes = new Set();
  return {
    disabled: false, textContent: '', value: '',
    classList: {
      toggle(c, f) { if (f === undefined) { if (classes.has(c)) classes.delete(c); else classes.add(c); } else if (f) classes.add(c); else classes.delete(c); },
      add(c) { classes.add(c); },
      remove(c) { classes.delete(c); },
      contains(c) { return classes.has(c); },
    },
    dispatchEvent() {},
  };
}

// Stub native recognizer. script: array of utterances; each is an array of
// growing partial strings, or {delay, partials} for a late utterance.
// A start() with no scripted utterance emits 'started' and stays listening.
// stop() models a real recognizer: it cancels any pending partial/'stopped'
// timers for that run (a stopped recognizer emits no more events for it) and
// confirms 'stopped' asynchronously (stopDelay ms later), so the teardown
// promise resolves on the event, not on the stop() call. emit() lets a test
// inject a stale event from an old run after a new run started.
function makeStubNative(clock, script, opts = {}) {
  const listeners = {};
  const calls = { start: [], stop: 0, startAt: [] };
  let startCount = 0;
  let pending = [];
  const emit = (ev, data) => { (listeners[ev] || []).forEach(cb => { try { cb(data); } catch (e) { console.error('listener error', e); } }); };
  const stub = {
    available: async () => ({ available: true }),
    checkPermissions: async () => ({ speechRecognition: opts.perm || 'granted' }),
    requestPermissions: async () => ({ speechRecognition: opts.requestPerm || 'granted' }),
    addListener: (ev, cb) => { (listeners[ev] = listeners[ev] || []).push(cb); return Promise.resolve(); },
    start: async (o) => {
      calls.start.push(o && o.language);
      calls.startAt.push(clock.now);
      const idx = startCount++;
      if (opts.failPaIN && o && o.language === 'pa-IN') throw new Error('pa-IN unavailable');
      const raw = script[idx] || [];
      const delay = Array.isArray(raw) ? 0 : (raw.delay || 0);
      const utt = Array.isArray(raw) ? raw : (raw.partials || []);
      pending.push(clock.setTimeout(() => emit('listeningState', { status: 'started' }), 5));
      utt.forEach((p, i) => { pending.push(clock.setTimeout(() => emit('partialResults', { matches: [p] }), delay + 10 + i * 15)); });
      if (utt.length) pending.push(clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), delay + 10 + utt.length * 15 + 10));
      return;
    },
    stop: () => {
      calls.stop++;
      pending.forEach(id => clock.clearTimeout(id)); pending = [];
      clock.setTimeout(() => emit('listeningState', { status: 'stopped' }), opts.stopDelay ?? 50);
      return Promise.resolve();
    },
    emit,
    _calls: calls,
  };
  return stub;
}

function makeNativeCtx(script, opts = {}) {
  const clock = makeClock();
  const stub = makeStubNative(clock, script, opts);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(),  };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { GS_SPEECH: stub, GS_NATIVE_UPDATES: { isNative: true } },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, stub, input, els, state, sandbox };
}
function readRun(ctx) {
  vm.runInContext('this.__r={run:voiceRun,busy:searchVoiceBusy,stopReq:voiceStopRequested};', ctx);
  return ctx.__r;
}

// Fake Web SpeechRecognition (for the fallback path). One instance; start()
// is called repeatedly on it, each call playing script[idx].
function makeFakeSR(clock, script) {
  const shared = { instances: [] };
  class FakeSR {
    constructor() { this.lang = ''; this.interimResults = false; this.maxAlternatives = 0; this.onresult = null; this.onerror = null; this.onend = null; this._n = 0; shared.instances.push(this); }
    start() {
      const idx = this._n++;
      const utt = script[idx] || [];
      utt.forEach((p, i) => { clock.setTimeout(() => { if (this.onresult) this.onresult({ results: [[{ transcript: p }]] }); }, 10 + i * 15); });
      if (utt.length) clock.setTimeout(() => { if (this.onend) this.onend(); }, 10 + utt.length * 15 + 10);
    }
    stop() { clock.setTimeout(() => { if (this.onend) this.onend(); }, 5); }
  }
  return { FakeSR, shared };
}
function makeWebCtx(script) {
  const clock = makeClock();
  const sr = makeFakeSR(clock, script);
  const input = { id: 'searchInput', value: '', events: 0, dispatchEvent() { this.events++; } };
  const els = { voiceBtn: fakeEl(), askVoiceBtn: fakeEl(), voiceStatus: fakeEl(),  };
  const state = { lang: 'en' };
  const sandbox = {
    state, input,
    document: { getElementById: id => els[id] || null },
    window: { SpeechRecognition: sr.FakeSR },
    Event: class Event { constructor(t) { this.type = t; } },
    setTimeout: clock.setTimeout, clearTimeout: clock.clearTimeout,
    console,
    $: id => sandbox.document.getElementById(id),
    age: (k, en) => state.lang === 'pa' ? k : en,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(voiceSlice, ctx);
  return { ctx, clock, sr, input, els, state, sandbox };
}

// ---- 3. Behavioral voice tests (async, fake clock) ----
let p;
// (a) Auto-restart accumulates ALL words across segments (the reported bug)
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(a) auto-restart: all 6 words in the input after 2 segments',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(a) auto-restart: recognizer started 3 times (initial + 2 restarts)',
    t.stub._calls.start.length === 3, JSON.stringify(t.stub._calls.start));
  // v2.2.37: no 15s cap — the run must still be listening long past it.
  await drive(t.clock, 30000);
  ok('(a) v2.2.37: no 15s cap — still listening after 30s (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(a) v2.2.37: no restart storm while waiting (start count stays 3)',
    t.stub._calls.start.length === 3, `starts=${t.stub._calls.start.length}`);
  // Stop ends it right away, words intact.
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(a) v2.2.37: Stop settles the run with the 6 words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(a) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r.run === null && r.busy === false, JSON.stringify(r));
}
// (b) Manual stop (X / resetVoiceNow) — no restart after it
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(b) before stop: 3 words heard, recognizer restarted once',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ' && t.stub._calls.start.length === 2,
    `value=${JSON.stringify(t.input.value)} starts=${t.stub._calls.start.length}`);
  vm.runInContext('resetVoiceNow()', t.ctx);
  const startsAtStop = t.stub._calls.start.length;
  await drive(t.clock, 3000);
  ok('(b) manual stop: no restart after X (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(b) manual stop: the 3 words stay in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
  await drive(t.clock, 2000);
  ok('(b) v2.2.37: run resolves promptly after manual stop (Stop ends the wait, no safety timer)',
    settled === true, `settled=${settled}`);
}
// (c) v2.2.37: NO 15s cap — the run keeps listening past 15s and past 30s,
// and only Stop ends it.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1000);
  const r1 = readRun(t.ctx);
  ok('(c) run listening after the first segment (voiceRun set, busy)',
    r1.run !== null && r1.busy === true, JSON.stringify({ run: !!r1.run, busy: r1.busy }));
  await drive(t.clock, 30000);
  ok('(c) v2.2.37: still listening after 30s — no 15s cap (not settled, busy)',
    settled === false && readRun(t.ctx).run !== null && readRun(t.ctx).busy === true,
    `settled=${settled}`);
  ok('(c) v2.2.37: no restart while waiting (start count stays 2)',
    t.stub._calls.start.length === 2, `starts=${t.stub._calls.start.length}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(c) v2.2.37: Stop ends the run with the words intact',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  const r2 = readRun(t.ctx);
  ok('(c) v2.2.37: run cleaned up after Stop (voiceRun null, not busy)',
    r2.run === null && r2.busy === false, JSON.stringify(r2));
}
// (d) 4s no-heard notice, then recovery when words arrive
{
  const t = makeNativeCtx([
    { delay: 5000, partials: ['ਸਤਿਨਾਮੁ'] },
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 4500);
  ok('(d) 4s no-heard notice fires when nothing is heard',
    t.els.voiceStatus.textContent.includes('not hearing'),
    JSON.stringify(t.els.voiceStatus.textContent));
  await drive(t.clock, 1500);
  ok('(d) status returns to Listening when words arrive',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(d) the word is captured after the notice',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (e) Permission denied + pa-IN -> en-US fallback
{
  const t = makeNativeCtx([], { perm: 'denied', requestPerm: 'denied' });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 500);
  ok('(e1) permission denied: status explains it',
    t.els.voiceStatus.textContent.includes('permission was denied'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(e1) permission denied: recognizer never started',
    t.stub._calls.start.length === 0, `starts=${t.stub._calls.start.length}`);
  const r = readRun(t.ctx);
  ok('(e1) permission denied: mic button re-enabled, not busy',
    r.busy === false && t.els.voiceBtn.disabled === false, JSON.stringify({ busy: r.busy, disabled: t.els.voiceBtn.disabled }));
}
{
  const t = makeNativeCtx([[], ['ਸਤਿਨਾਮੁ']], { failPaIN: true });
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 800);
  ok('(e2) pa-IN fails -> en-US fallback is tried',
    t.stub._calls.start[0] === 'pa-IN' && t.stub._calls.start[1] === 'en-US',
    JSON.stringify(t.stub._calls.start));
  ok('(e2) fallback run hears words on the en-US start',
    t.input.value.includes('ਸਤਿਨਾਮੁ'), JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) Web Speech fallback accumulates across onend restarts
{
  const t = makeWebCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
    ['ਨਾਨਕ', 'ਨਾਨਕ ਦੇਵ', 'ਨਾਨਕ ਦੇਵ ਜੀ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 1200);
  ok('(f) web fallback: all 6 words after 2 onend restarts',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ', JSON.stringify(t.input.value));
  ok('(f) web fallback: recognizer started 3 times',
    t.sr.shared.instances[0]._n === 3, `starts=${t.sr.shared.instances[0]._n}`);
  // v2.2.37: no 15s cap on the web path either.
  await drive(t.clock, 30000);
  ok('(f) v2.2.37: web fallback still listening after 30s (not settled)',
    settled === false && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(f) v2.2.37: web fallback Stop settles the run with the 6 words',
    settled === true && t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ ਨਾਨਕ ਦੇਵ ਜੀ',
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// (g) v2.2.40: the mic button ITSELF becomes the Stop sign while listening
// (no separate Stop button) and stops right away when tapped.
{
  const t = makeNativeCtx([
    ['ਮੇਰਾ', 'ਮੇਰਾ ਵੈਦ', 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  ok('(g) mic button shows the Stop sign while listening (⏹, not 🎙)',
    t.els.voiceBtn.textContent === '⏹',
    JSON.stringify(t.els.voiceBtn.textContent));
  ok('(g) mic button has the listening class while listening',
    t.els.voiceBtn.classList.contains('gs-listening') === true,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  ok('(g) status shows Listening while listening',
    t.els.voiceStatus.textContent.includes('Listening'),
    JSON.stringify(t.els.voiceStatus.textContent));
  ok('(g) mic button itself is not disabled while listening (it IS the Stop button)',
    t.els.voiceBtn.disabled === false,
    JSON.stringify(t.els.voiceBtn.disabled));
  const startsAtStop = t.stub._calls.start.length;
  vm.runInContext('stopVoiceSearch()', t.ctx);
  // Immediate: the listening UI turns off synchronously with the Stop tap.
  ok('(g) Stop turns the mic back to the mic icon at once (⏹ -> 🎙)',
    t.els.voiceBtn.textContent === '🎙',
    JSON.stringify(t.els.voiceBtn.textContent));
  ok('(g) Stop turns the listening class off at once',
    t.els.voiceBtn.classList.contains('gs-listening') === false,
    JSON.stringify(t.els.voiceBtn.classList.contains('gs-listening')));
  await drive(t.clock, 2000);
  ok('(g) Stop settles the run right away',
    settled === true, `settled=${settled}`);
  ok('(g) no restart after Stop (start count frozen)',
    t.stub._calls.start.length === startsAtStop, `starts=${t.stub._calls.start.length} was ${startsAtStop}`);
  ok('(g) Stop keeps the spoken words in the input',
    t.input.value === 'ਮੇਰਾ ਵੈਦ ਗੁਰੁ', JSON.stringify(t.input.value));
}
// (h) v2.2.40: after a re-render (fresh button elements), the mic button
// still shows Stop while a run is listening.
{
  const t = makeNativeCtx([['ਸਤਿਨਾਮੁ']]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 300);
  // Simulate a re-render: the mic button is recreated with the plain 🎙 icon.
  t.els.voiceBtn = fakeEl(); t.els.voiceBtn.textContent = '🎙';
  t.els.askVoiceBtn = fakeEl(); t.els.askVoiceBtn.textContent = '🎙';
  ok('(h) fresh mic button shows the mic icon before sync',
    t.els.voiceBtn.textContent === '🎙' && t.els.voiceBtn.classList.contains('gs-listening') === false,
    JSON.stringify(t.els.voiceBtn.textContent));
  vm.runInContext('syncVoiceStopUI()', t.ctx);
  ok('(h) sync restores the Stop sign on the fresh mic button while listening',
    t.els.voiceBtn.textContent === '⏹' && t.els.voiceBtn.classList.contains('gs-listening') === true,
    JSON.stringify(t.els.voiceBtn.textContent));
  vm.runInContext('stopVoiceSearch()', t.ctx);
  ok('(h) Stop after re-render turns the mic back to 🎙 at once',
    t.els.voiceBtn.textContent === '🎙',
    JSON.stringify(t.els.voiceBtn.textContent));
  await drive(t.clock, 2000);
  ok('(h) Stop after re-render settles the run with the word intact',
    settled === true && t.input.value.includes('ਸਤਿਨਾਮੁ'),
    `settled=${settled} value=${JSON.stringify(t.input.value)}`);
}

// ---- 4. v2.2.32 regressions (static — the full suite also runs in test-v252) ----
ok('regression v2.2.32: AI language follows app language (aiLangManual sync)',
  app.includes('aiLangManual') && app.includes("if(!state.aiLangManual)state.aiLang=state.lang;"));
ok('regression v2.2.32: transliteration in search results',
  app.includes('gs-result-roman') && ss.includes("roman:String(roman||'')"));
ok('regression v2.2.32: cloud AI by default',
  app.includes("AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev'"));
ok('regression v2.2.31: elaborate prompt + Dasam Granth in worker',
  worker.includes('Dasam Granth') && worker.includes('1500') && worker.includes('total essence'));
ok('regression v2.2.30: Hindi absent, English in search results, font slider',
  !app.includes('showHi') && app.includes('gs-result-en') && app.includes('fontSlider'));
ok('regression v2.2.28: search source labels',
  app.includes('gs-result-bani-tag') && app.includes('Dasam Granth'));
ok('regression v2.2.27: reader top bar hide/show',
  app.includes('barScrollDecision') && app.includes('readerBarHidden'));
ok('regression v2.2.26: centered Bani headings, pinch Ask-only',
  css.includes('text-align:center') && app.includes('pinchFont') && app.includes('pinchDist'));
ok('regression: voice permission flow (fast path + listeners once)',
  app.includes('voicePermGranted') && app.includes('ensureVoiceListeners'));

// ---- 5. v2.2.33 stale-event fix (behavioral) ----
// Helper: drive 1ms at a time until a voice run exists (voiceRun set).
// Catches the window after a new run is created but before its 'started'
// event fires (5ms after start()).
async function waitForRun(t, maxMs = 300) {
  for (let i = 0; i < maxMs; i++) {
    if (readRun(t.ctx).run) return true;
    await drive(t.clock, 1, 1);
  }
  return !!readRun(t.ctx).run;
}
// (a) Delayed partial from run A arriving after run B started is IGNORED
{
  const t = makeNativeCtx([
    { delay: 300, partials: ['WORD1'] },
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 100);
  // X: reset stops run A (its pending partial at 310ms is cancelled) + start B.
  vm.runInContext('resetVoiceNow()', t.ctx);
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(a) stale partial: run B keeps ONLY its own words (WORD1 never appears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(a) stale partial: WORD1 never appears even after the full run',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
}
// (a2) Guard: a partial injected after run B is created but before its
// 'started' event is ignored (the started check).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(a2) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale partial from run A right now (run B not started yet).
  t.stub.emit('partialResults', { matches: ['WORD1'] });
  await drive(t.clock, 600);
  ok('(a2) guard: stale partial before started is ignored',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (b) Delayed 'stopped' from run A arriving after run B started does NOT
// end run B's segment (run B keeps listening).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  const live = await waitForRun(t);
  ok('(b) guard: run B is created before its started event', live, JSON.stringify(readRun(t.ctx)));
  // Inject a stale 'stopped' from run A right now (run B not started yet).
  t.stub.emit('listeningState', { status: 'stopped' });
  await drive(t.clock, 600);
  const r = readRun(t.ctx);
  ok('(b) stale stopped: run B keeps listening and hears its own words',
    t.input.value === 'WORD2' && r.run !== null && r.busy === true,
    `value=${JSON.stringify(t.input.value)} run=${!!r.run} busy=${r.busy}`);
  await drive(t.clock, 17000);
}
// (c) X -> tap mic -> speak word 2 gives ONLY word 2's results
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  ok('(c) word 1 heard first', t.input.value === 'WORD1', JSON.stringify(t.input.value));
  // X: reset + clear the input (what the X handler does).
  vm.runInContext('resetVoiceNow()', t.ctx);
  t.input.value = '';
  // Tap the mic again and speak word 2.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  ok('(c) X -> mic -> word 2: ONLY word 2 in the input (word 1 never reappears)',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
  ok('(c) X -> mic -> word 2: word 1 still absent after the full run',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
}
// (d) v2.2.37: a run that hears nothing does NOT end by itself — it keeps
// listening until Stop; Stop settles it and the mic button is re-enabled.
{
  const t = makeNativeCtx([[]]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 20000);
  ok('(d) v2.2.37: nothing heard yet the run keeps listening (not settled)',
    settled === false && readRun(t.ctx).run !== null,
    `settled=${settled}`);
  vm.runInContext('stopVoiceSearch()', t.ctx);
  await drive(t.clock, 2000);
  ok('(d) v2.2.37: Stop settles the empty run',
    settled === true, `settled=${settled}`);
  const r = readRun(t.ctx);
  ok('(d) v2.2.37: mic button re-enabled, not busy, run cleaned up after Stop',
    r.busy === false && r.run === null && t.els.voiceBtn.disabled === false,
    `settled=${settled} busy=${r.busy} run=${!!r.run} disabled=${t.els.voiceBtn.disabled}`);
  ok('(d) v2.2.37: input stays empty after Stop with nothing heard',
    t.input.value === '', JSON.stringify(t.input.value));
}
// (e) Starting a new voice run clears the previous search results.
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  // The results area (not in the default els) — add it so the clear is visible.
  t.els.searchResults = { innerHTML: '' };
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  // Simulate run A's search results sitting in the results area.
  t.els.searchResults.innerHTML = '<div>old results for WORD1</div>';
  vm.runInContext('resetVoiceNow()', t.ctx);
  vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 600);
  ok('(e) new voice run clears the previous search results',
    t.els.searchResults.innerHTML === '', JSON.stringify(t.els.searchResults.innerHTML));
  ok('(e) new run still hears its own words',
    t.input.value === 'WORD2', JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}
// (f) A mic tap while busy waits for the old run to fully stop before the
// new run starts (serialized, no overlap).
{
  const t = makeNativeCtx([
    ['WORD1'],
    [],
    ['WORD2'],
  ]);
  p = vm.runInContext('startVoiceSearch(input)', t.ctx);
  await drive(t.clock, 100);
  const tapAt = t.clock.now;
  const startsBeforeTap = t.stub._calls.start.length;
  // Mic tap while run A is busy — must wait for run A to fully stop.
  const p2 = vm.runInContext('startVoiceSearch(input)', t.ctx);
  let settled = false; p2.then(() => { settled = true; }, () => { settled = true; });
  await drive(t.clock, 600);
  // Run B's first start is the one after the tap. It must be after the
  // teardown ('stopped' 50ms after stop() at the tap) — no overlap.
  ok('(f) serialized: new run starts only after the old run stopped',
    t.stub._calls.startAt.length > startsBeforeTap && t.stub._calls.startAt[startsBeforeTap] >= tapAt + 50,
    `startAt=${JSON.stringify(t.stub._calls.startAt)} tapAt=${tapAt} startsBeforeTap=${startsBeforeTap}`);
  ok('(f) serialized: new run hears its own words, not the old run\'s',
    t.input.value === 'WORD2' && !t.input.value.includes('WORD1'),
    JSON.stringify(t.input.value));
  await drive(t.clock, 17000);
}


// ---- 6. v2.2.35 white Bani bg + tight Jaap pairs + Noto Serif Gurmukhi ----
const fs2 = fs;
const fontsDir = path.join(ROOT, 'www/assets/fonts');
// (v2.2.35a) The cream bug: NO #fdfcf9 anywhere, Bani reader is pure white.
ok('v235: no #fdfcf9 anywhere in the CSS (the missed cream hex is gone)',
  !/#fdfcf9/i.test(css));
ok('v235: Bani reader background is pure white (#ffffff)',
  css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }'));
ok('v235: no near-cream background left in the Bani reader path',
  // Cream = R>=245, G>=240, B>=235 but not pure white. The night-mode dark
  // background #0b0e0c is intentional and must not fail this check.
  ![...css.matchAll(/\.gs-reader-bani[^\{]*\{([^}]*)\}/g)]
    .some(m => [...m[1].matchAll(/background\s*:\s*#([0-9a-f]{6})/gi)]
      .some(h => { const v = parseInt(h[1], 16);
        return v !== 0xffffff && ((v >> 16) & 255) >= 245 && ((v >> 8) & 255) >= 240 && (v & 255) >= 235; })));
// (v2.2.35b) The ::after strut is gone for Bani blocks (SGGS keeps it).
ok('v235: Bani ::after strut override present (content:none, Bani only)',
  css.includes('.gs-reader-bani #verses .verse-block:after{content:none!important;}'));
ok('v235: SGGS still gets the compact ::after strut (Japji unchanged)',
  css.includes('.verse-list .verse-block:after{content:" ";white-space:pre}'));
ok('v235: pair margin-bottom is 0 (was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}') && !css.includes('margin-bottom:0.25em'));
ok('v235: no +0.15 line-height extra left anywhere',
  !/var\(--leading\)\s*\+\s*0\.15/.test(css));
ok('v235: Bani reader widened to Sundar Gutka side margins (720px / 16px)',
  css.includes('.gs-reader-bani .reading{max-width:720px;padding-left:16px;padding-right:16px;}'));
// (v2.2.35c) Noto Serif Gurmukhi bundled, first in stacks; Tiro kept as fallback.
const tiroG = path.join(fontsDir, 'tiro-gurmukhi-400-gurmukhi.woff2');
const tiroL = path.join(fontsDir, 'tiro-gurmukhi-400-latin.woff2');
const notoG = path.join(fontsDir, 'noto-serif-gurmukhi-400-gurmukhi.woff2');
const notoL = path.join(fontsDir, 'noto-serif-gurmukhi-400-latin.woff2');
const notoG7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-gurmukhi.woff2');
const notoL7 = path.join(fontsDir, 'noto-serif-gurmukhi-700-latin.woff2');
ok('v235: Noto Serif 400 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG) && fs2.statSync(notoG).size > 10000 &&
  fs2.existsSync(notoL) && fs2.statSync(notoL).size > 10000);
ok('v235: Noto Serif 700 gurmukhi + latin woff2 bundled',
  fs2.existsSync(notoG7) && fs2.statSync(notoG7).size > 10000 &&
  fs2.existsSync(notoL7) && fs2.statSync(notoL7).size > 10000);
ok('v235: Noto Serif woff2 files are real woff2 bytes',
  fs2.readFileSync(notoG).subarray(0, 4).toString() === 'wOF2' &&
  fs2.readFileSync(notoG7).subarray(0, 4).toString() === 'wOF2');
ok('v235: @font-face for Noto Serif 400 + 700 references the bundled files',
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:400;') &&
  css.includes('@font-face{font-family:"Noto Serif Gurmukhi";font-style:normal;font-weight:700;') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/noto-serif-gurmukhi-700-gurmukhi.woff2)'));
ok('v235: Tiro files still present as fallback (not deleted)',
  fs2.existsSync(tiroG) && fs2.existsSync(tiroL));
// (a) Background #FFFFFF in the default theme: every :root fallback AND the
// light-tone rule that actually wins (html[data-tone="light"]).
for (const [name, re] of [
  ['default :root (line 1)', /:root\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
  ['v0.6 :root', /:root\{--bg:#ffffff;--paper:#ffffff;/],
  ['v1.0 :root', /:root \{--bg:#ffffff;--paper:#ffffff;/],
  ['light tone rule', /html\[data-tone="light"\]\{[^}]*--bg:#ffffff;--paper:#ffffff;/],
]) ok(`bg: ${name} is #FFFFFF`, re.test(css));
ok('bg: sepia tone untouched (#f4eddf)', css.includes('html[data-tone="sepia"]{color-scheme:light;--bg:#f4eddf;--paper:#f4eddf;'));
ok('bg: charcoal tone untouched (#242729)', css.includes('html[data-tone="charcoal"]{color-scheme:dark;--bg:#242729;--paper:#242729;'));
ok('bg: dark theme untouched (#151e19)', css.includes('.dark{color-scheme:dark;--bg:#151e19;--paper:#151f1a;'));
ok('bg: no other default --bg/--paper left behind',
  // Only the --bg/--paper variables must be white. The home screen keeps its
  // own cream surfaces (.home-v10, .home-tile, .home-list-item, .hero-temple,
  // .daily-card) by design, so #fbf7ef/#fffdfa as a `background:` value is fine.
  !/--(?:bg|paper):#(eeeee9|fcfbf8|f2f0e9|faf9f5|f3eee5|fbf7ef)/.test(css));
ok('home: home screen unchanged (cream, per Karamjit)',
  css.includes('.home-v10{padding:0 17px 22px;background:#fbf7ef}') &&
  (css.match(/background:#fffdfa/g) || []).length === 2 &&
  css.includes('linear-gradient(0deg,#fbf7ef 0%,transparent 20%)') &&
  css.includes('background:linear-gradient(130deg,#f2f7ef,#fcfaf3)'));
// (b) Leading + block margin.
ok('gaps: base --leading is 1.5', css.includes('--font:25px;--leading:1.5;'));
ok('gaps: verse-block margin is 8px', css.includes('.verse-block{margin:0 0 8px}'));
ok('gaps: font size still 25px', css.includes('--font:25px;'));
ok('gaps: line-layout leading tightened (compact 1.35 / standard 1.5 / spacious 1.65)',
  css.includes('html[data-line-layout="compact"]{--leading:1.35;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="standard"]{--leading:1.5;--verse-gap:0px;}') &&
  css.includes('html[data-line-layout="spacious"]{--leading:1.65;--verse-gap:0px;}'));
ok('gaps: theme() map tightened to match', app.includes("const ls={compact:[1.35,'0px'],standard:[1.5,'0px'],spacious:[1.65,'0px']}"));
ok('gaps: Bani para margin tightened to .3em, no +0.15 line-height extra',
  css.includes('.gs-bani-para{display:block!important;text-align:center!important;line-height:var(--leading)!important;margin:0 0 .3em!important;'));
ok('gaps: Bani stanza-end margin tightened to .3em', css.includes('html.reading-open .gs-reader-bani #verses .gs-pankti.gs-stanza-end{margin-bottom:.3em!important;}'));
ok('gaps: Bani pankti line-height is var(--leading) (no +0.15 extra)',
  css.includes('.gs-bani-pankti .verse-text { line-height: var(--leading); }'));
// (c) Bundled Tiro Gurmukhi font.
ok('font: gurmukhi woff2 bundled', fs2.existsSync(tiroG) && fs2.statSync(tiroG).size > 10000);
ok('font: latin woff2 bundled', fs2.existsSync(tiroL) && fs2.statSync(tiroL).size > 10000);
ok('font: gurmukhi woff2 is real woff2 bytes', fs2.readFileSync(tiroG).subarray(0, 4).toString() === 'wOF2');
ok('font: latin woff2 is real woff2 bytes', fs2.readFileSync(tiroL).subarray(0, 4).toString() === 'wOF2');
ok('font: @font-face references the bundled files',
  css.includes('@font-face{font-family:"Tiro Gurmukhi"') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-gurmukhi.woff2)') &&
  css.includes('url(assets/fonts/tiro-gurmukhi-400-latin.woff2)'));
ok('font: AnmolUni is first in every serif Gurmukhi stack (v2.2.39)',
  (css.match(/"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi"/g) || []).length >= 15 &&
  // No Noto-first STACK left: a stack has a comma after the family name;
  // @font-face declarations end with a semicolon and must not count.
  !/font-family:"Noto Serif Gurmukhi",/.test(css) &&
  !/font-family:"Tiro Gurmukhi",/.test(css));
ok('font: serif data-font override uses AnmolUni first (v2.2.39)',
  css.includes('html[data-font="serif"] .verse-text,html[data-font="serif"] .word,html[data-font="serif"] .daily-quote{font-family:"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi","Raavi","Nirmala UI",serif}'));
ok('font: sans/system data-font overrides keep their stacks (no Noto Serif forced)',
  css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Sans Gurmukhi","Mukta Mahee","Nirmala UI",sans-serif}') &&
  !css.includes('html[data-font="sans"] .verse-text,html[data-font="sans"] .word,html[data-font="sans"] .daily-quote{font-family:"Noto Serif Gurmukhi"'));
ok('font: no external/webfont link anywhere (offline)',
  !css.includes('fonts.googleapis') && !css.includes('fonts.gstatic') &&
  !html.includes('fonts.googleapis') && !html.includes('fonts.gstatic') &&
  !app.includes('fonts.googleapis') && !app.includes('fonts.gstatic'));
ok('font: vishraam colours unchanged (green/orange still in CSS)',
  css.includes('.vishraam-short') && css.includes('.vishraam-long'));


// ---- 7. v2.2.35 transliteration per line (iGranth) + Jaap Sahib pairs ----
const vm2 = vm;
const sandbox7 = {window:{}, console};
vm2.runInNewContext(rv, sandbox7);
const V7 = sandbox7.window.GS_VERSES;
const jaapLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/4.json'), 'utf8')).lines;
const anandLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/10.json'), 'utf8')).lines;
// Anand opening: "ਅਨੰਦੁ ਭਇਆ ਮੇਰੀ ਮਾਏ ਸਤਿਗੁਰੂ ਮੈ ਪਾਇਆ ॥" + next pankti.
const anandPara = anandLines.slice(2, 4);
const htmlOn = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{translit:true}, foundIdx:-1});
const htmlOff = V7.baniFlowHTML(anandPara, {vishraamOn:false, show:{}, foundIdx:-1});
// (a) Translit ON: one roman block per pankti, directly under its own line.
const romanTexts = [...htmlOn.matchAll(/<div class="verse-layer verse-roman"[^>]*>([^<]*)<\/div>/g)].map(m => m[1]);
ok('translit: one roman block per pankti', romanTexts.length === anandPara.length, `got ${romanTexts.length}, want ${anandPara.length}`);
ok('translit: first roman is that pankti only (not joined)',
  romanTexts[0] === 'anand bheaa meree maae; satiguroo. mai paaeaa |', JSON.stringify(romanTexts[0]));
ok('translit: second roman is that pankti only (not joined)',
  romanTexts[1] === 'satigur. ta paaeaa sehaj setee; man vajeea vaadhaaeea |', JSON.stringify(romanTexts[1]));
ok('translit: each roman sits inside its own pankti block, right after its verse-text',
  [...htmlOn.matchAll(/<div class="verse-block gs-pankti[^>]*><div class="verse-text"[^>]*>[\s\S]*?<\/div><div class="verse-layer verse-roman"/g)].length === anandPara.length);
ok('translit: every word still a tappable button',
  (htmlOn.match(/<button type="button" class="word"/g) || []).length >= 10);
ok('translit: no joined paragraph roman (no single block holding both romans)',
  !romanTexts.some(t => t.includes('anand bheaa') && t.includes('satigur. ta paaeaa')));
// (b) Translit OFF: flowing paragraph unchanged — one verse-text holds the
// whole paragraph's words, no roman at all.
ok('translit off: one flowing verse-text holds the whole paragraph',
  (htmlOff.match(/<div class="verse-block gs-bani-para"/g) || []).length === 1 &&
  htmlOff.includes('ਅਨੰਦੁ') && htmlOff.includes('ਵਾਧਾਈਆ'));
ok('translit off: no roman blocks', !htmlOff.includes('verse-roman'));
// (c) Jaap Sahib pair mode: short "ਨਮਸਤੁੰ" panktis pair two-per-block after
// the "ਭੁਜੰਗ ਪ੍ਰਯਾਤ ਛੰਦ ॥" heading, and render as tight pair blocks.
const jaapGroups = V7.groupBaniParagraphs(jaapLines.slice(2, 30));
const pairGroups = jaapGroups.filter(g => g.type === 'pair');
ok('jaap: short namastun panktis pair two-per-block',
  pairGroups.filter(g => g.items.length === 2).length >= 8,
  `pairs=${pairGroups.length} full=${pairGroups.filter(g => g.items.length === 2).length}`);
const jaapHtml = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{}, foundIdx:-1});
ok('jaap: pair blocks render as gs-bani-para gs-bani-pair',
  (jaapHtml.match(/class="verse-block gs-bani-para gs-bani-pair"/g) || []).length >= 8);
ok('jaap: pair block holds both short panktis on one tight block',
  (jaapHtml.match(/<div class="verse-block gs-bani-para gs-bani-pair"[^>]*>[\s\S]*?<\/div><\/div>/g) || [])
    .some(b => { const t = b.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' '); return t.includes('ਨਮਸਤ੍ਵੰ ਅਕਾਲੇ') && t.includes('ਨਮਸਤ੍ਵੰ ਕ੍ਰਿਪਾਲੇ'); }));
ok('jaap: pair/para margin is tight (.3em, not the old .6em)',
  css.includes('margin:0 0 .3em!important;') && !css.includes('margin:0 0 .6em!important;'));
ok('jaap: pair margin-bottom is 0 (tight, was .25em)',
  css.includes('.gs-bani-pair{margin-bottom:0!important;}'));
// (d) Ang reader untouched: verseHTML still puts roman under each line.
const angLines = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1.json'), 'utf8')).lines;
const angHtml = angLines.slice(0, 3).map((line, i) => V7.verseHTML(line, {idx:i, kind:'ang', vishraamOn:false, show:{translit:true}})).join('');
ok('ang: roman still per line under its own pankti',
  (angHtml.match(/verse-roman/g) || []).length === 3);


// ---- 8. v2.2.36 centred search line (ONE change) ----
// (a) SGGS scroll-mode resume: the line's centre lands at innerHeight/2.
const resumeLine = app.split('\n').find(l => l.includes('state.readView') && l.includes('state.mode') && l.includes('scroll') && l.includes('getBoundingClientRect'));
ok('v2.2.36: SGGS resume scroll centres the line (r.top + r.height/2 - innerHeight/2)',
  !!resumeLine && resumeLine.includes('r.top+r.height/2-window.innerHeight/2') && resumeLine.includes('Math.max(0,y)'),
  resumeLine ? resumeLine.slice(0, 200) : 'resume line not found');
ok('v2.2.36: SGGS resume scroll has no -73 top offset left',
  !app.includes('getBoundingClientRect().top-73'));
ok('v2.2.36: SGGS resume still keeps the user scroll progress (verseOffset)',
  !!resumeLine && resumeLine.includes('+state.verseOffset'));
// (b) Bani/remote jump (search tap, saved verse, resume): block:'center'.
const jumpLine = app.split('\n').find(l => l.includes('highlightLine') && l.includes('scrollIntoView'));
ok('v2.2.36: remote line jump uses scrollIntoView block center',
  !!jumpLine && jumpLine.includes("scrollIntoView({block:'center'})"),
  jumpLine ? jumpLine.slice(-160) : 'jump line not found');
ok('v2.2.36: remote line jump no longer uses block start',
  !!jumpLine && !jumpLine.includes("block:'start'"));
// (c) Out of scope — unchanged: page-turn, home, Kirtan alphabet jump.
ok('v2.2.36: page-turn still scrolls to top (turn() unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes('function turn(dir)')); return !!l && l.includes('window.scrollTo({top:0,behavior:'); })());
ok('v2.2.36: leaving the reader still scrolls home to top (go() unchanged)',
  app.includes("if(view!=='reader')window.scrollTo({top:0,behavior:'instant'});"));
ok('v2.2.36: Kirtan alphabet jump still block start (list row, not a pangti)',
  app.includes("row.scrollIntoView({block:'start'})"));
ok('v2.2.36: Kirtan shabad open still scrolls to top',
  (() => { const i = app.indexOf('async function openKirtanShabad'); const seg = app.slice(i, i + 1500); return seg.includes('window.scrollTo({top:0,behavior:'); })());
// (d) The search tap still sets highlightLine and opens with progress.
ok('v2.2.36: search tap still sets highlightLine + openAng/openBani with preserveProgress',
  app.includes('highlightLine=Number(found.dataset.foundIdx') && app.includes('openAng(Number(found.dataset.foundAng') && app.includes('openBani(Number(foundBani.dataset.foundBani'));

// ---- 6. v2.2.37: brand follows language + Muse-style Stop button ----
// (a) Brand.
ok('v2.2.37: top-bar brand follows the app language (render uses age)',
  app.includes("$('brand').textContent=age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh');"));
ok('v2.2.37: home hero brand follows the app language',
  app.includes("<h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: search header follows the app language',
  app.includes("<div class=\"search-darkhead\"><h1>${age('ਗੁਰਬਾਣੀ ਸਾਂਝ','Gurbani Saanjh')}</h1>"));
ok('v2.2.37: no "Saanj" without H left in app.js',
  !/Saanj(?!h)/.test(app));
ok('v2.2.37: settings subtitle left alone (version line, not a brand)',
  app.includes("ਗੁਰਬਾਣੀ ਸਾਂਝ · v${APP_VERSION}"));
// (b) v2.2.40: the mic button ITSELF is the Stop sign — the separate Stop
// button (v2.2.37) is gone at Karamjit's request ("mic nu hi Stop sign bana
// de"). The v2.2.37 Stop-button assertions are superseded by these.
ok('v2.2.40: no separate Stop button anywhere (voiceStopBtn/askVoiceStopBtn gone)',
  !app.includes('voiceStopBtn') && !app.includes('askVoiceStopBtn') && !app.includes('gs-voice-stop'));
ok('v2.2.40: no gs-show Stop-button CSS left',
  !css.includes('.gs-voice-stop') && !css.includes('gs-show'));
ok('v2.2.40: setListeningUI swaps the mic icon to ⏹ while listening, 🎙 when idle',
  app.includes("b.textContent=on?'⏹':'🎙'") && app.includes("for(const id of ['voiceBtn','askVoiceBtn'])"));
ok('v2.2.40: listening mic looks like a Stop button (red bg + red ⏹, dark-mode variant)',
  css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{background:#fbe9e7;color:#b3261e;') &&
  css.includes('.dark #voiceBtn.gs-listening,.dark #askVoiceBtn.gs-listening{background:#4a2622;color:#f6c9c4;'));
ok('v2.2.40: mic tap stops while listening, starts while idle (no separate Stop wiring)',
  app.includes('if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(input);') &&
  app.includes('if(searchVoiceBusy||voiceListeningOn)stopVoiceSearch();else startVoiceSearch(qi)') &&
  !app.includes('vsb.onclick') && !app.includes('avs.onclick'));
ok('v2.2.40: mic buttons are never disabled (stays tappable as Stop)',
  !app.includes('if(btn)btn.disabled=true;') && !app.includes('if(btn)btn.disabled=false') &&
  !app.includes("const b=$('voiceBtn');if(b)b.disabled=false;") &&
  !app.includes("const a=$('askVoiceBtn');if(a)a.disabled=false;"));
ok('v2.2.37: stopVoiceSearch stops the mic without clearing the search',
  app.includes('function stopVoiceSearch(){resetVoiceNow();}'));
ok('v2.2.40: syncVoiceStopUI re-applies the mic-as-Stop state after every render (attach calls it)',
  app.includes('function syncVoiceStopUI(){') && app.includes('syncVoiceStopUI();') &&
  app.includes("b.textContent=voiceListeningOn?'⏹':'🎙'"));
// (c) Listen until Stop.
ok('v2.2.37: watchdog is the 2-minute per-segment backstop (120000)',
  app.includes('},120000);'));
ok('v2.2.37: watchdog re-armed per segment (native + web restarts)',
  (app.match(/armVoiceWatchdog\(btn\);/g) || []).length >= 3);
ok('v2.2.37: resetVoiceNow wakes the run loop at once (endSegment)',
  app.includes('if(run)run.endSegment();'));
ok('v2.2.37: web fallback recognizer stopped right away (voiceWebRec)',
  app.includes('let voiceWebRec=null;') && app.includes('voiceWebRec=rec;') && app.includes('if(voiceWebRec){try{voiceWebRec.stop()}catch{}voiceWebRec=null;}'));
ok('v2.2.37: X still clears search + stops mic (unchanged)',
  (() => { const l = app.split('\n').find(x => x.includes("searchClear')") && x.includes('clear.onclick')); return !!l && l.includes('resetVoiceNow()') && l.includes("input.value=''") && l.includes("innerHTML=''"); })());

// ---- v2.2.38: Daily Hukamnama card is more compact (Home) ----
ok('v2.2.38: hukam-hero padding is compact (8px 14px 7px)',
  css.includes('padding:8px 14px 7px;') && !css.includes('padding:12px 16px 11px;'));
ok('v2.2.38: hukam-hero margins tightened (8px 0 5px)',
  css.includes('.hukam-hero{display:block;width:100%;text-align:center;border:0;cursor:pointer;') &&
  /\.hukam-hero\{[^}]*margin:8px 0 5px;/.test(css));
ok('v2.2.38: hukam-hero title smaller (21px, was 26px)',
  css.includes('.hukam-hero-title{display:block;font-size:21px;') && !css.includes('.hukam-hero-title{display:block;font-size:26px;'));
ok('v2.2.38: hukam-hero kicker/date/meta tightened to 12px with 2px gaps',
  css.includes('.hukam-hero-kicker{display:block;font-size:12px;') && css.includes('margin-bottom:2px;}') &&
  css.includes('.hukam-hero-date{display:block;font-size:12px;') && css.includes('margin-top:2px;}') &&
  css.includes('.hukam-hero-meta{display:block;font-size:12px;'));
ok('v2.2.38: hukam-hero preview slimmer (16px, line-height 1.35, margin-top 5px)',
  css.includes('.hukam-hero-preview{display:block;font-size:16px;line-height:1.35;margin-top:5px;') &&
  !css.includes('.hukam-hero-preview{display:block;font-size:18px;line-height:1.5;margin-top:8px;'));
ok('v2.2.38: hukam-hero chevron smaller with tighter gap (16px, margin-top 3px)',
  css.includes('.hukam-hero-go{display:block;font-size:16px;line-height:1;color:#e6c25a;margin-top:3px;}'));
ok('v2.2.38: hukam-hero keeps its green-and-gold card (gradient + radius + shadow)',
  css.includes('background:linear-gradient(180deg,#14532d,#0b3d20);color:#fdf6e3;border-radius:14px;') &&
  css.includes('box-shadow:0 4px 14px rgba(11,61,32,.25);}'));
ok('v2.2.38: no Hukamnama card content removed (kicker/title/date/meta/preview/sub/chevron all rendered)',
  app.includes('hukam-hero-kicker') && app.includes('hukam-hero-title') && app.includes('hukam-hero-date') &&
  app.includes('hukam-hero-meta') && app.includes('hukam-hero-preview') && app.includes('hukam-hero-sub') && app.includes('hukam-hero-go'));
ok('v2.2.38: hero untouched (premium-hero still 274px)',
  css.includes(".premium-hero{position:relative;margin:0 -17px 10px;background:linear-gradient(180deg,#fffaf0,#fcf4e6 74%,#faf4e9);height:274px;"));
ok('v2.2.38: Continue card untouched (home-v10 min-height 65px)',
  css.includes('.home-v10 .continue-card{min-height:65px;'));
ok('v2.2.38: library tiles untouched (tile-3d still min-height 164px)',
  css.includes('.home-v7 .home-tile.tile-3d{min-height:164px;'));


// ---- 10. v2.2.39 AnmolUni font from iGranth + verse-text weight 400 ----
const anmol = path.join(fontsDir, 'AnmolUni.ttf');
const anmolBuf = fs.existsSync(anmol) ? fs.readFileSync(anmol) : Buffer.alloc(0);
ok('v239: AnmolUni.ttf bundled (143,256 bytes)', fs.existsSync(anmol) && fs.statSync(anmol).size === 143256);
ok('v239: AnmolUni.ttf is real TTF bytes (00 01 00 00 magic)',
  anmolBuf.length > 4 && anmolBuf[0] === 0x00 && anmolBuf[1] === 0x01 && anmolBuf[2] === 0x00 && anmolBuf[3] === 0x00);
ok('v239: AnmolUni.ttf is the verified file (MD5 pins the Unicode build)',
  crypto.createHash('md5').update(anmolBuf).digest('hex') === '1b7dab4c4e610f9fcaa89b00b3f7bde9');
ok('v239: @font-face for AnmolUni references the bundled file',
  css.includes('@font-face{font-family:"AnmolUni"') &&
  css.includes('url(assets/fonts/AnmolUni.ttf)') &&
  css.includes('format("truetype")'));
ok('v239: AnmolUni is first in all 15 Gurmukhi stacks',
  (css.match(/"AnmolUni","Noto Serif Gurmukhi","Tiro Gurmukhi"/g) || []).length === 15);
ok('v239: verse-text weight is 400, no 550 left (was rounding up to Bold 700)',
  !css.includes('font-weight:550') &&
  /\.verse-text\{[^}]*font-weight:400;/.test(css) &&
  /\.gs-book-page \.gs-book-flow\{[^}]*font-weight:400;/.test(css));
ok('v239: Ang + Bani reader verse-text rules are weight 400 too',
  /#verses \.gs-pankti \.verse-text\{[^}]*font-weight:400;/.test(css) &&
  /#verses \.gs-bani-para \.verse-text\{[^}]*font-weight:400;/.test(css));
ok('v239: Noto Serif + Tiro files still present as fallback (not deleted)',
  fs.existsSync(notoG) && fs.existsSync(notoL) && fs.existsSync(notoG7) && fs.existsSync(notoL7) &&
  fs.existsSync(tiroG) && fs.existsSync(tiroL));
ok('v239: heading/UI weights unchanged (brand still 750, hero h1 still 700)',
  /\.brand\{[^}]*font-weight:750;/.test(css) &&
  /\.hero h1\{[^}]*font-weight:700;/.test(css));
ok('v239: font size still 25px (his job via A-/slider/A+)',
  css.includes('--font:25px;'));

// ---- 11. v2.2.40 iGranth-style transliteration layout (Bani reader, translit ON only) ----
// The section carries .gs-translit-on only for a Bani reader with transliteration on.
ok('v240: Bani reader section gets gs-translit-on only when Bani + showTranslit',
  app.includes("kind==='bani'&&state.showTranslit?' gs-translit-on':''") &&
  !app.includes("gs-reader-sggs gs-translit-on"));
ok('v240: translit-ON Bani pankti is centred (beats the left-align rule)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}'));
ok('v240: translit-ON does NOT auto-blue the Bani Gurmukhi (v2.2.41 reverts the v2.2.40 misreading)',
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}') &&
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}'));
ok('v240: translit-ON Bani Roman is orange #f3541d, centred, no left border',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('v240: translit-ON Bani headings are orange #f3541d (the heading rule carries #verses, so it still wins over the Blue option)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-verse-heading .verse-text{color:#f3541d;}'));
ok('v240: translit-ON rules are Bani-only (no gs-reader-sggs translit-on rule anywhere)',
  !css.includes('.gs-reader-sggs.gs-translit-on') && !css.includes('.gs-sggs-pankti .verse-text{color:#0d0445'));
ok('v240: translit OFF unchanged — base roman still red #b3261e, base verse-text still --ink, Bani paras still centred',
  css.includes('.verse-roman { color: #b3261e; }') &&
  /\.verse-text\{[^}]*color:var\(--ink\);/.test(css) &&
  css.includes('.gs-bani-para{display:block!important;text-align:center!important;'));
ok('v240: Ang/SGGS reader still uses gs-gurmukhi-blue for its Gurmukhi (unchanged)',
  app.includes("gurmukhiClass:kind==='ang'?'gs-gurmukhi-blue':''") &&
  css.includes('.gs-gurmukhi-blue { color: #1a3fa0; font-weight: 700; }'));
ok('v240: Bani reader background still pure white, font still AnmolUni weight 400',
  css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }') &&
  !css.includes('font-weight:550'));

// ---- 12. v2.2.41 translit-ON pairs two-per-line, exactly like iGranth ----
// v2.2.40 centred each short "ਨਮਸਤੁੰ" line on its own row, wasting the
// sides of the page; Karamjit rejected it ("Follow this, don't use ur
// logic"). Now a pair group renders as ONE block even with transliteration
// ON: two Gurmukhi on one line, two Romans on the next line under the pair.
const jaapOn = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{translit:true}, foundIdx:-1});
const jaapOff41 = V7.baniFlowHTML(jaapLines.slice(2, 30), {vishraamOn:false, show:{}, foundIdx:-1});
const pairBlocksOn = jaapOn.match(/<div class="verse-block gs-bani-para gs-bani-pair"[^>]*>[\s\S]*?<\/div>(?=<div class="verse-block|$)/g) || [];
const stripTags = s => s.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
ok('v241: translit ON still renders the pairs as pair blocks (not per-pankti)',
  pairBlocksOn.length >= 8, `pairs=${pairBlocksOn.length}`);
ok('v241: translit ON first pair has TWO Gurmukhi on ONE line',
  pairBlocksOn.length > 0 && stripTags(pairBlocksOn[0]).includes('ਨਮਸਤ੍ਵੰ ਅਕਾਲੇ ॥ ਨਮਸਤ੍ਵੰ ਕ੍ਰਿਪਾਲੇ ॥'),
  pairBlocksOn.length ? stripTags(pairBlocksOn[0]).slice(0, 80) : 'no pair block');
ok('v241: translit ON first pair has TWO Romans on the NEXT line under the pair',
  pairBlocksOn.length > 0 && /<div class="verse-text"[^>]*>[\s\S]*?<\/div><div class="verse-layer verse-roman"[^>]*>namasatvan akaale \| namasatvan kripaale \|<\/div>/.test(pairBlocksOn[0]),
  pairBlocksOn.length ? stripTags(pairBlocksOn[0]).slice(0, 120) : 'no pair block');
ok('v241: translit ON second pair follows the same way',
  pairBlocksOn.length > 1 && stripTags(pairBlocksOn[1]).includes('ਨਮਸਤੰ ਅਰੂਪੇ ॥ ਨਮਸਤੰ ਅਨੂਪੇ ॥੨॥') &&
  stripTags(pairBlocksOn[1]).includes('namasatan aroope | namasatan anoope |2|'),
  pairBlocksOn.length > 1 ? stripTags(pairBlocksOn[1]).slice(0, 120) : 'no second pair');
ok('v241: translit ON has NO single-namastun pankti block left (one-per-line is gone)',
  ![...jaapOn.matchAll(/<div class="verse-block gs-pankti gs-bani-pankti"[^>]*><div class="verse-text"[^>]*>([\s\S]*?)<\/div>/g)]
    .some(m => /ਨਮਸ/.test(stripTags(m[1]))));
ok('v241: translit ON long non-pair lines still render one-per-line with their own Roman',
  [...jaapOn.matchAll(/<div class="verse-block gs-pankti gs-bani-pankti"[^>]*>([\s\S]*?)<\/div>(?=<div class="verse-block|$)/g)]
    .some(b => { const t = stripTags(b[1]); return t.includes('ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ') && t.includes('chakr chihan'); }));
ok('v241: translit OFF pairs unchanged (same pair blocks, no Roman)',
  (jaapOff41.match(/class="verse-block gs-bani-para gs-bani-pair"/g) || []).length >= 8 &&
  !jaapOff41.includes('verse-roman'));
ok('v241: pair blocks carry data-line (first item) so the search-jump still lands on them',
  (jaapOn.match(/gs-bani-para gs-bani-pair"[^>]*data-line="\d+"/g) || []).length >= 8);
ok('v241: app.js jump falls back to data-lines when data-line is not found',
  app.includes("find(el=>(el.getAttribute('data-lines')||'').split(',').includes(String(idx)))"));
ok('v241: CSS does NOT auto-blue the translit-ON pair Gurmukhi (revert of the v2.2.40 misreading)',
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}'));
ok('v241: CSS colours the translit-ON pair Roman orange #f3541d, centred, no left border',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pair .verse-roman{color:#f3541d;text-align:center;border-left:0;padding-left:0;margin-left:0;}'));
ok('v241: CSS centres the translit-ON pair block itself',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pair{text-align:center!important;}'));
ok('v241: v2.2.40 per-pankti translit centring/orange Roman unchanged (only the auto-blue is gone)',
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti{text-align:center!important;}') &&
  css.includes('html.reading-open .gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;') &&
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}'));

// ---- 13. v2.2.41 font-colour option (Blue/Black, whole reading, default Black) ----
// (a) Default Gurmukhi is black #202a26 even with translit ON.
ok('v241c: default Gurmukhi is black — base verse-text colour is var(--ink) and --ink is #202a26',
  /\.verse-text\{[^}]*color:var\(--ink\);/.test(css) && css.includes('--ink:#202a26'));
ok('v241c: no auto-blue rule anywhere for verse-text (translit ON cannot blue it by itself)',
  !css.includes('.gs-bani-pankti .verse-text{color:#0d0445;}') &&
  !css.includes('.gs-bani-pair .verse-text{color:#0d0445;}') &&
  !/\.gs-translit-on[^}]*\.verse-text\{color:#0d0445/.test(css));
// (b) Blue option applies #0d0445 to Bani AND Ang verse text and persists.
ok('v241c: Blue option CSS sets ALL verse-text (Bani + Ang) to #0d0445',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="blue"] .verse-text{color:#0d0445;}'));
ok('v241c: theme() applies the option as html[data-gurmukhi-color]',
  app.includes("html.dataset.gurmukhiColor=state.fontColor==='blue'?'blue':'black';"));
ok('v241c: fontColor defaults to black in state and is normalised to blue/black',
  app.includes("fontColor:'black'") && app.includes("state.fontColor=state.fontColor==='blue'?'blue':'black';"));
ok('v241c: fontColor survives backup/restore (in the permitted list)',
  app.includes("'baniTextSize','fontColor','layerScale','aiApiKey'"));
ok('v241c: Bani View Preferences has the Blue/Black choice next to the font size',
  app.includes("choice('fontColor',[['black',t('fontBlack')],['blue',t('fontBlue')]])"));
ok('v241c: font-colour labels exist in both languages',
  app.includes("fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ'") && app.includes("fontColor:'Text colour'") &&
  app.includes("fontBlack:'ਕਾਲਾ'") && app.includes("fontBlue:'ਨੀਲਾ'"));
// (c) Black option restores #202a26 (including the Ang reader, whose
// gs-gurmukhi-blue used to force #1a3fa0).
ok('v241c: Black option restores #202a26 on the Ang reader (overrides gs-gurmukhi-blue #1a3fa0)',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="black"] .gs-gurmukhi-blue{color:#202a26;}'));
ok('v241c: colour rules are scoped to the light theme (dark theme keeps readable text)',
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="blue"]') &&
  css.includes('html:not(.dark):not([data-nightmode="on"])[data-gurmukhi-color="black"]'));

// ---- 14. v2.2.42: mic auto-stop on result tap + Roman bigger + one layer-size control ----
// (a) Mic: tapping a search result (or a saved verse) to open it stops the
// mic FIRST — Karamjit's video showed the mic still listening after he came
// back from the reader, so he had to press Stop again himself.
ok('v242a: result tap (Ang) calls stopVoiceSearch() before openAng',
  /\[data-found-ang\],\[data-open-saved-ang\]\'\);if\(found\)\{stopVoiceSearch\(\);/.test(app));
ok('v242a: result tap (Bani) calls stopVoiceSearch() before openBani',
  /\[data-found-bani\],\[data-open-saved-bani\]\'\);if\(foundBani\)\{stopVoiceSearch\(\);/.test(app));
ok('v242a: stopVoiceSearch keeps the spoken words + results (it only resets the run)',
  app.includes('function stopVoiceSearch(){resetVoiceNow();}') &&
  !/function stopVoiceSearch\(\)\{[^}]*searchInput/.test(app));
ok('v242a: only verse-open taps stop the mic (save/bookmark taps do not call stopVoiceSearch)',
  !app.includes("data-save-hit") || !/data-save-hit[^}]*stopVoiceSearch/.test(app.split('[data-found-ang]')[0]));
// (b) Roman bigger via the single layer scale (Change 2 is now the control's default).
ok('v242b: .verse-layer uses the single --layer-scale (default .8), not the old fixed .62',
  css.includes('.verse-layer { font-size: calc(var(--font) * var(--layer-scale, .8));') &&
  !css.includes('.verse-layer { font-size: calc(var(--font) * .62);'));
ok('v242b: no fixed layer sizes left (.68/.74/.88/.95 banisize overrides are gone)',
  !/\.verse-layer[^}]*\* \.(68|74|88|95)\)/.test(css) && !css.includes('.verse-layer.verse-roman { font-size:'));
ok('v242b: Roman colour unchanged (base #b3261e; translit-ON Bani still orange #f3541d)',
  css.includes('.verse-roman { color: #b3261e; }') &&
  css.includes('.gs-reader-bani.gs-translit-on #verses .gs-bani-pankti .verse-roman{color:#f3541d;'));
ok('v242b: Gurmukhi verse size unchanged (still var(--font), weight 400, AnmolUni first)',
  /\.verse-text\{[^}]*font-size:var\(--font\);/.test(css) &&
  css.includes('font-family:"AnmolUni","Noto Serif Gurmukhi"'));
// (c) ONE size control for Roman + English + Punjabi (Change 3).
ok('v242c: layerScale state exists, default 0.8, clamped to 0.7–1.0',
  app.includes("layerScale:0.8") &&
  app.includes("state.layerScale=Math.min(1,Math.max(0.7,Number(state.layerScale)||0.8));"));
ok('v242c: theme() publishes the scale as --layer-scale',
  app.includes("html.style.setProperty('--layer-scale',String(state.layerScale));"));
ok('v242c: Bani View Preferences has ONE layer-size slider + A-/A+ next to the font size',
  app.includes('id="vpLayerSlider"') && app.includes('min="0.7" max="1" step="0.05"') &&
  app.includes('id="vpLayerMinus"') && app.includes('id="vpLayerPlus"') && app.includes('id="vpLayerValue"'));
ok('v242c: layer-size slider wiring updates state + theme + persists (mirrors the font slider)',
  app.includes('const setVpLayer=') && app.includes("ls.addEventListener('input',()=>setVpLayer(ls.value))") &&
  app.includes("lm.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)-0.05)") &&
  app.includes("lp.onclick=()=>setVpLayer((Number(state.layerScale)||0.8)+0.05)"));
ok('v242c: layer-size label exists in both languages',
  app.includes("layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ'") && app.includes("layerSize:'Roman + translation size'"));
ok('v242c: layerScale survives backup/restore (in the permitted list)',
  app.includes("'baniTextSize','fontColor','layerScale','aiApiKey'"));
ok('v242c: all three under-line layers share the ONE scale (no per-language size rule)',
  (() => { const cssNoHukam = css.replace(/\.hukam-verses[^{]*\{[^}]*\}/g, '');
    return !/\.verse-en\{[^}]*font-size/.test(cssNoHukam) && !/\.verse-pa\{[^}]*font-size/.test(cssNoHukam) &&
    css.includes('.verse-layer { font-size: calc(var(--font) * var(--layer-scale, .8));') &&
    css.includes('.verse-meaning{font-size:calc(var(--font)*var(--layer-scale,.8));'); })());
ok('v242c: Gurmukhi size is NOT affected by the layer control (verse-text has no layer-scale)',
  !/\.verse-text\{[^}]*layer-scale/.test(css));

// ---- 15. v2.2.43: Play Store build hides the AI settings; AI itself untouched ----
// The AI section lives in Bani View Preferences (viewprefsScreen), NOT in
// settingsHTML (reader settings) — gating the wrong screen was caught and fixed.
const bw = fs.readFileSync(path.join(ROOT, 'scripts/build-web.mjs'), 'utf8');
ok('v243: build-web.mjs reads GS_HIDE_AI_SETTINGS and writes hideAiSettings into GS_BUILD',
  bw.includes("process.env.GS_HIDE_AI_SETTINGS==='1'") && bw.includes('hideAiSettings') &&
  bw.includes('hideAiSettings})') && bw.includes('window.GS_BUILD='));
ok('v243: viewprefsScreen gates the AI section on window.GS_BUILD.hideAiSettings',
  app.includes('const hideAI=!!(window.GS_BUILD&&window.GS_BUILD.hideAiSettings);') &&
  app.includes('const aiSection=hideAI?\'\':`<div class="menu-group-label">AI</div>') &&
  app.includes('${aiSection}'));
ok('v243: AI heading occurs exactly once (inside aiSection only)',
  (app.match(/menu-group-label">AI/g) || []).length === 1);
ok('v243: aiKeyInput occurs exactly twice (aiSection + change handler), never in the main template',
  (app.match(/aiKeyInput/g) || []).length === 2);
ok('v243: aiSection lives in viewprefsScreen, not in settingsHTML (wrong-screen guard)',
  (() => { const vp = app.slice(app.indexOf('function viewprefsScreen(){'),
      app.indexOf('/* ---- Menu / daily ---- */'));
    const sh = app.slice(app.indexOf('function settingsHTML(){'),
      app.indexOf('function openSettings()'));
    return vp.includes('const aiSection=') && vp.includes('${aiSection}') &&
      !sh.includes('aiSection') && !sh.includes('hideAI'); })());
ok('v243: AI rows are only inside aiSection (the main return template has no AI inputs)',
  (() => { const vp = app.slice(app.indexOf('function viewprefsScreen(){'),
      app.indexOf('/* ---- Menu / daily ---- */'));
    const mainReturn = vp.slice(vp.indexOf('return `'));
    return !mainReturn.includes('aiKeyInput') && !mainReturn.includes('aiModelInput') &&
      !mainReturn.includes('aiAccessInput') && vp.includes('aiKeyInput'); })());
// Workflows live next to this repo (~/workspace/gurbani/), not inside the zip:
// in the clean room they are absent, so these two checks only run when present.
const aabPath = path.join(ROOT, '..', 'android-aab-v263.yml');
const apkPath = path.join(ROOT, '..', 'android-apk-1-v263.yml');
if (fs.existsSync(aabPath) && fs.existsSync(apkPath)) {
  const aab = fs.readFileSync(aabPath, 'utf8');
  const apk = fs.readFileSync(apkPath, 'utf8');
  ok('v243: AAB workflow sets GS_HIDE_AI_SETTINGS=1 on the build:web step (and never zipaligns)',
    aab.includes("GS_HIDE_AI_SETTINGS: '1'") && aab.includes('npm run build:web') &&
    aab.includes('bundleRelease') && !aab.includes('zipalign"'));
  ok('v243: APK workflow does NOT set the flag (APK build keeps the AI settings)',
    !apk.includes('GS_HIDE_AI_SETTINGS') && apk.includes('assembleRelease'));
} else {
  console.log('SKIP  workflow checks (android-aab-v263.yml / android-apk-1-v263.yml not in this tree)');
}
// (c) Ask / cloud AI logic unchanged.
ok('v243c: cloud AI still the default (endpoint falls back to AI_CLOUD_ENDPOINT)',
  app.includes("const AI_CLOUD_ENDPOINT='https://gurbani-ai.karmjguber.workers.dev';") &&
  app.includes("String(state.aiEndpoint||'').trim()||AI_CLOUD_ENDPOINT"));
ok('v243c: Ask screen + answer logic untouched',
  app.includes('function askScreen(){') && app.includes('function aiAnswerHTML(answer){') &&
  app.includes('function answerQuestion()'));
// ---- Runtime: render Bani View Preferences in a vm sandbox, both flag states ----
const vpSrc = app.slice(app.indexOf('function viewprefsScreen(){'),
  app.indexOf('/* ---- Menu / daily ---- */')).trim();
ok('v243r: viewprefsScreen source extractable', vpSrc.startsWith('function viewprefsScreen(){') && vpSrc.endsWith('}'));
const AI_IDS = ['aiKeyInput', 'aiApiEndpointInput', 'aiModelInput', 'aiEndpointInput', 'aiAccessInput'];
const runViewprefs = (hide) => {
  const sandbox = {
    window: hide === undefined ? {} : { GS_BUILD: { hideAiSettings: hide } },
    state: { tone: 0, theme: 'light', font: 25, uiScale: 1.12, raisedHeadings: true,
      lineLayout: 'compact', margin: 'normal', mode: 'scroll', pageTurnSpeed: 'slow',
      showTranslit: true, showEn: false, showPa: false, showArth: false, layerScale: 0.8,
      baniTextSize: 'normal', fontColor: 'black', nightMode: false,
      aiApiKey: '', aiApiEndpoint: '', aiModel: 'gemini-3.5-flash-lite', aiEndpoint: '', aiAccessToken: '' },
    t: (k) => ({ aiKey: 'AI API key', aiEndpoint: 'AI endpoint', aiModel: 'AI model' }[k] || k),
    age: (pa, en) => en,
    esc: (s) => String(s ?? ''),
    AI_DEFAULT_ENDPOINT: 'https://api.openai.com/v1/chat/completions',
  };
  vm.createContext(sandbox);
  return vm.runInContext(vpSrc + '\nviewprefsScreen();', sandbox);
};
const htmlHidden = runViewprefs(true);
const htmlShown = runViewprefs(false);
const htmlNoFlag = runViewprefs(undefined);
ok('v243r: flag ON — no AI heading in Bani View Preferences',
  !htmlHidden.includes('<div class="menu-group-label">AI</div>'));
ok('v243r: flag ON — none of the 5 AI inputs render',
  AI_IDS.every((id) => !htmlHidden.includes('id="' + id + '"')));
ok('v243r: flag ON — no AI text anywhere (key / endpoint / model / private server / access code)',
  !/AI API key|AI endpoint|AI model|Private AI server|AI access code/i.test(htmlHidden));
ok('v243r: flag ON — rest of the screen intact (Voice, mic test, font + layer sliders, no gap)',
  htmlHidden.includes('micTestStatus') && htmlHidden.includes('id="vpFontSlider"') &&
  htmlHidden.includes('id="vpLayerSlider"') && htmlHidden.includes('Voice') &&
  htmlHidden.trim().endsWith('</section>'));
ok('v243r: flag OFF — AI heading + all 5 AI inputs render',
  htmlShown.includes('<div class="menu-group-label">AI</div>') &&
  AI_IDS.every((id) => htmlShown.includes('id="' + id + '"')));
ok('v243r: flag OFF — AI section matches v2.2.42 (same 5 rows, same labels)',
  ['AI API key', 'AI endpoint', 'AI model', 'Private AI server', 'AI access code']
    .every((label) => htmlShown.includes(label)));
ok('v243r: flag ABSENT (no GS_BUILD) — AI section renders (APK default)',
  htmlNoFlag.includes('<div class="menu-group-label">AI</div>') &&
  AI_IDS.every((id) => htmlNoFlag.includes('id="' + id + '"')));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
