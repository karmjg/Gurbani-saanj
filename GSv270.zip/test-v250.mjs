/* Gurbani Saanj v2.2.30 — three changes.
 * 1. Hindi translation DELETED from the reading view: no Hindi toggle in
 *    Bani View Preferences, no Hindi layer under any verse (scroll AND
 *    page-turn), showHi gone from state/normalization/backup/layerOpts.
 *    Transliteration (Roman) is KEPT — it is what helps English readers.
 * 2. Search results show the English translation under the Gurmukhi line,
 *    so a person who searches in English can confirm it is the same line.
 *    Bani matches carry `en` through matchRows; SGGS matches get `en`
 *    from the Ang file via the fillRaagHeaders async-enrichment pattern.
 *    Display-only: matching/scoring unchanged, source labels unchanged.
 * 3. Bani View Preferences font size is now a slider (A- / range / A+,
 *    live px value) instead of fixed 18/24/30/36 buttons. Range 18-40,
 *    A± step 2, clamped; an existing saved size is shown, never reset.
 * Run: node test-v250.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// Brace-matched extraction of a function/block starting at `marker`.
function extractBlock(src, marker) {
  const i = src.indexOf(marker);
  if (i < 0) throw new Error('marker not found: ' + marker);
  const open = src.indexOf('{', i);
  let depth = 0;
  for (let j = open; j < src.length; j++) {
    const ch = src[j];
    if (ch === '{') depth++;
    else if (ch === '}') { depth--; if (depth === 0) return src.slice(i, j + 1); }
  }
  throw new Error('unbalanced: ' + marker);
}

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const ss = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
const rv = fs.readFileSync(path.join(ROOT, 'www/render-verses.js'), 'utf8');
const esc = s => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
ok('version.json is 2.2.30', vj.version === '2.2.30');
ok('package.json is 2.2.30', pj.version === '2.2.30');
ok('version notes mention all three v2.2.30 changes',
  vj.notes.includes('v2.2.30:') && vj.notes.includes('Hindi translation deleted')
  && vj.notes.includes('English translation under the Gurmukhi line')
  && vj.notes.includes('slider'), vj.notes.slice(-160));

// ---- 1. Change 1: Hindi deleted (static) ----
ok('no showHi anywhere in app.js', !app.includes('showHi'));
ok('no hiTrans anywhere in app.js', !app.includes('hiTrans'));
ok('no show.hi / verse-hi in app.js or render-verses.js',
  !app.includes('show.hi') && !rv.includes('show.hi') && !rv.includes('verse-hi') && !rv.includes("layer('hi'"));
ok('layerOpts() has no hi key', (() => {
  const code = extractBlock(app, 'function layerOpts()');
  const ctx = vm.createContext({ state: { showTranslit: true, showEn: true, showPa: true, showHi: true, showArth: true }, console });
  vm.runInContext(code + '\nthis.__lo = layerOpts();', ctx);
  const lo = ctx.__lo;
  return lo && !('hi' in lo) && lo.translit === true && lo.en === true && lo.pa === true && lo.arth === true;
})());
ok('importBackup permitted list has no showHi', !/permitted=\[[^\]]*showHi/.test(app));
ok('LAYER_SETTINGS + bools sets have no showHi',
  !app.includes("new Set(['showTranslit','showEn','showPa','showHi'") && !app.includes("'showHi','showArth','nightMode'"));

// ---- 1. Change 1: Hindi deleted (rendered — real verseHTML + baniFlowHTML) ----
const rvCtx = vm.createContext({ window: {}, console });
vm.runInContext(rv, rvCtx);
const VERSES = rvCtx.window.GS_VERSES;
const hiLine = { g: 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ ਤੁਧੁ ਬਿਨੁ ਖਰੀ ਨਿਮਾਣੀ ॥', roman: 'mil mere preetamaa jeeo tudh bin kharee nimaanee |', en: 'Meet me, O my Beloved; without You, I am totally miserable.', pa: 'ਹੇ ਮੇਰੇ ਪਿਆਰੇ ਪ੍ਰਭੂ! ਮੈਨੂੰ ਮਿਲ।', hi: 'मिल मेरे प्रीतम जीउ तुध बिन खरी निमाणी ॥' };
const vHtml = VERSES.verseHTML(hiLine, { idx: 33, kind: 'ang', show: { translit: true, en: true, pa: true, hi: true, arth: true }, arth: [{ word: 'ਪ੍ਰੀਤਮਾ', meaning: 'beloved' }], koshHas: () => false });
ok('(b) verse with a hi field + show.hi:true renders NO Hindi layer',
  !vHtml.includes('verse-hi') && !vHtml.includes('मिल मेरे') && !vHtml.includes('lang="hi"'), vHtml.slice(0, 200));
ok('(d) English, Punjabi, Transliteration and Arth layers still render',
  vHtml.includes('verse-roman') && vHtml.includes('verse-en') && vHtml.includes('verse-pa') && vHtml.includes('verse-arth'));
const paraHtml = VERSES.baniFlowHTML(
  [{ g: 'ਸੁਖਮਨੀ ਸੁਖ ਅੰਮ੍ਰਿਤ ਪ੍ਰਭ ਨਾਮੁ ॥', roman: 'sukhamanee sukh amrit prabh naam |', en: 'Sukhmani: the Peace of Mind, the Nectar of the Name of God.', pa: 'ਸੁਖਮਨੀ ਸੁਖ ਦਾ ਅੰਮ੍ਰਿਤ ਹੈ।', hi: 'सुखमनी सुख अमृत प्रभ नाम ॥' },
   { g: 'ਸੰਤ ਜਨਾ ਕੈ ਮਨਿ ਵਸੈ ॥', roman: 'sant janaa kai man vasai |', en: 'It abides in the minds of the Saints.', pa: 'ਸੰਤ ਜਨਾਂ ਦੇ ਮਨ ਵਿੱਚ ਵੱਸਦਾ ਹੈ।', hi: 'संत जना कै मनि वसै ॥' }],
  { show: { translit: true, en: true, pa: true, hi: true, arth: false }, koshHas: () => false, vishraamOn: false });
ok('(b) Bani paragraph flow renders NO Hindi layer either',
  !paraHtml.includes('verse-hi') && !paraHtml.includes('सुखमनी'), paraHtml.slice(0, 200));

// ---- 1. Change 1: no Hindi toggle in Bani View Preferences (real viewprefsScreen) ----
const vpCode = extractBlock(app, 'function viewprefsScreen()');
function runViewprefs(font) {
  const ctx = vm.createContext({
    state: { font, showTranslit: true, showEn: false, showPa: false, showArth: false, nightMode: false, baniTextSize: 'normal', aiApiKey: '', aiApiEndpoint: '', aiModel: 'gemini-3.5-flash-lite' },
    t: k => k, age: (p, e) => p, esc, AI_DEFAULT_ENDPOINT: 'https://api.openai.com/v1/chat/completions', console,
  });
  vm.runInContext(vpCode + '\nthis.__vp = viewprefsScreen();', ctx);
  return ctx.__vp;
}
const vp24 = runViewprefs(24);
ok('(a) Bani View Preferences has NO Hindi toggle',
  !vp24.includes('showHi') && !vp24.toLowerCase().includes('hindi') && !vp24.includes('hiTrans'));
ok('(a) Transliteration / English / Punjabi toggles still present',
  vp24.includes('showTranslit') && vp24.includes('showEn') && vp24.includes('showPa'));

// ---- 2. Change 2: English under search results (real search + real markup) ----
const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
const sggsIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
const sctx = vm.createContext({
  window: {}, console,
  fetch: async (url) => {
    if (String(url).includes('bani-search')) return { ok: true, json: async () => baniIdx };
    return { ok: true, json: async () => sggsIdx };
  },
});
vm.runInContext(ss, sctx);
const S = sctx.window.GS_SCRIPTURE_SEARCH;
await S.load();
const q = (query, mode = 'auto') => S.query(query, 40, mode);

// Real scriptureResultsMarkup in a vm (same pattern as test-v248).
const mStart = app.indexOf('function scriptureResultsMarkup');
const mEnd = app.indexOf('\n}\n', mStart) + 3;
const mctx = vm.createContext({ state: { lang: 'pa', savedVerses: [] }, age: (p, e) => p, esc, console });
vm.runInContext(app.slice(mStart, mEnd), mctx);
const markup = (arr, opts) => mctx.scriptureResultsMarkup(arr, opts);

// (e) Bani match carries en + renders it under the Gurmukhi line
let r = await q('ਸੁਖਮਨੀ ਸੁਖ ਅੰਮ੍ਰਿਤ ਪ੍ਰਭ ਨਾਮੁ');
const sukh = r.find(x => x.src === 'bani' && x.baniId === 112);
ok('(e) Bani match carries its English translation', !!sukh && typeof sukh.en === 'string' && sukh.en.length > 10, JSON.stringify(sukh && sukh.en));
const sukhRow = baniIdx.find(x => x[0] === 112 && x[1] === 18);
ok('(e) Bani match en equals the Bani file English', !!sukh && !!sukhRow && sukh.en === sukhRow[3], String(sukh && sukh.en));
const hSukh = markup([sukh], { save: true });
ok('(e) Bani result renders the English translation under the Gurmukhi line',
  hSukh.includes('gs-result-en') && hSukh.includes(esc(sukh.en))
  && hSukh.indexOf(esc(sukh.en)) > hSukh.indexOf(esc(sukh.g)), hSukh.slice(0, 300));

// (f) SGGS result: English comes from the Ang file via fillResultEn (real Ang file)
r = await q('ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ');
const sggs = r[0];
ok('(f) SGGS line still finds Ang 244 first', sggs && sggs.src === 'sggs' && sggs.ang === 244 && sggs.idx === 33, JSON.stringify(sggs));
const hSggs = markup([sggs], { save: true });
ok('(f) SGGS result renders an empty data-en-for span for async fill',
  hSggs.includes('data-en-for="244:33"') && hSggs.includes('gs-result-en'));
const ang244 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/244.json'), 'utf8'));
const realEn244 = String(ang244.lines[33].en || '').trim();
ok('(f) real Ang 244 line 33 has an English translation', realEn244.length > 10, realEn244.slice(0, 60));
// Drive the real fillResultEn in a vm with a fake DOM + fake GS_REMOTE.read.
const fillStart = app.indexOf('async function enFor(');
const fillEnd = app.indexOf('\n}\n', app.indexOf('function fillResultEn(')) + 3;
const fillCode = app.slice(app.indexOf('const angFileCache=new Map();'), fillEnd);
function makeSpan(enFor) {
  return { dataset: { enFor }, textContent: '', removed: false, remove() { this.removed = true; } };
}
const span244 = makeSpan('244:33');
const fctx = vm.createContext({
  window: { GS_REMOTE: { read: async (kind, n) => (kind === 'ang' && n === 244 ? ang244 : null) } },
  esc, age: (p, e) => p, console,
});
vm.runInContext(fillCode + '\nthis.__fill = fillResultEn; this.__enFor = enFor;', fctx);
const fakeScope = { querySelectorAll: (sel) => (sel === '[data-en-for]' ? [span244] : []) };
fctx.__fill(fakeScope);
await new Promise(res => setTimeout(res, 50));
ok('(f) fillResultEn fills the SGGS span with the real Ang-file English',
  span244.textContent === realEn244 && !span244.removed, JSON.stringify(span244.textContent.slice(0, 60)));

// (g) a line with no English translation renders nothing (no placeholder)
const noEnBani = { src: 'bani', baniId: 4, baniTitle: 'ਜਾਪੁ ਸਾਹਿਬ', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam', idx: 4, g: 'ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ਅਰੁ ਪਾਤਿ ਨਹਿਨ ਜਿਹ ॥', en: '' };
ok('(g) Bani match with no en renders NO English span (no placeholder)',
  !markup([noEnBani], { save: true }).includes('gs-result-en'));
const spanNoEn = makeSpan('999:0');
const fctx2 = vm.createContext({
  window: { GS_REMOTE: { read: async () => ({ lines: [{ g: 'xxx', en: '' }] }) } },
  esc, age: (p, e) => p, console,
});
vm.runInContext(fillCode + '\nthis.__fill = fillResultEn;', fctx2);
fctx2.__fill({ querySelectorAll: (sel) => (sel === '[data-en-for]' ? [spanNoEn] : []) });
await new Promise(res => setTimeout(res, 50));
ok('(g) SGGS line with no en has its empty span removed (no placeholder)',
  spanNoEn.removed === true && spanNoEn.textContent === '');

// (h) source label unchanged
const hJaap = markup([{ src: 'bani', baniId: 4, baniTitle: 'ਜਾਪੁ ਸਾਹਿਬ', titlePa: 'ਜਾਪੁ ਸਾਹਿਬ', titleEn: 'Jaap Sahib', group: 'dasam', idx: 4, g: 'ਚੱਕ੍ਰ ਚਿਹਨ ਅਰੁ ਬਰਨ ਜਾਤਿ ਅਰੁ ਪਾਤਿ ਨਹਿਨ ਜਿਹ ॥', en: 'I have no caste, no lineage...' }], { save: true });
ok('(h) Dasam result still labelled "Dasam Granth — Jaap Sahib"',
  hJaap.includes('Dasam Granth') && hJaap.includes('Jaap Sahib'));
ok('(h) SGGS result still shows "Ang 244"', hSggs.includes('ਅੰਗ 244') && hSggs.includes('data-found-ang="244"'));

// (i) search matching/scoring unchanged
r = await q('ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੇ');
ok('(i) off-word phrase still finds Ang 1285 first', r[0] && r[0].src === 'sggs' && r[0].ang === 1285, JSON.stringify(r[0]));
r = await q('1366');
ok('(i) "1366" still returns only SGGS Ang 1366', r.length > 0 && r.every(x => x.src === 'sggs' && x.ang === 1366), `got ${r.length}`);
r = await q('ਸਸਅਪਨ');
ok('(i) first-letter Bani search still works', r.some(x => x.src === 'bani' && x.baniId === 112 && x.idx === 18));
ok('(i) CSS for the English line exists', css.includes('.gs-result-en{display:block'));

// ---- 3. Change 3: font slider in Bani View Preferences ----
ok('(3a) fixed 18/24/30/36 font buttons are gone',
  !vp24.includes('data-setting="font"') && !vp24.includes('data-value="18"') && !vp24.includes('data-value="36"'));
ok('(3b) slider + A- / A+ + live px value are present',
  vp24.includes('id="vpFontSlider"') && vp24.includes('type="range"') && vp24.includes('min="18"') && vp24.includes('max="40"')
  && vp24.includes('id="vpFontMinus"') && vp24.includes('id="vpFontPlus"') && vp24.includes('id="vpFontValue"') && vp24.includes('24px'));
ok('(3e) an existing saved font of 30 shows as 30 on the slider (no reset)',
  (() => { const h = runViewprefs(30); return h.includes('value="30"') && h.includes('30px'); })());

// Drive the real attach() viewprefs wiring in a vm.
const attachBlock = extractBlock(app, "if(state.view==='viewprefs'){");
function runAttachWiring(startFont) {
  const slider = { value: String(startFont), handlers: {}, addEventListener(t, fn) { this.handlers[t] = fn; } };
  const valEl = { textContent: startFont + 'px' };
  const minus = {}, plus = {};
  const els = { vpFontSlider: slider, vpFontValue: valEl, vpFontMinus: minus, vpFontPlus: plus };
  const state = { font: startFont, view: 'viewprefs' };
  let themeFont = null, themeCalls = 0, persistCalls = 0;
  const ctx = vm.createContext({
    $: (id) => els[id] || null, state,
    theme: () => { themeCalls++; themeFont = state.font; },
    persist: () => { persistCalls++; },
    console,
  });
  vm.runInContext(attachBlock, ctx);
  return { slider, valEl, minus, plus, state, get themeFont() { return themeFont; }, get themeCalls() { return themeCalls; }, get persistCalls() { return persistCalls; } };
}
{
  const w = runAttachWiring(24);
  w.slider.value = '20';
  w.slider.handlers.input();
  ok('(3c) moving the slider to 20 sets state.font to 20', w.state.font === 20 && w.slider.value === 20 && w.valEl.textContent === '20px', `font=${w.state.font} value=${w.slider.value} label=${w.valEl.textContent}`);
  ok('(3c) theme() is called on slider move (live --font)', w.themeCalls > 0 && w.themeFont === 20 && w.persistCalls > 0);
}
{
  const w = runAttachWiring(24);
  w.plus.onclick();
  ok('(3d) A+ from 24 goes to 26', w.state.font === 26 && w.valEl.textContent === '26px', `font=${w.state.font}`);
  w.minus.onclick();
  ok('(3d) A- from 26 goes back to 24', w.state.font === 24);
  w.minus.onclick();
  ok('(3d) A- from 24 goes to 22', w.state.font === 22, `font=${w.state.font}`);
}
{
  const w = runAttachWiring(40);
  w.plus.onclick();
  ok('(3d) A+ clamps at 40', w.state.font === 40);
  const w2 = runAttachWiring(18);
  w2.minus.onclick();
  ok('(3d) A- clamps at 18', w2.state.font === 18);
}
// The real theme() applies state.font as --font.
{
  const themeCode = extractBlock(app, 'function theme(){');
  const props = {};
  const fakeHtml = {
    classList: { toggle() {} }, dataset: {}, lang: '',
    style: { setProperty(k, v) { props[k] = v; } },
  };
  const ctx = vm.createContext({
    document: { documentElement: fakeHtml, querySelector: () => null },
    state: { theme: 'light', lineLayout: 'compact', fontStyle: 'serif', margin: 'normal', raisedHeadings: true, nightMode: false, baniTextSize: 'normal', font: 20, aiFont: 18, uiScale: 1.12, tone: 0, lang: 'pa' },
    console,
  });
  vm.runInContext(themeCode + '\ntheme();', ctx);
  ok('(3c) real theme() sets --font to 20px when state.font is 20', props['--font'] === '20px', JSON.stringify(props['--font']));
}

// ---- 4. Regressions ----
ok('v2.2.29: no 60px top padding in any book rule', ![...css.matchAll(/[^{}]*\.gs-book-reading[^{}]*\{[^}]*\}/g)].some(m => m[0].includes('60px')));
ok('v2.2.29: book top is status-bar clearance max(safe-area,24px)+4px',
  css.includes('padding:calc(max(env(safe-area-inset-top, 0px), 24px) + 4px)'));
ok('v2.2.28: bani-search.json has 9,452 lines / 29 Banis',
  baniIdx.length === 9452 && new Set(baniIdx.map(r => r[0])).size === 29, `got ${baniIdx.length}`);
ok('v2.2.28: Dasam Banis are exactly 4,6,9,117,118,119,124',
  JSON.stringify([...new Set(baniIdx.filter(r => r[8] === 'dasam').map(r => r[0]))].sort((a, b) => a - b)) === JSON.stringify([4, 6, 9, 117, 118, 119, 124]));
ok('v2.2.27: scroll-direction bar logic kept', app.includes('barScrollDecision') && app.includes('onReaderScroll'));
ok('v2.2.27: scroll bar sits below status bar', css.includes('top: max(env(safe-area-inset-top, 0px), 24px)'));
ok('v2.2.26: Bani headings + viewport pinch-off + page-turn min-height',
  rv.includes('ਮਹਲਾ') && html.includes('user-scalable=no') && css.includes('.gs-book-reading{min-height:calc(100dvh - 122px)}'));
ok('v2.2.25: A+/A- row gone, document-level pinch kept',
  !app.includes('ai-zoom-row') && app.includes('setupPinchZoom'));
ok('v2.2.23: exactly one .ai-answer font-size and it is var(--ai-font,18px)',
  (() => {
    const rules = [...css.matchAll(/\.ai-answer\{[^}]*\}/g)].map(m => m[0]);
    const sizes = rules.flatMap(r => [...r.matchAll(/font-size:([^;}]*)/g)].map(m => m[1].trim()));
    return sizes.length === 1 && sizes[0] === 'var(--ai-font,18px)';
  })());
ok('v2.2.22: not-hearing status + X-restart kept',
  app.includes('noHeardTimer') && app.includes('ਮਾਈਕ ਸੁਣ ਨਹੀਂ ਰਿਹਾ') && app.includes('const p=resetVoiceNow()'));
ok('v2.2.20: guarded stop in resetVoiceNow kept',
  app.includes('run.started&&!run.stopped&&!run.safetyStopped'));
ok('v2.2.18: ai-verse highlight + pinch clamp kept',
  app.includes('ai-verse') && app.includes('Math.min(32,Math.max(14'));
ok('v2.2.15: AI language toggle kept', app.includes('data-ai-lang'));

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
