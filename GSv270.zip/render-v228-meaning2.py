#!/usr/bin/env python3
"""Meaning popup photo — exactly like the real app popup:
line + close X, Punjabi/English toggle, meaning right under it. No extras.
"""
import cairosvg, os

OUT = '/home/hatch/workspace/gurbani'
W, H = 780, 1688
PAPER = '#fcfbf8'; BG = '#eeeee9'; INK = '#202a26'; MUTED = '#65716a'
PRIMARY = '#234c40'; LINE = '#e6e9e4'; YELLOW = '#fff2a8'
SERIF = 'Noto Serif Gurmukhi'; SANS = 'Noto Sans Gurmukhi'
LATIN = 'Noto Sans'; SYM = 'DejaVu Sans'

def esc(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')

def text(x, y, s, size, fill=INK, family=SANS, weight='400', anchor='start'):
    return (f'<text x="{x}" y="{y}" font-family="{family}" font-size="{size}" '
            f'font-weight="{weight}" fill="{fill}" text-anchor="{anchor}">{esc(s)}</text>')

def tspans(x, y, parts, size, anchor='start'):
    inner = ''.join(f'<tspan font-family="{fam}" font-size="{size}" font-weight="{w}" fill="{f}">{esc(s)}</tspan>' for s, fam, w, f in parts)
    return f'<text x="{x}" y="{y}" text-anchor="{anchor}">{inner}</text>'

def rect(x, y, w, h, fill, rx=0, stroke=None, sw=1):
    st = f' stroke="{stroke}" stroke-width="{sw}"' if stroke else ''
    return f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"{st}/>'

s = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">',
     f'<rect width="{W}" height="{H}" fill="{BG}"/>',
     f'<rect x="0" y="0" width="{W}" height="{H}" fill="{PAPER}"/>']
# Ang-jump bar (reader)
s += [rect(0, 0, W, 108, PAPER, 0, LINE),
      f'<line x1="0" y1="108" x2="{W}" y2="108" stroke="{LINE}" stroke-width="2"/>',
      text(32, 68, 'ਅੰਗ', 30, INK, SANS, '700'),
      rect(118, 26, 150, 56, '#ffffff', 14, LINE, 2),
      text(193, 66, '205', 32, INK, LATIN, '400', 'middle'),
      rect(284, 22, 130, 64, PRIMARY, 18),
      tspans(349, 66, [('ਜਾਓ ', SANS, '650', '#ffffff'), ('›', SYM, '650', '#ffffff')], 28, 'middle'),
      text(W - 32, 68, 'Aa', 32, INK, LATIN, '400', 'end')]
# the tapped (highlighted) line
s.append(rect(24, 182, W - 48, 118, YELLOW, 16))
s.append(text(W / 2, 232, 'ਮਾਇਆ ਮੋਹਿ ਸਭੋ ਜਗੁ ਸੋਇਆ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, 282, 'ਇਹੁ ਭਰਮੁ ਕਹਹੁ ਕਿਉ ਜਾਈ ॥੧॥', 40, INK, SERIF, '550', 'middle'))
# popup card — exactly like the app: X, toggle, meaning only (no repeated line)
px, py, pw = 36, 360, W - 72
s.append(rect(px, py, pw, 380, '#ffffff', 36, LINE, 2))
# close X at top-right
s.append(text(px + pw - 40, py + 62, '×', 44, MUTED, SYM, '400', 'end'))
# toggle: Punjabi / English
s.append(rect(px + 36, py + 92, 110, 62, PRIMARY, 16))
s.append(text(px + 91, py + 133, 'ਪ', 32, '#ffffff', SANS, '700', 'middle'))
s.append(rect(px + 158, py + 92, 110, 62, '#edf3ed', 16))
s.append(text(px + 213, py + 133, 'EN', 28, PRIMARY, LATIN, '700', 'middle'))
# meaning right under the toggle
meaning = ['ਧਨ-ਦੌਲਤ ਦੀ ਮੁਹੱਬਤ ਅੰਦਰ ਸਾਰਾ', 'ਸੰਸਾਰ ਸੁੱਤਾ ਪਿਆ ਹੈ। ਦੱਸੋ! ਇਹ', 'ਸੰਦੇਹ ਕਿਸ ਤਰ੍ਹਾਂ ਦੂਰ ਹੋ ਸਕਦਾ ਹੈ?']
yy = py + 224
for line in meaning:
    s.append(text(px + 36, yy, line, 32, INK, SANS, '400'))
    yy += 52
# more verses below the popup
s.append(text(W / 2, py + 470, 'ਏਕਾ ਸੰਗਤਿ ਇਕਤੁ ਗ੍ਰਿਹਿ ਬਸਤੇ', 40, INK, SERIF, '550', 'middle'))
s.append(text(W / 2, py + 524, 'ਮਿਲਿ ਬਾਤ ਨ ਕਰਤੇ ਭਾਈ ॥', 40, INK, SERIF, '550', 'middle'))
s.append('</svg>')
cairosvg.svg2png(bytestring=''.join(s).encode('utf-8'), write_to=os.path.join(OUT, 'v228_preview_meaning.png'))
print('meaning v2 done')
