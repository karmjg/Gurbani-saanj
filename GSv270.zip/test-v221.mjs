/* Gurbani Saanjh v2.2.1/v2.2.2 verification suite (node, offline).
 * Run: node test-v221.mjs
 * Checks the Kobo-style Reading settings: Tone slider, pure-white Light theme,
 * font size slider, 3 Gurmukhi-safe fonts, margins -> reading width, persistence.
 * Follows the test-v220.mjs pattern (static assertions + vm sandbox, no jsdom).
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`PASS  ${name}`); }
  else { fail++; console.log(`FAIL  ${name} ${extra}`); }
};
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');
const app = read('www/app.js');
const css = read('www/styles.css');
const html = read('www/index.html');

// ---- Static: settings sheet contents ----
ok('tone slider in settings sheet', /id="toneSlider"/.test(app) && /class="[^"]*tone-slider[^"]*"/.test(app));
ok('tone sun icons present', /tone-sun dim/.test(app));
const themesDef = app.match(/const themes=\[([\s\S]*?)\];/);
const themeVals = themesDef ? [...themesDef[1].matchAll(/\['(light|sepia|dark|charcoal)'/g)].map(m => m[1]) : [];
ok('4 theme pills single-select', new Set(themeVals).size === 4, JSON.stringify(themeVals));
ok('light theme dot is pure white', !!themesDef && /\['light',t\('light'\),'#ffffff'\]/.test(themesDef[1]));
ok('font size slider present (18-40)', /id="fontSlider"/.test(app) && /min="18" max="40"/.test(app));
ok('3 font options (serif/sans/system)', /\['system',t\('sysFont'\)\]/.test(app));
ok('margins choice present', /choice\('margin',\[\['narrow',t\('narrow'\)\],\['normal',t\('normal'\)\],\['wide',t\('wide'\)\]\]\)/.test(app));
ok('tone wired to theme()+persist', /e\.target\.id==='toneSlider'\)\{state\.tone=Number\(e\.target\.value\);theme\(\);persist\(\)\}/.test(app));

// ---- Static: CSS ----
const lightRule = css.match(/html\[data-tone="light"\]\{([^}]*)\}/);
ok('light theme rule exists', !!lightRule);
ok('light background is pure white', !!lightRule && /--bg:#ffffff/.test(lightRule[1]) && /--paper:#ffffff/.test(lightRule[1]), lightRule ? lightRule[1].slice(0, 80) : '');
ok('tone overlay CSS', /#toneOverlay\{[^}]*pointer-events:none[^}]*z-index:55/.test(css));
ok('tone slider red accent', /\.tone-slider\{accent-color:#c0392b\}/.test(css));
ok('system font stack (no bundled fonts)', /html\[data-font="system"\][^{]*\{font-family:system-ui,-apple-system,"Noto Sans Gurmukhi"/.test(css));
ok('no @font-face bundled fonts', !/@font-face/.test(css));
ok('margins change reading width', /html\[data-margin="narrow"\]\{--reading-pad:10px;--read-width:700px\}/.test(css)
  && /html\[data-margin="normal"\]\{--reading-pad:20px;--read-width:630px\}/.test(css)
  && /html\[data-margin="wide"\]\{--reading-pad:34px;--read-width:520px\}/.test(css));

// ---- Static: state & persistence ----
ok('tone in BASE state', /baniTextSize:'normal',tone:0,/.test(app));
ok('tone sanitized 0-100', /state\.tone=Math\.min\(100,Math\.max\(0,Number\(state\.tone\)\|\|0\)\)/.test(app));
ok('tone in backup permitted keys', /'keyboardOn','tone'/.test(app) && !/'vishraams'/.test(app));
ok('fontStyle allows system', /\['serif','sans','system'\]\.includes\(state\.fontStyle\)/.test(app));
ok('toneOverlay div in index.html', /<div id="toneOverlay" aria-hidden="true"><\/div>/.test(html));
ok('theme-color meta is pure white', /<meta name="theme-color" content="#ffffff">/.test(html));

// ---- Functional: theme() in a vm sandbox with stub DOM ----
function makeDoc() {
  const props = {};
  const el = {
    dataset: {},
    style: { setProperty: (k, v) => { props[k] = String(v); }, getProperty: (k) => props[k] },
    classList: { _s: new Set(), toggle: function (c, f) { f ? this._s.add(c) : this._s.delete(c); }, contains: function (c) { return this._s.has(c); } },
  };
  const meta = { content: '', setAttribute: function (k, v) { this[k] = v; } };
  return { el, meta, props, document: { documentElement: el, querySelector: (s) => s.includes('theme-color') ? meta : null, lang: '' } };
}
const themeSrc = app.match(/function theme\(\)\{[\s\S]*?\n\}/);
ok('theme() extractable', !!themeSrc);
if (themeSrc) {
  for (const [tname, tval, toneIn, expOp, expMeta] of [
    ['light', 'light', 0, '0.000', '#ffffff'],
    ['sepia', 'sepia', 0, '0.000', '#f4eddf'],
    ['dark', 'dark', 50, '0.250', '#19221f'],
    ['charcoal', 'charcoal', 100, '0.500', '#19221f'],
  ]) {
    const { el, meta, props, document } = makeDoc();
    const sb = { document, state: { theme: tname, tone: toneIn, font: 24, uiScale: 1.12, lineLayout: 'compact', fontStyle: 'serif', margin: 'normal', raisedHeadings: true, nightMode: false, baniTextSize: 'normal', lang: 'pa' } };
    vm.createContext(sb);
    vm.runInContext(themeSrc[0] + '\ntheme();', sb);
    ok(`theme() ${tname}: dataset.tone`, el.dataset.tone === tval, `got ${el.dataset.tone}`);
    ok(`theme() ${tname}: --tone-opacity=${expOp}`, props['--tone-opacity'] === expOp, `got ${props['--tone-opacity']}`);
    ok(`theme() ${tname}: --font=24px`, props['--font'] === '24px');
    ok(`theme() ${tname}: meta theme-color`, meta.content === expMeta, `got ${meta.content}`);
    if (tname === 'dark') ok('theme() dark adds .dark class', el.classList.contains('dark'));
    if (tname === 'light') ok('theme() light has no .dark class', !el.classList.contains('dark'));
  }
  // font slider effect: state.font -> --font
  const { props, document } = makeDoc();
  const sb = { document, state: { theme: 'light', tone: 0, font: 32, uiScale: 1.12, lineLayout: 'compact', fontStyle: 'system', margin: 'wide', raisedHeadings: true, nightMode: false, baniTextSize: 'normal', lang: 'pa' } };
  vm.createContext(sb);
  vm.runInContext(themeSrc[0] + '\ntheme();', sb);
  ok('font slider changes --font', props['--font'] === '32px', `got ${props['--font']}`);
  ok('margin wide -> dataset.margin', sb.document.documentElement.dataset.margin === 'wide');
  ok('fontStyle system -> dataset.font', sb.document.documentElement.dataset.font === 'system');
}

// ---- Persistence round-trip (simulated reload) ----
{
  const store = {};
  const localStorage = { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); } };
  const saved = { theme: 'sepia', tone: 70, font: 30, fontStyle: 'system', margin: 'wide', meaningLang: 'en' };
  localStorage.setItem('gurbani-saanjh-trial-v1', JSON.stringify(saved));
  const reloaded = JSON.parse(localStorage.getItem('gurbani-saanjh-trial-v1'));
  ok('settings persist across reload', reloaded.tone === 70 && reloaded.theme === 'sepia' && reloaded.fontStyle === 'system' && reloaded.margin === 'wide');
  const BASEm = app.match(/tone:0,/);
  ok('tone default is 0 (off)', !!BASEm);
}

// ---- Version 2.2.1 everywhere ----
ok('version.json 2.2.1', JSON.parse(read('www/version.json')).version === '2.2.2');
ok('package.json 2.2.1', JSON.parse(read('package.json')).version === '2.2.2');
ok('native-build-config 2.2.2', /version:'2\.2\.2'/.test(read('www/native-build-config.js')));
ok('index.html app-version 2.2.2', /<meta name="app-version" content="2\.2\.2">/.test(html));
ok('CHANGELOG has v2.2.2', /^## v2\.2\.2/m.test(read('CHANGELOG.md')));

// ---- Existing features untouched ----
ok('vishraam toggle UI removed (v2.2.2)', !/vishraamSwitch/.test(app) && !/vishraam-switch-card/.test(app));
ok('layered toggles untouched', /showTranslit/.test(app) && /showArth/.test(app));
ok('Aa settings button still wired', /\$\('settingsBtn'\)\.onclick=openSettings/.test(app));

// ---- v2.2.2: visible word-meaning language toggle ----
ok('meaning language toggle in Reading settings', /choice\('meaningLang',\[\['pa','ਪੰਜਾਬੀ'\],\['en','English'\]\]\)/.test(app));
ok('meaningLang label (pa+en)', /ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ/.test(app) && /Meaning language/.test(app));
ok('meaningLang defaults to Punjabi', /meaningLang:'pa'/.test(app));
ok('tap-a-word popup uses meaningLang', /GS_KOSH\.lookup\(current,wantLang\)/.test(app) || /lookup\(current, ?state\.meaningLang\)/.test(app));

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail ? 1 : 0);
