# Android build instructions — v1.8.0

1. Upload `GS_v180_source.zip` to your repository root on `main` (do not unzip).
2. Edit **the workflow GitHub actually runs**: `.github/workflows/android-apk-1.yml`.
3. Set `zip='GS_v180_source.zip'` in **Extract Android app source ZIP**, then commit to `main`.
4. GitHub → Actions → the corresponding Build Gurbani Saanjh Android APK workflow → **Run workflow** (new run, not Re-run jobs).
5. Only a successful run will provide a signed `Gurbani_Saanjh_v1.8.0.apk` inside the artifact ZIP.

The workflow requires existing repo secrets `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, `ANDROID_KEY_PASSWORD`. **Never put the signing values in public source.**

Build-time BaniDB fetch needs internet only on the GitHub runner. A failure at `Build complete offline Gurbani library` indicates missing data or upstream API issues, not a phone problem; open that step and inspect its log. The build intentionally fails on missing scripture instead of silently claiming it is offline.

Install over the existing signed app using same application ID `com.gurbanisaanjh.app` and the original signing key. Test Ang 1, Ang 1430, Japji Sahib, one other Bani, search and bookmarked Shabad in **Airplane mode**, then test Page Turn speed in Settings. Ask Gurbani will show cited offline matches without an AI backend. Live AI requires separate setup.
