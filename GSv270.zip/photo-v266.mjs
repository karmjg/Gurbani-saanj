/* Gurbani Saanj v2.2.46 — photo proof (Playwright Chromium 1254, local HTTP).
 * Serves www/ over a local HTTP server, opens the app in a fresh profile
 * (945x2051), and captures 5 photos:
 *   v2.2.46-photo-kirtan-no-title.png — Kirtan Sohila (Nitnem): top bar
 *     shows "ਕੀਰਤਨ ਸੋਹਿਲਾ", manglacharan present, NO big title, verses
 *     start directly with "ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧ ॥"
 *   v2.2.46-photo-rakhia-no-title.png — Rakhia De Shabad (Nitnem): top bar
 *     shows "ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ", manglacharan present, NO big title, verses
 *     start directly with "ਸਿਰ ਮਸ੍ਤਕ ਰਖੵਾ..."
 *   v2.2.46-photo-japji-no-title.png — Japji Sahib (Nitnem): top bar shows
 *     "ਜਪੁਜੀ ਸਾਹਿਬ", manglacharan present, NO big title, verses start
 *     directly with the Mool Mantar. (Japji is the Nitnem Bani that HAD the
 *     title and now does not — the correct proof of the removal.)
 *   v2.2.46-photo-chaupai-no-title.png — Chaupai Sahib (Nitnem): top bar
 *     shows "ਚੌਪਈ ਸਾਹਿਬ", NO header div at all (its first line is its own
 *     manglacharan, so no header is rendered), NO big title, verses start
 *     directly with "ੴ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥".
 *   v2.2.46-photo-arril.png — Chaupai Sahib "ਅੜਿਲ ॥" (idx 111) CENTRED in
 *     the middle, like the other Chhand headings.
 * Also asserts in the live app: no h1.bani-title anywhere in the reader,
 * the .bani-header div still exists (manglacharan only) where a header is
 * rendered, the top bar still carries the Bani title, and the Arril heading
 * is centred. The top bar auto-hides while reading forward (v2.2.27), so
 * each no-title shot scrolls down and back up first to reveal it.
 * Run: node photo-v266.mjs  (from ~/workspace/gurbani/v231)
 * Photos land in ~/workspace/gurbani/. No debug/probe output in the app.
 */
import fs from 'node:fs';
import http from 'node:http';
import path from 'node:path';
import { chromium } from 'playwright-core';

const ROOT = '/home/hatch/workspace/gurbani/v231/www';
const OUT = '/home/hatch/workspace/gurbani';
const CHROME = '/home/hatch/.cache/ms-playwright/chromium-1254/chrome-linux64/chrome';
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.ttf': 'font/ttf', '.woff2': 'font/woff2', '.png': 'image/png', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/+/, '') || 'index.html';
  const f = path.join(ROOT, p);
  if (!f.startsWith(ROOT) || !fs.existsSync(f) || !fs.statSync(f).isFile()) { res.writeHead(404); res.end('nf'); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream' });
  fs.createReadStream(f).pipe(res);
});
await new Promise(r => server.listen(0, '127.0.0.1', r));
const port = server.address().port;
const base = `http://127.0.0.1:${port}/`;

let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const browser = await chromium.launch({ headless: true, executablePath: CHROME,
  args: ['--disable-dev-shm-usage'] }); // /dev/shm is only 794MB — without this the renderer crashes on this heavy page
const ctx = await browser.newContext({ viewport: { width: 945, height: 2051 }, deviceScaleFactor: 1 });
const page = await ctx.newPage();
page.on('pageerror', e => console.log('PAGEERROR', String(e).slice(0, 200)));
await page.goto(base, { waitUntil: 'load' });
await page.waitForTimeout(5000); // bootData + kosh load + first render + kosh re-render settle

// app.js is an IIFE, so go()/openBani() are NOT globals — navigate through
// the UI exactly as a user would: home tiles (data-home-id) + the Bani rows
// (data-remote-bani) + the browser Back button to leave a reader (popstate
// restores the view, like Android back). NEVER click [data-view="home"]
// while already on home: go('home') from home crashes the renderer.
const goNitnemFromHome = async () => {
  await page.evaluate(() => document.querySelector('[data-home-id="nitnem"]')?.click());
  await page.waitForTimeout(900);
};
const backToList = async () => {
  await page.goBack();
  await page.waitForTimeout(900);
};
const booted = await page.evaluate(() => !!document.querySelector('[data-home-id="nitnem"]'));
ok('photo: app booted, home tiles present', booted);
await goNitnemFromHome();

// The reader top bar auto-hides while reading forward (v2.2.27) — it pops
// out only when scrolling BACK to already-read content. Scroll down a bit,
// then back to the top, so the top bar (with the Bani name) is visible in
// the photo. Returns true when the bar is actually shown.
const revealTopbar = async () => {
  await page.evaluate(() => window.scrollTo({ top: 600, behavior: 'instant' }));
  await page.waitForTimeout(400);
  await page.evaluate(() => window.scrollTo({ top: 0, behavior: 'instant' }));
  await page.waitForTimeout(500);
  return page.evaluate(() => {
    const bar = document.querySelector('.gs-reading-topbar');
    return !!bar && !bar.classList.contains('gs-topbar-hidden');
  });
};
const checkReader = (titleNeedle, firstVerseNeedle) => page.evaluate(({ t, fv }) => {
  const topbar = document.querySelector('.gs-bani-topbar-title')?.textContent || '';
  const header = document.querySelector('.bani-header');
  const mang = document.querySelector('.bani-manglacharan')?.textContent || '';
  const verses = document.querySelector('#verses')?.textContent || '';
  return {
    topbarHasTitle: topbar.includes(t),
    topbar,
    headerExists: !!header,
    manglacharan: mang.includes('ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ') && mang.includes('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ'),
    noH1Title: !document.querySelector('h1.bani-title'),
    noBaniTitleClass: !document.querySelector('.bani-title'),
    firstVerse: verses.includes(fv),
  };
}, { t: titleNeedle, fv: firstVerseNeedle });
const assertReader = (name, r) => {
  ok(`photo: ${name} top bar shows the Bani title`, r.topbarHasTitle, JSON.stringify(r.topbar));
  ok(`photo: ${name} header div still exists (manglacharan only)`, r.headerExists);
  ok(`photo: ${name} manglacharan line present`, r.manglacharan);
  ok(`photo: ${name} has NO big title (no h1.bani-title)`, r.noH1Title && r.noBaniTitleClass);
  ok(`photo: ${name} verses start directly with the first line`, r.firstVerse);
};
const openNitnemBani = async (id) => {
  await page.evaluate((bid) => document.querySelector(`.nitnem-page [data-remote-bani="${bid}"]`).click(), id);
  await page.waitForTimeout(1200); // loadRemote fetch + render
};

// ---- Photo 1: Kirtan Sohila (Nitnem, id 23) ----
await openNitnemBani(23);
assertReader('Kirtan Sohila', await checkReader('ਕੀਰਤਨ ਸੋਹਿਲਾ', 'ਸੋਹਿਲਾ ਰਾਗੁ ਗਉੜੀ ਦੀਪਕੀ ਮਹਲਾ ੧'));
ok('photo: Kirtan Sohila top bar is VISIBLE in the shot (scroll-back reveals it)', await revealTopbar());
await page.screenshot({ path: path.join(OUT, 'v2.2.46-photo-kirtan-no-title.png') });
await backToList(); // back to the Nitnem screen

// ---- Photo 2: Rakhia De Shabad (Nitnem, id 130) ----
await openNitnemBani(130);
assertReader('Rakhia De Shabad', await checkReader('ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ', 'ਸਿਰ ਮਸ੍ਤਕ ਰਖੵਾ'));
ok('photo: Rakhia De Shabad top bar is VISIBLE in the shot (scroll-back reveals it)', await revealTopbar());
await page.screenshot({ path: path.join(OUT, 'v2.2.46-photo-rakhia-no-title.png') });
await backToList(); // back to the Nitnem screen

// ---- Photo 3: Japji Sahib (Nitnem, id 2) — the Nitnem Bani that HAD the title ----
// (Chaupai never rendered it: its first line is its own manglacharan.)
await openNitnemBani(2);
assertReader('Japji Sahib', await checkReader('ਜਪੁਜੀ ਸਾਹਿਬ', 'ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ'));
ok('photo: Japji Sahib top bar is VISIBLE in the shot (scroll-back reveals it)', await revealTopbar());
await page.screenshot({ path: path.join(OUT, 'v2.2.46-photo-japji-no-title.png') });
await backToList(); // back to the Nitnem screen

// ---- Photo 4: Chaupai Sahib (Nitnem, id 9) — no title, and the Arril heading ----
// Chaupai's first line IS its own manglacharan ("ੴ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥"),
// so baniHeaderBlock returns '' — no header div at all, no big title.
// Check: top bar title, NO .bani-header, NO h1.bani-title, first verse present.
await openNitnemBani(9);
const chaupaiTop = await page.evaluate(() => {
  const topbar = document.querySelector('.gs-bani-topbar-title')?.textContent || '';
  const verses = document.querySelector('#verses')?.textContent || '';
  return {
    topbarHasTitle: topbar.includes('ਚੌਪਈ'),
    noHeader: !document.querySelector('.bani-header'),
    noH1Title: !document.querySelector('h1.bani-title'),
    firstVerse: verses.includes('ੴ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ'),
  };
});
ok('photo: Chaupai Sahib top bar shows the Bani title', chaupaiTop.topbarHasTitle);
ok('photo: Chaupai Sahib has NO header div (own manglacharan, unchanged)', chaupaiTop.noHeader);
ok('photo: Chaupai Sahib has NO big title (no h1.bani-title)', chaupaiTop.noH1Title);
ok('photo: Chaupai Sahib verses start directly with "ੴ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥"', chaupaiTop.firstVerse);
ok('photo: Chaupai Sahib top bar is VISIBLE in the shot (scroll-back reveals it)', await revealTopbar());
await page.screenshot({ path: path.join(OUT, 'v2.2.46-photo-chaupai-no-title.png') });

// ---- Photo 5: Chaupai Sahib "ਅੜਿਲ ॥" (idx 111) CENTRED ----
// A heading is centred when its text box is centred in the viewport
// (its centre x is within 60px of the viewport centre) AND the computed
// text-align is center.
const scrollLineToMiddle = async (idx) => {
  await page.evaluate((i) => {
    const el = document.querySelector(`#verses [data-line="${i}"]`);
    if (el) el.scrollIntoView({ block: 'center', behavior: 'instant' });
  }, idx);
  await page.waitForTimeout(600);
};
const headingCentred = (idx) => page.evaluate((i) => {
  const el = document.querySelector(`#verses [data-line="${i}"]`);
  if (!el) return { found: false };
  const txt = el.querySelector('.verse-text');
  const r = txt.getBoundingClientRect();
  const vw = window.innerWidth;
  const centre = r.left + r.width / 2;
  return {
    found: true,
    text: txt.textContent.trim(),
    textAlign: getComputedStyle(txt).textAlign,
    headingClass: !!el.closest('.gs-verse-heading') || el.classList.contains('gs-verse-heading'),
    centreX: Math.round(centre), viewportCentre: Math.round(vw / 2),
    offBy: Math.round(Math.abs(centre - vw / 2)),
    visible: r.top > 0 && r.bottom < window.innerHeight,
  };
}, idx);
await scrollLineToMiddle(111);
const arril = await headingCentred(111);
ok('photo: Chaupai Arril (idx111) is a centred heading',
  arril.found && arril.text === 'ਅੜਿਲ ॥' && arril.textAlign === 'center' && arril.headingClass && arril.offBy <= 60 && arril.visible,
  JSON.stringify(arril));
await page.screenshot({ path: path.join(OUT, 'v2.2.46-photo-arril.png') });

await browser.close();
server.close();
console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
