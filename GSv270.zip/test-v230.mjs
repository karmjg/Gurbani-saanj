/* Gurbani Saanj v2.2.8 — functional checks (node, offline).
 *  1. Kirtan A-Z sort uses traditional Gurmukhi order (ਅ, ੲ, ਸ, ਹ, ਕ … ੜ),
 *     NOT Unicode code-point order (which would put ਸ near the end).
 *  2. verseHTML / baniFlowHTML mark the searched line with .gs-found.
 *  3. Line-meaning data (en/pa) exists for Ang + Bani lines.
 * Run: node test-v229.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- 1. Gurmukhi A-Z sort (extract the exact code from app.js) ----
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const m = app.match(/const GS_ALPHA='[^']+';\nconst gsAlphaKey=[^\n]+/);
ok('sort code present in app.js', !!m);
const sortSrc = m[0] + `
const rows=[{firstLine:'ਕਬੀਰ'},{firstLine:'ਸੋਚੈ'},{firstLine:'ਅੰਤਰਿ'},{firstLine:'ੜਾ'},{firstLine:'ਹੁਕਮਿ'},{firstLine:'ਜਪੁ'}];
rows.sort((a,b)=>{const ka=gsAlphaKey(a.firstLine),kb=gsAlphaKey(b.firstLine);return ka<kb?-1:ka>kb?1:0});
rows.map(r=>r.firstLine).join('|');`;
const sorted = vm.runInNewContext(sortSrc, {});
ok('A-Z order is ਅ, ਸ, ਹ, ਕ, ਜ … ੜ (traditional, not Unicode)',
  sorted === 'ਅੰਤਰਿ|ਸੋਚੈ|ਹੁਕਮਿ|ਕਬੀਰ|ਜਪੁ|ੜਾ', `got: ${sorted}`);

// ---- 2. found-line highlight in render-verses.js ----
const sb = { window: {}, console };
const load = rel => vm.runInNewContext(fs.readFileSync(path.join(ROOT, rel), 'utf8'), sb, { filename: rel });
load('www/render-verses.js');
const V = sb.window.GS_VERSES;
const line = { g: 'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥', en: 'Not by thinking', pa: 'ਸੋਚਣ ਨਾਲ ਨਹੀਂ', roman: 'Sochai soch na hovaee' };
const show = { translit: false, en: false, pa: false, hi: false, arth: false };
const plain = V.verseHTML(line, { idx: 3, kind: 'ang', show });
const found = V.verseHTML(line, { idx: 3, kind: 'ang', show, found: true });
ok('plain verse has no gs-found', !plain.includes('gs-found'));
ok('found verse has gs-found', found.includes('gs-found') && found.includes('data-line="3"'));
const baniLines = [
  { g: 'ਪਹਿਲੀ ਪੰਗਤੀ ॥੧॥', en: 'First', pa: 'ਪਹਿਲੀ' },
  { g: 'ਦੂਜੀ ਪੰਗਤੀ ॥', en: 'Second', pa: 'ਦੂਜੀ' },
  { g: 'ਤੀਜੀ ਪੰਗਤੀ ॥੨॥', en: 'Third', pa: 'ਤੀਜੀ' },
];
const flow = V.baniFlowHTML(baniLines, { show, foundIdx: 1 });
ok('bani flow highlights the group with the found line',
  (flow.match(/gs-found/g) || []).length === 1, `gs-found count: ${(flow.match(/gs-found/g) || []).length}`);
const flowNone = V.baniFlowHTML(baniLines, { show, foundIdx: -1 });
ok('bani flow with no found line has no gs-found', !flowNone.includes('gs-found'));

// ---- 3. line-meaning data coverage ----
const ang1 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1.json'), 'utf8'));
ok('Ang 1: every line has en + pa',
  ang1.lines.length > 0 && ang1.lines.every(l => (l.en || '').trim() && (l.pa || '').trim()));
const bani10 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani/10.json'), 'utf8'));
ok('Bani 10: every line has en + pa',
  bani10.lines.length > 0 && bani10.lines.every(l => (l.en || '').trim() && (l.pa || '').trim()));

// ---- 4. the new UI strings exist ----
const styles = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
ok('CSS has kb toggle / ang jump / found / line-meaning styles',
  ['.gs-kb-toggle', '.gs-ang-jump', '.verse-block.gs-found', '.gs-line-meaning-toggle'].every(s => styles.includes(s)));
ok('reader topbar z-index raised (pressable)', styles.includes('.gs-reading-topbar { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 6px 2px 10px; position: sticky; top: 0; background: var(--paper); z-index: 10; }'));

// ---- 5. Sahaj Paath separation: search/jump must NOT move the continue position ----
ok('displayAng helper exists', app.includes('function displayAng()'));
ok('Continue (navReader) opens Sahaj with the sahaj flag', app.includes('openAng(state.ang,true,true)'));
ok('loadRemote updates state.ang only when sahaj', app.includes('if(extra.sahaj){state.ang=Number(id)'));
ok('no unconditional state.ang overwrite on Ang open', !app.includes("if(kind==='ang'){state.ang=Number(id);if(!preserveProgress)"));
ok('capture() saves scroll only on the Sahaj Ang', app.includes('displayAng()!==state.ang'));
ok('search tap does not overwrite the Sahaj verse', !app.includes('state.verse=highlightLine'));
ok('swipe nav uses the displayed Ang and carries the Sahaj flag', app.includes('const cur=displayAng();openAng(cur+(dx<0?1:-1),false,cur===state.ang)'));
ok('found-line scroll prefers the highlighted line', app.includes('const target=highlightLine>=0?highlightLine:state.verse'));

// ---- 6. Ask retrieval: natural questions find their topic verses (real index) ----
const sb2 = {
  window: {},
  fetch: async () => ({ ok: true, json: async () => JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8')) }),
};
vm.runInNewContext(fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8'), sb2);
const S = sb2.window.GS_SCRIPTURE_SEARCH;
const punjabiAnxiety = await S.query('ਚਿੰਤਾ ਬਾਰੇ ਗੁਰਬਾਣੀ ਕੀ ਕਹਿੰਦੀ ਹੈ', 12);
ok('Punjabi anxiety question retrieves chinta verses', punjabiAnxiety.length > 0 && punjabiAnxiety.every(m => m.g.includes('ਚਿੰਤਾ')), `got ${punjabiAnxiety.length}`);
const guruQ = await S.query('ਗੁਰੂ ਕੀ ਹੈ', 12);
ok('"ਗੁਰੂ ਕੀ ਹੈ" retrieves Guru verses', guruQ.length > 0 && guruQ.every(m => m.g.includes('ਗੁਰੂ')), `got ${guruQ.length}`);
const bridgeChinta = await S.query('ਚਿੰਤਾ', 6, 'word');
ok('English bridge word retrieves chinta verses', bridgeChinta.length === 6 && bridgeChinta.every(m => m.g.includes('ਚਿੰਤਾ')));
const idxRows = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
ok('Ask index is SGGS only (Ang 1-1430, no other text)',
  idxRows.length > 60000 && idxRows.every(r => r[0] >= 1 && r[0] <= 1430));
const ang1429 = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/ang/1429.json'), 'utf8'));
ok('famous anxiety verse is in the corpus (Ang 1429)',
  ang1429.lines.some(l => (l.g || '').includes('ਚਿੰਤਾ ਤਾ ਕੀ ਕੀਜੀਐ')));

// ---- 7. Full-screen reader (#15): bar hidden on open, appears on scroll down ----
ok('readerBarHidden state exists', app.includes('let readerBarHidden=true, readerOpenedAt=0'));
ok('text open starts full-screen (bar hidden)', app.includes('remoteBusy=true;readerBarHidden=true;'));
ok('leaving the reader resets to hidden', app.includes("if(view!=='reader'){highlightLine=-1;readerBarHidden=true;}"));
ok('scroll down reveals the bar (past 60px, 800ms after open)', app.includes("readerBarHidden&&window.scrollY>60&&Date.now()-readerOpenedAt>800"));
ok('SGGS top bar honours the hidden state (scroll mode only)', app.includes("gs-ang-jump${barHidden?' gs-topbar-hidden':''}"));
ok('Bani/Kirtan top bars honour the hidden state (scroll mode only)', (app.match(/gs-reading-topbar\$\{barHidden\?' gs-topbar-hidden':''\}/g) || []).length >= 2);
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
ok('hidden top bar takes no space', css.includes('.gs-reading-topbar.gs-topbar-hidden{display:none}'));
ok('bar reveal slides in from the top', css.includes('@keyframes gs-bar-in'));

// ---- 8. iGranth first-letter rule: bare base letters, no matra on top ----
// From his video: he typed ਮਹਅਤਅ (ਐਸੇ/ਐਸਾ → ਅ) and iGranth found Ang 613.
ok('first-letter fold maps precomposed vowels to base (ਐ/ਏ/ਓ/ਔ→ਅ, ਈ→ਇ, ਊ→ਉ)',
  fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8').includes("foldFirst"));
const m1 = S.matchRows(idxRows, 'ਮਹਅਤਅ', 5, 'auto');
ok('iGranth demo query ਮਹਅਤਅ finds Ang 613 in auto mode',
  m1.length === 1 && m1[0].ang === 613 && m1[0].g.includes('ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ'));
ok('typing ਏ instead of ਐ also finds it (ਮਹਏਤਏ)',
  S.matchRows(idxRows, 'ਮਹਏਤਏ', 5, 'auto').some(r => r.ang === 613));
ok('typing ਐ also finds it (ਮਹਐਤਐ)',
  S.matchRows(idxRows, 'ਮਹਐਤਐ', 5, 'auto').some(r => r.ang === 613));
ok('full word search still works (ਮਾਧੋ)',
  S.matchRows(idxRows, 'ਮਾਧੋ', 5, 'auto').length > 0);

// ---- 9. English first-letter search: roman was missing from the index ----
ok('every search row carries roman transliteration (English search needs it)',
  idxRows.every(r => String(r[5] || '').trim().length > 0));
const mh = S.matchRows(idxRows, 'mhata', 5, 'auto');
ok('English first letters mhata find Ang 613 in auto mode',
  mh.length === 1 && mh[0].ang === 613 && mh[0].g.includes('ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ'));
ok('English first letters mhata find Ang 613 in roman mode',
  S.matchRows(idxRows, 'mhata', 5, 'roman').some(r => r.ang === 613));
ok('English first letters spaced (m h a t a) also find Ang 613',
  S.matchRows(idxRows, 'm h a t a', 5, 'auto').some(r => r.ang === 613));


// ---- 10. v2.2.9: page topbar, viewprefs font row, AI three-part format, Bani meanings ----
ok('page-mode SGGS/Bani reader includes the top bar (Aa reachable)',
  app.includes('gs-book-reading gs-has-topbar') && app.includes('${drawer}${head}<div class="gs-book-reference"'));
ok('page-mode Kirtan reader includes a top bar with Aa',
  app.includes('gs-book-reading gs-has-topbar') && app.includes('item.lines[0]?.g') && app.includes('data-action="open-viewprefs"'));
ok('top bar is never hidden in page mode (scroll-only hiding)',
  app.includes("const barHidden=readerBarHidden&&state.mode==='scroll'"));
ok('book stage fills the space below the top bar in page mode',
  styles.includes('.gs-book-reading.gs-has-topbar{display:flex;flex-direction:column}') && styles.includes('.gs-book-reading.gs-has-topbar .gs-book-stage{flex:1;min-height:0;height:auto}') && styles.includes('.gs-book-reading.gs-has-topbar .gs-book-reference{display:none}'));
ok('Bani View Preferences has a letter-size row (18/24/30/36)',
  app.includes("choice('font',[[18,'18'],[24,'24'],[30,'30'],[36,'36']])"));
ok('AI prompt (app) uses the three-part format with total essence',
  app.includes('Structure every answer in three parts') && app.includes('Quote 2-3 relevant Gurbani verses FIRST') && app.includes('total essence'));
const worker=fs.readFileSync(path.join(ROOT,'ai-server/cloudflare-worker.mjs'),'utf8');
ok('AI instructions (worker) use the three-part format with total essence',
  worker.includes('Structure every answer in three parts') && worker.includes('Quote 2-3 relevant Gurbani verses FIRST') && worker.includes('total essence'));
ok('version is 2.2.10 in package.json and version.json',
  JSON.parse(fs.readFileSync(path.join(ROOT,'package.json'),'utf8')).version==='2.2.10' && JSON.parse(fs.readFileSync(path.join(ROOT,'www/version.json'),'utf8')).version==='2.2.10');
// Bani translation coverage (Nitnem must give meanings)
const cov=id=>{const d=JSON.parse(fs.readFileSync(path.join(ROOT,`www/offline/bani/${id}.json`),'utf8'));const n=d.lines.length;return {n,en:d.lines.filter(l=>String(l.en||'').trim()).length,pa:d.lines.filter(l=>String(l.pa||'').trim()).length};};
const c2=cov(2),c4=cov(4),c6=cov(6),c9=cov(9),c10=cov(10),c21=cov(21),c23=cov(23);
ok('Nitnem meanings: Japji 385/385, Anand 210/210, Kirtan Sohila 54/54',
  c2.en===385&&c10.en===210&&c23.en===54);
ok('Nitnem meanings: Jaap >=790/801, Tav Prasad 43/43 en, Chaupai >=115/130 en, Rehras >=390/421 en',
  c4.en>=790&&c6.en===43&&c9.en>=115&&c21.en>=390);
ok('Nitnem meanings: Punjabi coverage matches (Jaap >=790, Rehras >=400)',
  c4.pa>=790&&c21.pa>=400);

// ---- 11. v2.2.10: Kirtan line-meaning fix + Gemini free-tier worker ----
ok('Kirtan taps read the on-screen lines (activeRemote) first',
  app.includes('const line=(activeRemote?.lines?.[idx])') && app.includes('v2.2.10: Kirtan taps read the lines actually on screen'));
ok('Kirtan taps no longer use the static 2-Shabad list as the first lookup',
  !app.includes("const line=kind==='kirtan'?(CONTENT.kirtan.find"));
ok('Worker uses Gemini free tier (no OpenAI)',
  worker.includes('GEMINI_API_KEY') && worker.includes('generativelanguage.googleapis.com') && worker.includes('gemini-2.0-flash') && !worker.includes('OPENAI') && !worker.includes('api.openai.com'));
ok('Worker keeps the three-part format + access-token + verse guards',
  worker.includes('Structure every answer in three parts') && worker.includes('GS_AI_ACCESS_TOKEN') && worker.includes('Question and verified source verses are required'));

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
