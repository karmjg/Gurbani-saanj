/* Gurbani Saanj v2.2.17 — voice smooth + Hukamnama hero smaller (node, offline).
 *  The voice state machine is run in a VM against a controllable fake native
 *  plugin, so the two real failure modes are proven, not just grepped:
 *   A. A second search after a clean first one hears its words (not cut off).
 *   B. A stale 'stopped' arriving before the new run starts is ignored.
 *   C. No redundant native.stop() after a clean end.
 *   D. Repeat taps skip available()/permission AND re-registering listeners.
 * Run: node test-v237.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.17', vj.version === '2.2.17');
ok('package.json is 2.2.17', pj.version === '2.2.17');

// ---- Voice source shape ----
ok('persistent listeners: voiceRun + ensureVoiceListeners', app.includes('let voiceRun=null;') && app.includes('async function ensureVoiceListeners(){'));
ok("stopped only ends a run after 'started' (sawStarted guard)", app.includes("else if(data?.status==='stopped'){run.stopped=true;if(run.sawStarted)run.finish()}"));
ok('resetVoiceNow clears voiceRun', app.includes('voiceRun=null;') && app.includes('function resetVoiceNow(){'));
ok('fast path skips available() when permission is cached', app.includes('if(!voicePermGranted){') && app.includes('const res=await Promise.all([native.available().catch(()=>null),native.checkPermissions().catch(()=>null)]);'));
ok('no per-run addListener registration left', !app.includes("const [hPartial,hListen]=await Promise.all(["));
ok('no redundant stop() after a clean end', app.includes('if(mine&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('superseded run never touches the recognizer', app.includes('const mine=voiceRun===run;'));

// ---- Hukamnama hero smaller ----
ok('hero padding smaller', css.includes('padding:12px 16px 11px;'));
ok('hero title smaller', css.includes('.hukam-hero-title{display:block;font-size:26px;'));
ok('hero preview smaller', css.includes('.hukam-hero-preview{display:block;font-size:18px;'));
ok('hero meta/kicker smaller', css.includes('.hukam-hero-kicker{display:block;font-size:13px;') && css.includes('.hukam-hero-meta{display:block;font-size:13px;'));

// ---- VM: run the real startVoiceSearch against a fake native plugin ----
const startMark = app.indexOf('let searchVoiceBusy=false;');
const endMark = app.indexOf('// Settings "Test microphone"');
const voiceSrc = app.slice(startMark, endMark);

// Fake DOM element.
function fakeEl(id) {
  return {
    id, disabled: false, value: '', textContent: '',
    classList: { _s: new Set(), toggle(c, on) { on ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } },
    dispatchEvent() {},
  };
}
const els = {};
const input = fakeEl('searchInput');
const calls = [];
let listeners = {};
const fakeNative = {
  available: async () => { calls.push('available'); return { available: true }; },
  checkPermissions: async () => { calls.push('checkPermissions'); return { speechRecognition: 'granted' }; },
  requestPermissions: async () => { calls.push('requestPermissions'); return { speechRecognition: 'granted' }; },
  addListener: async (ev, fn) => { calls.push('addListener:' + ev); (listeners[ev] = listeners[ev] || []).push(fn); return { remove: async () => { calls.push('remove:' + ev); } }; },
  start: async (o) => { calls.push('start:' + o.language); },
  stop: async () => { calls.push('stop'); },
};
const emit = (ev, data) => { for (const h of (listeners[ev] || []).slice()) { try { h(data); } catch (e) { console.error('listener threw', e); } } };
const ctx = vm.createContext({
  console,
  setTimeout, clearTimeout,
  Event: class { constructor(t, o) { this.type = t; } },
  window: { GS_SPEECH: fakeNative, GS_NATIVE_UPDATES: { isNative: true } },
  $: (id) => { if (id === 'searchInput') return input; return (els[id] = els[id] || fakeEl(id)); },
  age: (pa) => pa,
});
vm.runInContext(voiceSrc + '\n;globalThis.__voice={start:startVoiceSearch};', ctx);
const start = ctx.__voice.start;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// --- Scenario A: two sequential searches, both hear their words ---
const p1 = start(input);
await sleep(30); // let it reach start()
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p1;
ok('run 1 heard its words', input.value === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', `got ${JSON.stringify(input.value)}`);
ok('run 1: no redundant native.stop() after clean end', !calls.includes('stop'), `calls=${calls.join(',')}`);

input.value = '';
const p2 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p2;
ok('run 2 heard its words (not cut off)', input.value === 'ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ', `got ${JSON.stringify(input.value)}`);
ok('run 2: still no native.stop()', !calls.includes('stop'));
ok('listeners registered once, not per tap', calls.filter(c => c.startsWith('addListener')).length === 2, `addListener calls=${calls.filter(c => c.startsWith('addListener')).length}`);
ok('repeat tap skipped available() (fast path)', calls.filter(c => c === 'available').length === 1, `available calls=${calls.filter(c => c === 'available').length}`);

// --- Scenario B: stale 'stopped' before 'started' is ignored ---
input.value = '';
const p3 = start(input);
await sleep(30);
emit('listeningState', { status: 'stopped' }); // stale, from the previous run's teardown
await sleep(30);
ok('stale stopped did not kill the run', input.value === '' && !calls.includes('stop'));
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਲੱਖ ਖੁਸ਼ੀਆਂ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p3;
ok('run 3 completed after the stale stop was ignored', input.value === 'ਲੱਖ ਖੁਸ਼ੀਆਂ', `got ${JSON.stringify(input.value)}`);

// ---- Regression (grep) ----
ok('v2.2.16: original emoji mic kept', app.includes('Voice search\')}">🎙</button>') && app.includes('Ask by voice\')}">🎙</button>'));
ok('v2.2.16: professional green-ring listening kept', css.includes('#voiceBtn.gs-listening,#askVoiceBtn.gs-listening{box-shadow:0 0 0 2px #14532d'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'") && app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('v2.2.15: Hukamnama follows settings', !app.includes('en:true,pa:true'));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));
ok('v2.2.13: interleaved AI prompt intact', app.includes('one at a time: quote the first verse exactly as given'));
ok('v2.2.12: reader Ang-jump box passes sahaj=true', app.includes("openAng(Math.max(1,Math.min(1430,Number(aj.value)||displayAng())),false,true)"));
ok('v2.2.11: real AI error display intact', app.includes("entry.aiError=String(e&&e.message||e)"));
ok('v2.2.10: kirtan tap reads on-screen lines', app.includes('(activeRemote?.lines?.[idx]) ?? (kind==='));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
