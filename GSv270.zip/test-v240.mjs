/* Gurbani Saanj v2.2.20 — voice X-then-mic fix (node, offline).
 * The v2.2.17 fix was incomplete: it removed the redundant native.stop() from
 * the run's finally block, but resetVoiceNow() (tapping X to clear, or tapping
 * the mic while busy) still called stop() unconditionally — even on a
 * recognizer that had already stopped cleanly. That redundant stop leaves
 * the recognizer in a bad state where the NEXT start() listens but hears
 * nothing (the search box stays empty with "Listening..." showing), which is
 * exactly the 13-16s bug in the user's 2026-11-06 video.
 * Run: node test-v240.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
ok('version.json is 2.2.20', vj.version === '2.2.20');
ok('package.json is 2.2.20', pj.version === '2.2.20');

// ---- Voice source shape ----
ok('resetVoiceNow only stops a live run', app.includes('const run=voiceRun;') && app.includes('if(run&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('no unconditional stop() left in resetVoiceNow', !app.includes("voiceRun=null;\n try{const n=window.GS_SPEECH;if(n&&typeof n.stop==='function'){const p=n.stop();if(p&&p.catch)p.catch(()=>{})}}catch{}"));
ok('v2.2.17 finally guard intact', app.includes('if(mine&&run.started&&!run.stopped&&!run.safetyStopped){'));
ok('persistent listeners intact', app.includes('let voiceRun=null;') && app.includes('async function ensureVoiceListeners(){'));
ok("stale-stop guard intact", app.includes("else if(data?.status==='stopped'){run.stopped=true;if(run.sawStarted)run.finish()}"));

// ---- VM: run the real startVoiceSearch + resetVoiceNow against a fake native plugin ----
const startMark = app.indexOf('let searchVoiceBusy=false;');
const endMark = app.indexOf('// Settings "Test microphone"');
const voiceSrc = app.slice(startMark, endMark);

function fakeEl(id) {
  return {
    id, disabled: false, value: '', textContent: '',
    classList: { _s: new Set(), toggle(c, on) { on ? this._s.add(c) : this._s.delete(c); }, contains(c) { return this._s.has(c); } },
    dispatchEvent() {},
  };
}
const els = {};
const input = fakeEl('searchInput');
const calls = [];
let listeners = {};
const fakeNative = {
  available: async () => { calls.push('available'); return { available: true }; },
  checkPermissions: async () => { calls.push('checkPermissions'); return { speechRecognition: 'granted' }; },
  requestPermissions: async () => { calls.push('requestPermissions'); return { speechRecognition: 'granted' }; },
  addListener: async (ev, fn) => { calls.push('addListener:' + ev); (listeners[ev] = listeners[ev] || []).push(fn); return { remove: async () => { calls.push('remove:' + ev); } }; },
  start: async (o) => { calls.push('start:' + o.language); },
  stop: async () => { calls.push('stop'); },
};
const emit = (ev, data) => { for (const h of (listeners[ev] || []).slice()) { try { h(data); } catch (e) { console.error('listener threw', e); } } };
const ctx = vm.createContext({
  console,
  setTimeout, clearTimeout,
  Event: class { constructor(t, o) { this.type = t; } },
  window: { GS_SPEECH: fakeNative, GS_NATIVE_UPDATES: { isNative: true } },
  $: (id) => { if (id === 'searchInput') return input; return (els[id] = els[id] || fakeEl(id)); },
  age: (pa) => pa,
});
vm.runInContext(voiceSrc + '\n;globalThis.__voice={start:startVoiceSearch,reset:resetVoiceNow};', ctx);
const start = ctx.__voice.start;
const reset = ctx.__voice.reset;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const stopCount = () => calls.filter(c => c === 'stop').length;

// --- Scenario A: the video bug — run 1 clean, tap X, run 2 hears its words ---
const p1 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ ਪ੍ਰੀਤਮੁ ਪਿਆਰਾ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p1;
ok('A1 run 1 heard its words', input.value === 'ਕੋਈ ਆਣਿ ਮਿਲਾਵੈ ਮੇਰਾ ਪ੍ਰੀਤਮੁ ਪਿਆਰਾ', `got ${JSON.stringify(input.value)}`);
ok('A2 no stop() after clean run 1', stopCount() === 0, `stops=${stopCount()}`);

reset(); // user taps X to clear (the exact video step)
input.value = '';
ok('A3 X after a clean search did NOT call stop()', stopCount() === 0, `stops=${stopCount()} calls=${calls.join(',')}`);

const p2 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p2;
ok('A4 run 2 (after X) heard its words', input.value === 'ਮਿਲੁ ਮੇਰੇ ਪ੍ਰੀਤਮਾ ਜੀਉ', `got ${JSON.stringify(input.value)}`);
ok('A5 still zero stop() calls in the whole X-then-mic flow', stopCount() === 0, `stops=${stopCount()}`);

// --- Scenario B: mic tap while a run is live still cancels it (stop() IS called) ---
input.value = '';
const p3 = start(input);
await sleep(30);
emit('listeningState', { status: 'started' });
const p4 = start(input); // mic tap while busy -> resetVoiceNow() cancels the live run
await sleep(30);
ok('B1 mic-tap-while-busy stopped the live run', stopCount() === 1, `stops=${stopCount()}`);
emit('listeningState', { status: 'started' });
emit('partialResults', { matches: ['ਲੱਖ ਖੁਸ਼ੀਆਂ'] });
await sleep(10);
emit('listeningState', { status: 'stopped' });
await p4;
ok('B2 run 4 heard its words after the cancel', input.value === 'ਲੱਖ ਖੁਸ਼ੀਆਂ', `got ${JSON.stringify(input.value)}`);
// p3 is orphaned (its safety timer fires at 15s); do not await it.

// --- Scenario C: reset with no live run calls no stop() ---
const stopsBeforeC = stopCount();
reset();
ok('C1 reset with no live run calls no stop()', stopCount() === stopsBeforeC, `stops=${stopCount()}`);

// ---- Regression (grep) ----
const pt = fs.readFileSync(path.join(ROOT, 'www/page-turn.js'), 'utf8');
ok('v2.2.19: book centered + para flow intact', css.includes('.gs-book-page .gs-book-flow') && pt.includes('groupBaniParagraphs') && css.includes('text-align:center'));
ok('v2.2.19: refresh() re-measures', pt.includes('refresh(){') && pt.includes('document.fonts.ready'));
ok('v2.2.18: AI verse bold+highlight intact', app.includes('ai-verse') && css.includes('.ai-verse{'));
ok('v2.2.18: AI zoom intact', app.includes("data-ai-zoom") && app.includes('aiFont'));
ok('v2.2.17: Hukamnama hero smaller intact', css.includes('padding:12px 16px 11px;'));
ok('v2.2.16: original emoji mic kept', app.includes('Voice search\')}">🎙</button>') && app.includes('Ask by voice\')}">🎙</button>'));
ok('v2.2.15: AI language toggle intact', app.includes("aiLang:'pa'") && app.includes("Answer in ${state.aiLang==='en'?'English':'Punjabi'}"));
ok('v2.2.15: Hukamnama follows settings', !app.includes('en:true,pa:true'));
ok('v2.2.14: Hukamnama hero + screen intact', app.includes('function hukamHeroHTML(){') && app.includes('function hukamnamaScreen(){'));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
