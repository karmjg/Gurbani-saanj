## v2.2.19

- Page-turn now matches scroll: the book text is centered (it was left-aligned, stuck on one side), and Bani flows in paragraphs exactly like scroll mode — the verses of one paragraph run together and wrap, with the same minimal gap between paragraphs.
- Full page: the pagination re-measures once layout and fonts settle (requestAnimationFrame + document.fonts.ready), so a too-early measure can no longer leave the page half empty — the page fills fully like a book page.

## v2.2.18

- Scroll Bani paragraphs are tight: the paragraph gap and the line height inside a paragraph are now minimal, so the text flows closely like a book instead of spread out.
- AI answer verse lines are bold + highlighted: a quoted Gurmukhi verse (Ang number or verse-number marker) now shows as a bold highlighted line, standing out from the explanation.
- AI answer zoom: A-/A+ buttons on the Ask screen adjust the AI answer text size (14-32px, saved), so the letters can be made bigger.

## v2.2.17

- Voice search fully smooth: the two native listeners are registered once and stay alive (no per-tap delay); a 'stopped' event only ends a run after that run has seen 'started', so a stale stop from the previous run can no longer cut off the next search; and no redundant native.stop() after a clean end — that extra stop left the recognizer in a bad state where the next search listened but heard nothing for 15 seconds. Once permission is granted, the availability and permission checks are skipped too, so repeat taps go straight to listening.
- Hukamnama hero card on Home is smaller (tighter padding, smaller title and preview).

## v2.2.16

- Mic visual correction: the v2.2.15 green-circle + red-pulsing mic looked unprofessional, so the mic button is back to exactly how it was (the original mic emoji, no circle, no SVG). While listening it now shows a clean green ring around the button and the status line turns green — clear that the mic is waiting, without red or pulsing. The mic-fast changes (parallel checks, cached permission, parallel listeners), the AI language toggle, and the Hukamnama settings fix from v2.2.15 are unchanged.

## v2.2.15

- Hukamnama translations now follow the settings (fix): the forced English + Punjabi under every Hukamnama line is removed. The Hukamnama works exactly like the SGGS reader and Banis — translations show only when the user has them ON in Bani View Preferences; otherwise tap a line for the meaning popup. Nothing works differently here anymore.
- AI answer language: a Punjabi / English toggle on the Ask screen, next to Simple / Detailed / In depth (default Punjabi, saved on the phone). The AI answers in the chosen language. The quoted verses stay in Gurmukhi either way. Wired on both paths: the direct-key call sends "Answer in Punjabi/English", and the private-server call sends `language` (the worker already reads it).
- Mic button is bold and the listening state is obvious: the Search and Ask mic buttons are now solid green circles (46px) with a white microphone icon — no more faint emoji. While listening the button turns red and pulses, and the "Listening… speak now" line goes large and bold. The button no longer fades when listening.
- Mic starts faster: availability + permission checks now run in parallel instead of one after another, a permission granted once is cached and never re-checked (repeat taps go straight to listening), and the two native listeners register in parallel.

## v2.2.14

- Daily Hukamnama replaces the Daily Gurbani reading plan: no settings at all — no source, order, amount, time or on/off to configure. The old reading-plan screen and its Home tile are gone.
- Hukamnama at the top of the app: a green-and-gold hero card sits above everything on Home, showing today's date, Ang and Raag, and the first line of the Hukamnama. Tap it to open the full Hukamnama screen (same green/gold design: cream background, gold frame, large centred verses).
- Fresh every day, works offline: today's Hukamnama is fetched free from BaniDB (`/hukamnamas/{year}/{month}/{day}` — Sri Darbar Sahib) when the app is online and saved on the phone; if the fetch fails, the last saved Hukamnama is shown and marked as saved. Verified live: 2026-11-06 is Ang 864, Raag Gond, Guru Arjan Dev Ji, 19 verses.
- Same meanings as everywhere else: English and Punjabi translations are shown under every Hukamnama line, and tapping any line shows the whole line's meaning (Punjabi/English toggle), exactly like the SGGS reader and Banis.
- Morning notification: the app schedules one repeating notification every day at 6:00 AM local time (Capacitor local-notifications plugin, POST_NOTIFICATIONS permission). Tapping it opens the Hukamnama. Caveat: the notification firing on a real phone cannot be verified from here — it needs a next-morning check on the device.

## v2.2.13

- Ask AI answers are interleaved, verse by verse: the AI used to quote all 2-3 verses first and explain them afterwards. It now quotes one verse and explains it right away, then the next verse and its explanation, one at a time — then the reasoning and total essence (ਸਾਰ). Same wording in the app (OpenAI-key path) and the private AI server (ai-server/cloudflare-worker.mjs); the server needs a redeploy, the direct key path takes effect on the next question.
- AI answer at the top: the answer now renders right under the question, before the related Shabads list — before, the verses came first and the answer sat at the very bottom. The failure toast now says the related Shabads are shown below (it used to say above).
- Ask shows only the current question: old questions no longer pile up on the screen, newest at the bottom. Only the latest question is displayed; the older ones stay saved invisibly so the AI can still use the last 3 for follow-up context.

## v2.2.12

- Ang jump now sticks: typing an Ang in the reader's Ang-jump box (or the Library's Ang picker) used to change only the screen — the saved position stayed at the old Ang, so going back and tapping Read re-opened the old page (e.g. jump to 1366, go back, Read showed 478 again). The jump now saves the new Ang as your position. Search results, saved Shabads and Kirtan "view full Ang" still open as detours and do not move the position.
- Kirtan Shabad search, same as Guru Granth Sahib: the book search box now accepts bare first letters of the first line — type the first letter of each word (ਮਾਧੋ→ਮ, ਐਸੇ→ਅ), in Punjabi or in English (roman initials). Full-word typing still works as before (substring match). A query with a matra (ਸਤਿਗੁਰ, ਜਪੁ) is treated as a full word, never as initials, so it cannot flood the list.
- A-Z side index on the Kirtan book: a slim letter strip on the right edge of the list — Gurmukhi alphabet in traditional order when the app is in Punjabi, A–Z when it is in English. Tap a letter (or drag a finger down the strip) to jump to the first Shabad starting with that letter; the row flashes briefly so you can see where you landed. The strip hides while you are filtering with the search box. Vowel-initial Shabads (ਆ, ਏ, ਐ, ਓ, ਇ, ਉ, ਊ…) now sort with their base letter instead of at the very end of the list.

## v2.2.11

- AI prompt tightened (the examples rule): a short real-world example is allowed ONLY to illustrate what a quoted verse means — the example must flow from that verse itself, never from outside knowledge. Same wording in the app (OpenAI-key path) and the private AI server (ai-server/cloudflare-worker.mjs). The three-part answer format is unchanged: quote 2-3 verses first (Gurmukhi + Ang), explain each verse in plain words, then the reasoning and total essence (ਸਾਰ).
- AI server model corrected to gemini-3.8-flash: gemini-2.0-flash was shut down (June 1, 2026), so the Worker's default is now gemini-3.8-flash. AI_SERVER_SETUP.md updated to match. The direct path (API key in the app) already uses the model you type in Bani View Preferences › AI.
- AI failure now shows the real error: when the AI call fails, the app used to show only "AI answer failed" and hide the reason. It now shows the actual error — e.g. "AI API returned 400" (key not valid) or "AI API returned 404" (model not found) — in the popup and in red under the question, so the exact cause can be fixed instead of guessed. Same for the private-server path.
- Roman questions retrieve Gurmukhi verses: "Guru kon hai?" and "Who is Guru?" used to find no passage at all (the word "guru" is a search stopword, so the first search returned nothing). The English-topic bridge (guru → ਗੁਰੂ) now rescues them — "Guru kon hai?" returns 6 Guru verses (Ang 8, 17, 27, 29…), so the AI has verses to quote and explain. Verified for "Guru kon hai?", "Who is Guru?", "Hukam ki hai" and "ਗੁਰੂ ਕੀ ਹੈ".
- Everything in v2.2.10 is included (Kirtan Shabad line meanings, Gemini free tier).

## v2.2.10

- Kirtan Shabad line meanings fixed: tapping a word in a Kirtan Shabad now shows the whole line's meaning. Root cause: the tap looked the line up in a tiny static list (only 2 Shabads, 1 line each) instead of the Shabad actually on screen, so the popup never opened (87% of Kirtan lines were unreachable). The tap now reads the on-screen lines (enriched from the Ang files — 388/388 lines in the first 50 Shabads carry both English and Punjabi).
- AI server switched to Google Gemini free tier (no OpenAI, no payment): the Cloudflare Worker now calls Gemini (`gemini-2.0-flash`) with a free `GEMINI_API_KEY` from Google AI Studio. Same three-part answer format, same access-token guard, same verse-only rules. AI_SERVER_SETUP.md updated with the free setup steps.
- Everything in v2.2.9 is included (first-letter search, English first-letter search, meanings for all Nitnem + all Banis, page-mode top bar, viewprefs letter size, AI three-part format).

## v2.2.9
- First-letter search follows the iGranth rule: type only the bare first letter of each word — no matra on top. ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ is typed ਮਹਅਤਅ (ਐਸੇ/ਐਸਾ → ਅ) and finds Ang 613. Vowels fold to their base letter for first-letter matching (ਆ/ਏ/ਐ/ਓ/ਔ → ਅ, ਈ → ਇ, ਊ → ਉ), so typing ਏ or ਐ both work. Same procedure for any line, not just that one — ਸਸਨਹ finds ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ (Ang 1), ਸਨਕਪ finds ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ (Ang 1). Full-word and full-phrase search still work as before.
- English first-letter search: type M H A T A (ਮਾਧੋ → M, ਹਮ → H, ਐਸੇ → A, ਤੂ → T, ਐਸਾ → A) and the line comes up. The search index had no roman transliteration at all (60,555 rows, all empty) even though the Ang files carry it — the index was rebuilt from the Ang files with roman filled in. Works in auto and roman modes; ssnhjslv and snkp find Ang 1 the same way.
- Nitnem word-tap meanings: tapping any word in a Nitnem Bani now shows the whole line's meaning. The translations were missing from the bundle for Jaap Sahib, Tav Prasad Savaiye, Chaupai Sahib and parts of Rehras — they were added from BaniDB (same source and licence as the rest of the app). Coverage now: Japji 385/385, Jaap 798/801, Tav Prasad 43/43, Chaupai 125/130 (English), Anand 210/210, Rehras 405/421 (English), Kirtan Sohila 54/54. All 29 Banis together: 9,354/9,452 lines carry an English meaning and 9,289/9,452 a Punjabi one. Other Banis improved too (Akal Ustat 1069/1101, Chandi Di Var 360/389, Aarti 62/63, Aarti Longer 115/116, Ardas 19/27). A few lines in the longer Taksal recensions still have no BaniDB translation — those show "meaning not bundled yet" instead of a wrong meaning.
- Page-turn reader gets a top bar: in page mode the reader had no top bar at all, so font size and translation could not be reached. It now has the same bar as scroll mode — Ang-jump box + Aa for Guru Granth Sahib, drawer + title + Aa for Banis, title + Aa for Kirtan Shabads. The book page fills the remaining space. Scroll mode is unchanged (full-screen on open, bar appears on scroll down); the bar is never hidden in page mode.
- Bani View Preferences (Aa) gains a letter-size row (18 / 24 / 30 / 36) for all scripture text, next to the translation toggles — so font size and English translation are both one tap away from the reader in either mode.
- Ask Guru Granth Sahib answers in three parts: (1) quote 2-3 verses first, in Gurmukhi with Ang numbers; (2) explain each verse's meaning in plain words; (3) explain the reasoning behind them — the total essence (ਸਾਰ) of what Gurbani says on the topic, in plain direct words, like explaining to a friend. Same wording in the app (OpenAI key path) and the private AI server (ai-server/cloudflare-worker.mjs) — the server must be redeployed to pick up the new wording. All GGS-only guardrails stay: answers come only from the supplied verses, never from any other scripture, author, book, or general knowledge.
## v2.2.8
- Mic ready instantly: after a voice search, tapping X to clear it resets the microphone right away — no waiting. A mic tap while a run is stuck also starts fresh without waiting for the old run to stop.
- Search bar: the gear ⚙ button is replaced by a small Punjabi/English keyboard toggle (ਪੁ / EN). Punjabi shows the in-app Gurmukhi keyboard when the search box is tapped; English uses the phone's own keyboard. Old installs keep their previous keyboard choice.
- Search highlight: the found line is highlighted yellow in the reader (text stays black, also in Night Mode).
- Tighter paragraph/stanza spacing in the reader, especially Nitnem Banis (stanza gaps 1.55em → 0.6em, SGGS 0.95em → 0.45em).
- Reader top bar replaced: SGGS gets a sticky Ang-jump box (type the Ang number + Go); Banis get a sticky bar with the drawer button + title. The bar is always tappable; font/translation settings stay one tap away via Aa.
- Read tab removed from the bottom nav — SGGS is reached via Home → Guru Granth Sahib or Sahaj Paath.
- Ask Guru Granth Sahib: answer levels — Simple (explains like to a child), Detailed, In depth — and a plain AI online/offline status line. The app already supports OpenAI keys and the private AI server (AI_SERVER_SETUP.md); the level wording is now sent to both. The private server needs a redeploy to pick up the new level wording.
- Tap-a-word meaning removed: tapping any word in a line now shows the WHOLE LINE's meaning, with a Punjabi/English toggle in the popup. The toggle shows ਪ (the first letter of ਪੰਜਾਬੀ) for Punjabi and EN for English, side by side next to the meaning. The popup shows only the meaning — the line itself is not repeated inside it (it is already on the page, highlighted). Uses the bundled per-line translations (all Ang + Bani lines carry them).
- Translation settings in ONE place only: Transliteration, English/Punjabi Translation, Shabad Arth, Night Mode and Bani Text Size were removed from the Reading settings sheet — they live only in Bani View Preferences.
- Kirtan Shabads A–Z: the Kirtan book list is now sorted in traditional Gurmukhi order (ਅ … ੜ), so a Shabad is easy to find. The Bani catalog/drawer grouping (Mool Mantar / Nitnem / Banis) is unchanged.
- Ask answers quote the verse first: for every point the AI first quotes the relevant Gurbani pankti exactly as written, in Gurmukhi with its Ang number, and only then explains it in Punjabi or English. It never explains without quoting first.
- Ask answers come ONLY from Sri Guru Granth Sahib: the AI is instructed to use only the supplied verses — never any other scripture, author, book, or its own general knowledge. The offline search index holds only SGGS (60,555 lines, Ang 1–1430, nothing else). If the verses do not contain the answer, the AI says so plainly instead of guessing, and it is not called at all when no verse is found.
- Ask follows up: the last 3 questions and answers are sent with each new question, so follow-up questions ("and why is the Guru needed for me?") keep their context. Natural questions now retrieve their topic verses — English topics map to Gurmukhi (anxiety → ਚਿੰਤਾ, Guru → ਗੁਰੂ) and Punjabi questions find their word (e.g. "ਚਿੰਤਾ ਬਾਰੇ ਗੁਰਬਾਣੀ ਕੀ ਕਹਿੰਦੀ ਹੈ" now returns ਚਿੰਤਾ verses; before it returned none).
- Sahaj Paath stays put: opening an Ang from Search, voice search, the Ang picker, the Ang-jump box, a saved verse, or a Kirtan Shabad no longer moves the Sahaj Paath position. The Home "Continue Sehaj Paath" card always returns to where the continuous reading left off. Sahaj Paath advances only via Continue or by swiping / turning pages forward from the Sahaj Ang itself.
- Reader opens full-screen: when a page opens there is no top bar at all — just the text. Scrolling down brings the top bar in at the top (Ang jump + Aa), so font size, translation and Ang jump are reachable while reading deep in a page. The bar stays once it appears; leaving the reader resets it to full-screen for the next open.
## v2.2.2
- Removed the Vishraam / Pause toggle UI everywhere (home card, menu, Reading settings, Bani View Preferences). Gurbani text now renders plain black; the bundled vishraam.json data is kept for a possible future return.
- Removed the kosh orange word highlight in reading views (Bani scroll, Ang view). Tap-a-word still works on every word — meaning popup follows the visible "Word meaning language" setting.
- Removed the "Sundar Gutka / Bani collection" home card and every user-facing "Sundar Gutka" label/mention (drawer, library, catalog headings). Banis remain reachable via Nitnem and Anek Baniyaan. Source attribution kept in SOURCE_AND_LICENSE.md / README only.
- Nitnem Banis appear ONLY in the Nitnem section — removed from the Anek Baniyaan catalog.
- Anek Baniyaan catalog rebuilt: lists only the 22 Banis with full bundled offline text (was 75 name-only entries). No entry without text is shown anywhere.
- New visible Settings toggle: "Word meaning language — Punjabi / English" (ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ), default Punjabi. Tap-a-word meanings now follow it, with graceful fallback to the other language when a meaning is missing.
## v2.2.1
- Kobo-style Reading settings sheet (Aa button): new **Tone** slider (screen dimmer between sun icons, red slider), theme pills **Light / Sepia / Dark / Charcoal** — Light is now **pure white (#ffffff)** background by default (the old dusky tint is gone).
- Font choice is now 3 Gurmukhi-safe system stacks: Book (serif), Clean (sans), System — no bundled font files.
- Margins (Narrow/Comfort/Wide) now also change the reading column width (700/630/520px).
- All reading settings persist on-device and are included in backup/restore.
## v2.2.0
- Sundar Gutka (Damdami Taksal) Bani layout: light page, dark Gurmukhi body, pankti-per-line, traditional opening header (orange ੴ), centered titles and chhand headings, side drawer with Bani list, new ਸੁੰਦਰ ਗੁਟਕਾ menu (7 items; content-less entries show "coming soon", never fabricated scripture).
- Vishraam pause colors from bundled www/offline/vishraam.json: green = short pause, orange = long pause; marks never invented. Visible ਵਿਸ਼ਰਾਮ / Pause switch on home, reading settings, and Bani View Preferences; default ON.
- iGranth-style search: dark blue header, clear/mic/options buttons, icon row, built-in 35-key Gurmukhi first-letter keyboard, Raag/Mahla + Ang results.
- Layered verses (Gurmukhi / Transliteration / English / Punjabi / Shabad Arth) for Ang, Bani, and Kirtan; Bani View Preferences screen with Night Mode and Bani text size.
- Voice search root-caused and fixed: removed the hanging pre-listen language-list await, added 15s safety timer, clear runtime permission prompt, live heard-text in the search box, Web Speech API fallback, Settings "Test microphone". Workflow runs npm ci (bundled lockfile) before cap sync, fail-fasts on missing voice bundle, verifies RECORD_AUDIO.
- Tap-a-word: exact → kosh-stems.json longest-first → ॥।/numeral strip → silent give-up; kosh words render orange; fully offline.
- Kirtan Shabad book: browsable/searchable full Shabads from bundled Angs, layered display, "View full Ang" link.
- Ask Guru Granth Sahib: offline retrieval labeled "Related Shabads (offline)"; optional "AI answer" via user's API key (OpenAI-compatible, constrained system prompt with Ang citations); private-server hook kept.
- Honest caveats: not device-tested; Taksal text/vishraam exactness needs Karamjit's on-device review; vishraam.json, kosh-stems.json, kirtan-shabads.json ship via the data pipeline and are required by the workflow.
## v2.1.0
- Bundle the full offline library IN the source ZIP: 1,430 Angs (60,555 lines), prebuilt search index (60,555 rows), 29 Banis (7 Nitnem + 22 Sundar Gutka, 9,452 lines), 6,963-word Punjabi/English dictionary. Removed the GitHub build-time text download step; the workflow now requires the bundled offline files and fails fast if missing.
- Voice search: mic button wired to the real Capacitor speech-recognition plugin (Punjabi pa-IN preferred, English fallback); RECORD_AUDIO permission added.
- Tap-a-word: fully offline against the bundled dictionary, respects English/Punjabi setting, keeps dismiss controls.
- Text source switched from BaniDB-at-build to Shabad OS database (MIT); English glosses shabados/translation (CC BY-SA 4.0); word meanings Mahan Kosh multilingual dataset (CC BY 4.0). See SOURCE_AND_LICENSE.md.
- Removed the duplicate legacy workflow `.github/workflows/android-apk.yml`.
- Honest caveats: Damdami Taksal exactness of Bani texts needs the user's review; Vishraam data not bundled (toggle inert); English/Roman search modes have no data; not device-tested.
## v1.8.0
- Replace verse-by-verse blocks with **genuine continuous inline scripture text** when meanings are hidden; paragraph gaps no longer appear in Compact, Standard or Spacious.
- Apply spacing settings to actual line height, and preserve meanings under individual verses when enabled.
- Page-turn animation speed control: Slow (default 1250 ms), Normal (800 ms), Fast (430 ms).
- Build a search index from the offline 1,430-Ang source as part of the GitHub build, for quoted-text search and source references.
- Search the corpus from Kirtan Shabads, save verse references and open the original Ang, offline.
- Fix Ask Gurbani home card navigation; Ask Gurbani: referenced passage retrieval locally; optional secure AI server integration (requires separate server setup).
- Daily Gurbani preview now reads from actual bundled scripture, not a hardcoded sample.
- No MP3 or audio controls. Same Android application ID and signing process.

## v1.7.0
- 3D page-flip framework, Scroll/Page Turn choice, and initial continuous layout experimentation.
