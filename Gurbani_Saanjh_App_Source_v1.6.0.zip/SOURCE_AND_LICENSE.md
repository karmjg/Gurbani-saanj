# Scripture source and redistribution notice

BaniDB (Khalis Foundation), https://banidb.com and https://api.banidb.com/v2, original Gurmukhi text and accompanying metadata.

BaniDB data is offered under **Non-Profit Open Software License 3.0 (NPOSL-3.0)**. The private trial must be **non-profit**. Do not sell this APK, bundle it into an advertisement-supported product or otherwise distribute commercially without checking the licence and obtaining additional rights where necessary. Keep source credit visible in project documentation. Other third-party translation/teeka rights may differ; seek additional verification before public release.

The script downloads upstream data during GitHub Actions build; source ZIP deliberately ships without scripture dataset bytes. Text is bundled ONLY in the signed APK produced by successful CI and loaded offline. There is no audio in this version.

The base Gurmukhi scripture is not changed. Vishraam annotations are optional study aids and should not be assumed to be verified for every Pankti. Check traditional variants (especially Rehras Sahib) before relying on them.
