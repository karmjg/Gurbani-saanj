import fs from 'node:fs';
import path from 'node:path';
import { build } from 'esbuild';
const root = path.resolve(process.cwd());
// A repository with an older workflow only needs to change the source ZIP filename.
// The offline snapshot is built automatically before bundling web assets.
if (!fs.existsSync('www/offline/manifest.json')) {
  console.log('Offline corpus not present: generating the complete Ang and Bani snapshot.');
  await import('./bundle-offline.mjs');
}

const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const repository=process.env.GS_GITHUB_REPOSITORY||'';
const version=process.env.GS_APP_VERSION||pkg.version;
const repoPattern=/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
if(repository&&!repoPattern.test(repository))throw Error('Invalid GitHub repository identifier');
fs.writeFileSync('www/native-build-config.js',`window.GS_BUILD=${JSON.stringify({version,repo:repository})};\n`);
await build({entryPoints:['src/native-updates.js'],bundle:true,format:'iife',platform:'browser',target:['chrome110'],minify:true,outfile:'www/native-updates.js'});
console.log(`Bundled Android UI v${version}; update source: ${repository||'not configured'}`);
