/**
 * Gurbani Saanjh: BUILD-TIME ONLY scripture snapshot for a PRIVATE, NON-PROFIT trial.
 * No network calls from the installed Android reader.
 * BaniDB content is distributed under NPOSL 3.0; see SOURCE_AND_LICENSE.md.
 * Hard fail on missing Ang / missing selected Nitnem Bani, to avoid silently shipping fragments.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
const BASE='https://api.banidb.com/v2';
const OUT=path.resolve('www/offline');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const containsG=s=>/[\u0A00-\u0A7F]/u.test(String(s||''));
const asText=x=>typeof x==='string'?x:(x?.unicode||x?.gurmukhi||x?.text||x?.value||'');
function translation(v,lang){
 const t=v.steek||v.translation||v.verse?.translation||{};
 const d=t[lang] || (lang==='pu'?t.pa:undefined);
 if(typeof d==='string')return d;
 if(d && typeof d==='object'){
  for (const k of (lang==='pu'?['ss','ms','bdb','ft']:['bdb','ssk','ss','ms','ft'])){
   const q=d[k];if(typeof q==='string'&&q!=='None')return q;
   if(q && typeof q==='object' && typeof q.unicode==='string'&&q.unicode!=='None')return q.unicode;
  }
 }
 return '';
}
function roman(v){const t=v.translit||v.transliteration||v.roman||v.verse?.transliteration||{};
 if(typeof t==='string')return t;
 for(const x of [t.en, t.english, t.en?.bdb,t.en?.ss,t.en?.unicode,t.roman])if(typeof x==='string')return x;
 return '';
}
function pause(v){let o={};const arr=v.visraam?.sttm||v.verse?.visraam?.sttm||[];
 if(Array.isArray(arr))for(const item of arr){const i=Number(item.p);if(Number.isInteger(i)&&i>=0){if(item.t==='y')o[i]='short';else if(item.t==='v')o[i]='long'}}
 return o;
}
function normalize(raw){
 const arr=Array.isArray(raw)?raw:Array.isArray(raw?.verses)?raw.verses:Array.isArray(raw?.page)?raw.page:Array.isArray(raw?.data?.verses)?raw.data.verses:Array.isArray(raw?.data)?raw.data:Array.isArray(raw?.shabads)?raw.shabads.flatMap(x=>x.verses||[]):[];
 return arr.map((item,i)=>{
  const v=item.line||item;
  const g=asText(typeof v.verse==='string'?v.verse:v.verse?.unicode||v.verse?.gurmukhi||v.unicode||v.gurmukhi||'').trim();
  return {id:String(v.verse_id||v.verseId||v.id||i),g,roman:roman(v),en:translation(v,'en'),pa:translation(v,'pu'),vishraam:pause(v)};
 }).filter(x=>x.g&&containsG(x.g));
}
async function request(uri){
 let last;
 for(let n=1;n<=7;n++){
  const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),45000);
  try{const resp=await fetch(BASE+uri,{signal:ctrl.signal,headers:{Accept:'application/json','User-Agent':'Gurbani-Saanjh-Private-Trial/1.6'}});
   if(!resp.ok)throw Error(`HTTP ${resp.status}`);
   return await resp.json();
  }catch(e){last=e;if(n<7)await sleep(Math.min(20000,(n*n*500)+Math.floor(Math.random()*800)))}
  finally{clearTimeout(timer)}
 }
 throw Error(`BaniDB ${uri} unavailable after retries: ${last}`);
}
function index(raw){
 // BaniDB /banis returns a dictionary keyed by ID (see official banidb.py examples).
 // Some deployments also return an array or a nested `banis` / `data` field.
 const data=raw?.banis||raw?.data||raw;
 const entries=Array.isArray(data)?data.map(x=>[String(x.baniID??x.baniId??x.id??''),x]):Object.entries(data||{});
 return entries.map(([key,x])=>({id:Number(x.baniID??x.baniId??x.id??key),titlePa:String(x.gurmukhiUni||x.unicodeBaniName||x.gurmukhi||x.titlePa||x.unicode||''),titleEn:String(x.baniName||x.name||x.titleEn||x.transliterations?.en||x.transliterations?.english||x.english||'')})).filter(x=>Number.isInteger(x.id)&&x.id>0&&(x.titlePa||x.titleEn));
}
async function save(kind,id,lines){await fs.mkdir(path.join(OUT,kind),{recursive:true});await fs.writeFile(path.join(OUT,kind,`${id}.json`),JSON.stringify({lines,origin:`${BASE}/${kind==='ang'?'angs/'+id+'/G':'banis/'+id}`,fetchedAt:new Date().toISOString()}));}
async function pool(items,limit,fn){let next=0,errors=[];await Promise.all(Array.from({length:limit},async()=>{while(next<items.length){const item=items[next++];try{await fn(item)}catch(e){errors.push(`${item}: ${e.message}`)}}}));if(errors.length)throw Error(`${errors.length} scripture requests failed:\n${errors.slice(0,20).join('\n')}`)}
async function main(){
 await fs.rm(OUT,{recursive:true,force:true});await fs.mkdir(OUT,{recursive:true});
 const all=index(await request('/banis'));
 if(all.length<20)throw Error(`Unexpected Bani index count (${all.length}); refusing incomplete APK.`);
 const ids=[...new Set(all.map(x=>x.id))];
 // The seven Nitnem IDs already present in the application must exist in this snapshot.
 const nitnem=[2,4,6,9,10,21,23];for(const id of nitnem)if(!ids.includes(id))throw Error(`Nitnem Bani ID ${id} missing from source list`);
 const concurrency=Math.min(10,Math.max(1,Number(process.env.GS_FETCH_CONCURRENCY)||6));
 console.log(`Downloading all 1,430 SGGS Angs and ${ids.length} available Sundar Gutka Banis. Concurrency ${concurrency}`);
 let angTotal=0,baniTotal=0;
 await pool(Array.from({length:1430},(_,i)=>i+1),concurrency,async id=>{const lines=normalize(await request(`/angs/${id}/G`));if(!lines.length)throw Error('no Gurmukhi lines returned'); await save('ang',id,lines);angTotal++;if(angTotal%100===0)console.log(`Angs ${angTotal}/1430`)});
 await pool(ids,concurrency,async id=>{const lines=normalize(await request(`/banis/${id}`));if(!lines.length)throw Error('no Gurmukhi lines returned');await save('bani',id,lines);baniTotal++});
 for(const id of nitnem){const x=JSON.parse(await fs.readFile(path.join(OUT,'bani',`${id}.json`),'utf8'));if(!x.lines.length)throw Error(`Nitnem ${id} incomplete`)}
 const manifest={source:'BaniDB',license:'NPOSL-3.0',licenseUrl:'https://banidb.com',version:'1.6.0',angCount:angTotal,baniCount:baniTotal,banis:all.filter(x=>ids.includes(x.id)),builtAt:new Date().toISOString()};
 await fs.writeFile(path.join(OUT,'manifest.json'),JSON.stringify(manifest));
 await fs.copyFile('SOURCE_AND_LICENSE.md',path.join(OUT,'SOURCE_AND_LICENSE.md'));
 console.log(`SUCCESS: ${angTotal} / 1430 Angs, ${baniTotal} Sundar Gutka Banis packaged for offline first-launch reading.`);
}
if(process.argv.includes('--fixture')){
 const example={verses:[{verse_id:1,verse:'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ॥',steek:{en:{bdb:'One creator.'},pu:{ss:{unicode:'ਇੱਕ ਪ੍ਰਭੂ ਹੈ।'}}},translit:{en:'Ik Oankaar Sat Naam'}}]};
 const names=index({'1':{gurmukhiUni:'ਗੁਰ ਮੰਤ੍ਰ',transliterations:{en:'gur mantar'}},'2':{gurmukhiUni:'ਜਪੁਜੀ ਸਾਹਿਬ',transliterations:{en:'japujee saahib'}}});
 const lines=normalize(example);if(names.length!==2||names[1].id!==2||lines.length!==1||!lines[0].g.includes('ੴ')||lines[0].en!=='One creator.'||lines[0].pa!=='ਇੱਕ ਪ੍ਰਭੂ ਹੈ।'||!lines[0].roman)throw Error('BaniDB fixture failed');
 console.log('Offline importer fixture passed');
}else await main().catch(e=>{console.error(e);process.exit(1)});
