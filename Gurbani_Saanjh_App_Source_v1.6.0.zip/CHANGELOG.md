# v1.6.0 — Offline library (private, non-profit trial)
- Installer builds offline scripture snapshot of all 1,430 Sri Guru Granth Sahib Ji Angs from BaniDB, plus every Bani that BaniDB Sundar Gutka currently lists.
- Build requires all Angs and all listed Banis. Missing texts block release.
- Offline reading from first launch; no API calls required on Samsung.
- Compact, Standard, Spacious line spacing preserved, Compact default.
- Bani catalogue titles retained, with unavailable special editions not falsely represented as full text.
- Removed audio/MP3 import; postponed to later release.
- Source attribution and non-profit licensing clarified.
