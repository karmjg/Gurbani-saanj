window.GS_BUILD={"version":"1.5.0","repo":"karmjg/Gurbani-saanj"};
