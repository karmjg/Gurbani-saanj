# Gurbani Saanjh v1.5.0 — reading-first private trial

## Changes
- Removed Japji Sahib MP3 UI, local audio import, player, and Listen-to-word button. Existing private MP3 is not included in the app source ZIP; old phone data is not deleted.
- Settings → Reading → Line spacing: Compact (default), Standard, Spacious. No large paragraph gaps in Compact. Preferences persist.
- Nitnem: seven daily Banis fetched by BaniDB Bani IDs on demand as full source texts. First read requires internet; successfully opened items are stored locally in IndexedDB and can be reopened offline. Verify variant: BaniDB Rehras may not match Damdami Taksal Rehras.
- Sri Guru Granth Sahib Ji: choose Ang 1–1430 from Read → Scripture Library; swipe horizontally in the immersive reader for adjoining Angs. Pages load on request (not bundled in this ZIP), and cache after successful opening.
- Anek Baaniyaan: entire user-provided title catalogue preserved and BaniDB Sundar Gutka index is displayed separately; titles with confirmed BaniDB IDs open full text; other titles are matched against the BaniDB catalogue on request. Tradition-specific names not in BaniDB remain unavailable; **never mislabel excerpts as complete**.
- Original Gurbani text is displayed without inserting pause marks. Pauses remain optional colours and require source review.
- No online AI answers or synced word audio implemented.

## Source and licensing
BaniDB maintained by Khalis Foundation: https://www.banidb.com/ and https://api.banidb.com/v2/api-docs/ . Requesting text from the network requires connectivity and is subject to the BaniDB data licence (including non-commercial restrictions); verify terms before commercial launch or distributing a bundled corpus. Explanatory translations belong to their source authors. This package does **not** include the complete offline scripture corpus.

## Release testing status
Syntax and archive checks done by the assistant; live BaniDB connectivity and Samsung APK usability must be verified on the user's actual phone. In case of API failure the app shows an explicit loading error, not incomplete scripture pretending to be complete.
