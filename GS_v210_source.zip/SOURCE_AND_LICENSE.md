# Scripture source and redistribution notice

The bundled Gurmukhi text comes from the **Shabad OS database** (https://github.com/shabados/database), offered under the **MIT licence**. The bundled offline word Kosh uses the same database, with English word glosses from **shabados/translation** (https://github.com/shabados/translation), offered under **CC BY-SA 4.0**. BaniDB is **no longer the bundled text source** (the app's optional, online-only Kosh lookup may still query the public BaniDB API as a fallback; the offline Kosh always takes precedence and works without any network).

This private beta must be **non-profit**. Do not sell this APK, bundle it into an advertisement-supported product or otherwise distribute commercially without checking the licences above and obtaining additional rights where necessary. Keep source credit visible in project documentation. Other third-party translation/teeka rights may differ; seek additional verification before public release.

The source ZIP ships WITH the offline scripture dataset bytes (www/offline/). Text is bundled ONLY in the signed APK produced by successful CI and loaded offline. There is no audio in this version.

The base Gurmukhi scripture is not changed. Vishraam annotations are optional study aids and should not be assumed to be verified for every Pankti. Check traditional variants (especially Rehras Sahib) before relying on them.
