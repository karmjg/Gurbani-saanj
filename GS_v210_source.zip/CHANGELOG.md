## v2.1.0
- Bundle the full offline library IN the source ZIP: 1,430 Angs (60,555 lines), prebuilt search index (60,555 rows), 29 Banis (7 Nitnem + 22 Sundar Gutka, 9,452 lines), 6,963-word Punjabi/English dictionary. Removed the GitHub build-time text download step; the workflow now requires the bundled offline files and fails fast if missing.
- Voice search: mic button wired to the real Capacitor speech-recognition plugin (Punjabi pa-IN preferred, English fallback); RECORD_AUDIO permission added.
- Tap-a-word: fully offline against the bundled dictionary, respects English/Punjabi setting, keeps dismiss controls.
- Text source switched from BaniDB-at-build to Shabad OS database (MIT); English glosses shabados/translation (CC BY-SA 4.0); word meanings Mahan Kosh multilingual dataset (CC BY 4.0). See SOURCE_AND_LICENSE.md.
- Removed the duplicate legacy workflow `.github/workflows/android-apk.yml`.
- Honest caveats: Damdami Taksal exactness of Bani texts needs the user's review; Vishraam data not bundled (toggle inert); English/Roman search modes have no data; not device-tested.
## v1.8.0
- Replace verse-by-verse blocks with **genuine continuous inline scripture text** when meanings are hidden; paragraph gaps no longer appear in Compact, Standard or Spacious.
- Apply spacing settings to actual line height, and preserve meanings under individual verses when enabled.
- Page-turn animation speed control: Slow (default 1250 ms), Normal (800 ms), Fast (430 ms).
- Build a search index from the offline 1,430-Ang source as part of the GitHub build, for quoted-text search and source references.
- Search the corpus from Kirtan Shabads, save verse references and open the original Ang, offline.
- Fix Ask Gurbani home card navigation; Ask Gurbani: referenced passage retrieval locally; optional secure AI server integration (requires separate server setup).
- Daily Gurbani preview now reads from actual bundled scripture, not a hardcoded sample.
- No MP3 or audio controls. Same Android application ID and signing process.

## v1.7.0
- 3D page-flip framework, Scroll/Page Turn choice, and initial continuous layout experimentation.
