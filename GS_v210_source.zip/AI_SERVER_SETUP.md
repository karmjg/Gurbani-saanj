# Gurbani Saanjh — optional live AI (not required for offline reading)

**Status:** The app's offline scripture search works without a server once the BaniDB corpus has been packaged. Generative AI responses require a securely hosted service and an API subscription. The APK contains **no OpenAI key**.

1. Create a Cloudflare Worker from `ai-server/cloudflare-worker.mjs` in your Cloudflare account.
2. Set the **secret** environment variables `OPENAI_API_KEY` (OpenAI developer API key) and `GS_AI_ACCESS_TOKEN` (your own random strong token). Optional: `OPENAI_MODEL` = `gpt-4.1-mini`. Never put these values into the public GitHub repository or into a chat screenshot.
3. Use Cloudflare rate limits / access restrictions to cap spending and prevent abuse; for a future public launch, use real account-based authentication instead of the test access token.
4. Copy the deployed HTTPS Worker URL to **Gurbani Saanjh → Settings → Reading settings → AI server URL**. Enter your `GS_AI_ACCESS_TOKEN` in the separate **AI access code** field.
5. Ask a question. The app retrieves source passages locally and sends only selected verse text and your question to the Worker. The Worker returns an AI interpretation with original Ang references. The API key never goes to the phone.

**Important:** This optional service does not automatically become active by building the APK; deployment, an API account and an access token are still needed. Treat AI interpretation as fallible. Always verify important meanings against a primary source and qualified scholarship. The free-text token is stored locally on the device for this private prototype; use more secure storage and authentication for public release.
