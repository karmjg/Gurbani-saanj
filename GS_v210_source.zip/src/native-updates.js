import { Capacitor } from '@capacitor/core';
import { Browser } from '@capacitor/browser';
import { SpeechRecognition } from '@capacitor-community/speech-recognition';
window.GS_SPEECH = SpeechRecognition;
// Never automatically download or install. User must approve Android's installer.
const native = Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
let offered = null;
const info = window.GS_BUILD || {};
function versionGreater(a,b){
  const A=String(a).replace(/^v/,'').split('.').map(Number),B=String(b).replace(/^v/,'').split('.').map(Number);
  if(A.length!==3||B.length!==3||![...A,...B].every(Number.isFinite))return false;
  return A.some((v,i)=>v>B[i] && A.slice(0,i).every((x,j)=>x===B[j]));
}
function say(pa,en,lang){return lang==='en'?en:pa;}
const G = {
  isNative:native,
  async check(onStatus,lang='pa'){
    if(!native)return;
    const notify=(pa,en)=>onStatus?.(say(pa,en,lang));
    if(offered){
      try {await Browser.open({url:offered});notify('APK ਡਾਊਨਲੋਡ ਕਰਕੇ Android ਤੋਂ ਅੱਪਡੇਟ ਇੰਸਟਾਲ ਕਰੋ।','Download the APK, then approve the Android update installer.');}
      catch(e){notify('ਅੱਪਡੇਟ ਲਿੰਕ ਖੋਲ੍ਹਿਆ ਨਹੀਂ ਜਾ ਸਕਿਆ।','Cannot open the update download link.');}
      return;
    }
    const repo=String(info.repo||'');
    if(!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)){
      notify('ਪਹਿਲਾਂ GitHub ਉੱਤੇ Android ਬਿਲਡ ਜਾਰੀ ਕਰੋ।','Publish a signed APK on GitHub Releases first.');return;
    }
    notify('ਨਵਾਂ Android ਵਰਜ਼ਨ ਚੈੱਕ ਹੋ ਰਿਹਾ ਹੈ…','Checking published Android releases…');
    try{
      const url=`https://api.github.com/repos/${repo}/releases/latest`;
      const response=await fetch(url,{headers:{Accept:'application/vnd.github+json'},cache:'no-store'});
      if(!response.ok)throw new Error('Release not available');
      const release=await response.json();
      const newVersion=String(release.tag_name||'').replace(/^v/,'');
      if(!versionGreater(newVersion,info.version||'1.1.0')){
        notify('ਤੁਹਾਡੇ ਕੋਲ ਤਾਜ਼ਾ Android ਵਰਜ਼ਨ ਹੈ।','Your Android app is up to date.');return;
      }
      const asset=(release.assets||[]).find(a=>a.name?.endsWith('.apk')&&a.browser_download_url);
      if(!asset){notify('ਨਵਾਂ ਵਰਜ਼ਨ ਹੈ, ਪਰ ਉਸ ਦੀ APK ਹਾਲੇ ਉਪਲਬਧ ਨਹੀਂ।','A release exists but has no downloadable APK yet.');return;}
      // Download URL must point to a GitHub release asset in the configured repo.
      if(!asset.browser_download_url.startsWith(`https://github.com/${repo}/releases/download/`))throw Error('Unexpected download host');
      offered=asset.browser_download_url;
      notify(`ਨਵਾਂ ਵਰਜ਼ਨ v${newVersion} ਮਿਲਿਆ! ਅੱਪਡੇਟ ਚੈੱਕ ਕਰੋ ਬਟਨ ਦੁਬਾਰਾ ਦਬਾਓ।`,`Version v${newVersion} is ready! Tap Check for updates again to download.`);
    }catch(err){console.warn('GitHub release check',err);notify('GitHub Releases ਨਹੀਂ ਖੁੱਲ੍ਹੇ। ਇੰਟਰਨੈੱਟ ਜਾਂ ਰਿਪੋਜ਼ਿਟਰੀ ਚੈੱਕ ਕਰੋ।','Cannot check GitHub Releases. Check the internet and repository visibility.');}
  }
};
window.GS_NATIVE_UPDATES=G;
if(native)document.documentElement.classList.add('android-app');
