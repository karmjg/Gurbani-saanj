import fs from 'node:fs';
import vm from 'node:vm';
const searchJS=fs.readFileSync('www/scripture-search.js','utf8');
const fixture=[
 [1,0,'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ॥','The eternal truth','','Ik Oankaar Sat Naam Karta Purakh'],
 [1,1,'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥','Not by thinking','','Sochai soch na hovaee'],
 [2,0,'ਹੁਕਮਿ ਰਜਾਈ ਚਲਣਾ ਨਾਨਕ ਲਿਖਿਆ ਨਾਲਿ ॥੧॥','Walk in the Divine will','','Hukam razai chalna'],
 ...Array.from({length:1001},(_,i)=>[i+3,0,'ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ','Thinking thoughts','',''])
];
const sandbox={window:{},fetch:async()=>({ok:true,json:async()=>fixture})};
vm.runInNewContext(searchJS,sandbox);
const api=sandbox.window.GS_SCRIPTURE_SEARCH;
const first=await api.query('ਸਨਕਪ',10,'first');
if(first[0]?.ang!==1||first[0]?.idx!==0)throw Error('Gurmukhi first-letter search failed');
const middle=await api.query('ਨਕਪ',10,'any-first');
if(middle[0]?.ang!==1||middle[0]?.idx!==0)throw Error('any-position initial search failed');
const auto=await api.query('ਸਨਕਪ');
if(auto[0]?.idx!==0)throw Error('auto-mode first-letter search failed');
const phrase=await api.query('ਹੁਕਮਿ ਰਜਾਈ');
if(phrase[0]?.ang!==2)throw Error('full phrase search failed');
const ang=await api.query('Ang 2',10,'ang');
if(ang[0]?.ang!==2)throw Error('Ang navigation search failed');
const roman=await api.query('hukam',10,'roman');
if(roman[0]?.ang!==2)throw Error('Romanized search failed');
if(api.lookup(2,0)?.g!==fixture[2][2])throw Error('search result lookup failed');
const app=fs.readFileSync('www/app.js','utf8'),styles=fs.readFileSync('www/styles.css','utf8');
if(!app.includes('gs-bani-pankti')||!app.includes('gs-sggs-pankti')||!app.includes('gs-stanza-end'))throw Error('separate Bani / SGGS typography missing');
if(!app.includes('data-close-word')||!app.includes('openWord(word)')||!app.includes('wordContext'))throw Error('word meaning popup close/tap/context missing');
if(!styles.includes('.gs-reader-bani')||!styles.includes('.gs-reader-sggs'))throw Error('reader styles missing');
const page=fs.readFileSync('www/page-turn.js','utf8');
if(!page.includes('gs-book-stanza-break')||!page.includes('slow:1250'))throw Error('page-turn stanza spacing missing');
const koshJS=fs.readFileSync('www/word-kosh.js','utf8');
const koshContext={window:{},localStorage:{getItem:()=>null},navigator:{onLine:false},fetch:async()=>({ok:false,json:async()=>({})})};
vm.runInNewContext(koshJS,koshContext);
const meaning=await koshContext.window.GS_KOSH.lookup('ਨਾਮੁ','en',false);
if(meaning.definitions?.[0]?.meaning!=='name; the Divine Name')throw Error('English word gloss not found');
const parsed=koshContext.window.GS_KOSH.parse([{word_uni:'ਅਕਥ',def_uni:'ਜੋ ਬਿਆਨ ਨਾ ਕੀਤਾ ਜਾ ਸਕੇ'}]);
if(parsed[0]?.word!=='ਅਕਥ'||!parsed[0]?.meaning)throw Error('BaniDB Kosh response shape not parsed');
if(app.includes('data-pop="listen"')||app.includes('data-pop="meaning"'))throw Error('old popup actions remain');
console.log('PASS: first-letter from start / anywhere, auto, romanized, full phrase, Ang, results, Bani/SGGS layout, popup dismiss, Punjabi Kosh parser, English gloss, no audio button');
