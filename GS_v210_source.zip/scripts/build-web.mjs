import fs from 'node:fs';
import path from 'node:path';
import { build } from 'esbuild';
const root = path.resolve(process.cwd());
// The offline corpus is bundled into the source ZIP by the data pipeline.
// Never download scripture at build time: a missing corpus is a hard error.
if (!fs.existsSync('www/offline/manifest.json')) {
  throw Error('Offline corpus missing: www/offline/manifest.json not found. Bundle the offline data before building.');
}

const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const repository=process.env.GS_GITHUB_REPOSITORY||'';
const version=process.env.GS_APP_VERSION||pkg.version;
const repoPattern=/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/;
if(repository&&!repoPattern.test(repository))throw Error('Invalid GitHub repository identifier');
fs.writeFileSync('www/native-build-config.js',`window.GS_BUILD=${JSON.stringify({version,repo:repository})};\n`);
await build({entryPoints:['src/native-updates.js'],bundle:true,format:'iife',platform:'browser',target:['chrome110'],minify:true,outfile:'www/native-updates.js'});
console.log(`Bundled Android UI v${version}; update source: ${repository||'not configured'}`);
