import fs from 'node:fs';
const gradle='android/app/build.gradle';
if(!fs.existsSync(gradle))throw Error('Capacitor Android Groovy Gradle project not found. Check Capacitor version.');
let s=fs.readFileSync(gradle,'utf8');
const version=process.env.GS_APP_VERSION||JSON.parse(fs.readFileSync('package.json','utf8')).version;
const code=Number(process.env.GS_VERSION_CODE||110001);
if(!Number.isInteger(code)||code<1||code>2147483647)throw Error('Invalid Android version code');
if(!/^\d+\.\d+\.\d+$/.test(version))throw Error('Version must be SemVer x.y.z');
if(!/versionCode\s*(?:=\s*)?\d+/.test(s)||!/versionName\s*(?:=\s*)?["'].*?["']/.test(s))throw Error('Gradle defaults changed; investigate before shipping');
s=s.replace(/versionCode\s*(?:=\s*)?\d+/,`versionCode = ${code}`).replace(/versionName\s*(?:=\s*)?["'].*?["']/,`versionName = "${version}"`);
fs.writeFileSync(gradle,s);
const manifest='android/app/src/main/AndroidManifest.xml';
let m=fs.readFileSync(manifest,'utf8');
if(!m.includes('android.permission.INTERNET'))m=m.replace('<application','<uses-permission android:name="android.permission.INTERNET" />\n    <application');
// Voice search (Capacitor speech-recognition plugin) requests RECORD_AUDIO at
// runtime; it must be declared in the manifest for the request to be grantable.
if(!m.includes('android.permission.RECORD_AUDIO'))m=m.replace('<application','<uses-permission android:name="android.permission.RECORD_AUDIO" />\n    <application');
fs.writeFileSync(manifest,m);
const main='android/app/src/main/res/values/strings.xml';
let x=fs.readFileSync(main,'utf8').replace(/<string name="app_name">[\s\S]*?<\/string>/,'<string name="app_name">ਗੁਰਬਾਣੀ ਸਾਂਝ</string>');
fs.writeFileSync(main,x);
// Use the selected clean gold/green logo in the launcher icons.
for(const dpi of ['mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi']){
  const target=`android/app/src/main/res/mipmap-${dpi}`;
  if(fs.existsSync(`native-icons/${dpi}/ic_launcher.png`)){
    fs.mkdirSync(target,{recursive:true});
    for(const n of ['ic_launcher.png','ic_launcher_round.png'])fs.copyFileSync(`native-icons/${dpi}/ic_launcher.png`,`${target}/${n}`);
  }
}
const anydpi='android/app/src/main/res/mipmap-anydpi-v26';
if(fs.existsSync(anydpi))for(const n of ['ic_launcher.xml','ic_launcher_round.xml']){
  const p=`${anydpi}/${n}`;if(fs.existsSync(p))fs.rmSync(p);
}
console.log(`Android set to ${version} (${code}).`);
