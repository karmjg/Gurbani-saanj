window.GS_NATIVE_UPDATES={isNative:false};
