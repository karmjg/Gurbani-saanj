/* Requested Bani titles; not a scripture corpus. Variant labels preserved. */
window.GS_CATALOG = [
  {
    "id": "bani-001",
    "group": "sggs",
    "titlePa": "ਸ਼ਬਦ ਹਜਾਰੇ",
    "titleEn": "Shabad Hazare",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-002",
    "group": "sggs",
    "titlePa": "ਬਾਰਹ ਮਾਹਾ ਮਾਂਝ",
    "titleEn": "Barah Maha Majh",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-003",
    "group": "sggs",
    "titlePa": "ਆਰਤੀ",
    "titleEn": "Aarti",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-004",
    "group": "sggs",
    "titlePa": "ਸੁਖਮਨੀ ਸਾਹਿਬ",
    "titleEn": "Sukhmani Sahib",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-005",
    "group": "sggs",
    "titlePa": "ਆਸਾ ਦੀ ਵਾਰ",
    "titleEn": "Asa Di Vaar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-006",
    "group": "sggs",
    "titlePa": "ਦਖਣੀ ਓਅੰਕਾਰ",
    "titleEn": "Dakhni Oankar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-007",
    "group": "sggs",
    "titlePa": "ਸਿਧ ਗੋਸਟਿ",
    "titleEn": "Sidh Gosht",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-008",
    "group": "sggs",
    "titlePa": "ਬਾਵਨ ਅਖਰੀ",
    "titleEn": "Bavan Akhri",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-009",
    "group": "sggs",
    "titlePa": "ਜੈਤਸਰੀ ਦੀ ਵਾਰ",
    "titleEn": "Jaitsri Di Vaar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-010",
    "group": "sggs",
    "titlePa": "ਰਾਮਕਲੀ ਕੀ ਵਾਰ",
    "titleEn": "Ramkali Ki Vaar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-011",
    "group": "sggs",
    "titlePa": "ਬਸੰਤ ਕੀ ਵਾਰ",
    "titleEn": "Basant Ki Vaar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-012",
    "group": "sggs",
    "titlePa": "ਬਾਰਹ ਮਾਹਾ ਤੁਖਾਰੀ",
    "titleEn": "Barah Maha Tukhari",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-013",
    "group": "sggs",
    "titlePa": "ਲਾਵਾਂ",
    "titleEn": "Laavan",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-014",
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਮਹਲਾ ੯",
    "titleEn": "Salok Mahalla 9",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-015",
    "group": "sggs",
    "titlePa": "ਰਾਗਮਾਲਾ",
    "titleEn": "Raagmala",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-016",
    "group": "sggs",
    "titlePa": "ਗੁਣਵੰਤੀ",
    "titleEn": "Gunvanti",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-017",
    "group": "sggs",
    "titlePa": "ਰਾਮਕਲੀ ਸਦੁ",
    "titleEn": "Ramkali Sadd",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-018",
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਸਹਸਕ੍ਰਿਤੀ",
    "titleEn": "Salok Sahaskriti",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-019",
    "group": "sggs",
    "titlePa": "ਗਾਥਾ",
    "titleEn": "Gatha",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-020",
    "group": "sggs",
    "titlePa": "ਫੁਨਹੇ",
    "titleEn": "Funhe",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-021",
    "group": "sggs",
    "titlePa": "ਚਉਬੋਲੇ",
    "titleEn": "Chaubole",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-022",
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਭਗਤ ਕਬੀਰ",
    "titleEn": "Salok Bhagat Kabir",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-023",
    "group": "sggs",
    "titlePa": "ਸਲੋਕ ਭਗਤ ਫਰੀਦ",
    "titleEn": "Salok Bhagat Farid",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-024",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਸ੍ਰੀ ਮੁਖਵਾਕ – ੧",
    "titleEn": "Savaiye Sri Mukhvak 1",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-025",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਸ੍ਰੀ ਮੁਖਵਾਕ – ੨",
    "titleEn": "Savaiye Sri Mukhvak 2",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-026",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਮਹਲੇ ਪਹਿਲੇ ਕੇ",
    "titleEn": "Savaiye Mehle Pehle Ke",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-027",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਮਹਲੇ ਦੂਜੇ ਕੇ",
    "titleEn": "Savaiye Mehle Dooje Ke",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-028",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਮਹਲੇ ਤੀਜੇ ਕੇ",
    "titleEn": "Savaiye Mehle Teeje Ke",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-029",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਮਹਲੇ ਚਉਥੇ ਕੇ",
    "titleEn": "Savaiye Mehle Chauthe Ke",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-030",
    "group": "sggs",
    "titlePa": "ਸਵੱਯੇ ਮਹਲੇ ਪੰਜਵੇ ਕੇ",
    "titleEn": "Savaiye Mehle Panjve Ke",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-031",
    "group": "sggs",
    "titlePa": "ਵਾਰਾਂ ਤੇ ਵਧੀਕ ਮਹਲਾ ੧",
    "titleEn": "Vaaran Te Vadheek Mahalla 1",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-032",
    "group": "sggs",
    "titlePa": "ਵਾਰਾਂ ਤੇ ਵਧੀਕ ਮਹਲਾ ੩",
    "titleEn": "Vaaran Te Vadheek Mahalla 3",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-033",
    "group": "sggs",
    "titlePa": "ਵਾਰਾਂ ਤੇ ਵਧੀਕ ਮਹਲਾ ੪",
    "titleEn": "Vaaran Te Vadheek Mahalla 4",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-034",
    "group": "dasam",
    "titlePa": "ਸ਼ਬਦ ਹਜਾਰੇ ਪਾ ੧੦",
    "titleEn": "Shabad Hazare Patshahi 10",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-035",
    "group": "dasam",
    "titlePa": "ਅਕਾਲ ਉਸਤਤ",
    "titleEn": "Akal Ustat",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-036",
    "group": "dasam",
    "titlePa": "ਬਚਿਤ੍ਰ ਨਾਟਕ",
    "titleEn": "Bachittar Natak",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-037",
    "group": "dasam",
    "titlePa": "ਚੰਡੀ ਚਰਿਤ੍ਰ ੧",
    "titleEn": "Chandi Charitra 1",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-038",
    "group": "dasam",
    "titlePa": "ਚੰਡੀ ਚਰਿਤ੍ਰ ੨",
    "titleEn": "Chandi Charitra 2",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-039",
    "group": "dasam",
    "titlePa": "ਚੰਡੀ ਚਰਿਤ੍ਰ ਉਸਤਤਿ",
    "titleEn": "Chandi Charitra Ustat",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-040",
    "group": "dasam",
    "titlePa": "ਸਸਤ੍ਰ ਨਾਮ ਮਾਲਾ",
    "titleEn": "Shastar Naam Mala",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-041",
    "group": "dasam",
    "titlePa": "ਗਿਆਨ ਪ੍ਰਬੋਧ",
    "titleEn": "Gyan Prabodh",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-042",
    "group": "dasam",
    "titlePa": "ਖਾਲਸਾ ਮਹਿਮਾ",
    "titleEn": "Khalsa Mahima",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-043",
    "group": "dasam",
    "titlePa": "੩੩ ਸਵੱਯੇ",
    "titleEn": "33 Savaiye",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-044",
    "group": "dasam",
    "titlePa": "੧੬ ਸਵੱਯੇ",
    "titleEn": "16 Savaiye",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-045",
    "group": "dasam",
    "titlePa": "ਬਾਰਹ ਮਾਹਾ (ਫਾਗਨ)",
    "titleEn": "Barah Maha (Phagan)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-046",
    "group": "dasam",
    "titlePa": "ਬਾਰਹ ਮਾਹਾ (ਪ੍ਰੇਮ ਛਕੀ)",
    "titleEn": "Barah Maha (Prem Chhaki)",
    "contentStatus": "pending",
    "source": "video",
    "titleNeedsReview": true
  },
  {
    "id": "bani-047",
    "group": "tradition",
    "titlePa": "ਅਰਦਾਸ",
    "titleEn": "Ardas",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-048",
    "group": "tradition",
    "titlePa": "ਸੂਰੇ ਦੀਨਨ",
    "titleEn": "Soore Deenan",
    "contentStatus": "pending",
    "source": "video",
    "titleNeedsReview": true
  },
  {
    "id": "bani-049",
    "group": "tradition",
    "titlePa": "ਕ੍ਰਸਨਾ",
    "titleEn": "Karsna",
    "contentStatus": "pending",
    "source": "video",
    "titleNeedsReview": true
  },
  {
    "id": "bani-050",
    "group": "tradition",
    "titlePa": "ਸੁਰਜੀ",
    "titleEn": "Surji",
    "contentStatus": "pending",
    "source": "video",
    "titleNeedsReview": true
  },
  {
    "id": "bani-051",
    "group": "tradition",
    "titlePa": "ਚੰਡੀ ਦੀ ਵਾਰ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Chandi Di Vaar (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-052",
    "group": "tradition",
    "titlePa": "ਰਹਰਾਸਿ ਸਾਹਿਬ (ਬੁੱਢਾ ਦਲ)",
    "titleEn": "Rehras Sahib (Buddha Dal)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-053",
    "group": "tradition",
    "titlePa": "ਰਹਰਾਸਿ ਸਾਹਿਬ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Rehras Sahib (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-054",
    "group": "tradition",
    "titlePa": "ਸੋਹਿਲਾ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Sohila (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-055",
    "group": "tradition",
    "titlePa": "ਆਰਤੀ-ਆਰਤਾ",
    "titleEn": "Aarti-Aarta",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-056",
    "group": "tradition",
    "titlePa": "ਆਰਤੀ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Aarti (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-057",
    "group": "tradition",
    "titlePa": "ਅਰਦਾਸ (ਬੁੱਢਾ ਦਲ)",
    "titleEn": "Ardas (Buddha Dal)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-058",
    "group": "tradition",
    "titlePa": "ਅਰਦਾਸ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Ardas (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-059",
    "group": "tradition",
    "titlePa": "ਉਗ੍ਰਦੰਤੀ (ਬੁੱਢਾ ਦਲ)",
    "titleEn": "Ugrdanti (Buddha Dal)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-060",
    "group": "tradition",
    "titlePa": "ਉਗ੍ਰਦੰਤੀ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Ugrdanti (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-061",
    "group": "tradition",
    "titlePa": "ਨਿਗੁਰਾ ਦੇ ਸਲੋਕ",
    "titleEn": "Nigura De Salok",
    "contentStatus": "pending",
    "source": "video",
    "titleNeedsReview": true
  },
  {
    "id": "bani-062",
    "group": "tradition",
    "titlePa": "ਸ਼ਹੀਦੀ ਦੇਗਾਂ ਦੇ ਸਲੋਕ",
    "titleEn": "Shaheedi Degan De Salok",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-063",
    "group": "tradition",
    "titlePa": "ਸਲੋਕ ਦੁਮਾਲੇ ਦਾ",
    "titleEn": "Salok Dumale Da",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-064",
    "group": "tradition",
    "titlePa": "ਖਾਲਸਾ ਮੂਲ ਮੰਤਰ",
    "titleEn": "Khalsa Mool Mantar",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-065",
    "group": "tradition",
    "titlePa": "ਭਗਉਤੀ ਅਸਤੋਤ੍ਰ (ਬੁੱਢਾ ਦਲ)",
    "titleEn": "Bhagauti Astotar (Buddha Dal)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-066",
    "group": "tradition",
    "titlePa": "ਭਗਉਤੀ ਅਸਤੋਤ੍ਰ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Bhagauti Astotar (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-067",
    "group": "tradition",
    "titlePa": "ਬ੍ਰਹਮ ਕਵਚ (ਬੁੱਢਾ ਦਲ)",
    "titleEn": "Brahm Kavach (Buddha Dal)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-068",
    "group": "tradition",
    "titlePa": "ਬ੍ਰਹਮ ਕਵਚ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Brahm Kavach (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-069",
    "group": "tradition",
    "titlePa": "ਖਾਲਸਾ ਰਹਿਤਨਾਮਾ",
    "titleEn": "Khalsa Rehitnama",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-070",
    "group": "tradition",
    "titlePa": "ਅਕਾਲ ਉਸਤਤ ਚੌਪਈ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Akal Ustat Chaupai (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-071",
    "group": "tradition",
    "titlePa": "੩੩ ਸਵੱਯੇ (ਹਜ਼ੂਰੀ)",
    "titleEn": "33 Savaiye (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-072",
    "group": "tradition",
    "titlePa": "ਚੰਡੀ ਚਰਿਤ੍ਰ ਉਸਤਤਿ (ਹਜ਼ੂਰੀ)",
    "titleEn": "Chandi Charitra Ustat (Hazuri)",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-073",
    "group": "tradition",
    "titlePa": "ਲੱਖੀ ਜੰਗਲ",
    "titleEn": "Lakhi Jangal",
    "contentStatus": "pending",
    "source": "video"
  },
  {
    "id": "bani-074",
    "group": "bhai",
    "titlePa": "ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੀਆਂ ਵਾਰਾਂ",
    "titleEn": "Bhai Gurdas Ji Vaaran",
    "contentStatus": "pending",
    "source": "user-request"
  },
  {
    "id": "bani-075",
    "group": "bhai",
    "titlePa": "ਭਾਈ ਗੁਰਦਾਸ ਜੀ ਦੇ ਕਬਿੱਤ ਸਵੱਈਏ",
    "titleEn": "Bhai Gurdas Ji Kabit Savaiye",
    "contentStatus": "pending",
    "source": "user-request"
  }
];
