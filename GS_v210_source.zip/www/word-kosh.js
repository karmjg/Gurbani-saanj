/* Word meanings for Gurbani Saanjh (NO Listen button).
 * Plain-word glossary (basic gloss) -> bundled offline Kosh snapshot
 * (www/offline/kosh.json, from the Shabad OS database; English glosses from
 * shabados/translation) -> localStorage cache -> optional live BaniDB Kosh.
 * Offline results always win; network failures are silent and never break
 * the offline lookup. Never generate unverified definitions.
 */
(()=>{'use strict';
const key='gurbani-saanjh-kosh-cache-v2';
let cache={};try{cache=JSON.parse(localStorage.getItem(key)||'{}')}catch{}
const GLOSS={
 'ਸਤਿ':['ਸੱਚ; ਸਦੀਵੀ ਸੱਚ','truth; eternal truth'],
 'ਨਾਮੁ':['ਨਾਮ; ਪਰਮਾਤਮਾ ਦਾ ਨਾਮ','name; the Divine Name'],
 'ਕਰਤਾ':['ਸਿਰਜਣਹਾਰ; ਰਚਣ ਵਾਲਾ','creator'],
 'ਪੁਰਖੁ':['ਹਸਤੀ; ਵਿਅਕਤੀ (ਪ੍ਰਸੰਗ ਅਨੁਸਾਰ)','being; person (depending on context)'],
 'ਨਿਰਭਉ':['ਜਿਸ ਨੂੰ ਕੋਈ ਡਰ ਨਹੀਂ','fearless; without fear'],
 'ਨਿਰਵੈਰੁ':['ਜਿਸ ਦਾ ਕਿਸੇ ਨਾਲ ਵੈਰ ਨਹੀਂ','without enmity'],
 'ਅਕਾਲ':['ਸਮੇਂ ਤੋਂ ਪਰੇ','timeless; beyond time'],
 'ਮੂਰਤਿ':['ਸਰੂਪ','form; manifestation'],
 'ਅਜੂਨੀ':['ਜਨਮ-ਮਰਨ ਤੋਂ ਪਰੇ','beyond birth and death'],
 'ਸੈਭੰ':['ਆਪਣੇ ਆਪ ਤੋਂ ਪ੍ਰਕਾਸ਼ਮਾਨ','self-existent'],
 'ਗੁਰ':['ਗੁਰੂ','Guru'],
 'ਪ੍ਰਸਾਦਿ':['ਕਿਰਪਾ ਰਾਹੀਂ','by grace'],
 'ਆਦਿ':['ਆਰੰਭ; ਸ਼ੁਰੂ','beginning; from the beginning'],
 'ਸਚੁ':['ਸੱਚ','truth; true'],
 'ਨਾਨਕ':['ਗੁਰੂ ਨਾਨਕ ਸਾਹਿਬ ਜੀ ਦਾ ਨਾਮ','Nanak (Guru Nanak)'],
 'ਹੁਕਮਿ':['ਹੁਕਮ ਅਨੁਸਾਰ','according to the Divine order'],
 'ਰਜਾਈ':['ਰਜ਼ਾ; ਇੱਛਾ ਅਨੁਸਾਰ','in accordance with the will'],
 'ਚਲਣਾ':['ਤੁਰਨਾ; ਜੀਵਨ ਬਿਤਾਉਣਾ','to walk; to conduct one’s life'],
 'ਸੋਚਿ':['ਸੋਚ; ਵਿਚਾਰ ਜਾਂ ਸੁੱਚ (ਪ੍ਰਸੰਗ ਅਨੁਸਾਰ)','thought or purification (context-dependent)'],
 'ਭੁਖ':['ਭੁੱਖ; ਇੱਛਾ ਜਾਂ ਤ੍ਰਿਸ਼ਨਾ','hunger; longing'],
 'ਜੇ':['ਜੇਕਰ','if'],
 'ਲਖ':['ਲੱਖ; 100,000','one hundred thousand'],
 'ਵਾਰ':['ਵਾਰੀ; ਮੌਕਾ','times; occasions'],
 'ਤੂੰ':['ਤੂੰ; ਤੇਰਾ ਸੰਬੋਧਨ','you'],
 'ਤੁਮ':['ਤੂੰ; ਤੁਸੀਂ','you'],
 'ਠਾਕੁਰੁ':['ਮਾਲਕ; ਪ੍ਰਭੂ','Lord; master'],
 'ਅਰਦਾਸਿ':['ਬੇਨਤੀ; ਪ੍ਰਾਰਥਨਾ','prayer; supplication'],
};
const clean=s=>String(s||'').normalize('NFC').trim().replace(/[॥।੦-੯,;.!?]+/gu,'');
function parse(x,out=[],depth=0){
 if(!x||depth>7||out.length>100)return out;
 if(Array.isArray(x)){x.forEach(v=>parse(v,out,depth+1));return out}
 if(typeof x!=='object')return out;
 const word=x.word_uni||x.wordUnicode||x.gurmukhi||x.unicode||x.headword||x.word?.unicode||x.word||'';
 const meaning=x.def_uni||x.definitionUnicode||x.meaning?.unicode||x.meaning||x.definition||x.arth||x.description||'';
 if(typeof word==='string'&&typeof meaning==='string'&&word.trim()&&meaning.trim()&&word.trim()!==meaning.trim())out.push({word:clean(word),meaning:meaning.trim(),lang:'pa'});
 for(const v of Object.values(x))if(v&&typeof v==='object')parse(v,out,depth+1);
 return out;
}
let snapshotPromise;
async function snapshot(){
 if(!snapshotPromise)snapshotPromise=fetch('offline/kosh.json',{cache:'force-cache'}).then(r=>r.ok?r.json():{}).catch(()=>({}));
 return snapshotPromise;
}
// Accept the bundled snapshot in a few plausible shapes: word ->
// [{word, meaning, lang}], word -> {definitions:[...]}, word -> {pa:'…',
// en:'…'}, or word -> a single definition object.
function toDefs(entry,q){
 const raw=Array.isArray(entry)?entry:(entry&&typeof entry==='object')?(Array.isArray(entry.definitions)?entry.definitions:[entry]):[];
 const out=[];
 for(const d of raw){
  if(!d||typeof d!=='object')continue;
  if(!d.meaning&&!d.def_uni&&!d.definitionUnicode&&!d.definition&&!d.arth&&!d.description){
   for(const lang of ['pa','en'])if(typeof d[lang]==='string'&&d[lang].trim())out.push({word:q,meaning:d[lang].trim(),lang});
   continue;
  }
  out.push({
   word:clean(d.word_uni||d.wordUnicode||d.gurmukhi||d.unicode||d.headword||d.word||q),
   meaning:String(d.def_uni||d.definitionUnicode||d.meaning||d.definition||d.arth||d.description||'').trim(),
   lang:d.lang==='en'?'en':'pa'
  });
 }
 return out.filter(d=>d.word&&d.meaning);
}
function save(){try{const entries=Object.entries(cache).slice(-400);localStorage.setItem(key,JSON.stringify(Object.fromEntries(entries)))}catch{}}
async function lookup(word,lang='pa',allowNetwork=true){
 const q=clean(word);if(!q)return {source:'none',definitions:[]};
 const local=GLOSS[q];if(local)return {source:'basic-gloss',definitions:[{word:q,meaning:local[lang==='en'?1:0],lang:lang==='en'?'en':'pa'}]};
 const offlineDefs=toDefs((await snapshot())?.[q],q).filter(d=>d.lang===lang);
 if(offlineDefs.length)return {source:'offline-kosh',definitions:offlineDefs};
 const cached=cache[q];if(Array.isArray(cached)&&cached.length){const defs=cached.filter(d=>d.lang===lang);if(defs.length)return {source:'offline-cache',definitions:defs}}
 // Kosh offers Punjabi definitions. Do not display them under an English label.
 if(lang==='en'||!allowNetwork||!navigator.onLine)return {source:'unavailable-offline',definitions:[]};
 const ctrl=new AbortController(),tid=setTimeout(()=>ctrl.abort(),4500);
 try{
  // Kosh Word and Kosh Search both exist; unicode support varies by query.
  for(const route of ['word','search']){
   const url=`https://api.banidb.com/v2/kosh/${route}/${encodeURIComponent(q)}`;
   const r=await fetch(url,{signal:ctrl.signal,headers:{Accept:'application/json'}});
   if(!r.ok)continue;
   const raw=parse(await r.json()).filter(x=>x.word===q).slice(0,5);
   if(raw.length){cache[q]=raw;save();return {source:'BaniDB Kosh',definitions:raw}}
  }
  return {source:'not-found',definitions:[]};
 }catch{return {source:'unavailable',definitions:[]}}finally{clearTimeout(tid)}
}
window.GS_KOSH={lookup,parse,clean};
})();
