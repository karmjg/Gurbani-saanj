/* Gurbani Saanjh book reader: responsive pagination with a tactile 3D page flip.
   Each original Gurbani word is kept intact, in source order. No generated scripture. */
(()=>{
'use strict';
const escapeHTML = value => String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const WORD_BATCH=22;
const stanzaEnds=s=>/(?:॥|\|\|)\s*[੦-੯0-9]+\s*(?:॥|\|\|)\s*$/u.test(String(s||'').trim())||/ਰਹਾਉ\s*(?:॥|\|\|)/u.test(String(s||''));
const reducedMotion=()=>window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
function tokensFor(lines,settings){
  const tokens=[];
  for(let verse=0;verse<lines.length;verse++){
    const entry=lines[verse];
    const source=String(entry.g||'').trim().split(/\s+/).filter(Boolean);
    const roman= settings.readingScript==='roman' && entry.roman;
    const parts=String(roman?entry.roman:entry.g||'').trim().split(/\s+/).filter(Boolean);
    for(let w=0;w<parts.length;w++){
      // v2.2.0: vishraam.json marks (s=short/green, l=long/orange) win over the
      // legacy per-line vishraam map; both honor the vishraams toggle.
      const markPause=settings.vishraams && entry._marks?.[w];
      const legacyPause=settings.vishraams && !markPause && entry.vishraam?.[w];
      const pause=markPause?(markPause==='s'?'short':'long'):legacyPause;
      const cls=pause==='short'?' vishraam-short':pause==='long'?' vishraam-long':'';
      const word=`<button type="button" class="word${cls}" data-word="${escapeHTML(source[w]||parts[w])}" data-kind="${escapeHTML(settings.kind)}" data-idx="${verse}" data-widx="${w}" lang="${roman?'en':'pa'}">${escapeHTML(parts[w])}</button>`;
      tokens.push({verse,word:w,html:`<span class="gs-book-token gs-script-word">${word} </span>`});
    }
    // A pankti is a real unit. A natural end-of-pauri gets more breathing room.
    tokens.push({verse,word:parts.length,html:`<span class="gs-book-line-break${stanzaEnds(entry.g)?' gs-book-stanza-break':''}" aria-hidden="true"></span>`});
    if(settings.meanings){
      const note=String(entry[settings.meaningLang]||'').trim();
      if(note){
        tokens.push({verse,word:parts.length,html:'<span class="gs-book-meaning-break" aria-hidden="true"></span>'});
        note.split(/\s+/).forEach((s,i)=>tokens.push({verse,word:parts.length+i,html:`<span class="gs-book-token gs-book-meaning-word" lang="${settings.meaningLang}">${escapeHTML(s)} </span>`}));
        tokens.push({verse,word:parts.length+note.length,html:'<span class="gs-book-meaning-end" aria-hidden="true"></span>'});
      }
    }
  }
  return tokens;
}
class BookReader{
  constructor(node,config){
    this.node=node;
    this.config=config;
    this.destroyed=false;
    this.pages=[];
    this.pageIndex=0;
    this.drag=null;
    this.flip=null;
    this.timer=null;
    this.resizeObserver=null;
    this.makePages();
    this.renderPage();
    this.attachEvents();
  }
  makePages(){
    const {node,config}=this;
    const tokens=tokensFor(config.lines,config);
    const width=Math.max(120,Math.round(node.clientWidth));
    const height=Math.max(220,Math.round(node.clientHeight));
    if(!tokens.length){this.pages=[{html:'',start:{verse:0,word:0}}];return;}
    const probe=document.createElement('div');
    probe.className='gs-book-page gs-book-measuring';
    probe.style.width=width+'px';probe.style.height=height+'px';
    const flow=document.createElement('div');flow.className='gs-book-flow';probe.append(flow);
    document.body.append(probe);
    const pages=[];let i=0;
    let pageStart=0;
    let chunks=[];
    const over=()=>probe.scrollHeight>probe.clientHeight+1 || flow.getBoundingClientRect().bottom>probe.getBoundingClientRect().bottom-10;
    const add=(from,count)=>flow.insertAdjacentHTML('beforeend',tokens.slice(from,from+count).map(t=>t.html).join(''));
    const remove=(count)=>{for(let k=0;k<count;k++)flow.lastElementChild?.remove()};
    const flush=()=>{
      if(!chunks.length)return;
      const first=tokens[pageStart];
      pages.push({html:chunks.join(''),start:{verse:first.verse,word:first.word},startToken:pageStart,afterToken:i});
      pageStart=i;chunks=[];flow.innerHTML='';
    };
    try{
      while(i<tokens.length){
        const batch=Math.min(WORD_BATCH,tokens.length-i);
        add(i,batch);
        if(!over()){
          chunks.push(...tokens.slice(i,i+batch).map(t=>t.html));
          i+=batch;continue;
        }
        remove(batch);
        // Fit the maximum number of tokens without dividing a Gurbani word.
        let lo=0,hi=batch;
        while(lo<hi){
          const mid=Math.ceil((lo+hi)/2);
          add(i,mid);
          const fits=!over();
          remove(mid);
          if(fits)lo=mid;else hi=mid-1;
        }
        if(lo){
          add(i,lo);chunks.push(...tokens.slice(i,i+lo).map(t=>t.html));i+=lo;
        }
        if(!lo&&!chunks.length){
          // A single extremely long token: keep it; CSS wraps rather than dropping it.
          add(i,1);chunks.push(tokens[i].html);i++;
        }
        flush();
      }
      flush();
    }finally{probe.remove()}
    if(tokens.length!==pages.reduce((n,p)=>n+p.afterToken-p.startToken,0)){
      throw Error('Book pagination omitted words; refusing to display incomplete text.');
    }
    this.pages=pages;
    const cursor=this.config.cursor||{verse:0,word:0};
    const desired=tokens.findIndex(t=>t.verse>cursor.verse||(t.verse===cursor.verse&&t.word>=cursor.word));
    const match=desired<0?Math.max(0,tokens.length-1):desired;
    this.pageIndex=Math.max(0,pages.findIndex(p=>p.startToken<=match&&p.afterToken>match));
    this.config.onStatus?.({pages:pages.length,scriptureWords:tokens.filter(t=>t.html.includes('data-word=')).length});
  }
  pageContent(idx){return `<div class="gs-book-page"><div class="gs-book-flow">${this.pages[idx]?.html||''}</div></div>`}
  renderPage(){
    if(this.destroyed)return;
    this.node.innerHTML=`<div class="gs-book-current" aria-label="${this.config.lang==='pa'?'ਪਾਠ ਦਾ ਪੰਨਾ':'Reading page'}">${this.pageContent(this.pageIndex)}</div>`;
  }
  remember(){const cursor=this.pages[this.pageIndex]?.start||{verse:0,word:0};this.config.onChange?.(cursor,this.pageIndex,this.pages.length)}
  flipPage(dir,{drag=false}={}){
    if(this.destroyed||this.flip)return false;
    const next=this.pageIndex+dir;
    if(next<0||next>=this.pages.length){
      this.config.onEdge?.(dir);
      return false;
    }
    const current=this.pageContent(this.pageIndex),incoming=this.pageContent(next);
    const face=dir>0?current:incoming;
    const beneath=dir>0?incoming:current;
    const stage=this.node;
    stage.innerHTML=`<div class="gs-book-under">${beneath}</div><div class="gs-book-turn" aria-hidden="true"><div class="gs-book-turn-front">${face}</div><div class="gs-book-turn-back"></div></div>`;
    const layer=stage.querySelector('.gs-book-turn');
    layer.style.transformOrigin='left center';
    layer.style.transform=`rotateY(${dir>0?0:-179}deg)`;
    this.flip={dir,next,layer,progress:0};
    if(!drag)this.finishFlip(true);
    return true;
  }
  draw(progress){
    if(!this.flip)return;
    const p=Math.max(0,Math.min(1,progress));
    this.flip.progress=p;
    this.flip.layer.style.transform=`rotateY(${-179*(this.flip.dir>0?p:1-p)}deg)`;
  }
  finishFlip(commit){
    const flip=this.flip;
    if(!flip)return;
    const target=commit?1:0;
    const speed={slow:1250,normal:800,fast:430}[this.config.pageTurnSpeed]||1250;
    flip.layer.style.transition=reducedMotion()?'none':`transform ${speed}ms cubic-bezier(.18,.7,.22,1)`;
    requestAnimationFrame(()=>{if(this.flip===flip)this.draw(target)});
    const finalize=()=>{
      if(this.flip!==flip||this.destroyed)return;
      if(commit){this.pageIndex=flip.next;this.remember()}
      this.flip=null;this.renderPage();
    };
    this.timer=setTimeout(finalize,reducedMotion()?30:speed+85);
  }
  navigate(dir){if(this.flip)return;this.flipPage(dir)}
  attachEvents(){
    const host=this.node;
    this.onDown=e=>{
      if(this.flip||e.button>0)return;
      this.drag={x:e.clientX,y:e.clientY,dir:0,active:false,id:e.pointerId};
    };
    this.onMove=e=>{
      const d=this.drag;if(!d||d.id!==e.pointerId)return;
      const dx=e.clientX-d.x,dy=e.clientY-d.y;
      if(!d.active){
        if(Math.abs(dx)<15||Math.abs(dx)<Math.abs(dy)*1.4)return;
        const dir=dx<0?1:-1;
        if(!this.flipPage(dir,{drag:true})){this.drag=null;return}
        d.active=true;d.dir=dir;
        try{host.setPointerCapture(e.pointerId)}catch{}
      }
      if(d.active){e.preventDefault();this.draw(Math.abs(dx)/Math.max(140,host.clientWidth*.7))}
    };
    this.onUp=e=>{
      const d=this.drag;if(!d||d.id!==e.pointerId)return;
      const dx=e.clientX-d.x,dy=e.clientY-d.y;
      this.drag=null;
      if(d.active){this.draw(Math.max(this.flip?.progress||0,Math.abs(dx)/Math.max(140,host.clientWidth*.7)));this.finishFlip(Math.abs(dx)>Math.max(65,host.clientWidth*.17));return}
      if(Math.abs(dx)<16&&Math.abs(dy)<16&&!e.target.closest('[data-word]')){
        const x=e.clientX-host.getBoundingClientRect().left;
        if(x>host.clientWidth*.82)this.navigate(1);
        else if(x<host.clientWidth*.18)this.navigate(-1);
      }
    };
    this.onCancel=()=>{this.drag=null;if(this.flip)this.finishFlip(false)};
    host.addEventListener('pointerdown',this.onDown);
    host.addEventListener('pointermove',this.onMove);
    host.addEventListener('pointerup',this.onUp);
    host.addEventListener('pointercancel',this.onCancel);
    // Reflow when screen orientation or browser viewport changes. Keep current word cursor.
    this.onResize=()=>{
      if(this.destroyed)return;
      clearTimeout(this.resizeTimer);
      this.resizeTimer=setTimeout(()=>{
        if(this.destroyed)return;
        const cursor=this.pages[this.pageIndex]?.start||{verse:0,word:0};
        this.config.cursor=cursor;
        this.makePages();this.renderPage();this.remember();
      },220);
    };
    window.addEventListener('resize',this.onResize);
  }
  destroy(){this.destroyed=true;clearTimeout(this.timer);clearTimeout(this.resizeTimer);this.node?.removeEventListener('pointerdown',this.onDown);this.node?.removeEventListener('pointermove',this.onMove);this.node?.removeEventListener('pointerup',this.onUp);this.node?.removeEventListener('pointercancel',this.onCancel);window.removeEventListener('resize',this.onResize)}
}
window.GS_PAGE_TURN={mount:(node,config)=>new BookReader(node,config)};
})();
