## v2.2.2
- Removed the Vishraam / Pause toggle UI everywhere (home card, menu, Reading settings, Bani View Preferences). Gurbani text now renders plain black; the bundled vishraam.json data is kept for a possible future return.
- Removed the kosh orange word highlight in reading views (Bani scroll, Ang view). Tap-a-word still works on every word — meaning popup follows the visible "Word meaning language" setting.
- Removed the "Sundar Gutka / Bani collection" home card and every user-facing "Sundar Gutka" label/mention (drawer, library, catalog headings). Banis remain reachable via Nitnem and Anek Baniyaan. Source attribution kept in SOURCE_AND_LICENSE.md / README only.
- Nitnem Banis appear ONLY in the Nitnem section — removed from the Anek Baniyaan catalog.
- Anek Baniyaan catalog rebuilt: lists only the 22 Banis with full bundled offline text (was 75 name-only entries). No entry without text is shown anywhere.
- New visible Settings toggle: "Word meaning language — Punjabi / English" (ਅਰਥਾਂ ਦੀ ਭਾਸ਼ਾ), default Punjabi. Tap-a-word meanings now follow it, with graceful fallback to the other language when a meaning is missing.
## v2.2.1
- Kobo-style Reading settings sheet (Aa button): new **Tone** slider (screen dimmer between sun icons, red slider), theme pills **Light / Sepia / Dark / Charcoal** — Light is now **pure white (#ffffff)** background by default (the old dusky tint is gone).
- Font choice is now 3 Gurmukhi-safe system stacks: Book (serif), Clean (sans), System — no bundled font files.
- Margins (Narrow/Comfort/Wide) now also change the reading column width (700/630/520px).
- All reading settings persist on-device and are included in backup/restore.
## v2.2.0
- Sundar Gutka (Damdami Taksal) Bani layout: light page, dark Gurmukhi body, pankti-per-line, traditional opening header (orange ੴ), centered titles and chhand headings, side drawer with Bani list, new ਸੁੰਦਰ ਗੁਟਕਾ menu (7 items; content-less entries show "coming soon", never fabricated scripture).
- Vishraam pause colors from bundled www/offline/vishraam.json: green = short pause, orange = long pause; marks never invented. Visible ਵਿਸ਼ਰਾਮ / Pause switch on home, reading settings, and Bani View Preferences; default ON.
- iGranth-style search: dark blue header, clear/mic/options buttons, icon row, built-in 35-key Gurmukhi first-letter keyboard, Raag/Mahla + Ang results.
- Layered verses (Gurmukhi / Transliteration / English / Punjabi / Shabad Arth) for Ang, Bani, and Kirtan; Bani View Preferences screen with Night Mode and Bani text size.
- Voice search root-caused and fixed: removed the hanging pre-listen language-list await, added 15s safety timer, clear runtime permission prompt, live heard-text in the search box, Web Speech API fallback, Settings "Test microphone". Workflow runs npm ci (bundled lockfile) before cap sync, fail-fasts on missing voice bundle, verifies RECORD_AUDIO.
- Tap-a-word: exact → kosh-stems.json longest-first → ॥।/numeral strip → silent give-up; kosh words render orange; fully offline.
- Kirtan Shabad book: browsable/searchable full Shabads from bundled Angs, layered display, "View full Ang" link.
- Ask Guru Granth Sahib: offline retrieval labeled "Related Shabads (offline)"; optional "AI answer" via user's API key (OpenAI-compatible, constrained system prompt with Ang citations); private-server hook kept.
- Honest caveats: not device-tested; Taksal text/vishraam exactness needs Karamjit's on-device review; vishraam.json, kosh-stems.json, kirtan-shabads.json ship via the data pipeline and are required by the workflow.
## v2.1.0
- Bundle the full offline library IN the source ZIP: 1,430 Angs (60,555 lines), prebuilt search index (60,555 rows), 29 Banis (7 Nitnem + 22 Sundar Gutka, 9,452 lines), 6,963-word Punjabi/English dictionary. Removed the GitHub build-time text download step; the workflow now requires the bundled offline files and fails fast if missing.
- Voice search: mic button wired to the real Capacitor speech-recognition plugin (Punjabi pa-IN preferred, English fallback); RECORD_AUDIO permission added.
- Tap-a-word: fully offline against the bundled dictionary, respects English/Punjabi setting, keeps dismiss controls.
- Text source switched from BaniDB-at-build to Shabad OS database (MIT); English glosses shabados/translation (CC BY-SA 4.0); word meanings Mahan Kosh multilingual dataset (CC BY 4.0). See SOURCE_AND_LICENSE.md.
- Removed the duplicate legacy workflow `.github/workflows/android-apk.yml`.
- Honest caveats: Damdami Taksal exactness of Bani texts needs the user's review; Vishraam data not bundled (toggle inert); English/Roman search modes have no data; not device-tested.
## v1.8.0
- Replace verse-by-verse blocks with **genuine continuous inline scripture text** when meanings are hidden; paragraph gaps no longer appear in Compact, Standard or Spacious.
- Apply spacing settings to actual line height, and preserve meanings under individual verses when enabled.
- Page-turn animation speed control: Slow (default 1250 ms), Normal (800 ms), Fast (430 ms).
- Build a search index from the offline 1,430-Ang source as part of the GitHub build, for quoted-text search and source references.
- Search the corpus from Kirtan Shabads, save verse references and open the original Ang, offline.
- Fix Ask Gurbani home card navigation; Ask Gurbani: referenced passage retrieval locally; optional secure AI server integration (requires separate server setup).
- Daily Gurbani preview now reads from actual bundled scripture, not a hardcoded sample.
- No MP3 or audio controls. Same Android application ID and signing process.

## v1.7.0
- 3D page-flip framework, Scroll/Page Turn choice, and initial continuous layout experimentation.
