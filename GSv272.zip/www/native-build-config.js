window.GS_BUILD={"version":"2.2.52","repo":"","hideAiSettings":false};
