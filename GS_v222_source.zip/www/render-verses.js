/* Gurbani Saanjh v2.2.0 — pure layered verse renderer (no DOM, no network).
 * Shared by the Ang reader, Bani reader and Kirtan book so all three show the
 * same stacked layers in the same order:
 *   Gurmukhi / Transliteration (roman) / English / Punjabi / Shabad Arth
 * Tokenization follows the vishraam data contract EXACTLY:
 *   g.trim().split(/\s+/)  — INCLUDING ॥..॥ numeral tokens.
 * Exposes window.GS_VERSES. Testable in node via vm (see test-v220.mjs).
 */
(()=>{
'use strict';
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
// EXACT contract tokenization — never change this without changing the data.
const tokens=g=>String(g||'').trim().split(/\s+/).filter(Boolean);
// Word cleanup ONLY for dictionary lookup (display keeps the original token).
const cleanWord=w=>String(w||'').normalize('NFC').replace(/^[॥।,;!?(){}\[\]"'“”‘’]+|[॥।,;!?(){}\[\]"'“”‘’]+$/gu,'').replace(/[੦-੯0-9]+/gu,'').trim();
const stanzaEnds=s=>/(?:॥|\|\|)\s*[੦-੯0-9]+\s*(?:॥|\|\|)\s*$/u.test(String(s||'').trim())||/ਰਹਾਉ\s*(?:॥|\|\|)/u.test(String(s||''));
const wordCount=s=>String(s||'').trim().split(/\s+/).filter(Boolean).length;
// Conservative Sundar Gutka chhand/section heading detection. Only short,
// clearly-marked headings qualify — never a regular pankti.
function isBaniHeading(g){
 const t=String(g||'').trim();if(!t)return false;
 const wc=wordCount(t);
 if(/^॥[^॥]*॥$/.test(t))return true;
 if(/ਛੰਦ/.test(t)&&wc<=10)return true;
 if(/ਸਵੱਯੇ|ਸਵਈਆ|ਸਵੈਯਾ/.test(t)&&wc<=10)return true;
 if(/ਚੌਪਈ/.test(t)&&wc<=10)return true;
 if(/ਪਾਤਿਸਾਹੀ|ਮੁਖਵਾਕ/.test(t)&&wc<=10)return true;
 if(/^(ਜਾਪੁ|ਜਪੁ)\s*॥/.test(t))return true;
 return false;
}
// Traditional opening header is rendered only when the Bani text itself does
// not already carry the manglacharan (avoids duplicating scripture).
function baniHeaderNeeded(lines){
 const first=String(lines?.[0]?.g||'');
 if(/ਸਤਿਗੁਰ\s*ਪ੍ਰਸਾਦਿ/.test(first))return false;
 if(/ਵਾਹਿਗੁਰੂ\s*ਜੀ\s*ਕੀ\s*ਫਤਹ/.test(first))return false;
 return true;
}
/* Render ONE verse as stacked layers.
 * line: {g, roman?, en?, pa?, hi?}
 * o: {idx, kind('ang'|'bani'|'kirtan'), vishraamOn, marks:{widx:'s'|'l'}|null,
 *     legacyVishraam:{widx:'short'|'long'}|null, koshHas(word)->bool,
 *     arth:[{word,meaning}]|null, show:{translit,en,pa,hi,arth},
 *     heading:bool, gurmukhiClass:''|'gs-gurmukhi-blue'}
 */
function verseHTML(line,o={}){
 const show=o.show||{};
 const idx=Number(o.idx)||0,kind=o.kind||'ang';
 const parts=tokens(line.g);
 const marks=o.marks||null,legacy=o.legacyVishraam||null;
 const koshHas=typeof o.koshHas==='function'?o.koshHas:null;
 const words=parts.map((part,w)=>{
  let cls='word',vCls='';
  if(o.vishraamOn){
   const m=marks?marks[w]:null;
   if(m==='s')vCls=' vishraam-short';
   else if(m==='l')vCls=' vishraam-long';
   else{
    const lm=legacy?legacy[w]:null;
    if(lm==='short')vCls=' vishraam-short';
    else if(lm==='long')vCls=' vishraam-long';
   }
  }
  // No orange/color highlight on kosh words (plain black text per user request).
  // Tap-a-word still works: every word is a button with data-word.
  const kCls='';
  return `<button type="button" class="${cls}${vCls}${kCls}" data-word="${esc(part)}" data-kind="${kind}" data-idx="${idx}" data-widx="${w}" lang="pa" aria-label="${esc(part)}">${esc(part)}</button>`;
 }).join(' ');
 const variant=kind==='bani'?'gs-bani-pankti':kind==='kirtan'?'gs-kirtan-pankti':'gs-sggs-pankti';
 const boundary=stanzaEnds(line.g)?' gs-stanza-end':'';
 const heading=o.heading?' gs-verse-heading':'';
 const gClass='verse-text'+(o.gurmukhiClass?' '+o.gurmukhiClass:'');
 let html=`<div class="verse-block gs-pankti ${variant}${boundary}${heading}" data-line="${idx}"><div class="${gClass}" lang="pa">${words}</div>`;
 const roman=String(line.roman||'').trim();
 if(show.translit&&roman)html+=`<div class="verse-layer verse-roman" lang="en">${esc(roman)}</div>`;
 const en=String(line.en||'').trim();
 if(show.en&&en)html+=`<div class="verse-layer verse-en" lang="en">${esc(en)}</div>`;
 const pa=String(line.pa||'').trim();
 if(show.pa&&pa)html+=`<div class="verse-layer verse-pa" lang="pa">${esc(pa)}</div>`;
 const hi=String(line.hi||'').trim();
 if(show.hi&&hi)html+=`<div class="verse-layer verse-hi" lang="hi">${esc(hi)}</div>`;
 const arth=Array.isArray(o.arth)?o.arth:[];
 if(show.arth&&arth.length){
  html+=`<div class="verse-layer verse-arth" lang="pa">${arth.map(a=>`<span class="arth-pair"><b>${esc(a.word)}</b> = ${esc(a.meaning)}</span>`).join(' ')}</div>`;
 }
 return html+'</div>';
}
window.GS_VERSES={esc,tokens,cleanWord,stanzaEnds,isBaniHeading,baniHeaderNeeded,verseHTML};
})();
