/* Gurbani Saanjh v2.2.71 — Karamjit 2026-11-17 (his go: "ਹਾਂ, v2.2.71 ਬਣਾ ਦਿਓ").
 * His words: "I'm talking about the spacing. I'm not talking about the
 * lines." + circled photos (book: Dhanaasari heading + Mool Mantar; app:
 * Maajh heading flowing into the verse) + "This one too" (the Dhanaasari
 * heading AND its Mool Mantar) + "Earlier one was wrong" (the first
 * mockup, which flowed the Mool Mantar with the verse).
 * Three things, exactly as planned and shown in the corrected mockups:
 * (1) Heading fix (render-verses.js): "Raag Mahala N ... Ghar N" lines
 *     are now headings — audit of ALL Bani lines: exactly 5 newly-
 *     classified headings, all real, zero verse lines misclassified.
 *     Before, they flowed into the following verse in the Bani reader
 *     (the Ang reader was unaffected — each Ang line is its own block —
 *     which is why the v2.2.69 data fix never showed up in the Bani
 *     reader). Headings render as centred bold blocks on their own line;
 *     the verse starts on the next line.
 * (2) Mool Mantar on its own line (render-verses.js): the full Mool
 *     Mantar line ends its paragraph, so the verse after it starts on
 *     the next line, like iGranth. Only 4 such lines exist in all Banis
 *     and the other three are already followed by a heading, so in
 *     practice only Shabad Hazare [18] changes. Regular weight, NOT bold.
 * (3) Bilawal Mool Mantar join (data): Shabad Hazare [79] + Ang 795[0]
 *     (the same line, id S97P) — words joined like the Dhanaasari one
 *     in v2.2.69. g + roman only; en/pa/id untouched.
 * No lines added or removed anywhere, no index shifts, saved verses
 * unaffected. Run: node test-v291.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v271-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const bani = (id) => j(`www/offline/bani/${id}.json`).lines;
const ang = (n) => j(`www/offline/ang/${n}.json`).lines;
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const V0 = loadV(readR('www/render-verses.js'));
const groups = (lines) => V.groupBaniParagraphs(lines).map((g) => `${g.type[0]}:${g.items.map((x) => x.idx).join(',')}`);
const groups0 = (lines) => V0.groupBaniParagraphs(lines).map((g) => `${g.type[0]}:${g.items.map((x) => x.idx).join(',')}`);

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.71', vj.version === '2.2.71');
ok('package.json is 2.2.71', pj.version === '2.2.71');
ok('native-build-config.js is 2.2.71', nbc.includes('"version":"2.2.71"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.71 entry (spacing + headings + Bilawal join)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.71:') &&
  vj.notes.includes("I'm talking about the spacing") && vj.notes.includes('Bilawal Mool Mantar'));
ok('package.json + native-build-config.js differ from v2.2.70 ONLY in the version string',
  read('package.json').replace('2.2.71', '2.2.70') === readR('package.json') &&
  nbc.replace('2.2.71', '2.2.70') === readR('www/native-build-config.js'));

// ---- 1. Heading rule: the 5 headings, and no verse misclassified ----
const FIVE = [
  [113, 1, 'ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥'],
  [116, 0, 'ਮਾਝ ਮਹਲਾ ੫ ਚਉਪਦੇ ਘਰੁ ੧ ॥'],
  [116, 17, 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥'],
  [116, 34, 'ਤਿਲੰਗ ਮਹਲਾ ੧ ਘਰੁ ੩ ॥'],
  [123, 0, 'ਬਾਰਹ ਮਾਹਾ ਮਾਂਝ ਮਹਲਾ ੫ ਘਰੁ ੪ ॥'],
];
for (const [bid, idx, g] of FIVE) {
  ok(`heading recognised: Bani ${bid}[${idx}] '${g}'`, V.isBaniHeading(g) && bani(bid)[idx].g === g);
}
const NOT_HEADING = [
  'ਮੇਰਾ ਮਨੁ ਲੋਚੈ ਗੁਰ ਦਰਸਨ ਤਾਈ ॥',
  'ਜੀਉ ਡਰਤੁ ਹੈ ਆਪਣਾ ਕੈ ਸਿਉ ਕਰੀ ਪੁਕਾਰ ॥',
  'ਸੇਵੀ ਸਾਹਿਬੁ ਆਪਣਾ ਅਵਰੁ ਨ ਜਾਚੰਉ ਕੋਇ ॥',
  'ਤੁਧੁ ਬਾਝੁ ਪਿਆਰੇ ਕੇਵ ਰਹਾ ॥',
  'ਹਰਿ ਅੰਮ੍ਰਿਤ ਭਿੰਨੇ ਲੋਇਣਾ ਮਨੁ ਪ੍ਰੇਮਿ ਰਤੰਨਾ ਰਾਮ ਰਾਜੇ ॥',
  'ਮੇਰੈ ਕੰਤ ਨ ਭਾਵੈ ਚੋਲੜਾ ਪਿਆਰੇ ਕਿਉ ਧਨ ਸੇਜੈ ਜਾਏ ॥੧॥',
];
for (const g of NOT_HEADING) ok(`still a verse, not a heading: '${g.slice(0, 28)}…'`, !V.isBaniHeading(g));
{
  // Full audit: old code vs new code over EVERY Bani line — exactly the
  // 5 headings change classification, nothing else.
  const diff = [];
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani')).filter((f) => f.endsWith('.json'))) {
    const lines = j(`www/offline/bani/${f}`).lines || [];
    lines.forEach((l, i) => { if (V.isBaniHeading(l.g) !== V0.isBaniHeading(l.g)) diff.push(`${f.replace('.json', '')}:${i}`); });
  }
  ok('audit: exactly 5 newly-classified headings across ALL Banis (113:1, 116:0, 116:17, 116:34, 123:0)',
    JSON.stringify(diff.sort()) === JSON.stringify(['113:1', '116:0', '116:17', '116:34', '123:0']));
}
ok('render-verses.js carries the v2.2.71 heading-rule comment + Ghar pattern',
  read('www/render-verses.js').includes('v2.2.71: "Raag Mahala N ... Ghar N" headings') &&
  read('www/render-verses.js').includes('ਘਰੁ') && read('www/render-verses.js').includes('ਚਉਪਦੇ|ਛੰਤ|ਛੰਦ'));

// ---- 2. Grouping: headings stand alone, verses start on the next line ----
{
  const g116 = groups(bani(116));
  ok('Shabad Hazare groups: heading [0] alone, verse para [1,2,3] next',
    JSON.stringify(g116.slice(0, 3)) === JSON.stringify(['h:0', 'p:1,2,3', 'p:4,5,6,7']));
  ok('Shabad Hazare groups: heading [17] alone, Mool Mantar [18] alone, verse para [19,20] next',
    JSON.stringify(g116.slice(6, 9)) === JSON.stringify(['h:17', 'p:18', 'p:19,20']));
  ok('Shabad Hazare groups: Tilang heading [34] alone, ੴ heading [35] alone, verse para [36,37] next',
    JSON.stringify(g116.slice(13, 16)) === JSON.stringify(['h:34', 'h:35', 'p:36,37']));
  ok('Shabad Hazare groups: Bilawal Mool Mantar [79] alone, heading [80] alone, verse para [81,82] next',
    JSON.stringify(g116.slice(29, 32)) === JSON.stringify(['p:79', 'h:80', 'p:81,82']));
  ok('Shabad Hazare full group list is exactly the expected 40 groups',
    g116.length === 40 && g116[0] === 'h:0' && g116[g116.length - 1] === 'p:101,102');
  ok('Asa Di Vaar groups: ੴ heading [0], Asa heading [1] alone, verse para [2,3,4,5] next',
    JSON.stringify(groups(bani(113)).slice(0, 3)) === JSON.stringify(['h:0', 'h:1', 'p:2,3,4,5']));
  ok('Barah Maha groups: heading [0] alone, ੴ heading [1] alone, verse para next',
    JSON.stringify(groups(bani(123)).slice(0, 3)) === JSON.stringify(['h:0', 'h:1', 'p:2,3,4,5,6,7,8,9,10,11']));
  // Old code vs new code over EVERY Bani: only 113, 116, 123 change.
  const changed = [];
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani')).filter((f) => f.endsWith('.json'))) {
    const lines = j(`www/offline/bani/${f}`).lines || [];
    if (JSON.stringify(groups0(lines)) !== JSON.stringify(groups(lines))) changed.push(f.replace('.json', ''));
  }
  ok('grouping changed in exactly 3 Banis (113, 116, 123) — every other Bani renders identically',
    JSON.stringify(changed.sort()) === JSON.stringify(['113', '116', '123']));
}

// ---- 3. Mool Mantar split: only Shabad Hazare [18] changes in practice ----
{
  const isMool = (g) => /^ੴ\s+ਸਤਿ\s*ਨਾਮੁ\s+ਕਰਤਾ\s+ਪੁਰਖੁ/.test(String(g || '').trim());
  const mools = [];
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani')).filter((f) => f.endsWith('.json'))) {
    const lines = j(`www/offline/bani/${f}`).lines || [];
    lines.forEach((l, i) => { if (isMool(l.g)) mools.push(`${f.replace('.json', '')}:${i}`); });
  }
  ok('exactly 4 full Mool Mantar lines exist in all Banis (113:6, 116:18, 116:79, 2:0)',
    JSON.stringify(mools.sort()) === JSON.stringify(['113:6', '116:18', '116:79', '2:0']));
  ok('Japji grouping is byte-identical old vs new (Mool Mantar [0] already stood alone)',
    JSON.stringify(groups0(bani(2))) === JSON.stringify(groups(bani(2))));
  ok('render-verses.js carries the v2.2.71 Mool Mantar comment + helper',
    read('www/render-verses.js').includes('v2.2.71: the full Mool Mantar line') &&
    read('www/render-verses.js').includes('isMoolMantar'));
}

// ---- 4. Bilawal Mool Mantar join (data) ----
{
  const OLD_G = 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
  const NEW_G = 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥';
  const OLD_R = 'ik oankaar sat naam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gur prasaad |';
  const NEW_R = 'ik oankaar satinaam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gurprasaad |';
  ok('Bani 116[79] words joined (g + roman); en/pa/id untouched',
    bani(116)[79].g === NEW_G && bani(116)[79].roman === NEW_R &&
    bani(116)[79].en === jr('www/offline/bani/116.json').lines[79].en &&
    bani(116)[79].pa === jr('www/offline/bani/116.json').lines[79].pa &&
    bani(116)[79].id === 'S97P');
  ok('Ang 795[0] words joined (g + roman); the same line in both places',
    ang(795)[0].g === NEW_G && ang(795)[0].roman === NEW_R && ang(795)[0].id === 'S97P' &&
    ang(795)[0].en === bani(116)[79].en && ang(795)[0].pa === bani(116)[79].pa);
  ok('Bani 116 still has 103 lines; Ang 795 line count unchanged; no index shifts',
    bani(116).length === 103 && ang(795).length === jr('www/offline/ang/795.json').lines.length);
  const sj = j('www/offline/search.json');
  const sjR = jr('www/offline/search.json'); // parsed ONCE — parsing it per row takes hours
  ok('search.json still 60,555 rows; row [795,0] joined; all other rows identical',
    sj.length === 60555 &&
    JSON.stringify(sj.find((r) => r[0] === 795 && r[1] === 0)) ===
      JSON.stringify([795, 0, NEW_G, '', '', NEW_R]) &&
    sj.filter((r, i) => JSON.stringify(r) !== JSON.stringify(sjR[i])).length === 1);
  const bs = j('www/offline/bani-search.json');
  const bsR = jr('www/offline/bani-search.json');
  ok('bani-search.json still 9,315 rows; exactly one row changed — (116,79) joined',
    bs.length === 9315 && bs.filter((r, i) => JSON.stringify(r) !== JSON.stringify(bsR[i])).length === 1 &&
    JSON.stringify(bs.find((r) => r[0] === 116 && r[1] === 79)[2]) === JSON.stringify(NEW_G));
  ok('manifest counts unchanged: searchVerseCount 60,555; baniCount 29; angCount 1430; vishraam 86,833',
    j('www/offline/manifest.json').searchVerseCount === 60555 &&
    j('www/offline/manifest.json').baniCount === 29 &&
    j('www/offline/manifest.json').angCount === 1430 &&
    j('www/offline/manifest.json').vishraamMarkCount === 86833);
  ok('vishraam.json byte-identical to v2.2.70',
    fs.readFileSync(path.join(ROOT, 'www/offline/vishraam.json')).equals(
      fs.readFileSync(path.join(ROLL, 'www/offline/vishraam.json'))));
  const walk = (dir) => {
    const out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) out.push(...walk(p));
      else out.push(p);
    }
    return out;
  };
  const offChanged = walk(path.join(ROOT, 'www/offline'))
    .map((f) => path.relative(ROOT, f))
    .filter((f) => read(f) !== readR(f));
  ok('only 4 offline files changed: ang/795, bani/116, bani-search, search',
    JSON.stringify(offChanged.sort()) === JSON.stringify([
      'www/offline/ang/795.json', 'www/offline/bani-search.json',
      'www/offline/bani/116.json', 'www/offline/search.json']));
}

// ---- 5. render-verses.js differs from v2.2.70 ONLY by the two v2.2.71 inserts + the flush line ----
{
  const rv = read('www/render-verses.js');
  const rvR = readR('www/render-verses.js');
  let back = rv;
  const hStart = back.indexOf('// v2.2.71: "Raag Mahala N');
  const hEnd = back.indexOf('return true;', hStart) + 'return true;'.length;
  ok('heading-rule block found as one contiguous insert', hStart > 0 && hEnd > hStart);
  back = back.slice(0, hStart - 1) + back.slice(hEnd);
  const mStart = back.indexOf('// v2.2.71: the full Mool Mantar line');
  const mLine = back.indexOf('isMoolMantar=g=>', mStart);
  const mEnd = back.indexOf(';\n', mLine) + 2; // +2 consumes the trailing newline too
  ok('Mool Mantar helper found as one contiguous insert', mStart > 0 && mEnd > mStart);
  back = back.slice(0, mStart) + back.slice(mEnd);
  back = back.replace('if(verseNumEnd(g)||isMoolMantar(g))flush();', 'if(verseNumEnd(g))flush();');
  ok('render-verses.js differs from v2.2.70 ONLY by the heading rule + Mool Mantar helper + flush line',
    back === rvR);
}

// ---- 6. Nothing else changed ----
{
  const walk = (dir) => {
    const out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.isDirectory() && (e.name === 'node_modules' || e.name === 'tmp')) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) out.push(...walk(p));
      else out.push(p);
    }
    return out;
  };
  const changed = ['www/render-verses.js', 'www/offline/ang/795.json', 'www/offline/bani/116.json',
    'www/offline/bani-search.json', 'www/offline/search.json',
    'www/version.json', 'package.json', 'www/native-build-config.js'];
  const added = ['test-v291.mjs', 'scripts/fix-v271.py'];
  const mine = new Set(walk(ROOT).map((f) => path.relative(ROOT, f)));
  const theirs = new Set(walk(ROLL).map((f) => path.relative(ROLL, f)));
  let clean = true;
  for (const f of theirs) {
    if (changed.includes(f)) continue;
    if (!mine.has(f) || read(f) !== readR(f)) { clean = false; console.log(`  changed/missing: ${f}`); }
  }
  const newFiles = [...mine].filter((f) => !theirs.has(f)).sort();
  ok('every other file is byte-identical to v2.2.70', clean);
  ok('the only new files are test-v291.mjs + scripts/fix-v271.py',
    JSON.stringify(newFiles) === JSON.stringify([...added].sort()));
  ok('app.js and styles.css are byte-identical to v2.2.70 (no UI-code change beyond render-verses.js)',
    read('www/app.js') === readR('www/app.js') && read('www/styles.css') === readR('www/styles.css'));
}

// ---- 7. Kept from earlier versions ----
{
  const app = read('www/app.js');
  const css = read('www/styles.css');
  ok('kept v2.2.70: 10 Punjabi labels still Punjabi; Night Mode block still present',
    app.includes("viewPrefs:'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ'") && app.includes("nightMode:'ਨਾਈਟ ਮੋਡ'") &&
    css.includes('v2.2.70: Night Mode had the same invisible-text problem') &&
    css.includes('html[data-nightmode="on"] .hukam-page { background: var(--paper); }'));
  ok('kept v2.2.69: Dhanaasari Mool Mantar words still joined (Ang 660[1] + Bani 116[18])',
    ang(660)[1].g === 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥' &&
    bani(116)[18].g === 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥');
  ok('kept v2.2.68: Dark tone block exists; Check-for-updates button still gone',
    css.includes('html[data-tone="dark"]{') && !app.includes('data-action="check-update"'));
  ok('kept v2.2.67: Rehras Taksal still opens with the Chhant (ੴ deleted at [0], kept ੴ at [4])',
    bani(21)[0].g.startsWith('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ') && bani(21)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
  ok('kept v2.2.65: Mundavni Bani (126) still gone',
    !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
  ok('kept v2.2.64: Jaap Fateh line still at (4,1); Rehras Short ੴ still before ਸਲੋਕੁ ਮਃ ੧',
    bani(4)[1].g === 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥' && bani(107)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
  ok('kept: Ang 1 Mool Mantar still SPACED (scope guard — only the Dhanaasari/Bilawal copies join)',
    ang(1)[0].g.includes('ਸਤਿ ਨਾਮੁ') && !ang(1)[0].g.includes('ਸਤਿਨਾਮੁ'));
  ok('kept: Japji Mool Mantar (Bani 2[0]) still SPACED — only Shabad Hazare [79] joins',
    bani(2)[0].g.includes('ਸਤਿ ਨਾਮੁ') && !bani(2)[0].g.includes('ਸਤਿਨਾਮੁ'));
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
