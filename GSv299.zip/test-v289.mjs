/* Gurbani Saanjh v2.2.69 — CORRECTED spacing fix (Karamjit 2026-11-16).
 * His correction after the first build: the heading goes on its OWN
 * first line and the verse starts on the NEXT line — the heading and
 * the verse are NOT joined into one line ("ਜਿਹੜਾ 'ਹਰਿ ਅੰਮ੍ਰਿਤ ਭਿੰਨੇ
 * ਲੋਇਣਾ' ਉਹ ਅਗਲੀ ਲਾਈਨ ਚ, ਉਹਨਾਂ ਨਾਲ ਦੀ ਨਾਲ ਨਹੀਂ ਸਟਾਰਟ ਕਰਨਾ").
 * So NO merges at all. The ONLY change: in the Dhanaasari Mahala 1
 * Mool Mantar line, the words join to match iGranth — "ਸਤਿ ਨਾਮੁ" ->
 * "ਸਤਿਨਾਮੁ", "ਗੁਰ ਪ੍ਰਸਾਦਿ" -> "ਗੁਰਪ੍ਰਸਾਦਿ" (roman "sat naam" ->
 * "satinaam", "gur prasaad" -> "gurprasaad"). That line exists twice
 * (Ang 660 [1] + Shabad Hazare 116 [18], same line id AH1X); both
 * copies are fixed. Asa (Ang 448) and Maajh (Ang 96) need NO change —
 * their headings were already on their own lines with the verse on the
 * next line. Ang 1's Mool Mantar stays SPACED — only the Dhanaasari
 * copy joins. No lines added or removed, no index shifts, no
 * saved-verse side effect; vishraam.json untouched.
 * manifest searchVerseCount corrected to the true Ang row count 60,555
 * (was 60,385 — the v2.2.65/67 Bani deletions had been subtracted from
 * an Ang count by mistake; bundle-offline.mjs defines it as
 * searchRows.length).
 * NO colours changed: the green/orange in his iGranth screenshot is
 * iGranth's Vishraam colouring; our app shows plain black text by
 * design (v2.2.7 removed the Vishraam toggle UI).
 * Kept from v2.2.68: Dark/Charcoal fixes + Check-for-updates removed.
 * Kept from v2.2.67: Rehras opens with the Chhant, kept ੴ at [4].
 * Kept from v2.2.66: all 5 renames/move. Kept from v2.2.65: Mundavni
 * still gone. Kept from v2.2.64: Jaap Fateh (4,1), Rehras Short ੴ.
 * Run: node test-v289.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v269-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const ang = (n) => j(`www/offline/ang/${n}.json`).lines;
const bani = (id) => j(`www/offline/bani/${id}.json`).lines;
const angR = (n) => jr(`www/offline/ang/${n}.json`).lines;
const baniR = (id) => jr(`www/offline/bani/${id}.json`).lines;

const MOOL_JOINED = 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥';
const MOOL_JOINED_ROMAN = 'ik oankaar satinaam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gurprasaad |';
const MOOL_SPACED = 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const DHAN_HEADING = 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥';
const ASA_HEADING = 'ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥';
const ASA_VERSE = 'ਹਰਿ ਅੰਮ੍ਰਿਤ ਭਿੰਨੇ ਲੋਇਣਾ ਮਨੁ ਪ੍ਰੇਮਿ ਰਤੰਨਾ ਰਾਮ ਰਾਜੇ ॥';
const MAAJH_HEADING = 'ਮਾਝ ਮਹਲਾ ੫ ਚਉਪਦੇ ਘਰੁ ੧ ॥';
const MAAJH_VERSE = 'ਮੇਰਾ ਮਨੁ ਲੋਚੈ ਗੁਰ ਦਰਸਨ ਤਾਈ ॥';
// The WRONG merged lines from the first build — must not exist anywhere.
const MERGED_DHAN = 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥';
const MERGED_ASA = 'ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥ ਹਰਿ ਅੰਮ੍ਰਿਤ ਭਿੰਨੇ ਲੋਇਣਾ ਮਨੁ ਪ੍ਰੇਮਿ ਰਤੰਨਾ ਰਾਮ ਰਾਜੇ ॥';
const MERGED_MAAJH = 'ਮਾਝ ਮਹਲਾ ੫ ਚਉਪਦੇ ਘਰੁ ੧ ॥ ਮੇਰਾ ਮਨੁ ਲੋਚੈ ਗੁਰ ਦਰਸਨ ਤਾਈ ॥';

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.69', vj.version === '2.2.69');
ok('package.json is 2.2.69', pj.version === '2.2.69');
ok('native-build-config.js is 2.2.69', nbc.includes('"version":"2.2.69"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.69 entry (Dhanaasari, joined words, headings NOT joined, searchVerseCount 60,555)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.69:') &&
  vj.notes.includes('Dhanaasari Mahala 1') && vj.notes.includes('ਸਤਿਨਾਮੁ') &&
  vj.notes.includes('NOT joined into one line') && vj.notes.includes('60,555'));
ok('package.json + native-build-config.js differ from v2.2.68 ONLY in the version string',
  read('package.json').replace('2.2.69', '2.2.68') === readR('package.json') &&
  nbc.replace('2.2.69', '2.2.68') === readR('www/native-build-config.js'));

// ---- 1. The one changed line (two copies): exact text ----
ok('Ang 660[1] Mool Mantar words joined (g + roman exact)',
  ang(660)[1].g === MOOL_JOINED && ang(660)[1].roman === MOOL_JOINED_ROMAN);
ok('Bani 116[18] Mool Mantar words joined (same text as Ang 660[1])',
  bani(116)[18].g === MOOL_JOINED && bani(116)[18].roman === MOOL_JOINED_ROMAN);
ok('the Mool Mantar en/pa/id unchanged (only g + roman joined)',
  ang(660)[1].en === angR(660)[1].en && ang(660)[1].pa === angR(660)[1].pa && ang(660)[1].id === 'AH1X' &&
  bani(116)[18].en === baniR(116)[18].en && bani(116)[18].pa === baniR(116)[18].pa && bani(116)[18].id === 'AH1X');
ok('Ang + Bani Mool Mantar lines still identical on g/en/pa/roman/id',
  ['g', 'en', 'pa', 'roman', 'id'].every((k) => ang(660)[1][k] === bani(116)[18][k]));

// ---- 2. Headings stay on their OWN lines; verses start on the NEXT line ----
ok('Dhanaasari heading is its own line (with ॥) and the Mool Mantar is the NEXT line',
  ang(660)[0].g === DHAN_HEADING && ang(660)[1].g === MOOL_JOINED &&
  bani(116)[17].g === DHAN_HEADING && bani(116)[18].g === MOOL_JOINED);
ok('Asa heading is its own line and the verse is the NEXT line (unchanged from v2.2.68)',
  ang(448)[26].g === ASA_HEADING && ang(448)[27].g === ASA_VERSE &&
  bani(113)[1].g === ASA_HEADING && bani(113)[2].g === ASA_VERSE);
ok('Maajh heading is its own line and the verse is the NEXT line (unchanged from v2.2.68)',
  ang(96)[23].g === MAAJH_HEADING && ang(96)[24].g === MAAJH_VERSE &&
  bani(116)[0].g === MAAJH_HEADING && bani(116)[1].g === MAAJH_VERSE);
ok('NO merged heading+verse line exists anywhere in the corpus (the first-build mistake is gone)',
  (() => {
    const allG = [];
    for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/ang'))) allG.push(...ang(Number(f.replace(/\.json$/i, ''))).map((l) => l.g));
    for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani'))) allG.push(...bani(Number(f.replace(/\.json$/i, ''))).map((l) => l.g));
    return !allG.includes(MERGED_DHAN) && !allG.includes(MERGED_ASA) && !allG.includes(MERGED_MAAJH);
  })());
ok('line counts UNCHANGED everywhere touched (no lines added or removed): 660:27, 448:30, 96:34, 113:734, 116:103',
  ang(660).length === 27 && ang(448).length === 30 && ang(96).length === 34 &&
  bani(113).length === 734 && bani(116).length === 103);
ok('every line except the two Mool Mantar lines is byte-identical to v2.2.68 (ids + text)',
  (() => {
    for (const n of [660, 448, 96]) {
      const a = ang(n), b = angR(n);
      if (a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) {
        if (n === 660 && i === 1) continue;
        if (JSON.stringify(a[i]) !== JSON.stringify(b[i])) return false;
      }
    }
    for (const id of [113, 116]) {
      const a = bani(id), b = baniR(id);
      if (a.length !== b.length) return false;
      for (let i = 0; i < a.length; i++) {
        if (id === 116 && i === 18) continue;
        if (JSON.stringify(a[i]) !== JSON.stringify(b[i])) return false;
      }
    }
    return true;
  })());

// ---- 3. search.json (Ang search index) ----
const sj = j('www/offline/search.json');
const sjR = jr('www/offline/search.json');
ok('search.json: still 60,555 rows (no merges, no shifts)',
  sj.length === 60555 && sjR.length === 60555);
{
  const row = (a, i) => sj.find((r) => r[0] === a && r[1] === i);
  ok('search.json row [660,1] carries the joined Mool Mantar (g + roman, en/pa empty as always)',
    row(660, 1)[2] === MOOL_JOINED && row(660, 1)[5] === MOOL_JOINED_ROMAN && row(660, 1)[3] === '' && row(660, 1)[4] === '');
  ok('every OTHER search.json row is identical to v2.2.68',
    sj.every((r) => {
      if (r[0] === 660 && r[1] === 1) return true;
      const old = sjR.find((x) => x[0] === r[0] && x[1] === r[1]);
      return old && JSON.stringify(old) === JSON.stringify(r);
    }));
}

// ---- 4. bani-search.json (Bani search index, rebuilt) ----
const bs = j('www/offline/bani-search.json');
const bsR = jr('www/offline/bani-search.json');
ok('bani-search.json: still 9,315 rows (no merges, no shifts)',
  bs.length === 9315 && bsR.length === 9315);
{
  const row = (b, i) => bs.find((r) => r[0] === b && r[1] === i);
  ok('bani-search.json row (116,18) carries the joined Mool Mantar',
    row(116, 18)[2] === MOOL_JOINED);
  ok('every OTHER bani-search.json row is identical to v2.2.68',
    bs.every((r) => {
      if (r[0] === 116 && r[1] === 18) return true;
      const old = bsR.find((x) => x[0] === r[0] && x[1] === r[1]);
      return old && JSON.stringify(old) === JSON.stringify(r);
    }));
  ok('build-bani-search.mjs header count still (29 Banis, 9,315 lines)',
    read('scripts/build-bani-search.mjs').includes('29 Banis, 9,315 lines'));
}

// ---- 5. vishraam.json: untouched ----
ok('vishraam.json byte-identical to v2.2.68 (no marks on the Mool Mantar lines, no index shifts)',
  read('www/offline/vishraam.json') === readR('www/offline/vishraam.json'));
{
  const vm = j('www/offline/vishraam.json').marks;
  ok('vishraam marks total still 86,833; no marks on the changed lines (a660:1, b116:18)',
    Object.keys(vm).length === 86833 &&
    !Object.keys(vm).some((k) => k.startsWith('a660:1:') || k.startsWith('b116:18:')));
}

// ---- 6. Manifest ----
const man = j('www/offline/manifest.json');
const manR = jr('www/offline/manifest.json');
ok('manifest searchVerseCount is 60,555 (true Ang row count; was 60,385, 170 low)',
  man.searchVerseCount === 60555 && manR.searchVerseCount === 60385);
ok('manifest baniCount 29, angCount 1430, vishraamMarkCount 86,833 unchanged',
  man.baniCount === 29 && man.angCount === 1430 && man.vishraamMarkCount === 86833);

// ---- 7. Nothing else changed ----
{
  let clean = true;
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/ang')).sort()) {
    const n = Number(f.replace(/\.json$/i, ''));
    if (n === 660) continue;
    if (read(`www/offline/ang/${f}`) !== readR(`www/offline/ang/${f}`)) { clean = false; console.log(`  changed: ang/${f}`); }
  }
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani')).sort()) {
    const n = Number(f.replace(/\.json$/i, ''));
    if (n === 116) continue;
    if (read(`www/offline/bani/${f}`) !== readR(`www/offline/bani/${f}`)) { clean = false; console.log(`  changed: bani/${f}`); }
  }
  ok('every other Ang + Bani file is byte-identical to v2.2.68', clean);
  ok('app code untouched: app.js, styles.css, index.html, catalog.js, render-verses.js, vishraam.js, scripture-search.js byte-identical',
    ['www/app.js', 'www/styles.css', 'www/index.html', 'www/catalog.js',
     'www/render-verses.js', 'www/vishraam.js', 'www/scripture-search.js']
      .every((p) => read(p) === readR(p)));
}

// ---- 8. Scope guard: only THESE two copies changed ----
{
  const allG = [];
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/ang'))) allG.push(...ang(Number(f.replace(/\.json$/i, ''))).map((l) => l.g));
  for (const f of fs.readdirSync(path.join(ROOT, 'www/offline/bani'))) allG.push(...bani(Number(f.replace(/\.json$/i, ''))).map((l) => l.g));
  const count = (s) => allG.filter((g) => g === s).length;
  ok('Ang 1 Mool Mantar still spaced (scope: only the Dhanaasari Mool Mantar joins)',
    ang(1)[0].g === MOOL_SPACED);
  ok('the joined Mool Mantar occurs exactly twice in the whole corpus (Ang 660[1] + Bani 116[18])',
    count(MOOL_JOINED) === 2);
  ok('no spaced "ਸਤਿ ਨਾਮੁ" survives in the two Dhanaasari Mool Mantar lines',
    !ang(660)[1].g.includes('ਸਤਿ ਨਾਮੁ') && !bani(116)[18].g.includes('ਸਤਿ ਨਾਮੁ') &&
    !ang(660)[1].g.includes('ਗੁਰ ਪ੍ਰਸਾਦਿ') && !bani(116)[18].g.includes('ਗੁਰ ਪ੍ਰਸਾਦਿ'));
}

// ---- 9. Kept from earlier versions ----
{
  const css = read('www/styles.css');
  const app = read('www/app.js');
  ok('kept v2.2.68: Dark tone block exists; Check-for-updates button still gone',
    css.includes('html[data-tone="dark"]{') && !app.includes('data-action="check-update"'));
  ok('kept v2.2.67: Rehras Taksal still opens with the Chhant (ੴ deleted at [0], kept ੴ at [4])',
    bani(21)[0].g.startsWith('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ') && bani(21)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
  ok('kept v2.2.66: Bhog title still the long form; catalog still Sundar Gutka',
    j('www/offline/manifest.json').banis.some((b) => b.id === 127) &&
    read('www/catalog.js').includes('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ'));
  ok('kept v2.2.65: Mundavni Bani (126) still gone',
    !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
  ok('kept v2.2.64: Jaap Fateh line still at (4,1); Rehras Short ੴ still before ਸਲੋਕੁ ਮਃ ੧',
    bani(4)[1].g === 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥' && bani(107)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
