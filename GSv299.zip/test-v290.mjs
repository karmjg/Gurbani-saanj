/* Gurbani Saanjh v2.2.70 — Karamjit 2026-11-17 (his go: "ਹਾਂ, v2.2.70 ਬਣਾ ਦਿਓ").
 * Two things, exactly as planned and shown in the mockups:
 * (1) Punjabi labels: the app language is Punjabi but 10 strings in
 *     txt.pa (www/app.js) were still English. They now carry Punjabi
 *     values; txt.en is untouched, so English mode stays English. The
 *     same strings feed the Bani View Preferences screen, the Settings
 *     menu card + subtitle, and the reader settings sheet. The Ask
 *     offline line names the screen too, so its Punjabi sentence gets
 *     the Punjabi name as well.
 * (2) Night Mode fix (CSS-only, mirrors v2.2.68's Dark/Charcoal
 *     overrides): Night Mode turns the text light but the Hukamnama
 *     page/frame, Home tiles, bottom bar, Ask quotes and daily card
 *     stayed light — the Hukamnama Gurmukhi was white on cream
 *     (invisible, his video). html[data-nightmode="on"] overrides for
 *     those surfaces. Light/Sepia with Night Mode off are unchanged.
 * NOT included: the optional doubled-descriptions shortening — he did
 * not pick it, so the slider descs stay as they are.
 * No data changes: no Ang/Bani/search/manifest/vishraam file is touched.
 * Run: node test-v290.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v270-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const bani = (id) => j(`www/offline/bani/${id}.json`).lines;
const ang = (n) => j(`www/offline/ang/${n}.json`).lines;

const PA = [
  ['viewPrefs', 'Bani View Preferences', 'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ'],
  ['nightMode', 'Night Mode', 'ਨਾਈਟ ਮੋਡ'],
  ['translit', 'Transliteration', 'ਲਿਪੀਅੰਤਰ'],
  ['enTrans', 'English Translation', 'ਅੰਗਰੇਜ਼ੀ ਅਨੁਵਾਦ'],
  ['paTrans', 'Punjabi Translation', 'ਪੰਜਾਬੀ ਅਨੁਵਾਦ'],
  ['shabadArth', 'Shabad Arth', 'ਸ਼ਬਦ ਅਰਥ'],
  ['baniTextSize', 'Bani Text Size', 'ਬਾਣੀ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ'],
  ['tSizeNormal', 'Normal', 'ਆਮ'],
  ['tSizeLarge', 'Large', 'ਵੱਡਾ'],
  ['tSizeXLarge', 'Extra-large', 'ਬਹੁਤ ਵੱਡਾ'],
];
const OLD_AI_PA = 'AI ਔਫਲਾਈਨ ਹੈ — Bani View Preferences › AI ਵਿੱਚ API key ਜਾਂ ਆਪਣਾ ਸਰਵਰ ਜੋੜੋ।';
const NEW_AI_PA = 'AI ਔਫਲਾਈਨ ਹੈ — ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ › AI ਵਿੱਚ API key ਜਾਂ ਆਪਣਾ ਸਰਵਰ ਜੋੜੋ।';

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.70', vj.version === '2.2.70');
ok('package.json is 2.2.70', pj.version === '2.2.70');
ok('native-build-config.js is 2.2.70', nbc.includes('"version":"2.2.70"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.70 entry (Punjabi labels + Night Mode)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.70:') &&
  vj.notes.includes('ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ') && vj.notes.includes('Night Mode now truly goes dark') &&
  vj.notes.includes('Gurmukhi was invisible'));
ok('package.json + native-build-config.js differ from v2.2.69 ONLY in the version string',
  read('package.json').replace('2.2.70', '2.2.69') === readR('package.json') &&
  nbc.replace('2.2.70', '2.2.69') === readR('www/native-build-config.js'));

// ---- 1. Punjabi labels ----
const app = read('www/app.js');
const lines = app.split('\n');
const paLine = lines.find((l) => l.includes("viewPrefs:'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ'"));
const enLine = lines.find((l) => l.includes("viewPrefs:'Bani View Preferences'"));
ok('Pa labels line found (viewPrefs is Punjabi); En labels line still exists separately',
  !!paLine && !!enLine && paLine !== enLine);
for (const [k, en, pa] of PA) {
  ok(`txt.pa ${k} is Punjabi ('${pa}')`, paLine.includes(`${k}:'${pa}'`));
  ok(`txt.en ${k} is still English ('${en}')`, enLine.includes(`${k}:'${en}'`));
  ok(`txt.pa ${k} no longer carries the English value`, !paLine.includes(`${k}:'${en}'`));
}
ok('the other Pa strings on the same line are untouched (font colour, layer size)',
  paLine.includes("fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ'") && paLine.includes("fontBlack:'ਕਾਲਾ'") &&
  paLine.includes("fontBlue:'ਨੀਲਾ'") && paLine.includes("layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ'"));
ok("Ask offline Pa line uses the Punjabi screen name ('ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ › AI')",
  app.includes(NEW_AI_PA) && !app.includes(OLD_AI_PA));
ok('Ask offline En line still names the screen in English',
  app.includes('add an API key or your private server in Bani View Preferences › AI.'));
ok("'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ' occurs exactly twice in app.js (Pa label + Ask line)",
  app.split('ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ').length - 1 === 2);
ok('the doubled slider descs are NOT changed (he did not pick that option)',
  app.includes("age('ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ — ਸਾਰੇ ਪਾਠ ਲਈ','Letter size — for all scripture text')") &&
  app.includes("age('ਰੋਮਨ + ਅੰਗਰੇਜ਼ੀ + ਪੰਜਾਬੀ — ਇੱਕੋ ਆਕਾਰ','Roman + English + Punjabi — one size')"));

// ---- 2. Night Mode CSS ----
const css = read('www/styles.css');
const cssR = readR('www/styles.css');
const NM = 'html[data-nightmode="on"]';
const NM_RULES = [
  [`${NM} .hukam-page { background: var(--paper); }`, 'hukam-page follows theme'],
  [`${NM} .hukam-frame { background: var(--surface); }`, 'hukam-frame follows theme'],
  [`${NM} .hukam-meta { color: var(--gold); }`, 'hukam-meta gold'],
  [`${NM} .hukam-stale { color: var(--muted); }`, 'hukam-stale muted'],
  [`${NM} .hukam-verses .verse-block { border-bottom-color: var(--line); }`, 'hukam verse dividers'],
  [`${NM} .home-v7 .tile-3d { background: linear-gradient(135deg,#26392e,#1f2a25); border-color: #48604f; border-bottom-color: #37493b;`, 'home v7 tiles dark'],
  [`${NM} .home-v10 .home-tile.tile-3d:not(.tile-daily) { background: linear-gradient(130deg,#23382b,#24392c); border-color: #53674d; }`, 'home v10 tiles dark'],
  [`${NM} .home-v10 .home-tile strong:not(.tile-daily strong) { color: #e8f2df; }`, 'home v10 tile text light'],
  [`${NM} .bottomnav { background: rgba(11,14,12,.97);`, 'bottom bar dark'],
  [`${NM} .ai-verse { color: #202a26; }`, 'Ask quotes dark text'],
  [`${NM} .daily-card, ${NM} .daily-preview { background: #1e3327; border-color: #3c5843; }`, 'daily card/preview dark'],
  [`${NM} .daily-card p, ${NM} .daily-preview p { color: #d3e1d4; }`, 'daily card text light'],
  [`${NM} .daily-icon { background: #2d4535; }`, 'daily icon dark'],
];
for (const [rule, name] of NM_RULES) ok(`nightmode rule present: ${name}`, css.includes(rule));
ok('nightmode block carries the v2.2.70 comment',
  css.includes('v2.2.70: Night Mode had the same invisible-text problem v2.2.68 fixed'));
{
  // Removing exactly the inserted block must restore the v2.2.69 stylesheet.
  const start = css.indexOf('\n/* v2.2.70: Night Mode had the same invisible-text problem');
  const endMarker = `${NM} .daily-icon { background: #2d4535; }`;
  const end = css.indexOf(endMarker) + endMarker.length;
  ok('nightmode block found as one contiguous insert', start > 0 && end > start);
  const stripped = css.slice(0, start) + css.slice(end);
  ok('styles.css differs from v2.2.69 ONLY by the inserted nightmode block', stripped === cssR);
}
ok('nightmode verse colours unchanged (white Gurmukhi, green en, maroon pa)',
  css.includes(`${NM} .verse-text { color: #ffffff; }`) &&
  css.includes(`${NM} .verse-roman, ${NM} .verse-en { color: #58d68d; }`) &&
  css.includes(`${NM} .verse-pa, ${NM} .verse-hi, ${NM} .verse-arth { color: #b76e79; }`));
ok('nightmode Bani reader still dark (unchanged)',
  css.includes(`${NM} .gs-reader-bani, ${NM} .gs-reader-bani .reading { background: #0b0e0c; }`));

// ---- 3. app.js differs from v2.2.69 ONLY in the Pa labels + Ask line ----
{
  const appR = readR('www/app.js');
  let back = app;
  const paOld = "  viewPrefs:'Bani View Preferences',nightMode:'Night Mode',translit:'Transliteration',enTrans:'English Translation',paTrans:'Punjabi Translation',shabadArth:'Shabad Arth',baniTextSize:'Bani Text Size',tSizeNormal:'Normal',tSizeLarge:'Large',tSizeXLarge:'Extra-large',fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ',fontBlack:'ਕਾਲਾ',fontBlue:'ਨੀਲਾ',layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ',";
  const paNew = "  viewPrefs:'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ',nightMode:'ਨਾਈਟ ਮੋਡ',translit:'ਲਿਪੀਅੰਤਰ',enTrans:'ਅੰਗਰੇਜ਼ੀ ਅਨੁਵਾਦ',paTrans:'ਪੰਜਾਬੀ ਅਨੁਵਾਦ',shabadArth:'ਸ਼ਬਦ ਅਰਥ',baniTextSize:'ਬਾਣੀ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',tSizeNormal:'ਆਮ',tSizeLarge:'ਵੱਡਾ',tSizeXLarge:'ਬਹੁਤ ਵੱਡਾ',fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ',fontBlack:'ਕਾਲਾ',fontBlue:'ਨੀਲਾ',layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ',";
  ok('Pa labels line is the expected new line', back.includes(paNew) && !back.includes(paOld));
  back = back.replace(paNew, paOld).replace(NEW_AI_PA, OLD_AI_PA);
  ok('app.js differs from v2.2.69 ONLY in the Pa labels line + Ask offline line', back === appR);
}

// ---- 4. Data untouched ----
{
  const walk = (dir) => {
    const out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) out.push(...walk(p));
      else out.push(p);
    }
    return out;
  };
  const offFiles = walk(path.join(ROOT, 'www/offline'));
  let clean = true;
  for (const f of offFiles) {
    const rel = path.relative(ROOT, f);
    if (read(rel) !== readR(rel)) { clean = false; console.log(`  changed: ${rel}`); }
  }
  ok('every offline data file is byte-identical to v2.2.69 (no data changes)', clean);
  const man = j('www/offline/manifest.json');
  ok('manifest counts unchanged: searchVerseCount 60,555; baniCount 29; angCount 1430; vishraam 86,833',
    man.searchVerseCount === 60555 && man.baniCount === 29 && man.angCount === 1430 && man.vishraamMarkCount === 86833);
}

// ---- 5. Nothing else changed ----
{
  const walk = (dir) => {
    const out = [];
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      // node_modules + tmp are excluded from the zip (zip -x), so they
      // never ship and are not compared against the rollback.
      if (e.isDirectory() && (e.name === 'node_modules' || e.name === 'tmp')) continue;
      const p = path.join(dir, e.name);
      if (e.isDirectory()) out.push(...walk(p));
      else out.push(p);
    }
    return out;
  };
  const changed = ['www/app.js', 'www/styles.css', 'www/version.json', 'package.json', 'www/native-build-config.js'];
  const added = ['test-v290.mjs', 'scripts/fix-v270.py'];
  const mine = new Set(walk(ROOT).map((f) => path.relative(ROOT, f)));
  const theirs = new Set(walk(ROLL).map((f) => path.relative(ROLL, f)));
  let clean = true;
  for (const f of theirs) {
    if (changed.includes(f)) continue;
    if (!mine.has(f) || read(f) !== readR(f)) { clean = false; console.log(`  changed/missing: ${f}`); }
  }
  const newFiles = [...mine].filter((f) => !theirs.has(f)).sort();
  ok('every other file is byte-identical to v2.2.69', clean);
  ok('the only new files are test-v290.mjs + scripts/fix-v270.py',
    JSON.stringify(newFiles) === JSON.stringify([...added].sort()));
}

// ---- 6. Kept from earlier versions ----
{
  ok('kept v2.2.68: Dark tone block exists; Check-for-updates button still gone',
    css.includes('html[data-tone="dark"]{') && !app.includes('data-action="check-update"'));
  ok('kept v2.2.68: tone overrides for hukam/bottomnav/ai-verse still present',
    css.includes('html[data-tone="dark"] .hukam-page') &&
    css.includes('html[data-tone="dark"] .bottomnav') &&
    css.includes('html[data-tone="dark"] .ai-verse'));
  ok('kept v2.2.67: Rehras Taksal still opens with the Chhant (ੴ deleted at [0], kept ੴ at [4])',
    bani(21)[0].g.startsWith('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ') && bani(21)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
  ok('kept v2.2.66: Bhog title still the long form; catalog still Sundar Gutka',
    app.includes("catalog:'Sundar Gutka'") || read('www/catalog.js').includes('ਸੁੰਦਰ ਗੁਟਕਾ'));
  ok('kept v2.2.65: Mundavni Bani (126) still gone',
    !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
  ok('kept v2.2.64: Jaap Fateh line still at (4,1); Rehras Short ੴ still before ਸਲੋਕੁ ਮਃ ੧',
    bani(4)[1].g === 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥' && bani(107)[4].g === 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥');
  ok('kept v2.2.69: Dhanaasari Mool Mantar words still joined (Ang 660[1] + Bani 116[18])',
    ang(660)[1].g === 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥' &&
    bani(116)[18].g === 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥');
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
