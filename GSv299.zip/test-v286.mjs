/* Gurbani Saanj v2.2.66 — Amrik Veerji's feedback (confirmed by Karamjit
 * 2026-11-14, item by item). Exactly 5 changes against v2.2.65, ALL
 * renames / one move — NOTHING added, no Bani added, no lines added:
 * (1) Bhog (127) RENAMED: titlePa "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ
 * ਭੋਗ ਦੇ ਸਲੋਕ", titleEn "Sri Guru Granth Sahib Ji de Paath de Bhog de
 * Salok". Rename ONLY — the Bhog's 231 lines are byte-identical.
 * (2) Catalog RENAMED: 'ਅਨੇਕ ਬਾਣੀਆਂ' -> 'ਸੁੰਦਰ ਗੁਟਕਾ' (Pa) and
 * 'Anek Baaniyaan' -> 'Sundar Gutka' (En). The same t('catalog') string
 * feeds the catalog screen heading AND the Home page card, so the main
 * page card now reads 'ਸੁੰਦਰ ਗੁਟਕਾ' too.
 * (3) Dasam section RENAMED: 'ਦਸਮ ਗ੍ਰੰਥ ਸੰਬੰਧੀ ਬਾਣੀਆਂ' ->
 * 'ਦਸਮ ਪਾਤਸ਼ਾਹ ਦੀਆਂ ਬਾਣੀਆਂ' (Pa), 'Dasam Granth related compositions' ->
 * 'Dasam Patshah Dian Banian' (En).
 * (4) Ardas (114) MOVED out of the catalog into Nitnem, between Rehras
 * (21) and Rakhia De Shabad (130), as in the Gutka. It is still a Bani
 * file (114.json, 27 lines) — only its listing moves. Its search group
 * stays 'tradition' via the nitnem mirror in build-bani-search.mjs.
 * (5) Section 3 RENAMED: 'ਹੋਰ ਪਾਠ ਅਤੇ ਵੱਖਰੇ ਰੂਪ' -> 'ਹੋਰ ਪਾਠ ਅਤੇ
 * ਬਾਣੀ ਰੂਪ' (Pa), 'Other recitations and variations' -> 'Other
 * recitations and Bani forms' (En); 'ਵੱਡੀ ਆਰਤੀ' (110) -> 'ਆਰਤੀ (ਵੱਡੀ)'
 * (Pa), 'Aarti (Longer)' -> 'Aarti (Vaddi)' (En).
 * Data changes (all verified): catalog.js 21->20 entries (114 deleted,
 * 127 + 110 retitled); manifest banis still 29, baniCount still 29
 * (114 is still a Bani, just listed under Nitnem now); bani-search.json
 * rebuilt (9,316 lines, unchanged total; the diff is exactly the 231
 * retitled 127 tuples + the 116 retitled 110 tuples; 114's 27 tuples
 * byte-identical). No Bani file changed; vishraam.json untouched.
 * Kept from v2.2.65: 126 (Mundavni) still gone everywhere; 127 lines
 * byte-identical. Kept from v2.2.64: Jaap Fateh (4,1), Rehras ੴ (21,5)
 * and (107,4). Kept from v2.2.63: Kirtan heart fallback + stay-put save
 * + Saved remove, language-toggle hang guards, no Mool Mantar in the
 * drawer, ensureCatalog, icon row gone, clock after ਪੁ/EN, pills nowrap.
 * No Help button (cancelled).
 * Mockups (white, our style): catalog-v266-mockup-white.webp,
 * menu-v266-mockup-white.webp, home-v266-mockup-white.webp.
 * Run: node test-v286.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v266-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const catSrc = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
const bani = (id) => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8'));
const g = (lines, i) => (lines[i] && lines[i].g) || '';
const ONKAR = 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const FATEH = 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥';
const BHOG_PA = 'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ';
const BHOG_EN = 'Sri Guru Granth Sahib Ji de Paath de Bhog de Salok';
const AARTI_PA = 'ਆਰਤੀ (ਵੱਡੀ)';
const AARTI_EN = 'Aarti (Vaddi)';

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.66', vj.version === '2.2.66');
ok('package.json is 2.2.66', pj.version === '2.2.66');
ok('native-build-config.js is 2.2.66', nbc.includes('"version":"2.2.66"'));
ok('version notes mention v2.2.66 + Sundar Gutka + Ardas + Bhog rename',
  vj.notes.includes('v2.2.66:') && vj.notes.includes('Sundar Gutka') &&
  vj.notes.includes('Ardas') && vj.notes.includes('Bhog de Salok'));

// ---- 1a. Strings (app.js): catalog + section 2 + section 3, both languages ----
ok("Pa string catalog is 'ਸੁੰਦਰ ਗੁਟਕਾ'", app.includes("catalog:'ਸੁੰਦਰ ਗੁਟਕਾ'"));
ok("En string catalog is 'Sundar Gutka'", app.includes("catalog:'Sundar Gutka'"));
ok("Pa string section2 is 'ਦਸਮ ਪਾਤਸ਼ਾਹ ਦੀਆਂ ਬਾਣੀਆਂ'",
  app.includes("catalogSection2:'ਦਸਮ ਪਾਤਸ਼ਾਹ ਦੀਆਂ ਬਾਣੀਆਂ'"));
ok("En string section2 is 'Dasam Patshah Dian Banian'",
  app.includes("catalogSection2:'Dasam Patshah Dian Banian'"));
ok("Pa string section3 is 'ਹੋਰ ਪਾਠ ਅਤੇ ਬਾਣੀ ਰੂਪ'",
  app.includes("catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਬਾਣੀ ਰੂਪ'"));
ok("En string section3 is 'Other recitations and Bani forms'",
  app.includes("catalogSection3:'Other recitations and Bani forms'"));
ok('old strings are gone from app.js (Anek / Dasam Granth related / variations / ਵੱਖਰੇ ਰੂਪ / ਵੱਡੀ ਆਰਤੀ)',
  !app.includes('ਅਨੇਕ ਬਾਣੀਆਂ') && !app.includes('Anek Baaniyaan') &&
  !app.includes('ਦਸਮ ਗ੍ਰੰਥ ਸੰਬੰਧੀ') && !app.includes('Dasam Granth related') &&
  !app.includes('ਵੱਖਰੇ ਰੂਪ') && !app.includes('Other recitations and variations') &&
  !app.includes('ਵੱਡੀ ਆਰਤੀ') && !app.includes('Aarti (Longer)'));
ok('Home catalog card uses t(catalog) — so the main page shows Sundar Gutka too',
  app.includes("catalog:t('catalog')"));

// ---- 1b. NITNEM_LIST + drawer: Ardas between Rehras (21) and Rakhia (130) ----
{
  const m = app.match(/const NITNEM_LIST=\[([\s\S]*?)\];/);
  ok('NITNEM_LIST exists and has 9 entries with Ardas (114) between 21 and 130',
    !!m && m[1].includes("['ਅਰਦਾਸ','Ardas',114]") &&
    m[1].indexOf("['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',21]") <
    m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") &&
    m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") <
    m[1].indexOf("['ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ','Rakhia De Shabad',130]"));
  ok('drawer nitnemIds is [2,4,6,9,10,21,114,130,23]',
    app.includes('const nitnemIds=[2,4,6,9,10,21,114,130,23];'));
}

// ---- 1c. Catalog (www/catalog.js): 20 entries, no 114, 127 + 110 retitled ----
{
  const catCtx = { window: {} };
  vm.runInNewContext(catSrc, catCtx);
  const cat = catCtx.window.GS_CATALOG || [];
  ok('catalog: 20 entries (was 21 — only 114 left)', cat.length === 20);
  ok('catalog: no entry with id 114', !cat.some((c) => c.id === 114));
  const c127 = cat.find((c) => c.id === 127);
  ok('catalog: ID 127 titlePa is exactly the new Bhog title',
    !!c127 && c127.titlePa === BHOG_PA);
  ok('catalog: ID 127 titleEn is exactly the new Bhog title',
    !!c127 && c127.titleEn === BHOG_EN);
  ok('catalog: ID 127 still in group sggs, neighbours still 109 (Aarti) then 117',
    !!c127 && c127.group === 'sggs' &&
    cat[cat.findIndex((c) => c.id === 127) - 1].id === 109 &&
    cat[cat.findIndex((c) => c.id === 127) + 1].id === 117);
  const c110 = cat.find((c) => c.id === 110);
  ok('catalog: ID 110 titlePa is exactly "ਆਰਤੀ (ਵੱਡੀ)"',
    !!c110 && c110.titlePa === AARTI_PA);
  ok('catalog: ID 110 titleEn is exactly "Aarti (Vaddi)"',
    !!c110 && c110.titleEn === AARTI_EN);
  ok('catalog: ID 110 still in group tradition, after 124 and before 106',
    !!c110 && c110.group === 'tradition' &&
    cat[cat.findIndex((c) => c.id === 110) - 1].id === 124 &&
    cat[cat.findIndex((c) => c.id === 110) + 1].id === 106);
  ok('catalog: id order is exactly the v2.2.65 order minus 114',
    (() => {
      const rollSrc = fs.readFileSync(path.join(ROLL, 'www/catalog.js'), 'utf8');
      const rollCtx = { window: {} };
      vm.runInNewContext(rollSrc, rollCtx);
      const rollIds = rollCtx.window.GS_CATALOG.map((c) => c.id).filter((id) => id !== 114);
      return JSON.stringify(cat.map((c) => c.id)) === JSON.stringify(rollIds);
    })());
  ok('catalog: no old strings anywhere in catalog.js',
    !/ਅਨੇਕ ਬਾਣੀਆਂ|ਵੱਡੀ ਆਰਤੀ|Aarti \(Longer\)|ਪਾਠ ਦਾ ਭੋਗ"/.test(catSrc));
}

// ---- 1d. Manifest: still 29 Banis; only 127 + 110 titles changed ----
{
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8'));
  const rm = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/manifest.json'), 'utf8'));
  ok('manifest: baniCount still 29, banis list still 29', m.baniCount === 29 && m.banis.length === 29);
  const b127 = m.banis.find((b) => b.id === 127);
  ok('manifest: ID 127 titlePa is the new Bhog title', !!b127 && b127.titlePa === BHOG_PA);
  ok('manifest: ID 127 titleEn is the new Bhog title', !!b127 && b127.titleEn === BHOG_EN);
  const b110 = m.banis.find((b) => b.id === 110);
  ok('manifest: ID 110 titlePa is "ਆਰਤੀ (ਵੱਡੀ)"', !!b110 && b110.titlePa === AARTI_PA);
  ok('manifest: ID 110 titleEn is "Aarti (Vaddi)"', !!b110 && b110.titleEn === AARTI_EN);
  ok('manifest: ID 114 still listed (it is still a Bani — only its catalog listing moved)',
    !!m.banis.find((b) => b.id === 114));
  ok('manifest: every other Bani title is byte-identical to v2.2.65',
    m.banis.every((b) => {
      if (b.id === 127 || b.id === 110) return true;
      const r = rm.banis.find((x) => x.id === b.id);
      return !!r && r.titlePa === b.titlePa && r.titleEn === b.titleEn;
    }));
  ok('manifest: counts unchanged (searchVerseCount 60386, vishraam 86833/28342/58491, angCount 1430)',
    m.searchVerseCount === 60386 && m.vishraamMarkCount === 86833 &&
    m.vishraamShortCount === 28342 && m.vishraamLongCount === 58491 && m.angCount === 1430);
}

// ---- 1e. Bani files: 127 + 110 + 114 lines byte-identical to v2.2.65 ----
{
  for (const id of [127, 110, 114]) {
    const oldB = JSON.parse(fs.readFileSync(path.join(ROLL, `www/offline/bani/${id}.json`), 'utf8'));
    const newB = bani(id);
    ok(`${id}.json: lines byte-identical to v2.2.65 (${newB.lines.length} lines)`,
      JSON.stringify(newB.lines) === JSON.stringify(oldB.lines));
  }
  ok('127.json: 231 lines, first line ੴ, last line the Nanak closing',
    bani(127).lines.length === 231 && g(bani(127).lines, 0) === ONKAR &&
    g(bani(127).lines, 230) === 'ਨਾਨਕ ਤੇ ਮੁਖ ਉਜਲੇ ਕੇਤੀ ਛੁਟੀ ਨਾਲਿ ॥੧॥');
  ok('114.json (Ardas) still exists with 27 lines',
    fs.existsSync(path.join(ROOT, 'www/offline/bani/114.json')) && bani(114).lines.length === 27);
}

// ---- 1f. Search index: 9,316 lines; 127 + 110 retitled; 114 identical ----
{
  const bs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const rbs = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/bani-search.json'), 'utf8'));
  ok('bani-search.json: 9,316 lines (unchanged total)', bs.length === 9316);
  const per = {};
  for (const r of bs) per[r[0]] = (per[r[0]] || 0) + 1;
  ok('bani-search.json: 231 entries for 127, all with the new Bhog titles',
    per[127] === 231 && bs.filter((r) => r[0] === 127).every((r) => r[6] === BHOG_PA && r[7] === BHOG_EN));
  ok('bani-search.json: 116 entries for 110, all with the new Aarti titles',
    per[110] === 116 && bs.filter((r) => r[0] === 110).every((r) => r[6] === AARTI_PA && r[7] === AARTI_EN));
  ok('bani-search.json: 27 entries for 114, byte-identical to v2.2.65 (same titles, group tradition)',
    per[114] === 27 &&
    JSON.stringify(bs.filter((r) => r[0] === 114)) === JSON.stringify(rbs.filter((r) => r[0] === 114)));
  ok('bani-search.json: diff vs v2.2.65 is exactly the 347 retitled tuples (231 + 116), nothing else',
    (() => {
      let n = 0;
      for (let i = 0; i < rbs.length; i++) {
        if (JSON.stringify(bs[i]) !== JSON.stringify(rbs[i])) {
          n++;
          if (bs[i].slice(0, 6).join('|') !== rbs[i].slice(0, 6).join('|') || bs[i][8] !== rbs[i][8]) return false;
        }
      }
      return n === 347;
    })());
  ok('bani-search.json: no old titles anywhere ("ਪਾਠ ਦਾ ਭੋਗ" without "ਦੇ ਸਲੋਕ", "ਵੱਡੀ ਆਰਤੀ", "Aarti (Longer)")',
    !bs.some((r) => r[6] === 'ਵੱਡੀ ਆਰਤੀ' || r[7] === 'Aarti (Longer)' ||
      r[6] === 'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ' || r[7] === 'Sri Guru Granth Sahib Paath Bhog'));
  ok('bani-search.json: 29 distinct Bani ids', Object.keys(per).length === 29);
}

// ---- 1g. Nitnem mirror in build-bani-search.mjs ----
{
  const bs = fs.readFileSync(path.join(ROOT, 'scripts/build-bani-search.mjs'), 'utf8');
  ok('build script mirror has Ardas (114) between 21 and 130, group tradition',
    bs.includes("[114, 'ਅਰਦਾਸ', 'Ardas', 'tradition']") &&
    bs.indexOf("[21, 'ਰਹਰਾਸਿ ਸਾਹਿਬ'") < bs.indexOf("[114, 'ਅਰਦਾਸ'") &&
    bs.indexOf("[114, 'ਅਰਦਾਸ'") < bs.indexOf("[130, 'ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ'"));
  ok('build script header counts updated (29 Banis, 9,316 lines, 20 catalog, 9 Nitnem)',
    bs.includes('29 Banis, 9,316 lines') && bs.includes('20 catalog Banis') && bs.includes('9 Nitnem titles'));
}

// ---- 2. Kept from v2.2.65: Mundavni still gone ----
ok('v2.2.65: 126.json still deleted', !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
ok('v2.2.65: no Mundavni title in catalog, manifest or search index',
  !/Mundav|ਮੁੰਦਾਵਣੀ/.test(
    catSrc + JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8')).banis.map((b) => b.titlePa + ' ' + b.titleEn).join(' ')) +
    JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8')).map((r) => r[6] + ' ' + r[7]).join(' ')));

// ---- 3. Kept from v2.2.64 ----
{
  const d4 = bani(4), L4 = d4.lines;
  ok('v2.2.64: Jaap (ID 4) still 802 lines, [1] is the Fateh line',
    L4.length === 802 && g(L4, 1) === FATEH && g(L4, 0) === ONKAR && g(L4, 2) === 'ਜਾਪੁ ॥');
  const d21 = bani(21), L21 = d21.lines;
  ok('v2.2.64: Rehras Taksal (ID 21) still 422 lines, [5] is ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L21.length === 422 && g(L21, 5) === ONKAR && g(L21, 6) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  const d107 = bani(107), L107 = d107.lines;
  ok('v2.2.64: Rehras Short (ID 107) still 340 lines, [4] is ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L107.length === 340 && g(L107, 4) === ONKAR && g(L107, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
}

// ---- 4. Kept markers (v2.2.63 / 62 / 61 / 60 / 59 / 58 / 57, no Help) ----
ok('v2.2.63: Kirtan fallback present (save from kirtanBookList when lookup() is null)',
  app.includes('Kirtan book fallback') && app.includes('const s=kb.find(x=>x.ang===ang&&x.lineStart===idx);'));
ok('v2.2.63: stay-put — heart updates in place, no render() on the save-hit path',
  app.includes("save.classList.toggle('selected',added);") && app.includes("save.textContent=added?'♥':'♡';"));
ok('v2.2.63: no navigation to bookmarks anywhere (no go(bookmarks))',
  !app.includes("go('bookmarks')"));
ok('v2.2.63: Saved tab rows have a remove control (data-remove-saved ♥)',
  (() => { const bm = app.split('\n').find((l) => l.startsWith('function bookmarksScreen(){')); return !!bm && bm.includes('data-remove-saved=') && bm.includes('</button><button data-remove-saved='); })());
ok('v2.2.62: language-toggle hang guards still in ensureHukamnama',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.60: Kirtan heart button still on each Shabad row (data-save-hit ang:lineStart)',
  app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: History clock still AFTER the ਪੁ/EN button in the search box',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 5. Mockups exist (v2.2.66, white, our style) ----
{
  const gfxAbs = '/home/hatch/workspace/gurbani/play-store/graphics';
  for (const f of ['catalog-v266-mockup-white.webp', 'menu-v266-mockup-white.webp', 'home-v266-mockup-white.webp']) {
    ok(`mockup exists: ${f}`, fs.existsSync(path.join(gfxAbs, f)) && fs.statSync(path.join(gfxAbs, f)).size > 10000);
  }
}

// ---- 6. vm: the REAL scripture search over the REAL rebuilt index ----
{
  const ssSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sggs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
  const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const sandbox = {
    console,
    window: {},
    fetch: (url) => {
      const data = String(url).includes('bani-search') ? baniIdx : sggs;
      return Promise.resolve({ ok: true, json: async () => data });
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(ssSrc, sandbox);
  const GS = sandbox.window.GS_SCRIPTURE_SEARCH;
  ok('vm: real scripture-search loads (lookupBani + query available)', !!GS && typeof GS.lookupBani === 'function' && typeof GS.query === 'function');
  await GS.load();
  const r127 = GS.lookupBani(127, 0);
  ok('vm: lookupBani(127, 0) returns the first line with the NEW Bhog title',
    !!r127 && r127.g === ONKAR && r127.baniTitle === BHOG_PA);
  const r110 = GS.lookupBani(110, 0);
  ok('vm: lookupBani(110, 0) returns the first line with the NEW Aarti title',
    !!r110 && r110.baniTitle === AARTI_PA);
  const r114 = GS.lookupBani(114, 0);
  ok('vm: lookupBani(114, 0) still returns Ardas (title ਅਰਦਾਸ, group tradition)',
    !!r114 && r114.baniTitle === 'ਅਰਦਾਸ' && r114.group === 'tradition');
  // NOTE: GS.query() matches LINE TEXT (first letters), not Bani titles,
  // and caps at 40 results — so a title-only word like "ਅਰਦਾਸ" returns
  // SGGS lines that contain it, not the Bani itself. That is pre-existing
  // search behaviour, not a v2.2.66 change, so the vm checks below assert
  // the renamed Banis are findable by their actual lines instead.
  const qArdas = await GS.query('ਦਸਾਂ ਪਾਤਿਸ਼ਾਹੀਆਂ ਦੀ ਜੋਤ');
  ok('vm: an Ardas line is searchable and finds Bani 114',
    qArdas.some((r) => r.src === 'bani' && r.baniId === 114 && r.idx === 11));
  const qBhog = await GS.query('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ');
  ok('vm: searching the new Bhog title finds Bani 127',
    qBhog.some((r) => r.src === 'bani' && r.baniId === 127));
  const qAarti = await GS.query('ਗਗਨ ਮੈ ਥਾਲੁ');
  ok('vm: an Aarti (Vaddi) line is searchable and finds Bani 110',
    qAarti.some((r) => r.src === 'bani' && r.baniId === 110 && r.idx === 2));
  const qFateh = await GS.query('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ');
  ok('vm: v2.2.64 Fateh line still searchable (baniId 4, idx 1)',
    qFateh.some((r) => r.src === 'bani' && r.baniId === 4 && r.idx === 1 && r.g === FATEH));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
