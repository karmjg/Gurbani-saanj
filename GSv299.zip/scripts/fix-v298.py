#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.78 - one session per tap (Karamjit 2026-11-18:
"after 30 sec mic should stop" + "then person can restart it" + "and
when a person leave the page mic should stop").

v2.2.77 lengthened stretches to 30s, but the segment loop still
RESTARTED the mic after each segment ended - so while he was quiet it
would stop at 30s and start again on its own, beeping each time. That
restart loop is the beeping. This build removes it.

Exactly 1 change vs v2.2.77:
  ONE SESSION PER TAP. The mic listens for one segment (up to 30s of
  silence, or until the spoken line ends), then it STOPS and does not
  restart on its own. The person taps the mic again to start a new
  session. The 30s is a silence timeout, not a hard cutoff: if he is
  speaking, partial results keep the segment alive, so a long line or
  question is still captured in full. Leaving the page still stops the
  mic right away (bottom nav, back button, or switching apps - the
  v2.2.73/75 stops are untouched), and the mic never restarts after
  that either.

Keeps: 30s stretches, music keeps playing (mute is system +
notification only), the sound meter, the 8s "not hearing" wait. No
audio in this build (Play Store build). No Bani or Ang changes; no
lines added or removed, saved verses unaffected. Supersedes v2.2.77
(GSv297.zip) - do NOT upload GSv297, upload GSv298 instead.

Run from the repo root (pristine v2.2.77 in /tmp/v298-rollback):
  python3 scripts/fix-v298.py
Then: node test-v298.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_278 = (" v2.2.78: one session per tap. The mic listens for one "
            "segment (up to 30s of silence, or until the spoken line "
            "ends), then it STOPS and does not restart on its own - the "
            "person taps the mic again to start a new session. This ends "
            "the restart-beep cycle for good. Leaving the page still "
            "stops the mic right away (bottom nav, back button, or "
            "switching apps). The 30s is a silence timeout, not a hard "
            "cutoff: while he is speaking, the segment stays alive, so "
            "a long line or question is still captured in full. No audio "
            "in this build (Play Store build); no Bani or Ang changes, "
            "saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.77 -> 2.2.78 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.77', f"version.json is {vj['version']}"
    assert 'v2.2.77:' in vj['notes'], 'version notes do not contain v2.2.77'
    vj['notes'] = vj['notes'] + NOTE_278
    vj['version'] = '2.2.78'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.77"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.77"', '"version": "2.2.78"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.77"' in nbc, 'native-build-config.js is not 2.2.77'
    assert nbc.count('2.2.77') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.77"', '"version":"2.2.78"'),
        encoding='utf-8')
    print('version bump 2.2.77 -> 2.2.78 done')

    # ---- the restart loop must be gone; one segment, then stop ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'for(;;){' not in app, 'restart loop still present in app.js'
    assert 'await new Promise(r=>setTimeout(r,400));' not in app, '400ms restart pause still present'
    assert 'if(!(await beginSegment()))break;' not in app, 'restart call still present'
    assert app.count('await beginSegment()') == 1, 'beginSegment must be called exactly once (the first start)'
    assert 'await segEnded;\n     commitSegment();' in app, 'single-segment wait not present'
    assert 'v2.2.78: one session per tap' in app, 'v2.2.78 comment missing'
    print('restart loop removed (one session per tap)')

    # ---- leaving the page still stops the mic (v2.2.73/75, untouched) ----
    assert "if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();" in app, 'popstate mic-stop missing'
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app, 'visibilitychange mic-stop missing'
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app, 'pagehide mic-stop missing'
    print('mic-stop on leaving the page still present (go/popstate/visibility/pagehide)')

    # ---- 30s stretches + sound meter + music still present ----
    assert 'armSegGuard(30000);' in app, 'app guard is not 30s'
    assert 'if(quietFor<30000){armSegGuard(30000-quietFor);return;}' in app, 'guard quiet check is not 30s'
    assert '},8000);' in app, '8s not-hearing timer changed (must stay 8s)'
    assert 'id="voiceMeter"' in app, 'voiceMeter missing from app.js'
    assert "native.addListener('rmsChanged'" in app, 'rmsChanged listener missing'
    patch = (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8')
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000' in patch, 'patch does not set 30s silence'
    assert 'int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };' in patch, 'mute is not system+notification only'
    print('30s stretches + sound meter + music-keep-playing still present')

    # ---- no audio, no player (Play Store build) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')


if __name__ == '__main__':
    main()
