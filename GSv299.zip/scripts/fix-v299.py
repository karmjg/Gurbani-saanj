#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.79 - first tap works (Karamjit 2026-11-19: the mic
is "mostly satisfied" now, but the FIRST tap after opening the app or
after switching pages often does nothing - he has to stop it and tap
again. "When it says Listening but no green line, mic doesn't work."
His go: "build it" (2026-11-19 05:39).

ROOT CAUSE (verified in code + both videos): the phone's voice
recognizer dies instantly on that first start, but it never tells the
app. The plugin's start() resolves at once (call.resolve right after
startListening), so the app shows "Listening" with a dead recognizer -
no green line, no words - until the 30s guard ends it. The plugin's
onError() kills the recognizer without emitting 'stopped', so the app
never finds out. The second tap works because by then the recognizer
is warmed up.

Exactly 2 changes vs v2.2.78:
  1. PLUGIN: onError() now tells the app the recognizer died. The patch
     script (patch-speech-mic.mjs) adds a listeningState 'stopped' event
     to onError(), so a dead segment ends at once instead of the app
     sitting deaf for 30s.
  2. APP: ONE automatic retry, only if a segment dies almost
     immediately with no words heard (deadStart = no words, segment
     younger than 3s, run still live, at most 1 retry). The retry makes
     the first tap work. A segment that ends after speech, or after 30s
     of silence, ends the run - NO retry, so the "after 30s mic stops"
     rule still holds. beginSegment() now records run.segStartedAt.

Keeps: one session per tap, 30s stretches, stops on leaving the page
(bottom nav / back button / switching apps), music keeps playing, the
sound meter, the 8s "not hearing" wait, offline. No audio (Play Store
build). No Bani or Ang changes; no lines added or removed, saved
verses unaffected. Supersedes v2.2.78 (GSv298.zip) - do NOT upload
GSv298, upload GSv299 instead.

Run from the repo root (pristine v2.2.78 in /tmp/v299-rollback):
  python3 scripts/fix-v299.py
Then: node test-v299.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_279 = (" v2.2.79: first tap works. The phone's voice recognizer "
            "sometimes dies instantly on the first tap after opening the "
            "app or after switching pages, but it never told the app - so "
            "the app showed 'Listening' with a dead mic (no green line, "
            "no words) until the 30s guard ended it. Two fixes: (1) the "
            "plugin's onError() now tells the app at once when the "
            "recognizer dies, so a dead segment ends right away; (2) if a "
            "segment dies within 3 seconds with no words heard, the app "
            "restarts the mic once by itself, so the first tap works - no "
            "need to stop and tap again. A segment that ends after speech, "
            "or after 30s of silence, still ends the run with no retry. No "
            "audio in this build (Play Store build); no Bani or Ang "
            "changes, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.78 -> 2.2.79 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.78', f"version.json is {vj['version']}"
    assert 'v2.2.78:' in vj['notes'], 'version notes do not contain v2.2.78'
    vj['notes'] = vj['notes'] + NOTE_279
    vj['version'] = '2.2.79'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.78"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.78"', '"version": "2.2.79"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.78"' in nbc, 'native-build-config.js is not 2.2.78'
    assert nbc.count('2.2.78') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.78"', '"version":"2.2.79"'),
        encoding='utf-8')
    print('version bump 2.2.78 -> 2.2.79 done')

    # ---- 1. Plugin patch: onError notifies JS ----
    patch = (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8')
    assert 'v2.2.79: tell the app the recognizer died' in patch, 'onError notify patch missing from patch script'
    assert 'ret.put("status", "stopped");' in patch, 'onError stopped event missing from patch script'
    assert 'notifyListeners(LISTENING_EVENT, ret);' in patch, 'onError notifyListeners missing from patch script'
    # The patch must be applied in the local plugin Java (postinstall runs
    # it on the GitHub build too).
    java_path = ROOT / 'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java'
    java = java_path.read_text(encoding='utf-8')
    assert java.count('v2.2.79: tell the app the recognizer died') == 1, 'onError notify not applied (or duplicated) in plugin Java'
    print('plugin onError notifies JS (applied in local Java)')

    # ---- 2. App: dead-start retry (once, <3s, no words) ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'run.segStartedAt=Date.now();' in app, 'segStartedAt not recorded in beginSegment'
    assert 'v2.2.79: ONE automatic retry' in app, 'dead-start retry comment missing'
    assert 'let deadStartRetries=0;' in app, 'deadStartRetries counter missing'
    assert 'const deadStart=!heard.text.trim()&&(Date.now()-run.segStartedAt)<3000&&!runEnded()&&deadStartRetries<1;' in app, 'deadStart condition missing or wrong'
    assert 'if(!(await beginSegment()))break;' in app, 'retry beginSegment call missing'
    # The retry is the ONLY restart in the segment wait: no unbounded loop.
    assert app.count('await beginSegment()') == 2, 'beginSegment must be called exactly twice (first start + one retry)'
    assert 'for(;;){' in app, 'segment wait loop missing'
    print('dead-start retry present (once, <3s, no words)')

    # ---- leaving the page still stops the mic (v2.2.73/75, untouched) ----
    assert "if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();" in app, 'popstate mic-stop missing'
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app, 'visibilitychange mic-stop missing'
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app, 'pagehide mic-stop missing'
    print('mic-stop on leaving the page still present (go/popstate/visibility/pagehide)')

    # ---- 30s stretches + sound meter + music still present ----
    assert 'armSegGuard(30000);' in app, 'app guard is not 30s'
    assert 'if(quietFor<30000){armSegGuard(30000-quietFor);return;}' in app, 'guard quiet check is not 30s'
    assert '},8000);' in app, '8s not-hearing timer changed (must stay 8s)'
    assert 'id="voiceMeter"' in app, 'voiceMeter missing from app.js'
    assert "native.addListener('rmsChanged'" in app, 'rmsChanged listener missing'
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000' in patch, 'patch does not set 30s silence'
    assert 'int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };' in patch, 'mute is not system+notification only'
    print('30s stretches + sound meter + music-keep-playing still present')

    # ---- no audio, no player (Play Store build) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')


if __name__ == '__main__':
    main()
