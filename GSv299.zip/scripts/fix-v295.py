#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.75 — mic stops on the BACK BUTTON too (Karamjit
2026-11-18, his words: "test it here instead of installing it again and
again").

v2.2.73/74 stopped the mic only in go() (the bottom-nav buttons). The
Android BACK button takes a different path: Capacitor's backButton listener
calls window.history.back(), which fires the popstate handler — and popstate
set state.view directly and rendered WITHOUT calling go() or stopVoiceSearch().
So pressing Back from Search to Home left the mic (and the beeping) running.
That is why v2.2.74 still beeped on Home.

This build adds the same mic-stop to the popstate handler. Now the mic
stops no matter how he leaves Search/Ask: bottom-nav button OR back button.
Verified HERE before delivery by test-nav-stop.mjs (14 passed): it extracts
the REAL go() and popstate handler from app.js and runs them in a sandbox
with a mock mic, proving the mic stops on both paths.

Run from the repo root (pristine v2.2.74 in /tmp/v295-rollback):
  python3 scripts/fix-v295.py
Then: node test-v295.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_275 = (" v2.2.75: the mic now stops on the BACK BUTTON too. v2.2.73/74 "
            "stopped the mic only when the bottom-nav buttons were used; the "
            "Android back button takes a different path (popstate) that "
            "skipped the mic-stop, so the mic and the beeping kept running "
            "on Home. Now the mic stops no matter how Search/Ask is left: "
            "bottom-nav button OR back button. Tested here first "
            "(test-nav-stop.mjs, 14 passed) before this build was delivered. "
            "No audio in this build (Play Store build, same as v2.2.74); the "
            "mic fixes from v2.2.73 stay. No Bani or Ang changes; no lines "
            "added or removed, saved verses unaffected.")

POPSTOP = ("if((state.view==='search'||state.view==='ask')&&"
           "(nv!=='search'&&nv!=='ask'))stopVoiceSearch();")
GOSTOP = ("if((oldView==='search'||oldView==='ask')&&"
          "(view!=='search'&&view!=='ask'))stopVoiceSearch();")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.74 -> 2.2.75 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.74', f"version.json is {vj['version']}"
    assert 'v2.2.74:' in vj['notes'], 'version notes do not contain v2.2.74'
    vj['notes'] = vj['notes'] + NOTE_275
    vj['version'] = '2.2.75'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.74"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.74"', '"version": "2.2.75"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.74"' in nbc, 'native-build-config.js is not 2.2.74'
    assert nbc.count('2.2.74') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.74"', '"version":"2.2.75"'),
        encoding='utf-8')
    print('version bump 2.2.74 -> 2.2.75 done')

    # ---- the popstate fix must be present, and go() fix intact ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert POPSTOP in app, 'popstate mic-stop missing from app.js'
    assert GOSTOP in app, 'go() mic-stop missing from app.js'
    assert "const nv=(e.state?.gsView)||'home';" in app, 'popstate nv line missing'
    # popstate must still do everything it did (capture/close/render/scroll)
    assert "if(state.view==='reader'&&state.readView==='sggs')capture();closeWord();closeSettings();" in app
    print('popstate mic-stop present; go() mic-stop intact')

    # ---- no audio, no player (Play Store build, same as v2.2.74) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')

    # ---- mic fixes from v2.2.73 still present ----
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app
    assert '},8000);' in app, '8s not-hearing timer missing'
    print('mic fixes from v2.2.73 still present (stop + 8s + silence patch)')


if __name__ == '__main__':
    main()
