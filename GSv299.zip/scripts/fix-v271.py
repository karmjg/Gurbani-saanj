#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.71 — Karamjit 2026-11-17 (his go: "ਹਾਂ, v2.2.71 ਬਣਾ ਦਿਓ").

His complaint, in his words: "I'm talking about the spacing. I'm not
talking about the lines." + circled photos (book: Dhanaasari heading +
Mool Mantar; app: Maajh heading flowing into the verse) + "This one too"
(the Dhanaasari heading AND its Mool Mantar) + "Earlier one was wrong"
(the first mockup, which flowed the Mool Mantar with the verse).

ROOT CAUSE (verified in www/render-verses.js): the Bani reader groups
lines into flowing paragraphs; a line only breaks the flow when
isBaniHeading() recognises it. The "Raag Mahala N ... Ghar N" headings
do NOT match any rule — the Mahla rule needs "ਮਹਲਾ N ॥" at the END with
<=5 words, and these have "ਚਉਪਦੇ/ਛੰਤ/ਘਰੁ N" after the Mahla number
(7-8 words). So in Shabad Hazare the Maajh, Dhanaasari and Tilang
headings flow into the following verses on the same line. The Ang reader
is unaffected (each Ang line is its own block) — which is why the v2.2.69
Asa/Maajh data fix never showed up in the Bani reader.

Three things, exactly as planned and shown in the corrected mockups:

(1) Heading fix (render-verses.js, isBaniHeading): a "Raag Mahala N ...
    Ghar N" line (Mahla number + a "ਘਰੁ N" or "ਚਉਪਦੇ/ਛੰਤ/ਛੰਦ" ending,
    <=8 words) is a heading. Audit of ALL Bani lines: exactly 5
    newly-classified headings, all real, zero verse lines misclassified:
      113:1  ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥        (Asa Di Vaar — the Nov 16 Asa
                                            heading, still flowing in Bani)
      116:0  ਮਾਝ ਮਹਲਾ ੫ ਚਉਪਦੇ ਘਰੁ ੧ ॥     (Shabad Hazare, his app photo)
      116:17 ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥ (Shabad Hazare, his book photo)
      116:34 ਤਿਲੰਗ ਮਹਲਾ ੧ ਘਰੁ ੩ ॥         (Shabad Hazare)
      123:0  ਬਾਰਹ ਮਾਹਾ ਮਾਂਝ ਮਹਲਾ ੫ ਘਰੁ ੪ ॥ (Barah Maha)
    Headings render as centred bold blocks on their own line; the verse
    starts on the next line. Rendering rule only — no data lines change.

(2) Mool Mantar on its own line (render-verses.js, groupBaniParagraphs):
    the full Mool Mantar line ("ੴ ਸਤਿਨਾਮੁ/ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ...")
    ends its paragraph, so the verse after it starts on the next line —
    like iGranth. Only 4 such lines exist in all Banis (113:6, 116:18,
    116:79, 2:0) and the other three are already followed by a heading,
    so in practice only Shabad Hazare [18] changes. The Mool Mantar
    itself stays regular weight (NOT a bold heading).

(3) Bilawal Mool Mantar join (data): Shabad Hazare [79] (id S97P, before
    the Bilawal heading at [80]) still spaced — join its words like the
    Dhanaasari one in v2.2.69, and its Ang twin Ang 795[0] (same line).
    g + roman only; en/pa/id untouched. search.json row [795,0] updated;
    bani-search.json rebuilt with the sanctioned script afterwards.

What does NOT change (asserted): no line added or removed anywhere, no
line index shifts, vishraam.json byte-identical, all other Ang/Bani files
byte-identical, manifest counts unchanged, app.js / styles.css untouched.
Saved verses unaffected.

Run from the repo root (pristine v2.2.70 verified against /tmp/v271-rollback):
  python3 scripts/fix-v271.py
  node scripts/build-bani-search.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ROLL = Path('/tmp/v271-rollback')
OLD_G = 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥'
NEW_G = 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥'
OLD_R = 'ik oankaar sat naam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gur prasaad |'
NEW_R = 'ik oankaar satinaam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gurprasaad |'
NOTE_271 = (" v2.2.71: Shabad Hazare spacing — the heading now stands on its own line and the verse starts on the next line "
            "(Karamjit: 'I'm talking about the spacing'). (1) The Bani reader now recognises 'Raag Mahala N ... Ghar N' headings "
            "('ਮਾਝ ਮਹਲਾ ੫ ਚਉਪਦੇ ਘਰੁ ੧ ॥', 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥', 'ਤਿਲੰਗ ਮਹਲਾ ੧ ਘਰੁ ੩ ॥' in Shabad Hazare, "
            "'ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥' in Asa Di Vaar, 'ਬਾਰਹ ਮਾਹਾ ਮਾਂਝ ਮਹਲਾ ੫ ਘਰੁ ੪ ॥' in Barah Maha — 5 headings, audit of all Bani lines, "
            "no verse line misclassified); before, they flowed into the following verse because the old Mahla rule needed 'ਮਹਲਾ N ॥' at the end. "
            "(2) The full Mool Mantar line now ends its paragraph, so the verse after it starts on the next line — in practice only Shabad Hazare [18] changes. "
            "(3) The Bilawal Mool Mantar (Shabad Hazare [79] + Ang 795[0], the same line) has its words joined to match iGranth — "
            "'ਸਤਿ ਨਾਮੁ'->'ਸਤਿਨਾਮੁ' and 'ਗੁਰ ਪ੍ਰਸਾਦਿ'->'ਗੁਰਪ੍ਰਸਾਦਿ' — like the Dhanaasari one in v2.2.69. "
            "No lines added or removed, no index shifts, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def join_line(line, where):
    assert line['g'] == OLD_G, f'{where}: g is not the expected Mool Mantar line'
    assert line['roman'] == OLD_R, f'{where}: roman is not the expected one'
    assert line['g'].count('ਸਤਿ ਨਾਮੁ') == 1, f'{where}: ਸਤਿ ਨਾਮੁ not exactly once'
    assert line['g'].count('ਗੁਰ ਪ੍ਰਸਾਦਿ') == 1, f'{where}: ਗੁਰ ਪ੍ਰਸਾਦਿ not exactly once'
    assert line['roman'].count('sat naam') == 1, f'{where}: sat naam not exactly once'
    assert line['roman'].count('gur prasaad') == 1, f'{where}: gur prasaad not exactly once'
    en, pa, lid = line['en'], line['pa'], line['id']
    line['g'] = NEW_G
    line['roman'] = NEW_R
    assert line['en'] == en and line['pa'] == pa and line['id'] == lid
    assert line['g'] == NEW_G and line['roman'] == NEW_R


def main():
    # ---- (1)+(2) render-verses.js: heading rule + Mool Mantar break ----
    p = ROOT / 'www/render-verses.js'
    rv = p.read_text(encoding='utf-8')
    anchor = "if(/^ਰਾਗੁ\\s+.*(ਮਹਲਾ|ਮਃ)\\s*[੦-੯0-9]+/.test(t)&&wc<=8)return true;"
    assert rv.count(anchor) == 1, 'Raag-rule anchor not found exactly once'
    heading_rule = """
// v2.2.71: "Raag Mahala N ... Ghar N" headings — e.g. "ਮਾਝ ਮਹਲਾ ੫
// ਚਉਪਦੇ ਘਰੁ ੧ ॥", "ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥", "ਤਿਲੰਗ ਮਹਲਾ ੧
// ਘਰੁ ੩ ॥", "ਆਸਾ ਮਹਲਾ ੪ ਛੰਤ ਘਰੁ ੪ ॥", "ਬਾਰਹ ਮਾਹਾ ਮਾਂਝ ਮਹਲਾ ੫
// ਘਰੁ ੪ ॥". The Mahla rule needs "ਮਹਲਾ N ॥" at the END (≤5 words)
// and the Raag rule needs a leading "ਰਾਗੁ", so these fell through
// and flowed into the following verse in the Bani reader — Karamjit's
// circled Shabad Hazare photos (2026-11-17, "I'm talking about the
// spacing"). Audit of ALL Bani lines: exactly 5 newly-classified
// lines, all real headings, no verse line misclassified. Word guard ≤8.
if(/(ਮਹਲਾ|ਮਃ)\\s*[੦-੯0-9]+/.test(t)&&(/ਘਰੁ\\s*[੦-੯0-9]+\\s*॥?\\s*$/.test(t)||/(ਚਉਪਦੇ|ਛੰਤ|ਛੰਦ)\\s*॥?\\s*$/.test(t))&&wc<=8)return true;"""
    rv = rv.replace(anchor, anchor + heading_rule, 1)
    # Mool Mantar helper + paragraph break after it.
    anchor2 = "function groupBaniParagraphs(lines){"
    assert rv.count(anchor2) == 1, 'groupBaniParagraphs anchor not found exactly once'
    helper = """// v2.2.71: the full Mool Mantar line ("ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ...",
 // spaced or joined) stands on its own line in the Bani reader — the
 // verse after it starts on the next line, like iGranth (Karamjit's
 // circled Dhanaasari photo, 2026-11-17: "this one too"). Only 4 such
 // lines exist in all Banis and the other three are already followed
 // by a heading, so in practice only Shabad Hazare [18] changes. The
 // Mool Mantar stays regular weight — it is NOT a bold heading.
const isMoolMantar=g=>/^ੴ\\s+ਸਤਿ\\s*ਨਾਮੁ\\s+ਕਰਤਾ\\s+ਪੁਰਖੁ/.test(String(g||'').trim());
"""
    rv = rv.replace(anchor2, helper + anchor2, 1)
    old_flush = "   if(verseNumEnd(g))flush();\n  }\n });"
    assert rv.count(old_flush) == 1, 'paragraph flush anchor not found exactly once'
    rv = rv.replace(old_flush,
                    "   if(verseNumEnd(g)||isMoolMantar(g))flush();\n  }\n });", 1)
    p.write_text(rv, encoding='utf-8')
    print('render-verses.js: Ghar heading rule + Mool Mantar paragraph break done')

    # ---- (3) The two Bilawal Mool Mantar lines (Ang + Bani copies) ----
    a795 = load('www/offline/ang/795.json')
    b116 = load('www/offline/bani/116.json')
    assert len(b116['lines']) == 103, 'Bani 116 line count changed already?'
    assert a795['lines'][1]['g'] == 'ਰਾਗੁ ਬਿਲਾਵਲੁ ਮਹਲਾ ੧ ਚਉਪਦੇ ਘਰੁ ੧ ॥', 'Ang 795 heading not as expected'
    assert b116['lines'][80]['g'] == 'ਰਾਗੁ ਬਿਲਾਵਲੁ ਮਹਲਾ ੧ ਚਉਪਦੇ ਘਰੁ ੧ ॥', 'Bani 116 Bilawal heading not as expected'
    join_line(a795['lines'][0], 'Ang 795[0]')
    join_line(b116['lines'][79], 'Bani 116[79]')
    for k in ('g', 'en', 'pa', 'roman', 'id'):
        assert a795['lines'][0][k] == b116['lines'][79][k], f'Ang/Bani Mool Mantar differ on {k}'
    dump('www/offline/ang/795.json', a795)
    dump('www/offline/bani/116.json', b116)
    print('joined words in Ang 795[0] + Bani 116[79]')

    # search.json: update row [795,0] only; row count + all other rows unchanged
    sj = load('www/offline/search.json')
    assert len(sj) == 60555, f'search.json rows {len(sj)} != 60555'
    row = next(r for r in sj if r[0] == 795 and r[1] == 0)
    assert row[2] == OLD_G and row[5] == OLD_R, 'search.json [795,0] not the old Mool Mantar'
    assert row[3] == '' and row[4] == '', 'search.json [795,0] en/pa not empty as expected'
    row[2] = NEW_G
    row[5] = NEW_R
    dump('www/offline/search.json', sj)
    print('search.json row [795,0] updated (60,555 rows, no shifts)')

    # ---- Version bump 2.2.70 -> 2.2.71 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.70', f"version.json is {vj['version']}, expected 2.2.70"
    assert 'v2.2.71' not in vj['notes'], 'v2.2.71 note already present?'
    vj['notes'] = vj['notes'] + NOTE_271
    vj['version'] = '2.2.71'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.70"' in pj
    (ROOT / 'package.json').write_text(pj.replace('"version": "2.2.70"', '"version": "2.2.71"', 1), encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.70"' in nbc
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.70"', '"version":"2.2.71"', 1), encoding='utf-8')
    print('version bumped to 2.2.71')

    # ---- Guards: nothing else moved ----
    assert (ROOT / 'www/offline/vishraam.json').read_bytes() == (ROLL / 'www/offline/vishraam.json').read_bytes(), \
        'vishraam.json changed — it must be byte-identical'
    print('vishraam.json untouched (byte-identical to v2.2.70)')
    print('DONE — now run: node scripts/build-bani-search.mjs')


if __name__ == '__main__':
    main()
