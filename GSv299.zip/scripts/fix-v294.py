#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.74 — Play Store build, NO audio (Karamjit 2026-11-18,
his go: "v2.2.74, audio ਤੋਂ ਬਿਨਾਂ").

The Bhai Jarnail Singh recording is T-Series' (℗ 2003) — a written license
is needed before a Play Store release, and there is none. So this build
carries NO audio: the recording, the timing file AND the karaoke player
(play button, highlighting, tap-to-seek) are all removed. The mic fixes
from v2.2.73 stay (8s stretches, mic-stop on leave/background, 8s 'not
hearing' wait). The audio version (v2.2.73, GSv293.zip) stays as his
personal APK only — it is NOT for the Play Store.

The removal itself is done by scripts/remove-japji-audio.py (already run).
This script only bumps the version and asserts the removal is complete.

Run from the repo root (pristine v2.2.73 in /tmp/v294-rollback):
  python3 scripts/fix-v294.py
Then: node test-v294.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
V271_REF = Path('/tmp/v271-ref/www/styles.css')

NOTE_274 = (" v2.2.74: Play Store build — the Japji audio and karaoke player "
            "are REMOVED (the Bhai Jarnail Singh recording is T-Series', "
            "℗ 2003, and there is no written license for the store). The "
            "recording, the timing file and the play button/highlighting "
            "are all gone from this build. The mic fixes from v2.2.73 stay: "
            "8-second listening stretches, mic stops when leaving Search/Ask "
            "or the app, and the 'not hearing' message waits the full 8 "
            "seconds. The audio version (v2.2.73, GSv293.zip) stays as "
            "Karamjit's personal APK only — it is NOT for the Play Store. "
            "No other Bani or Ang changes; no lines added or removed, saved "
            "verses unaffected.")

PLAYER_NAMES = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
                'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords',
                'japjiAudio', 'japjiTimes', 'japjiPlaying', 'japjiRaf',
                'japjiNow', 'isJapjiReader', 'japjiSeekFromWord',
                'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
                'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
                'gs-audio-now', 'gs-japji-play', 'japji-full-clear',
                'japji-word-times', 'JAPJI_BANI_ID', 'JAPJI_DANDA']


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.73 -> 2.2.74 (three files, version string only
    # ---- except version.json, which also appends the note) ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.73', f"version.json is {vj['version']}"
    assert 'v2.2.73:' in vj['notes'], 'version notes do not contain v2.2.73'
    vj['notes'] = vj['notes'] + NOTE_274
    vj['version'] = '2.2.74'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.73"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.73"', '"version": "2.2.74"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.73"' in nbc, 'native-build-config.js is not 2.2.73'
    assert nbc.count('2.2.73') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.73"', '"version":"2.2.74"'),
        encoding='utf-8')
    print('version bump 2.2.73 -> 2.2.74 done')

    # ---- audio + timing files must be GONE ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists(), 'audio file still present'
    assert not (ROOT / 'www/offline/japji-word-times.json').exists(), 'timing file still present'
    assert not (ROOT / 'www/audio').exists(), 'www/audio/ dir still present'
    print('audio + timing files gone')

    # ---- no player identifiers left in app.js / styles.css ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    css = (ROOT / 'www/styles.css').read_text(encoding='utf-8')
    for name in PLAYER_NAMES:
        assert name not in app, f'player identifier left in app.js: {name}'
        assert name not in css, f'player identifier left in styles.css: {name}'
    assert 'Japji Sahib' in app, 'Bani name Japji Sahib must stay'
    print('no player identifiers left in app.js / styles.css')

    # ---- styles.css must be byte-identical to v2.2.71 (no CSS changes) ----
    if V271_REF.exists():
        assert css.encode('utf-8') == V271_REF.read_bytes(), 'styles.css differs from v2.2.71'
        print('styles.css byte-identical to v2.2.71')
    else:
        print('v2.2.71 styles reference not available — skipped byte check')

    # ---- mic fixes from v2.2.73 must still be present ----
    assert "(oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app, 'visibilitychange mic-stop missing'
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app, 'pagehide mic-stop missing'
    assert '},8000);' in app, '8s not-hearing timer missing'
    patch = ROOT / 'scripts/patch-speech-silence.mjs'
    assert patch.exists(), 'silence patch script missing'
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000' in patch.read_text(encoding='utf-8')
    pj2 = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"postinstall": "node scripts/patch-speech-silence.mjs"' in pj2, 'postinstall missing'
    print('mic fixes from v2.2.73 still present (stop + 8s + silence patch)')


if __name__ == '__main__':
    main()
