#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.77 - fix the mic RESTARTING properly (Karamjit
2026-11-18: "lets fix the mic that keeps beeping cause its restarting
again agin" + "thats what we need to fix" + "properly" + "music playing
go quiet?").

v2.2.76 muted the beep, but muting is a cover-up, not a fix - and it
muted the music stream too, so music went quiet. The real cause: the mic
restarts again and again, and EACH restart beeps. A segment ends after
~8s of silence (recognizer silence timeout + the app-side guard), so
while he is quiet the mic stops and restarts every few seconds, beeping
each time.

Exactly 2 changes vs v2.2.76, both aimed at the restarting:
  1. LISTENING STRETCHES ARE NOW 30s (was 8s). The recognizer silence
     timeouts (patch-speech-mic.mjs) AND the app-side guard (armSegGuard
     in app.js) are both 30s now, so a segment runs up to 30s of silence
     before it ends and the mic restarts. Far fewer restarts, far fewer
     beeps. The "not hearing" message still appears after 8s (it is only
     a message, not a restart trigger).
  2. MUSIC KEEPS PLAYING. The beep mute no longer touches the music
     stream. The beep rides the system / notification streams (it stops
     when the phone is on vibration, which silences those streams but
     not music), so muting those two silences the beep without touching
     music. The patch script upgrades a v2.2.76 mute in place.

Keeps: the v2.2.76 sound meter, the v2.2.73/74/75 mic fixes (mic stops
on leaving the page / back button / app background), the 8s "not
hearing" wait. No audio in this build (Play Store build, same as
v2.2.74/75/76). No Bani or Ang changes; no lines added or removed,
saved verses unaffected. Supersedes v2.2.76 (GSv296.zip) - do NOT
upload GSv296, upload GSv297 instead.

Run from the repo root (pristine v2.2.76 in /tmp/v297-rollback):
  python3 scripts/fix-v297.py
Then: node test-v297.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_277 = (" v2.2.77: fix the mic RESTARTING properly. v2.2.76 only muted "
            "the beep, but the mic still restarted again and again (each "
            "restart beeps). Now each listening stretch is 30s (was 8s), "
            "so the mic rarely restarts and rarely beeps. Music keeps "
            "playing now - the beep mute no longer touches the music "
            "stream (the beep rides the system / notification streams). "
            "The sound meter, the mic-stop on leaving the page / back "
            "button / app background, and the 8s 'not hearing' wait all "
            "stay. No audio in this build (Play Store build); no Bani or "
            "Ang changes, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.76 -> 2.2.77 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.76', f"version.json is {vj['version']}"
    assert 'v2.2.76:' in vj['notes'], 'version notes do not contain v2.2.76'
    vj['notes'] = vj['notes'] + NOTE_277
    vj['version'] = '2.2.77'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.76"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.76"', '"version": "2.2.77"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.76"' in nbc, 'native-build-config.js is not 2.2.76'
    assert nbc.count('2.2.76') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.76"', '"version":"2.2.77"'),
        encoding='utf-8')
    print('version bump 2.2.76 -> 2.2.77 done')

    # ---- 30s stretches: patch script + app.js guard ----
    patch = (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8')
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000' in patch, 'patch does not set 30s silence'
    assert 'EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000' in patch, 'patch does not set 30s possibly-complete silence'
    # The 8000 string may only appear in the upgrade check (replacing an
    # older 8s value), never in a fresh putExtra insert.
    assert 'intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000)' not in patch, 'patch still inserts 8s silence'
    assert 'intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000)' not in patch, 'patch still inserts 8s possibly-complete silence'
    assert 'AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION' in patch, 'mute does not use system+notification only'
    # The MUSIC streams line appears exactly once: in the upgrade replace
    # (removing it from an older v2.2.76 mute). The fresh mute insert uses
    # system + notification only, so music keeps playing.
    assert patch.count('int[] streams = { AudioManager.STREAM_MUSIC') == 1, 'mute insert still includes the music stream'
    assert 'int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };' in patch, 'fresh mute insert is not system+notification only'
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'armSegGuard(30000);' in app, 'app guard is not 30s'
    assert 'if(quietFor<30000){armSegGuard(30000-quietFor);return;}' in app, 'guard quiet check is not 30s'
    assert 'armSegGuard(8000)' not in app, 'app still has an 8s guard'
    assert '},8000);' in app, '8s not-hearing timer changed (must stay 8s)'
    print('30s stretches present (patch + app guard); not-hearing timer still 8s')

    # ---- sound meter + mic fixes from v2.2.73/75/76 still present ----
    assert 'id="voiceMeter"' in app, 'voiceMeter missing from app.js'
    assert "native.addListener('rmsChanged'" in app, 'rmsChanged listener missing'
    css = (ROOT / 'www/styles.css').read_text(encoding='utf-8')
    assert '.gs-voice-meter{' in css, 'voice meter CSS missing'
    assert "if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();" in app, 'popstate mic-stop missing'
    assert "if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app
    print('sound meter + mic fixes from v2.2.73/75/76 still present')

    # ---- no audio, no player (Play Store build) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')


if __name__ == '__main__':
    main()
