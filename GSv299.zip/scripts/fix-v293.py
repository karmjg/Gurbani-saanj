#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.73 — Karamjit 2026-11-18 (his instruction:
"don't remove the mic — my main focus was the mic; make it listen
5/7/8/10 seconds per stretch, do it however you like").

Three changes vs v2.2.72, nothing else:
(1) Karaoke timing fix — Whisper rendered 6 stretches (seg01, seg10,
    seg15, seg21, seg34, seg35; 289 words) in Shahmukhi (Urdu script),
    so those words dropped out of the alignment and got invented,
    evenly-spaced times. The fixed file re-times them (line 21 now
    80.8-83.4 s, biggest gap 1.64 s, 366 words moved). Only the timing
    file changes; the recording and the player are untouched.
(2) Mic stops on leaving the page — the mic now stops when he leaves
    the Search or Ask page (go()) and when the app goes to the
    background (visibilitychange hidden / pagehide). It no longer keeps
    listening (and beeping) on another page or in another app. Search
    and Ask share the mic, so both are covered.
(3) Mic listens ~8s per stretch — the speech plugin's recognizer used
    the stock ~2s silence timeout, so it stopped (and the phone beeped)
    every ~2s while idle. A postinstall patch
    (scripts/patch-speech-silence.mjs) sets the silence timeouts to
    8000 ms in the plugin's intent, so each stretch lasts ~8s of
    silence before it ends and restarts — far fewer beeps. The mic is
    NOT removed (his explicit call).

What does NOT change: no other Bani or Ang, no lines added or removed,
no index shifts, saved verses unaffected, all other offline files
byte-identical. The recording is unchanged (T-Series permission still
needed before a Play Store release; the APK try needs none).

Run from the repo root (pristine v2.2.72 in /tmp/v293-rollback):
  python3 scripts/fix-v293.py
Then: node test-v293.mjs && node test-reader.mjs
"""
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TIMES_SRC = Path('/home/hatch/workspace/gurbani/audio/japji-word-times-fixed.json')
AUDIO_SECS = 1143.798
SILENCE_MS = 8000

NOTE_273 = (" v2.2.73: Mic kept (Karamjit: do NOT remove it — the mic is "
            "his main focus). Three changes: (1) the karaoke timing file "
            "is fixed — Whisper had rendered 6 stretches in Shahmukhi "
            "(Urdu script), so those words had invented times; they are "
            "now properly timed (line 21 now 80.8-83.4 s, biggest gap "
            "1.64 s, 366 words moved). (2) The mic now stops when he "
            "leaves the Search or Ask page, and when the app goes to the "
            "background — it no longer keeps listening (and beeping) on "
            "another page or in another app. (3) Each mic listening "
            "stretch now lasts ~8 seconds of silence before the service "
            "ends it (was ~2 s), so the phone beeps far less often while "
            "listening. No other Bani or Ang changes; no lines added or "
            "removed, saved verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.72 -> 2.2.73 (three files, version string only
    # ---- except version.json, which also appends the note) ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.72', f"version.json is {vj['version']}"
    assert 'v2.2.72:' in vj['notes'], 'version notes do not contain v2.2.72'
    vj['notes'] = vj['notes'] + NOTE_273
    vj['version'] = '2.2.73'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.72"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.72"', '"version": "2.2.73"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.72"' in nbc, 'native-build-config.js is not 2.2.72'
    assert nbc.count('2.2.72') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.72"', '"version":"2.2.73"'),
        encoding='utf-8')
    print('version bump 2.2.72 -> 2.2.73 done')

    # ---- (1) timing file (slim the FIXED file: line/g/s/e only) ----
    assert TIMES_SRC.exists(), 'fixed timing file missing'
    raw = json.loads(TIMES_SRC.read_text(encoding='utf-8'))
    assert len(raw) == 2150, f'timing entries {len(raw)} != 2150'
    slim = [{'line': x['line'], 'g': x['g'], 's': x['s'], 'e': x['e']}
            for x in raw]
    lines = {x['line'] for x in slim}
    assert lines == set(range(385)), 'timing does not cover all 385 lines'
    assert all(0 <= x['s'] <= x['e'] <= AUDIO_SECS for x in slim), \
        'timing outside the audio duration'
    assert all(slim[i]['s'] >= slim[i - 1]['s'] - 0.01
               for i in range(1, len(slim))), 'timing not in order'
    # the fixed file's worst spots must be fixed (old file: line 21 split
    # 59.4 -> 85.1; lines 123-124 stretched 362 -> 435)
    l21 = [x for x in slim if x['line'] == 21]
    assert 80.0 <= l21[0]['s'] and l21[-1]['e'] <= 84.0, \
        f"line 21 not fixed: {l21[0]['s']} -> {l21[-1]['e']}"
    gaps = [slim[i + 1]['s'] - slim[i]['e'] for i in range(len(slim) - 1)]
    assert max(gaps) <= 2.0, f'biggest gap {max(gaps)} > 2s'
    dump('www/offline/japji-word-times.json', slim)
    print(f'timing file written: www/offline/japji-word-times.json '
          f'({len(slim)} words, max gap {max(gaps):.2f}s)')

    # ---- (2) mic-stop edits must be present in app.js ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert ("(oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"
            in app), 'go() mic-stop missing'
    assert ("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"
            in app), 'visibilitychange mic-stop missing'
    assert ("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"
            in app), 'pagehide mic-stop missing'
    print('mic-stop edits verified in app.js (go + background)')

    # ---- (3) silence patch: script + postinstall + applied locally ----
    patch = ROOT / 'scripts/patch-speech-silence.mjs'
    assert patch.exists(), 'patch-speech-silence.mjs missing'
    ps = patch.read_text(encoding='utf-8')
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000' in ps
    assert 'EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000' in ps
    pj2 = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"postinstall": "node scripts/patch-speech-silence.mjs"' in pj2, \
        'postinstall missing from package.json'
    java = ROOT / ('node_modules/@capacitor-community/speech-recognition/'
                   'android/src/main/java/com/getcapacitor/community/'
                   'speechrecognition/SpeechRecognition.java')
    assert java.exists(), 'plugin java file missing (run npm ci first)'
    js = java.read_text(encoding='utf-8')
    assert js.count('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS') == 1, \
        'silence patch not applied (or applied twice) in plugin java'
    print('silence patch verified (script + postinstall + plugin java)')


if __name__ == '__main__':
    main()
