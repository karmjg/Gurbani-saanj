#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.76 - offline mic improvement (Karamjit 2026-11-18:
"lets improve the mic" + "so no beep?" + "find a way offline, we don't
want to do it online").

Exactly 2 new changes vs v2.2.75, both offline (no cloud, no internet):
  1. BEEP MUTED in the app. The beep is the phone's speech-service sound
     and has no off switch, so the app now quiets the sound streams it
     plays on (music/system/notification) while the mic listens, and
     restores them when the mic stops. Done in the speech plugin via a
     postinstall patch (scripts/patch-speech-mic.mjs), which also keeps
     the v2.2.73 8s silence fix and adds the MODIFY_AUDIO_SETTINGS
     permission (normal, auto-granted). Only streams that were unmuted
     are muted, so the user's own mute settings are preserved.
     Side effect: music playing on the phone goes quiet while the mic
     is on (the beep rides the music stream) and comes back when it stops.
  2. SOUND METER. The plugin now forwards the mic sound level
     (onRmsChanged) to the app as an "rmsChanged" event (~10/s), and the
     search + ask screens show a live green bar so he can SEE the mic
     hearing him. The Ask screen also gains a voice-status line (it had
     none). The meter follows the listening state (hidden when not
     listening).

NOT a change: fuzzy matching. It is already in the app (v2.2.44
skeleton/matra-stripped matching in scripture-search.js, verified) - a
misheard matra or wrong word still finds the right pangti. No new code
needed for it.

Keeps: the v2.2.73/74/75 mic fixes (8s stretches, mic stops on leaving
the page / back button / app background, "not hearing" waits 8s). No
audio in this build (Play Store build, same as v2.2.74/75). No Bani or
Ang changes; no lines added or removed, saved verses unaffected.

Run from the repo root (pristine v2.2.75 in /tmp/v296-rollback):
  python3 scripts/fix-v296.py
Then: node test-v296.mjs && node test-nav-stop.mjs && node test-reader.mjs
"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

NOTE_276 = (" v2.2.76: offline mic improvement - the beep is now muted "
            "inside the app (the app quiets the beep sound streams while "
            "the mic listens and restores them when it stops), and the "
            "search + ask screens show a live sound bar so you can see "
            "the mic hearing you. Fully offline, no internet needed. "
            "Side effect: music playing on the phone goes quiet while "
            "the mic is on and comes back when it stops. The mic fixes "
            "from v2.2.73/74/75 stay (8s stretches, mic stops on leaving "
            "the page / back button / app background). No audio in this "
            "build (Play Store build); no Bani or Ang changes, saved "
            "verses unaffected.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.75 -> 2.2.76 ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.75', f"version.json is {vj['version']}"
    assert 'v2.2.75:' in vj['notes'], 'version notes do not contain v2.2.75'
    vj['notes'] = vj['notes'] + NOTE_276
    vj['version'] = '2.2.76'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.75"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.75"', '"version": "2.2.76"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.75"' in nbc, 'native-build-config.js is not 2.2.75'
    assert nbc.count('2.2.75') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.75"', '"version":"2.2.76"'),
        encoding='utf-8')
    print('version bump 2.2.75 -> 2.2.76 done')

    # ---- the mic patch script must exist and cover mute + RMS + manifest ----
    patch = (ROOT / 'scripts/patch-speech-mic.mjs').read_text(encoding='utf-8')
    assert 'muteBeepStreams' in patch, 'mute logic missing from patch script'
    assert 'unmuteBeepStreams' in patch, 'unmute logic missing from patch script'
    assert 'rmsChanged' in patch, 'RMS forward missing from patch script'
    assert 'MODIFY_AUDIO_SETTINGS' in patch, 'manifest permission missing from patch script'
    assert 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS' in patch, '8s silence fix missing from patch script'
    assert not (ROOT / 'scripts/patch-speech-silence.mjs').exists(), 'old silence-only patch script still present'
    pj2 = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"postinstall": "node scripts/patch-speech-mic.mjs"' in pj2, 'postinstall does not run the mic patch'
    print('mic patch script present (mute + RMS + manifest + 8s silence)')

    # ---- sound meter must be in app.js + styles.css ----
    app = (ROOT / 'www/app.js').read_text(encoding='utf-8')
    assert 'id="voiceMeter"' in app, 'voiceMeter div missing from app.js'
    assert 'id="voiceMeterFill"' in app, 'voiceMeterFill div missing from app.js'
    assert 'function rmsToLevel' in app, 'rmsToLevel missing from app.js'
    assert 'function setVoiceMeter' in app, 'setVoiceMeter missing from app.js'
    assert 'function hideVoiceMeter' in app, 'hideVoiceMeter missing from app.js'
    assert "native.addListener('rmsChanged'" in app, 'rmsChanged listener missing from app.js'
    assert app.count('id="voiceMeter"') == 2, 'voiceMeter must be in search + ask screens'
    assert app.count('id="voiceStatus"') == 2, 'voiceStatus must be in search + ask screens'
    css = (ROOT / 'www/styles.css').read_text(encoding='utf-8')
    assert '.gs-voice-meter{' in css, 'voice meter CSS missing'
    assert '.gs-voice-meter-fill{' in css, 'voice meter fill CSS missing'
    print('sound meter present (app.js + styles.css, search + ask)')

    # ---- no audio, no player (Play Store build, same as v2.2.74/75) ----
    assert not (ROOT / 'www/audio/japji-full-clear.mp3').exists()
    assert not (ROOT / 'www/offline/japji-word-times.json').exists()
    assert not (ROOT / 'www/audio').exists()
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio',
                 'stopJapjiAudio', 'gs-audio-now', 'gs-japji-play',
                 'japji-full-clear', 'japji-word-times']:
        assert name not in app, f'player identifier left in app.js: {name}'
    print('no audio, no player (Play Store build)')

    # ---- mic fixes from v2.2.73/75 still present ----
    assert "if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();" in app, 'popstate mic-stop missing'
    assert "if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();" in app, 'go() mic-stop missing'
    assert "if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}" in app
    assert "window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});" in app
    assert '},8000);' in app, '8s not-hearing timer missing'
    print('mic fixes from v2.2.73/75 still present (stop + 8s + silence patch)')

    # ---- fuzzy matching already present (v2.2.44), no change needed ----
    ss = (ROOT / 'www/scripture-search.js').read_text(encoding='utf-8')
    assert 'stripMatras' in ss and 'longestRun' in ss, 'fuzzy skeleton matching missing from scripture-search.js'
    print('fuzzy matching verified present (v2.2.44 skeleton/matra matching)')


if __name__ == '__main__':
    main()
