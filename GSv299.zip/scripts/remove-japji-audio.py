#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.74 — remove the Japji audio + karaoke player from the
Play Store build (Karamjit 2026-11-18, his go: "v2.2.74, audio ਤੋਂ ਬਿਨਾਂ").

The Bhai Jarnail Singh recording is T-Series' (℗ 2003) — a written license
is needed before a Play Store release, and there is none. So the Play Store
build carries NO audio: the recording, the timing file AND the karaoke
player (play button, highlighting, tap-to-seek) are all removed. The mic
fixes from v2.2.73 stay (8s stretches, mic-stop on leave/background, 8s
'not hearing' wait). The audio version (v2.2.73, GSv293.zip) stays as his
personal APK only — it is NOT for the Play Store.

This script reverses ONLY the v2.2.72 player additions, keeping the v2.2.73
mic changes. Verified against the pristine v2.2.71 reference
(/tmp/v271-ref, from GSv291.zip): after this runs, app.js differs from
v2.2.71 ONLY by the v2.2.73 mic changes, and styles.css is byte-identical
to v2.2.71.

Run from the repo root:
  python3 scripts/remove-japji-audio.py
Then: node test-v294.mjs && node test-reader.mjs
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    app_p = ROOT / 'www/app.js'
    app = app_p.read_text(encoding='utf-8')

    # ---- 1. Play button render (readerScreen) -> v2.2.71 single line ----
    old_btn = (
        "  // v2.2.72: Japji audio — a floating play button, Japji reader only.\n"
        "  const japjiPlay=(kind==='bani'&&Number(activeRemote.id)===2)?`<button type=\"button\" id=\"japjiPlayBtn\" class=\"gs-japji-play\" data-action=\"japji-play\" aria-label=\"${age('ਜਪੁਜੀ ਸਾਹਿਬ ਸੁਣੋ','Play Japji Sahib')}\">▶</button>`:'';\n"
        "  return `<section class=\"reading reading-immersive ${isSggs?'gs-reader-sggs':'gs-reader-bani'}${kind==='bani'&&state.showTranslit?' gs-translit-on':''}${kind==='bani'&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}\">${drawer}${head}<div class=\"verse-list\" id=\"verses\">${versesHTML}</div>${japjiPlay}</section>`;"
    )
    new_btn = (
        "  return `<section class=\"reading reading-immersive ${isSggs?'gs-reader-sggs':'gs-reader-bani'}${kind==='bani'&&state.showTranslit?' gs-translit-on':''}${kind==='bani'&&(state.showTranslit||state.showEn||state.showPa)?' gs-layers-on':''}\">${drawer}${head}<div class=\"verse-list\" id=\"verses\">${versesHTML}</div></section>`;"
    )
    assert old_btn in app, 'play-button render block not found'
    app = app.replace(old_btn, new_btn, 1)
    print('play button render removed')

    # ---- 2. Whole player block (lines 998-1107) ----
    start = app.find('/* ---- v2.2.72: Japji Sahib audio + karaoke word highlighting ---- */')
    end = app.find('/* ---- Search wiring ---- */')
    assert start != -1 and end != -1 and start < end, 'player block markers not found'
    block = app[start:end]
    assert 'toggleJapjiAudio' in block and 'japjiSeekFromWord' in block, 'player block looks wrong'
    app = app[:start] + app[end:]
    print(f'player block removed ({len(block)} chars)')

    # ---- 3. action() case ----
    case = " case'japji-play':toggleJapjiAudio();break;\n"
    assert case in app, 'japji-play case not found'
    app = app.replace(case, '', 1)
    print('action() japji-play case removed')

    # ---- 4. attach() hook ----
    hook = (
        " // v2.2.72: Japji audio — stop it when the Japji reader is not on screen;\n"
        " // rebuild the word index when it is (the reader re-renders on settings\n"
        " // changes, so the index must be rebuilt from the fresh DOM each time).\n"
        " if(!isJapjiReader())stopJapjiAudio();else buildJapjiWordIndex();\n"
    )
    assert hook in app, 'attach() japji hook not found'
    app = app.replace(hook, '', 1)
    print('attach() japji hook removed')

    # ---- 5. Word tap -> v2.2.71 (meaning only, no seek) ----
    old_tap = "if(word){e.stopPropagation();if(japjiSeekFromWord(word))return;openLineMeaning(word);return}"
    new_tap = "if(word){e.stopPropagation();openLineMeaning(word);return}"
    assert old_tap in app, 'word-tap seek hook not found'
    app = app.replace(old_tap, new_tap, 1)
    print('word-tap seek hook removed')

    # ---- 6. No player identifiers left (the Bani NAME 'Japji Sahib' stays) ----
    for name in ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
                 'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords',
                 'japjiAudio', 'japjiTimes', 'japjiPlaying', 'japjiRaf',
                 'japjiNow', 'isJapjiReader', 'japjiSeekFromWord',
                 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
                 'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
                 'gs-audio-now', 'gs-japji-play', 'japji-full-clear',
                 'japji-word-times', 'JAPJI_BANI_ID', 'JAPJI_DANDA']:
        assert name not in app, f'player identifier left in app.js: {name}'
    assert 'Japji Sahib' in app, 'Bani name Japji Sahib must stay'
    app_p.write_text(app, encoding='utf-8')
    print('app.js clean (no player identifiers left)')

    # ---- 7. styles.css: remove the player rules, restore v2.2.71 line ----
    css_p = ROOT / 'www/styles.css'
    css = css_p.read_text(encoding='utf-8')
    start = css.find('/* v2.2.72: Japji audio — the word being sung lights up orange')
    end = css.find('.verse-meaning{')
    assert start != -1 and end != -1 and start < end, 'player CSS markers not found'
    removed = css[start:end]
    assert '.word.gs-audio-now' in removed and '.gs-japji-play{' in removed, 'player CSS looks wrong'
    # also drop the newline that separated the v2.2.71 line from the player
    # block, so the line joins exactly as in v2.2.71
    assert css[start - 1] == '\n', 'expected newline before player CSS'
    css = css[:start - 1] + css[end:]
    css_p.write_text(css, encoding='utf-8')
    print('styles.css player rules removed')


if __name__ == '__main__':
    main()
