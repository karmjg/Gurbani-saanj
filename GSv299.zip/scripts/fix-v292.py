#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.72 — Karamjit 2026-11-17 (his go: "Can we try in
apk" + "First" = APK try first, before any Play Store release).

His verdict on the karaoke demo: "Almost perfect" + "Sometimes not right"
— the highlight is mostly right, a few words off. The timing file is just
a list, so single wrong words can be corrected one by one later.

What this build adds (Japji Sahib reader only, Bani 2):
(1) The enhanced Bhai Jarnail Singh Japji Sahib recording
    (japji-full-clear.mp3, 19 min 04 s, 128 kbps, the chain he approved
    on the 60 s sample: "Sounds good") bundled in the app under
    www/audio/ — offline, like the rest of the library.
(2) A word-timing file www/offline/japji-word-times.json — 2,150 words,
    one entry per sung word {line, g, s, e}, from the Whisper base model
    + the DP alignment (align-words.py). All 2,150 words timed; Pauri
    starts in order; last word ends 1,119.89 s (file is 1,143.8 s).
(3) A play button in the Japji reader: tap it, the audio plays, the word
    being sung lights up orange, the page scrolls to follow, and tapping
    a word while playing jumps the audio to that word. Tapping a word
    while paused still shows the line meaning, exactly as before.
    The audio stops when he leaves the reader or opens another text.

What does NOT change: no other Bani or Ang, no lines added or removed,
no index shifts, saved verses unaffected, all other offline files
byte-identical. The mic, search, Ask and all other screens are untouched.

RIGHTS note (not a code change): this recording is T-Series'
(℗ 2003 Super Cassettes Industries Pvt. Ltd.). A written permission from
T-Series is needed before a Play Store release; the APK try on his own
phone needs none.

Run from the repo root (pristine v2.2.71 in /tmp/v292-rollback):
  python3 scripts/fix-v292.py
Then: node test-v292.mjs && node test-reader.mjs
"""
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
AUDIO_SRC = Path('/home/hatch/workspace/gurbani/audio/japji-full-clear.mp3')
TIMES_SRC = Path('/home/hatch/workspace/gurbani/audio/japji-word-times.json')
AUDIO_BYTES = 18301908
AUDIO_SECS = 1143.798

NOTE_272 = (" v2.2.72: Japji Sahib audio with karaoke word highlighting "
            "(Karamjit: 'Almost perfect' — a few words still off, and the "
            "timing list lets single words be corrected one by one). The "
            "enhanced Bhai Jarnail Singh recording (19 min, offline) is "
            "bundled in the app with a word-timing file (2,150 words); a "
            "play button in the Japji reader plays the audio, the word "
            "being sung lights up orange, the page scrolls to follow, and "
            "tapping a word while playing jumps the audio to that word. "
            "Tapping a word while paused still shows the line meaning, as "
            "before. The audio stops when he leaves the reader or opens "
            "another text. No other Bani or Ang changes; no lines added or "
            "removed, saved verses unaffected. Note: this recording is "
            "T-Series' (℗ 2003 Super Cassettes Industries) — a written "
            "permission from T-Series is needed before a Play Store "
            "release; the APK try on his own phone needs none.")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def main():
    # ---- version bump 2.2.71 -> 2.2.72 (three files, version string only
    # ---- except version.json, which also appends the note) ----
    vj = load('www/version.json')
    assert vj['version'] == '2.2.71', f"version.json is {vj['version']}"
    assert 'v2.2.71:' in vj['notes'], 'version notes do not contain v2.2.71'
    vj['notes'] = vj['notes'] + NOTE_272
    vj['version'] = '2.2.72'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.71"' in pj
    (ROOT / 'package.json').write_text(
        pj.replace('"version": "2.2.71"', '"version": "2.2.72"', 1),
        encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.71"' in nbc, 'native-build-config.js is not 2.2.71'
    assert nbc.count('2.2.71') == 1, 'version appears more than once'
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.71"', '"version":"2.2.72"'),
        encoding='utf-8')
    print('version bump 2.2.71 -> 2.2.72 done')

    # ---- audio file (the enhanced recording he approved) ----
    assert AUDIO_SRC.exists(), 'enhanced audio file missing'
    assert AUDIO_SRC.stat().st_size == AUDIO_BYTES, \
        f"audio size {AUDIO_SRC.stat().st_size} != {AUDIO_BYTES}"
    dest = ROOT / 'www/audio/japji-full-clear.mp3'
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(AUDIO_SRC, dest)
    assert dest.stat().st_size == AUDIO_BYTES
    print(f'audio copied: www/audio/japji-full-clear.mp3 ({AUDIO_BYTES} bytes)')

    # ---- timing file (slim: keep line/g/s/e, drop Whisper debug fields) ----
    raw = json.loads(TIMES_SRC.read_text(encoding='utf-8'))
    assert len(raw) == 2150, f'timing entries {len(raw)} != 2150'
    slim = [{'line': x['line'], 'g': x['g'], 's': x['s'], 'e': x['e']}
            for x in raw]
    lines = {x['line'] for x in slim}
    assert lines == set(range(385)), 'timing does not cover all 385 lines'
    assert all(0 <= x['s'] <= x['e'] <= AUDIO_SECS for x in slim), \
        'timing outside the audio duration'
    assert all(slim[i]['s'] >= slim[i - 1]['s'] - 0.01
               for i in range(1, len(slim))), 'timing not in order'
    dump('www/offline/japji-word-times.json', slim)
    print(f'timing file written: www/offline/japji-word-times.json '
          f'({len(slim)} words, lines 0-384)')


if __name__ == '__main__':
    main()
