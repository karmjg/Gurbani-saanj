#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.69 — CORRECTED spacing fix (Karamjit 2026-11-16).

CORRECTION: the first v2.2.69 build MERGED each heading with its verse
into one data line. Karamjit corrected it (circled screenshot + "ਜਿਹੜਾ
'ਹਰਿ ਅੰਮ੍ਰਿਤ ਭਿੰਨੇ ਲੋਇਣਾ' ਉਹ ਅਗਲੀ ਲਾਈਨ ਚ, ਉਹਨਾਂ ਨਾਲ ਦੀ ਨਾਲ ਨਹੀਂ
ਸਟਾਰਟ ਕਰਨਾ" — the verse starts on the NEXT line, not right along with
the heading). So NO merges. The heading stays on its own first line and
the verse starts on the next line, exactly as the app already had them
for Asa (Ang 448) and Maajh (Ang 96) — those two need NO change at all.

The ONLY real fix: in the Dhanaasari Mahala 1 Mool Mantar line, join the
words to match iGranth — "ਸਤਿ ਨਾਮੁ" -> "ਸਤਿਨਾਮੁ" and "ਗੁਰ ਪ੍ਰਸਾਦਿ" ->
"ਗੁਰਪ੍ਰਸਾਦਿ" (roman "sat naam" -> "satinaam", "gur prasaad" ->
"gurprasaad"). That line exists twice (Ang 660 line [1] + Shabad Hazare
116 line [18], same line id AH1X); both copies are fixed so the spacing
matches wherever the Shabad is opened. Ang 1's Mool Mantar stays
SPACED — only the Dhanaasari copy joins.

What changes:
  - www/offline/ang/660.json line [1]: g + roman (en/pa/id untouched)
  - www/offline/bani/116.json line [18]: g + roman (en/pa/id untouched)
  - www/offline/search.json row [660,1]: g + roman (60,555 rows, no shifts)
  - www/offline/bani-search.json: rebuilt with the sanctioned script
    (9,315 rows, only (116,18) text changes) — run AFTER this script
  - www/offline/manifest.json: searchVerseCount 60,385 -> 60,555, the
    TRUE Ang search-row count (bundle-offline.mjs defines it as
    searchRows.length; it stood 170 low because the v2.2.65 Mundavni
    (-169) and v2.2.67 Rehras (-1) BANI deletions had been subtracted
    from an Ang count by mistake)
  - version 2.2.68 -> 2.2.69 in version.json (+ notes), package.json,
    native-build-config.js
What does NOT change (asserted): no line is added or removed anywhere,
no line index shifts, vishraam.json byte-identical (the Mool Mantar lines
carry no marks), all other Ang/Bani files byte-identical, app code
untouched. NO saved-verse side effect (unlike the merged build, which
shifted saved verses one line down).

Run from the repo root (after restoring pristine v2.2.68):
  python3 scripts/fix-v269-spacing.py
  node scripts/build-bani-search.mjs
"""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ROLL = Path('/tmp/v269-rollback')
OLD_G = 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰ ਪ੍ਰਸਾਦਿ ॥'
NEW_G = 'ੴ ਸਤਿਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ਨਿਰਵੈਰੁ ਅਕਾਲ ਮੂਰਤਿ ਅਜੂਨੀ ਸੈਭੰ ਗੁਰਪ੍ਰਸਾਦਿ ॥'
OLD_R = 'ik oankaar sat naam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gur prasaad |'
NEW_R = 'ik oankaar satinaam karataa purakh nirbhau niravair akaal moorat ajoonee saibhan gurprasaad |'
NOTE_269 = (" v2.2.69: Dhanaasari Mahala 1 Mool Mantar words joined to match "
            "iGranth — 'ਸਤਿ ਨਾਮੁ'->'ਸਤਿਨਾਮੁ' and 'ਗੁਰ ਪ੍ਰਸਾਦਿ'->'ਗੁਰਪ੍ਰਸਾਦਿ' "
            "(Ang 660 + Shabad Hazare 116, the same line in both). Headings "
            "stay on their own lines and each verse starts on the next line "
            "— the heading and the verse are NOT joined into one line "
            "(corrected after the first v2.2.69 build merged them). No lines "
            "added or removed, no index shifts, saved verses unaffected. "
            "manifest searchVerseCount corrected to the true Ang search-row "
            "count 60,555 (was 60,385 — the v2.2.65/67 Bani deletions had "
            "been subtracted from an Ang count by mistake).")


def load(p):
    return json.loads((ROOT / p).read_text(encoding='utf-8'))


def dump(p, obj):
    (ROOT / p).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')


def join_line(line, where):
    assert line['g'] == OLD_G, f'{where}: g is not the expected Mool Mantar line'
    assert line['roman'] == OLD_R, f'{where}: roman is not the expected one'
    assert line['g'].count('ਸਤਿ ਨਾਮੁ') == 1, f'{where}: ਸਤਿ ਨਾਮੁ not exactly once'
    assert line['g'].count('ਗੁਰ ਪ੍ਰਸਾਦਿ') == 1, f'{where}: ਗੁਰ ਪ੍ਰਸਾਦਿ not exactly once'
    assert line['roman'].count('sat naam') == 1, f'{where}: sat naam not exactly once'
    assert line['roman'].count('gur prasaad') == 1, f'{where}: gur prasaad not exactly once'
    en, pa, lid = line['en'], line['pa'], line['id']
    line['g'] = NEW_G
    line['roman'] = NEW_R
    assert line['en'] == en and line['pa'] == pa and line['id'] == lid
    assert line['g'] == NEW_G and line['roman'] == NEW_R


def main():
    # 1. The two Mool Mantar lines (Ang + Bani copies of the same Shabad)
    a660 = load('www/offline/ang/660.json')
    b116 = load('www/offline/bani/116.json')
    assert len(a660['lines']) == 27 and len(b116['lines']) == 103, 'line counts changed already?'
    assert a660['lines'][0]['g'] == 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥', 'Ang 660 heading not as expected'
    assert b116['lines'][17]['g'] == 'ਧਨਾਸਰੀ ਮਹਲਾ ੧ ਘਰੁ ੧ ਚਉਪਦੇ ॥', 'Bani 116 heading not as expected'
    join_line(a660['lines'][1], 'Ang 660[1]')
    join_line(b116['lines'][18], 'Bani 116[18]')
    for k in ('g', 'en', 'pa', 'roman', 'id'):
        assert a660['lines'][1][k] == b116['lines'][18][k], f'Ang/Bani Mool Mantar differ on {k}'
    dump('www/offline/ang/660.json', a660)
    dump('www/offline/bani/116.json', b116)
    print('joined words in Ang 660[1] + Bani 116[18]')

    # 2. search.json: update row [660,1] only; row count + all other rows unchanged
    sj = load('www/offline/search.json')
    assert len(sj) == 60555, f'search.json rows {len(sj)} != 60555'
    row = next(r for r in sj if r[0] == 660 and r[1] == 1)
    assert row[2] == OLD_G and row[5] == OLD_R, 'search.json [660,1] not the old Mool Mantar'
    assert row[3] == '' and row[4] == '', 'search.json [660,1] en/pa not empty as expected'
    row[2] = NEW_G
    row[5] = NEW_R
    dump('www/offline/search.json', sj)
    print('search.json row [660,1] updated (60,555 rows, no shifts)')

    # 3. manifest: correct searchVerseCount to the true Ang row count
    man = load('www/offline/manifest.json')
    assert man['searchVerseCount'] == 60385, f"manifest searchVerseCount {man['searchVerseCount']} != 60385"
    man['searchVerseCount'] = 60555
    assert man['baniCount'] == 29 and man['angCount'] == 1430 and man['vishraamMarkCount'] == 86833
    dump('www/offline/manifest.json', man)
    print('manifest searchVerseCount 60385 -> 60555')

    # 4. Version bump 2.2.68 -> 2.2.69
    vj = load('www/version.json')
    assert vj['version'] == '2.2.68', f"version.json is {vj['version']}, expected 2.2.68"
    assert 'v2.2.69' not in vj['notes'], 'v2.2.69 note already present?'
    vj['notes'] = vj['notes'] + NOTE_269
    vj['version'] = '2.2.69'
    dump('www/version.json', vj)
    pj = (ROOT / 'package.json').read_text(encoding='utf-8')
    assert '"version": "2.2.68"' in pj
    (ROOT / 'package.json').write_text(pj.replace('"version": "2.2.68"', '"version": "2.2.69"', 1), encoding='utf-8')
    nbc = (ROOT / 'www/native-build-config.js').read_text(encoding='utf-8')
    assert '"version":"2.2.68"' in nbc
    (ROOT / 'www/native-build-config.js').write_text(
        nbc.replace('"version":"2.2.68"', '"version":"2.2.69"', 1), encoding='utf-8')
    print('version bumped to 2.2.69')

    # 5. Guards: nothing else moved
    assert (ROOT / 'www/offline/vishraam.json').read_bytes() == (ROLL / 'www/offline/vishraam.json').read_bytes(), \
        'vishraam.json changed — it must be byte-identical (no marks on the Mool Mantar lines)'
    print('vishraam.json untouched (byte-identical to v2.2.68)')
    print('DONE — now run: node scripts/build-bani-search.mjs')


if __name__ == '__main__':
    main()
