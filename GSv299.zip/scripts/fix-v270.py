#!/usr/bin/env python3
"""Gurbani Saanjh v2.2.70 — Karamjit 2026-11-17 (his go: "ਹਾਂ, v2.2.70 ਬਣਾ ਦਿਓ").

Two things, exactly as planned and shown in the mockups (NOT the optional
doubled-descriptions fix — he did not pick it):

(1) Punjabi labels: the app language is Punjabi but 10 strings in txt.pa
    (www/app.js) were still English. Give them Punjabi values (txt.en is
    untouched, so English mode stays English). The same strings feed the
    Bani View Preferences screen, the Settings menu card + subtitle, and
    the reader settings sheet. The Ask offline line names the screen too,
    so its Punjabi sentence gets the Punjabi name as well.
(2) Night Mode fix (CSS-only, mirrors v2.2.68's Dark/Charcoal overrides):
    Night Mode turns the text light but the Hukamnama page/frame, Home
    tiles, bottom bar, Ask quotes and daily card stayed light — the
    Hukamnama Gurmukhi was white on cream (invisible, his video). Add
    html[data-nightmode="on"] overrides for those surfaces. Light/Sepia
    with Night Mode off are unchanged.

No data changes: no Ang/Bani/search/manifest/vishraam file is touched.
"""
import json

ROOT = "/home/hatch/workspace/gurbani/v231"

PA_LABELS = [
    ("viewPrefs", "Bani View Preferences", "ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ"),
    ("nightMode", "Night Mode", "ਨਾਈਟ ਮੋਡ"),
    ("translit", "Transliteration", "ਲਿਪੀਅੰਤਰ"),
    ("enTrans", "English Translation", "ਅੰਗਰੇਜ਼ੀ ਅਨੁਵਾਦ"),
    ("paTrans", "Punjabi Translation", "ਪੰਜਾਬੀ ਅਨੁਵਾਦ"),
    ("shabadArth", "Shabad Arth", "ਸ਼ਬਦ ਅਰਥ"),
    ("baniTextSize", "Bani Text Size", "ਬਾਣੀ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ"),
    ("tSizeNormal", "Normal", "ਆਮ"),
    ("tSizeLarge", "Large", "ਵੱਡਾ"),
    ("tSizeXLarge", "Extra-large", "ਬਹੁਤ ਵੱਡਾ"),
]

# ---- (1a) txt.pa labels (app.js line 98 — the Pa object only) ----
p = f"{ROOT}/www/app.js"
app = open(p, encoding="utf-8").read()
pa_line_old = ("  viewPrefs:'Bani View Preferences',nightMode:'Night Mode',"
    "translit:'Transliteration',enTrans:'English Translation',"
    "paTrans:'Punjabi Translation',shabadArth:'Shabad Arth',"
    "baniTextSize:'Bani Text Size',tSizeNormal:'Normal',tSizeLarge:'Large',"
    "tSizeXLarge:'Extra-large',fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ',fontBlack:'ਕਾਲਾ',"
    "fontBlue:'ਨੀਲਾ',layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ',")
assert app.count(pa_line_old) == 1, "Pa labels line not found exactly once"
pa_line_new = ("  viewPrefs:'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ',nightMode:'ਨਾਈਟ ਮੋਡ',"
    "translit:'ਲਿਪੀਅੰਤਰ',enTrans:'ਅੰਗਰੇਜ਼ੀ ਅਨੁਵਾਦ',"
    "paTrans:'ਪੰਜਾਬੀ ਅਨੁਵਾਦ',shabadArth:'ਸ਼ਬਦ ਅਰਥ',"
    "baniTextSize:'ਬਾਣੀ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ',tSizeNormal:'ਆਮ',tSizeLarge:'ਵੱਡਾ',"
    "tSizeXLarge:'ਬਹੁਤ ਵੱਡਾ',fontColor:'ਅੱਖਰਾਂ ਦਾ ਰੰਗ',fontBlack:'ਕਾਲਾ',"
    "fontBlue:'ਨੀਲਾ',layerSize:'ਰੋਮਨ + ਅਨੁਵਾਦ ਦਾ ਆਕਾਰ',")
app = app.replace(pa_line_old, pa_line_new)
# The En object (line 124) must still carry the English values.
en_line = ("  viewPrefs:'Bani View Preferences',nightMode:'Night Mode',"
    "translit:'Transliteration',enTrans:'English Translation',"
    "paTrans:'Punjabi Translation',shabadArth:'Shabad Arth',"
    "baniTextSize:'Bani Text Size',tSizeNormal:'Normal',tSizeLarge:'Large',"
    "tSizeXLarge:'Extra-large',fontColor:'Text colour',fontBlack:'Black',"
    "fontBlue:'Blue',layerSize:'Roman + translation size',")
assert app.count(en_line) == 1, "En labels line changed by accident"

# ---- (1b) Ask offline line: Punjabi sentence names the screen ----
old_ai = "AI ਔਫਲਾਈਨ ਹੈ — Bani View Preferences › AI ਵਿੱਚ API key ਜਾਂ ਆਪਣਾ ਸਰਵਰ ਜੋੜੋ।"
new_ai = "AI ਔਫਲਾਈਨ ਹੈ — ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ › AI ਵਿੱਚ API key ਜਾਂ ਆਪਣਾ ਸਰਵਰ ਜੋੜੋ।"
assert app.count(old_ai) == 1, "Ask offline Pa line not found exactly once"
app = app.replace(old_ai, new_ai)
assert app.count("add an API key or your private server in Bani View Preferences › AI.") == 1
open(p, "w", encoding="utf-8").write(app)
print("app.js: 10 Pa labels + Ask offline line done")

# ---- (2) Night Mode CSS overrides (styles.css, after the nightmode block) ----
p = f"{ROOT}/www/styles.css"
css = open(p, encoding="utf-8").read()
anchor = 'html[data-nightmode="on"] .gs-key { background: #101512; }'
assert css.count(anchor) == 1, "nightmode anchor not found exactly once"
block = '''
/* v2.2.70: Night Mode had the same invisible-text problem v2.2.68 fixed
   for Dark/Charcoal — the Hukamnama page/frame, Home tiles, bottom bar,
   Ask quotes and daily card stayed light while Night Mode turns the text
   light. Same overrides, for data-nightmode="on"; Light/Sepia with Night
   Mode off are unchanged. */
html[data-nightmode="on"] .hukam-page { background: var(--paper); }
html[data-nightmode="on"] .hukam-frame { background: var(--surface); }
html[data-nightmode="on"] .hukam-meta { color: var(--gold); }
html[data-nightmode="on"] .hukam-stale { color: var(--muted); }
html[data-nightmode="on"] .hukam-verses .verse-block { border-bottom-color: var(--line); }
html[data-nightmode="on"] .home-v7 .tile-3d { background: linear-gradient(135deg,#26392e,#1f2a25); border-color: #48604f; border-bottom-color: #37493b; box-shadow: inset 0 1px 0 #ffffff16,0 3px 0 #16231a,0 10px 20px #0003; color: var(--ink); }
html[data-nightmode="on"] .home-v10 .home-tile.tile-3d:not(.tile-daily) { background: linear-gradient(130deg,#23382b,#24392c); border-color: #53674d; }
html[data-nightmode="on"] .home-v10 .home-tile strong:not(.tile-daily strong) { color: #e8f2df; }
html[data-nightmode="on"] .bottomnav { background: rgba(11,14,12,.97); border-top-color: var(--line); box-shadow: 0 -5px 23px #00000033; }
html[data-nightmode="on"] .ai-verse { color: #202a26; }
html[data-nightmode="on"] .daily-card, html[data-nightmode="on"] .daily-preview { background: #1e3327; border-color: #3c5843; }
html[data-nightmode="on"] .daily-card p, html[data-nightmode="on"] .daily-preview p { color: #d3e1d4; }
html[data-nightmode="on"] .daily-icon { background: #2d4535; }'''
assert block.strip() not in css, "v2.2.70 block already present"
css = css.replace(anchor, anchor + block, 1)
open(p, "w", encoding="utf-8").write(css)
print("styles.css: nightmode v2.2.70 block done")

# ---- (3) Version bump: 2.2.69 -> 2.2.70 ----
notes_add = (" v2.2.70: (1) Bani View Preferences labels are now Punjabi when the app language is Punjabi — "
    "'Bani View Preferences' is 'ਬਾਣੀ ਵਿਊ ਪਸੰਦਾਂ', 'Night Mode' is 'ਨਾਈਟ ਮੋਡ', 'Transliteration' is 'ਲਿਪੀਅੰਤਰ', "
    "'English Translation' is 'ਅੰਗਰੇਜ਼ੀ ਅਨੁਵਾਦ', 'Punjabi Translation' is 'ਪੰਜਾਬੀ ਅਨੁਵਾਦ', 'Shabad Arth' is 'ਸ਼ਬਦ ਅਰਥ', "
    "'Bani Text Size' is 'ਬਾਣੀ ਦੇ ਅੱਖਰਾਂ ਦਾ ਆਕਾਰ', and the sizes are 'ਆਮ' / 'ਵੱਡਾ' / 'ਬਹੁਤ ਵੱਡਾ'; "
    "the Settings card and the Ask offline line use the same Punjabi name. English mode is unchanged. "
    "(2) Night Mode now truly goes dark — the same fix v2.2.68 made for Dark/Charcoal, now for Night Mode: "
    "the Hukamnama page and frame follow the theme (they stayed cream while the verse text went white, so the Gurmukhi was invisible), "
    "the Home tiles, the bottom bar, the Ask answer quotes and the daily card follow the theme too; "
    "Light/Sepia with Night Mode off are unchanged.")
p = f"{ROOT}/www/version.json"
vj = json.load(open(p, encoding="utf-8"))
assert vj["version"] == "2.2.69", vj["version"]
assert vj["notes"].rstrip().endswith("60,385 — the v2.2.65/67 Bani deletions had been subtracted from an Ang count by mistake).")
vj["notes"] = vj["notes"] + notes_add
vj["version"] = "2.2.70"
with open(p, "w", encoding="utf-8") as f:
    json.dump(vj, f, ensure_ascii=False, separators=(", ", ": "))
    f.write("\n")

p = f"{ROOT}/package.json"
pkg = open(p, encoding="utf-8").read()
assert pkg.count('"version": "2.2.69"') == 1
open(p, "w", encoding="utf-8").write(pkg.replace('"version": "2.2.69"', '"version": "2.2.70"', 1))

p = f"{ROOT}/www/native-build-config.js"
nbc = open(p, encoding="utf-8").read()
assert nbc.count('"version":"2.2.69"') == 1
open(p, "w", encoding="utf-8").write(nbc.replace('"version":"2.2.69"', '"version":"2.2.70"', 1))
print("version bumped to 2.2.70")
