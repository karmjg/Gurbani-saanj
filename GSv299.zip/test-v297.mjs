/* Gurbani Saanjh v2.2.77 - fix the mic RESTARTING properly (Karamjit
 * 2026-11-18: "lets fix the mic that keeps beeping cause its restarting
 * again agin" + "thats what we need to fix" + "properly" + "music playing
 * go quiet?").
 *
 * v2.2.76 muted the beep, but muting is a cover-up, not a fix - and it
 * muted the music stream too, so music went quiet. The real cause: the
 * mic restarts again and again, and EACH restart beeps. A segment ended
 * after ~8s of silence, so while he is quiet the mic stopped and
 * restarted every few seconds, beeping each time.
 *
 * Exactly 2 changes vs v2.2.76:
 *  1. LISTENING STRETCHES ARE NOW 30s (was 8s): recognizer silence
 *     timeouts + the app-side guard are both 30s, so a segment runs up
 *     to 30s of silence before it ends and the mic restarts. Far fewer
 *     restarts, far fewer beeps. The "not hearing" message still appears
 *     after 8s (it is only a message, not a restart trigger).
 *  2. MUSIC KEEPS PLAYING: the beep mute no longer touches the music
 *     stream (system + notification only). The beep rides the system /
 *     notification streams (it stops on vibration, which silences those
 *     but not music).
 * Run: node test-v297.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execSync } from 'node:child_process';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v297-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.77', vj.version === '2.2.77');
ok('package.json is 2.2.77', pj.version === '2.2.77');
ok('native-build-config.js is 2.2.77', nbc.includes('"version":"2.2.77"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.77 entry',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.77:') &&
  vj.notes.includes('RESTARTING') && vj.notes.includes('30s') && vj.notes.includes('Music keeps'));
ok('native-build-config.js differs from v2.2.76 ONLY in the version string',
  nbc.replace('2.2.77', '2.2.76') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.76 ONLY in the version string',
  read('package.json').replace('2.2.77', '2.2.76') === readR('package.json'));

// ---- 1. 30s stretches (the proper fix for the restarting) ----
const patch = read('scripts/patch-speech-mic.mjs');
ok('patch sets the recognizer silence timeouts to 30000ms',
  patch.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000') &&
  patch.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000'));
ok('patch does not insert an 8s silence timeout (only the upgrade check may mention 8s)',
  !patch.includes('intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000)') &&
  !patch.includes('intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000)'));
ok('patch upgrades an older 8s value to 30s when re-run (no duplicates)',
  patch.includes("s.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000')"));
const app = read('www/app.js');
ok('app guard arms at 30000ms (was 8000ms)',
  app.includes('armSegGuard(30000);'));
ok('app guard quiet-check uses 30000ms',
  app.includes('if(quietFor<30000){armSegGuard(30000-quietFor);return;}'));
ok('no 8s guard left in app.js',
  !app.includes('armSegGuard(8000'));
ok('not-hearing message still waits 8s (it is only a message, not a restart trigger)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app));
// The plugin Java lives in node_modules (not in the zip): check it only when present.
const PLUGIN_JAVA = 'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
if (fs.existsSync(path.join(ROOT, PLUGIN_JAVA))) {
  const java = read(PLUGIN_JAVA);
  ok('plugin Java has the 30s silence extras (both)',
    java.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000') &&
    java.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000'));
  ok('plugin Java has no 8s silence extras left',
    !java.includes('SILENCE_LENGTH_MILLIS, 8000'));
  ok('plugin Java mute uses system + notification only (no MUSIC, so music keeps playing)',
    java.includes('int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };') &&
    !java.includes('STREAM_MUSIC'));
  ok('plugin Java still forwards RMS (rmsChanged notify)',
    java.includes('notifyListeners("rmsChanged"'));
  // The patch script must re-apply cleanly (idempotent) on the already-patched tree.
  try {
    const out = execSync('node scripts/patch-speech-mic.mjs', { cwd: ROOT, encoding: 'utf8' });
    ok('patch script re-runs cleanly on the patched tree (idempotent, nothing freshly applied)',
      out.includes('already applied') && !out.includes(': applied\n') && out.includes('speech mic patch done'));
  } catch (e) {
    ok('patch script re-runs cleanly on the patched tree (idempotent, nothing freshly applied)', false, String(e && e.message || e));
  }
} else {
  console.log('SKIP  plugin Java checks (no node_modules in this copy — the postinstall patch applies them at build time)');
}

// ---- 2. Music keeps playing (mute no longer touches STREAM_MUSIC) ----
ok('fresh mute insert uses system + notification only (no MUSIC)',
  patch.includes('int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };'));
ok('patch still mutes the beep streams (system + notification)',
  patch.includes('muteBeepStreams') && patch.includes('unmuteBeepStreams') &&
  patch.includes('AudioManager.STREAM_SYSTEM') && patch.includes('AudioManager.STREAM_NOTIFICATION'));

// ---- 3. Sound meter + mic fixes from v2.2.73/75/76 still present ----
ok('voiceMeter div is in BOTH search and ask screens', (app.match(/id="voiceMeter"/g) || []).length === 2);
ok('rmsChanged listener is registered (native plugin event)',
  app.includes("native.addListener('rmsChanged'"));
ok('rmsToLevel + setVoiceMeter + hideVoiceMeter functions exist',
  app.includes('function rmsToLevel') && app.includes('function setVoiceMeter') && app.includes('function hideVoiceMeter'));
const css = read('www/styles.css');
ok('voice meter CSS exists (.gs-voice-meter + fill)',
  css.includes('.gs-voice-meter{') && css.includes('.gs-voice-meter-fill{'));
ok('styles.css is byte-identical to v2.2.76 (no CSS changes in this build)',
  fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(path.join(ROLL, 'www/styles.css'))));
ok('app stops the mic on background (visibilitychange hidden)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('app stops the mic on pagehide',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));
ok('popstate mic-stop still present (back button)',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('go() mic-stop still present (bottom-nav path)',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));

// ---- 4. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));

// ---- 5. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.76',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 6. Nothing else changed vs v2.2.76 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js', 'scripts/patch-speech-mic.mjs'];
const added = ['scripts/fix-v297.py', 'test-v297.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
for (const f of walk(path.join(ROLL, 'scripts'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.76 (only app.js + version files + mic patch)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.76 (no files missing)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.76',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
