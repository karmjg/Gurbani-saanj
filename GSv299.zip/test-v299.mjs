/* Gurbani Saanjh v2.2.79 - first tap works (Karamjit 2026-11-19:
 * the mic is "mostly satisfied" now, but the FIRST tap after opening
 * the app or after switching pages often does nothing - he has to stop
 * it and tap again. "When it says Listening but no green line, mic
 * doesn't work.")
 *
 * ROOT CAUSE: the phone's voice recognizer dies instantly on that first
 * start, but it never tells the app. The plugin's start() resolves at
 * once, so the app shows "Listening" with a dead recognizer - no green
 * line, no words - until the 30s guard ends it. onError() kills the
 * recognizer without emitting 'stopped', so the app never finds out.
 *
 * Exactly 2 changes vs v2.2.78:
 *  1. PLUGIN: onError() now tells the app the recognizer died (a
 *     listeningState 'stopped' event), so a dead segment ends at once.
 *  2. APP: ONE automatic retry, only if a segment dies almost
 *     immediately with no words heard (deadStart = no words, segment
 *     younger than 3s, run still live, at most 1 retry). The retry
 *     makes the first tap work. A segment that ends after speech, or
 *     after 30s of silence, ends the run - NO retry.
 * Run: node test-v299.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v299-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.79', vj.version === '2.2.79');
ok('package.json is 2.2.79', pj.version === '2.2.79');
ok('native-build-config.js is 2.2.79', nbc.includes('"version":"2.2.79"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.79 entry',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.79:') &&
  vj.notes.includes('first tap works') && vj.notes.includes('dead'));
ok('native-build-config.js differs from v2.2.78 ONLY in the version string',
  nbc.replace('2.2.79', '2.2.78') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.78 ONLY in the version string',
  read('package.json').replace('2.2.79', '2.2.78') === readR('package.json'));

// ---- 1. Dead-start retry is present (once, <3s, no words) ----
const app = read('www/app.js');
ok('segStartedAt is recorded in beginSegment',
  app.includes('run.segStartedAt=Date.now();'));
ok('dead-start retry comment is present',
  app.includes('v2.2.79: ONE automatic retry'));
ok('deadStartRetries counter is present',
  app.includes('let deadStartRetries=0;'));
ok('deadStart condition is exactly: no words, <3000ms, run live, <1 retry',
  app.includes('const deadStart=!heard.text.trim()&&(Date.now()-run.segStartedAt)<3000&&!runEnded()&&deadStartRetries<1;'));
ok('retry calls beginSegment once (and the first start once) = exactly 2 beginSegment calls',
  (app.match(/await beginSegment\(\)/g) || []).length === 2);
ok('retry has a 400ms pause before restarting (lets the dead recognizer release)',
  app.includes('await new Promise(r=>setTimeout(r,400));'));
ok('one-session-per-tap comment still present (v2.2.78 rule kept)',
  app.includes('v2.2.78: one session per tap'));

// Runtime proof: run the REAL retry loop (extracted from app.js) in a
// sandbox with a mock recognizer, and confirm it retries ONLY a dead
// start - not a segment that ended after speech, and not a 30s silent one.
const loopMatch = app.match(/let deadStartRetries=0;[\s\S]*?if\(\!\(await beginSegment\(\)\)\)break;\s*\}/);
ok('dead-start retry loop is extractable from app.js', !!loopMatch);
async function runRetryScenario({ wordsFirst, segAgeMs, label }) {
  const sb = {
    segEnded: null, segResolve: null,
    beginCalls: 0, committed: 0,
    heard: { text: wordsFirst ? 'satnam waheguru' : '' },
    run: { segStartedAt: Date.now() - segAgeMs },
    runEnded: () => false,
    setTimeout,
    commitSegment: function () { sb.committed++; },
    beginSegment: async function () {
      sb.beginCalls++;
      sb.segEnded = new Promise(r => { sb.segResolve = r; });
      sb.run.segStartedAt = Date.now();
      return true;
    },
  };
  vm.createContext(sb);
  sb.segEnded = new Promise(r => { sb.segResolve = r; });
  vm.runInContext(`
    globalThis.__loopDone = (async () => {
      ${loopMatch[0]}
      return { beginCalls, committed, deadStartRetries };
    })();
  `, sb);
  // End the first segment.
  sb.segResolve();
  // Wait for the 400ms retry pause + beginSegment.
  await new Promise(r => setTimeout(r, 900));
  // If a retry happened, end the second segment with words heard so it stops.
  if (sb.beginCalls > 0) {
    sb.heard.text = 'satnam waheguru';
    sb.segResolve();
    await new Promise(r => setTimeout(r, 200));
  }
  const res = await sb.__loopDone;
  return { ...res, label };
}
if (loopMatch) {
  // (a) Dead start: no words, segment just started -> MUST retry once.
  const dead = await runRetryScenario({ wordsFirst: false, segAgeMs: 0, label: 'dead start' });
  ok('dead start (no words, <3s) retries the mic exactly once',
    dead.beginCalls === 1 && dead.deadStartRetries === 1 && dead.committed === 2,
    JSON.stringify(dead));
  // (b) Words heard: segment ends after speech -> must NOT retry.
  const spoke = await runRetryScenario({ wordsFirst: true, segAgeMs: 0, label: 'words heard' });
  ok('segment ending after speech does NOT retry',
    spoke.beginCalls === 0 && spoke.deadStartRetries === 0 && spoke.committed === 1,
    JSON.stringify(spoke));
  // (c) 30s silent segment: no words, but 30s old -> must NOT retry (the
  // "after 30s mic stops" rule still holds).
  const silent30 = await runRetryScenario({ wordsFirst: false, segAgeMs: 30000, label: '30s silent' });
  ok('30s silent segment does NOT retry (mic still stops after 30s)',
    silent30.beginCalls === 0 && silent30.deadStartRetries === 0 && silent30.committed === 1,
    JSON.stringify(silent30));
}

// ---- 2. Plugin patch: onError notifies JS ----
const patch = read('scripts/patch-speech-mic.mjs');
ok('patch script adds the onError notify (v2.2.79)',
  patch.includes('v2.2.79: tell the app the recognizer died'));
ok('patch script emits a listeningState stopped event from onError',
  patch.includes('ret.put("status", "stopped");') &&
  patch.includes('notifyListeners(LISTENING_EVENT, ret);'));
ok('patch script is idempotent for the onError notify (marker check)',
  patch.includes("if (s.includes(marker))"));
// In the working copy the patch is applied to the local plugin Java
// (node_modules is NOT in the zip, so the zip run skips this check).
const JAVA = 'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
if (fs.existsSync(path.join(ROOT, JAVA))) {
  const java = read(JAVA);
  ok('plugin Java has the onError notify applied (exactly once)',
    java.split('v2.2.79: tell the app the recognizer died').length - 1 === 1);
  ok('plugin Java onError still unmutes and stops (notify added, nothing removed)',
    java.includes('public void onError(int error) {') &&
    java.includes('unmuteBeepStreams();') &&
    java.includes('SpeechRecognition.this.stopListening();') &&
    java.includes('String errorMssg = getErrorText(error);'));
} else {
  console.log('SKIP  plugin Java checks (no node_modules in zip)');
}
// The JS 'stopped' handler must end the segment when the recognizer dies
// (it already does - run.sawStarted && run.started -> endSegment).
ok('JS listeningState stopped handler ends the segment',
  app.includes("if(run){run.stopped=true;if(run.sawStarted&&run.started)run.endSegment();}"));
ok('patch script still sets the recognizer silence timeouts to 30000ms',
  patch.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000') &&
  patch.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000'));
ok('patch mute is still system + notification only (music keeps playing)',
  patch.includes('int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };'));

// ---- 3. Leaving the page still stops the mic (v2.2.73/75, untouched) ----
ok('go() stops the mic when leaving Search/Ask (bottom nav)',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('popstate stops the mic when leaving Search/Ask (back button)',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('visibilitychange hidden stops the mic (switching apps)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('pagehide stops the mic',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));

// ---- 4. 30s stretches + sound meter + music still present ----
ok('app guard arms at 30000ms', app.includes('armSegGuard(30000);'));
ok('app guard quiet-check uses 30000ms',
  app.includes('if(quietFor<30000){armSegGuard(30000-quietFor);return;}'));
ok('not-hearing message still waits 8s (only a message, not a restart trigger)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app));
ok('voiceMeter div is in BOTH search and ask screens', (app.match(/id="voiceMeter"/g) || []).length === 2);
ok('rmsChanged listener is registered (native plugin event)',
  app.includes("native.addListener('rmsChanged'"));
const css = read('www/styles.css');
ok('voice meter CSS exists (.gs-voice-meter + fill)',
  css.includes('.gs-voice-meter{') && css.includes('.gs-voice-meter-fill{'));
ok('styles.css is byte-identical to v2.2.78 (no CSS changes in this build)',
  fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(path.join(ROLL, 'www/styles.css'))));

// ---- 5. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));

// ---- 6. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.78',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 7. Nothing else changed vs v2.2.78 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js', 'scripts/patch-speech-mic.mjs'];
const added = ['scripts/fix-v299.py', 'test-v299.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
for (const f of walk(path.join(ROLL, 'scripts'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.78 (only app.js + patch script + version files)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.78 (no files missing)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.78',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
