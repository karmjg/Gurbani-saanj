/* Gurbani Saanj v2.2.68 — Dark/Charcoal fix + remove Check for updates
 * (Karamjit's report 2026-11-15, screenshots: Bani words invisible in
 * Dark/Charcoal — white text on a white reader / cream Hukamnama page;
 * and the Check for updates button can never work — the repo has zero
 * GitHub Releases, and Play Store delivers updates anyway).
 * Exactly 7 changes against v2.2.67, CSS + one button removal, NO data
 * changes (no Bani file, no search index, no manifest, no vishraam):
 * (1) Dark theme vars now apply — new `html[data-tone="dark"]` block
 *     (spec 0,1,1) with the same values as `.dark`, because `.dark`
 *     (line 11, spec 0,1,0) was overridden by the later `:root` blocks
 *     (lines 93, 187, same spec, later wins), so --paper/--ink stayed
 *     light in Dark mode (cream bottom bar + settings sheet, and the
 *     .verse-en/.verse-pa/.verse-roman light overrides then sat on
 *     light backgrounds). This also fixes the cream bottomnav/sheet.
 * (2) Bani reader background follows the theme in Dark/Charcoal
 *     (was hardcoded #ffffff; only the separate Night Mode toggle
 *     darkened it). Light/Sepia keep the white reader.
 * (3) Hukamnama page + frame follow the theme in Dark/Charcoal
 *     (were hardcoded cream #f7efdd / #fdf8ea); meta/stale text and the
 *     verse dividers follow too. Gold border, green header and gold
 *     headings stay. Light/Sepia keep the cream parchment.
 * (4) Ask-answer quoted verses (.ai-verse, pale-yellow #fff2a8) get
 *     dark text in Dark/Charcoal — they inherited light --ink and were
 *     unreadable on the yellow. Same fix as the .gs-found highlight.
 * (5) The "Check for updates" button is removed from the Settings menu
 *     (menuScreen). The Current version display + intro text stay, so
 *     he can still see which version is installed. The checkUpdate
 *     function + 'check-update' handler stay as dead code (the web
 *     service-worker update path is untouched).
 * (6) The bottom bar follows the theme in Dark/Charcoal — Karamjit
 *     asked "What about this part?" (screenshot of the cream bar). The
 *     fixed .bottomnav rule's hardcoded rgba(255,250,241,.97) beat the
 *     base var(--paper) background (same specificity, later wins), so
 *     the bar stayed cream in ALL modes, not just Dark. Now dark in
 *     Dark (rgba(21,31,26,.97)) and Charcoal (rgba(36,39,41,.97)).
 *     The icons already use var(--muted)/var(--primary), light on a
 *     dark bar (9.9:1 Dark, 8.3:1 Charcoal), so they read.
 * (7) Charcoal mirrors of the .dark-only overrides — Charcoal's
 *     --primary (#a8c8b5) is too light for white text (1.81:1, measured)
 *     and for the pale button backgrounds (1.61:1), so primary buttons,
 *     selected pills, search/popup buttons and the daily icon were
 *     unreadable in Charcoal. Same dark-green surfaces as Dark mode
 *     (white on #2a5b45 = 7.83:1, #e8f4e9 on #274635 = 9.21:1).
 * SIDE EFFECT: none on saved data — no line indices move, no verses
 * shift, no saved Bani/Ang/Kirtan item changes. Only colours + one
 * button. SGGS Ang reader was already fine (no hardcoded bg) and is
 * untouched. Mockups (our style): dark-reader-fixed-mockup.webp,
 * charcoal-reader-fixed-mockup.webp, dark-hukamnama-fixed-mockup.webp,
 * menu-no-update-button-mockup.webp, bottomnav-fixed-mockup.webp.
 * Kept from v2.2.67: Rehras opens with the Chhant, kept ੴ at [4].
 * Kept from v2.2.66: all 5 renames/move. Kept from v2.2.65: Mundavni
 * still gone. Kept from v2.2.64: Jaap Fateh (4,1), Rehras Short ੴ.
 * Run: node test-v288.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v268-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const catSrc = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
const bani = (id) => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8'));
const g = (lines, i) => (lines[i] && lines[i].g) || '';
const ONKAR = 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const FATEH = 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥';
const BHOG_PA = 'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ';
const BHOG_EN = 'Sri Guru Granth Sahib Ji de Paath de Bhog de Salok';
const AARTI_PA = 'ਆਰਤੀ (ਵੱਡੀ)';
const AARTI_EN = 'Aarti (Vaddi)';
const menuSrc = (() => {
  const m = app.match(/function menuScreen\(\)\{([\s\S]*?)\n\}\n\/\* ---- Reader settings sheet ---- \*\//);
  return m ? m[1] : '';
})();

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.68', vj.version === '2.2.68');
ok('package.json is 2.2.68', pj.version === '2.2.68');
ok('native-build-config.js is 2.2.68', nbc.includes('"version":"2.2.68"'));
ok('version notes mention v2.2.68 + Dark + reader + Hukamnama + Ask + button removed + bottom bar + Charcoal',
  vj.notes.includes('v2.2.68:') && vj.notes.includes('Dark mode now truly goes dark') &&
  vj.notes.includes('Bani reader background follows the theme') &&
  vj.notes.includes('Hukamnama page and frame follow the theme') &&
  vj.notes.includes('quoted verses in Ask answers') &&
  vj.notes.includes('Check for updates') &&
  vj.notes.includes('bottom bar follows the theme') &&
  vj.notes.includes('dark-green surfaces as Dark mode'));

// ---- 1. Change 1: Dark var block exists and beats :root by specificity ----
{
  const darkBlock = css.match(/html\[data-tone="dark"\]\{([^}]*)\}/);
  ok('dark tone block exists', !!darkBlock);
  const d = darkBlock ? darkBlock[1] : '';
  ok('dark tone block: color-scheme dark + --bg #151e19 + --paper #151f1a + --surface #1c2c23',
    d.includes('color-scheme:dark') && d.includes('--bg:#151e19') && d.includes('--paper:#151f1a') && d.includes('--surface:#1c2c23'));
  ok('dark tone block: --ink #f0f3ed + --muted #bcc8be + --primary #a7d0b7 + --line #314638 + --gold #dcb882 + --highlight #2d4533',
    d.includes('--ink:#f0f3ed') && d.includes('--muted:#bcc8be') && d.includes('--primary:#a7d0b7') &&
    d.includes('--line:#314638') && d.includes('--gold:#dcb882') && d.includes('--highlight:#2d4533'));
  ok('dark tone block values are IDENTICAL to the .dark class values',
    (() => { const m = css.match(/\.dark\{color-scheme:dark;([^}]*)\}/); if (!m) return false;
      const norm = (s) => s.replace(/color-scheme:dark;?/g, '').split(';').map((x) => x.trim()).filter(Boolean).sort().join(';');
      return norm(m[1]) === norm(d); })());
  ok('dark tone block sits in the tone section (before the charcoal block)',
    css.indexOf('html[data-tone="dark"]{') > 0 &&
    css.indexOf('html[data-tone="dark"]{') < css.indexOf('html[data-tone="charcoal"]{'));
  ok('the override hazard is still there (late :root sets --paper #ffffff) — and the new block beats it by specificity (0,1,1 vs 0,1,0)',
    /:root \{--bg:#ffffff;--paper:#ffffff;/.test(css) && /:root\{--bg:#ffffff;--paper:#ffffff;/.test(css));
  ok('.dark class rule still exists (component overrides untouched)',
    /\.dark\{color-scheme:dark;--bg:#151e19;/.test(css));
  ok('charcoal tone block unchanged (--paper #242729, --ink #f4f0e9)',
    /html\[data-tone="charcoal"\]\{color-scheme:dark;--bg:#242729;--paper:#242729;--surface:#313538;--ink:#f4f0e9;/.test(css));
  ok('light + sepia tone blocks unchanged (light --paper #ffffff, sepia --paper #f4eddf)',
    /html\[data-tone="light"\]\{color-scheme:light;--bg:#ffffff;--paper:#ffffff;/.test(css) &&
    /html\[data-tone="sepia"\]\{color-scheme:light;--bg:#f4eddf;--paper:#f4eddf;/.test(css));
}

// ---- 2. Change 2: Bani reader follows the theme in Dark/Charcoal ----
{
  ok('reader base rule still hardcoded white (light/sepia unchanged)',
    css.includes('.gs-reader-bani .reading, .gs-reader-bani { background: #ffffff; }'));
  const m = css.match(/html\[data-tone="dark"\] \.gs-reader-bani, html\[data-tone="dark"\] \.gs-reader-bani \.reading,\s*\nhtml\[data-tone="charcoal"\] \.gs-reader-bani, html\[data-tone="charcoal"\] \.gs-reader-bani \.reading \{ background: var\(--paper\); \}/);
  ok('reader dark/charcoal override exists: both tones, both .gs-reader-bani + .reading, background var(--paper)', !!m);
  ok('night mode reader rule still present (near-black #0b0e0c)',
    css.includes('html[data-nightmode="on"] .gs-reader-bani, html[data-nightmode="on"] .gs-reader-bani .reading { background: #0b0e0c; }'));
  ok('no light/sepia reader override (reader stays white there by design)',
    !css.includes('html[data-tone="light"] .gs-reader-bani') && !css.includes('html[data-tone="sepia"] .gs-reader-bani'));
  ok('SGGS reader has no hardcoded background (it already follows --paper, untouched)',
    !/\.gs-reader-sggs[^{]*\{[^}]*background:/.test(css));
}

// ---- 3. Change 3: Hukamnama page + frame follow the theme ----
{
  ok('hukam base rules still cream (light/sepia parchment unchanged)',
    css.includes('.hukam-page{background:#f7efdd;min-height:100%;}') &&
    css.includes('outline-offset:5px;background:#fdf8ea;}'));
  ok('hukam page dark/charcoal override: background var(--paper)',
    /html\[data-tone="dark"\] \.hukam-page, html\[data-tone="charcoal"\] \.hukam-page \{ background: var\(--paper\); \}/.test(css));
  ok('hukam frame dark/charcoal override: background var(--surface), gold border untouched',
    /html\[data-tone="dark"\] \.hukam-frame, html\[data-tone="charcoal"\] \.hukam-frame \{ background: var\(--surface\); \}/.test(css) &&
    css.includes('.hukam-frame{border:3px solid #c9a227;'));
  ok('hukam meta dark/charcoal override: color var(--gold); stale: var(--muted); dividers: var(--line)',
    /html\[data-tone="dark"\] \.hukam-meta, html\[data-tone="charcoal"\] \.hukam-meta \{ color: var\(--gold\); \}/.test(css) &&
    /html\[data-tone="dark"\] \.hukam-stale, html\[data-tone="charcoal"\] \.hukam-stale \{ color: var\(--muted\); \}/.test(css) &&
    /html\[data-tone="dark"\] \.hukam-verses \.verse-block, html\[data-tone="charcoal"\] \.hukam-verses \.verse-block \{ border-bottom-color: var\(--line\); \}/.test(css));
  ok('hukam header stays green gradient in all modes (no override)',
    css.includes('.hukam-head{background:linear-gradient(180deg,#14532d,#0b3d20);') &&
    !css.includes('html[data-tone="dark"] .hukam-head'));
  ok('meanings already go light in dark/charcoal (lines 428-431, now on a dark bg they read)',
    /html\[data-tone="dark"\] \.verse-en, html\[data-tone="charcoal"\] \.verse-en \{ color: #e8e4da; \}/.test(css) &&
    /html\[data-tone="dark"\] \.verse-pa, html\[data-tone="charcoal"\] \.verse-pa,/.test(css));
}

// ---- 4. Change 4: .ai-verse dark text in Dark/Charcoal ----
{
  ok('ai-verse base rule still pale-yellow highlight (#fff2a8)',
    css.includes('.ai-verse{display:block;font-weight:700;background:#fff2a8;'));
  ok('ai-verse dark/charcoal override: color #202a26 (same dark text as .gs-found)',
    /html\[data-tone="dark"\] \.ai-verse, html\[data-tone="charcoal"\] \.ai-verse \{ color: #202a26; \}/.test(css));
  ok('.gs-found highlight still forces dark text (unchanged)',
    css.includes('.verse-block.gs-found .verse-text,.verse-block.gs-found .word,.verse-block.gs-found .verse-layer{color:#202a26!important}'));
}

// ---- 5. Change 5: Check for updates button removed from the menu ----
{
  ok('menuScreen extracted', menuSrc.length > 500);
  ok('menu: NO check-update button (no data-action="check-update", no checkUpdateButton id)',
    !menuSrc.includes('data-action="check-update"') && !menuSrc.includes('checkUpdateButton'));
  ok('menu: Current version display still there (currentVersion + v${APP_VERSION} + version-dot)',
    menuSrc.includes("t('currentVersion')") && menuSrc.includes('v${APP_VERSION}') && menuSrc.includes('version-dot'));
  ok('menu: intro text still there (menuIntro — updates come without reinstalling)',
    menuSrc.includes("t('menuIntro')") && menuSrc.includes('id="updateStatus"'));
  ok('menu: APP UPDATES label still there',
    menuSrc.includes("t('updateCenter')"));
  ok('menu: web install button still there (web-only, unaffected)',
    menuSrc.includes('data-action="install-app"'));
  ok('checkUpdate function + check-update handler stay as dead code (web service-worker path intact)',
    app.includes('async function checkUpdate(){') && app.includes("case'check-update':checkUpdate();break;"));
  ok('no other check-update button anywhere in app.js or index.html',
    !html.includes('data-action="check-update"') &&
    (app.match(/data-action="check-update"/g) || []).length === 0);
}

// ---- 5b. Change 6: bottom bar follows the theme in Dark/Charcoal ----
{
  ok('bottomnav base fixed rule still hardcoded cream (light/sepia keep it)',
    css.includes('background:rgba(255,250,241,.97)'));
  ok('bottomnav dark override: rgba(21,31,26,.97) + var(--line) border',
    /html\[data-tone="dark"\] \.bottomnav \{ background: rgba\(21,31,26,\.97\); border-top-color: var\(--line\);/.test(css));
  ok('bottomnav charcoal override: rgba(36,39,41,.97) + var(--line) border',
    /html\[data-tone="charcoal"\] \.bottomnav \{ background: rgba\(36,39,41,\.97\); border-top-color: var\(--line\);/.test(css));
  ok('bottomnav overrides come AFTER the hardcoded cream rule (and beat it by specificity 0,2,1 vs 0,1,0)',
    css.indexOf('background:rgba(255,250,241,.97)') < css.indexOf('html[data-tone="dark"] .bottomnav'));
  ok('no light/sepia bottomnav override (cream bar stays there by design)',
    !css.includes('html[data-tone="light"] .bottomnav') && !css.includes('html[data-tone="sepia"] .bottomnav'));
  ok('bottomnav icons still use var(--muted) / var(--primary) — light on a dark bar, so they read',
    css.includes('.bottomnav button{border:0;background:none;color:var(--muted);') &&
    css.includes('.bottomnav button.active{font-weight:750;color:var(--primary)}'));
}

// ---- 5c. Change 7: Charcoal mirrors of the .dark-only overrides ----
{
  ok('charcoal primary/continue-card override: dark green #2a5b45 (white text readable, 7.83:1)',
    /html\[data-tone="charcoal"\] \.primary, html\[data-tone="charcoal"\] \.continue-card \{ background:#2a5b45; border-color:#2a5b45; color:#fff; \}/.test(css));
  ok('charcoal selected pills override: dark green #2e6047',
    /html\[data-tone="charcoal"\] \.choice button\.sel, html\[data-tone="charcoal"\] \.pill\.active, html\[data-tone="charcoal"\] \.answer-pills button\.sel \{ background:#2e6047; color:#fff; \}/.test(css));
  ok('charcoal popup/search button override: #274635 bg + #e8f4e9 text (9.21:1)',
    /html\[data-tone="charcoal"\] \.popup-actions button, html\[data-tone="charcoal"\] \.inputrow button \{ background:#274635; color:#e8f4e9; \}/.test(css));
  ok('charcoal daily-icon override: #2d4535 (light glyph on dark chip)',
    /html\[data-tone="charcoal"\] \.daily-icon \{ background:#2d4535; \}/.test(css));
  ok('the .dark mirrors are still there (the charcoal rules copy them, not replace them)',
    css.includes('.dark .primary,.dark .continue-card{background:#2a5b45;') &&
    css.includes('.dark .choice button.sel,.dark .pill.active,.dark .answer-pills button.sel{background:#2e6047;') &&
    css.includes('.dark .popup-actions button,.dark .inputrow button{background:#274635;') &&
    css.includes('.dark .daily-icon{background:#2d4535}'));
  ok('charcoal base --primary is still the light sage #a8c8b5 (text on dark surfaces, 8.3:1 — only white-on-primary was broken)',
    /html\[data-tone="charcoal"\]\{[^}]*--primary:#a8c8b5;/.test(css));
}

// ---- 6. Data untouched vs v2.2.67 rollback (CSS + one button only) ----
{
  const same = (rel) => fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(path.join(ROLL, rel)));
  ok('data untouched: 21.json byte-identical to v2.2.67', same('www/offline/bani/21.json'));
  ok('data untouched: 107.json byte-identical', same('www/offline/bani/107.json'));
  ok('data untouched: 4.json (Jaap) byte-identical', same('www/offline/bani/4.json'));
  ok('data untouched: bani-search.json byte-identical (9,315 lines)', same('www/offline/bani-search.json') &&
    JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8')).length === 9315);
  ok('data untouched: manifest.json byte-identical (searchVerseCount 60385, 29 Banis)',
    same('www/offline/manifest.json') &&
    JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8')).searchVerseCount === 60385);
  ok('data untouched: vishraam.json byte-identical (86,833 marks)',
    same('www/offline/vishraam.json') &&
    Object.keys(JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/vishraam.json'), 'utf8')).marks).length === 86833);
  ok('data untouched: catalog.js byte-identical', same('www/catalog.js'));
  ok('only styles.css, app.js, version files changed vs rollback',
    !same('www/styles.css') && !same('www/app.js') && !same('www/version.json') &&
    !same('package.json') && !same('www/native-build-config.js'));
}

// ---- 7. Kept markers (v2.2.67 / 66 / 65 / 64 / 63 / 62 / 61 / 60 / 59 / 58, no Help) ----
{
  const L21 = bani(21).lines;
  ok('v2.2.67 kept: Rehras still 421 lines, [0] Chhant, [4] kept ੴ, [5] ਸਲੋਕੁ ਮਃ ੧',
    L21.length === 421 && g(L21, 0) === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥' &&
    g(L21, 4) === ONKAR && g(L21, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  ok("v2.2.66 kept: catalog is 'ਸੁੰਦਰ ਗੁਟਕਾ' / 'Sundar Gutka', Dasam + section 3 strings",
    app.includes("catalog:'ਸੁੰਦਰ ਗੁਟਕਾ'") && app.includes("catalog:'Sundar Gutka'") &&
    app.includes("catalogSection2:'ਦਸਮ ਪਾਤਸ਼ਾਹ ਦੀਆਂ ਬਾਣੀਆਂ'") &&
    app.includes("catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਬਾਣੀ ਰੂਪ'"));
  ok('v2.2.66 kept: Ardas (114) still in NITNEM_LIST between 21 and 130',
    (() => { const m = app.match(/const NITNEM_LIST=\[([\s\S]*?)\];/);
      return !!m && m[1].includes("['ਅਰਦਾਸ','Ardas',114]") &&
        m[1].indexOf("['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',21]") < m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") &&
        m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") < m[1].indexOf("['ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ','Rakhia De Shabad',130]"); })());
  const catCtx = { window: {} };
  vm.runInNewContext(catSrc, catCtx);
  const cat = catCtx.window.GS_CATALOG || [];
  ok('v2.2.66 kept: catalog still 20 entries, no 114, 127 Bhog + 110 Aarti (Vaddi) titles',
    cat.length === 20 && !cat.some((c) => c.id === 114) &&
    cat.find((c) => c.id === 127).titlePa === BHOG_PA &&
    cat.find((c) => c.id === 127).titleEn === BHOG_EN &&
    cat.find((c) => c.id === 110).titlePa === AARTI_PA &&
    cat.find((c) => c.id === 110).titleEn === AARTI_EN);
  ok('v2.2.65 kept: 126.json still deleted, no Mundavni title in catalog/manifest/index',
    !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')) &&
    !/Mundav|ਮੁੰਦਾਵਣੀ/.test(
      catSrc + JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8')).banis.map((b) => b.titlePa + ' ' + b.titleEn).join(' ')) +
      JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8')).map((r) => r[6] + ' ' + r[7]).join(' ')));
  ok('v2.2.64 kept: Jaap still 802 lines, [1] Fateh; Rehras Short still 340 lines, [4] ੴ',
    bani(4).lines.length === 802 && g(bani(4).lines, 1) === FATEH &&
    bani(107).lines.length === 340 && g(bani(107).lines, 4) === ONKAR);
  ok('v2.2.63 kept: Kirtan fallback + stay-put heart + Saved remove control',
    app.includes('Kirtan book fallback') && app.includes("save.classList.toggle('selected',added);") &&
    app.includes("save.textContent=added?'♥':'♡';"));
  ok('v2.2.62 kept: language-toggle hang guards still in ensureHukamnama',
    /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
  ok('v2.2.61 kept: Mool Mantar entry gone from the Banis drawer',
    !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
  ok('v2.2.60 kept: Kirtan heart button still on each Shabad row',
    app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
  ok('v2.2.59 kept: ensureCatalog exists and the reader view calls it',
    app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
  ok('v2.2.58 kept: History clock still AFTER the ਪੁ/EN button in the search box',
    (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
  ok('no Help button anywhere (cancelled — it would be confusing)',
    !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
    !html.includes('data-action="help"'));
}

// ---- 8. Mockups exist (v2.2.68, our style) ----
{
  const gfxAbs = '/home/hatch/workspace/gurbani/play-store/graphics';
  for (const f of ['dark-reader-fixed-mockup.webp', 'charcoal-reader-fixed-mockup.webp', 'dark-hukamnama-fixed-mockup.webp', 'menu-no-update-button-mockup.webp', 'bottomnav-fixed-mockup.webp']) {
    ok(`mockup exists: ${f}`, fs.existsSync(path.join(gfxAbs, f)) && fs.statSync(path.join(gfxAbs, f)).size > 10000);
  }
}

// ---- 9. vm: the REAL scripture search over the REAL index (unchanged) ----
{
  const ssSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sggs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
  const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const sandbox = {
    console,
    window: {},
    fetch: (url) => {
      const data = String(url).includes('bani-search') ? baniIdx : sggs;
      return Promise.resolve({ ok: true, json: async () => data });
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(ssSrc, sandbox);
  const GS = sandbox.window.GS_SCRIPTURE_SEARCH;
  ok('vm: real scripture-search loads (lookupBani + query available)', !!GS && typeof GS.lookupBani === 'function' && typeof GS.query === 'function');
  await GS.load();
  const r21 = GS.lookupBani(21, 0);
  ok('vm: lookupBani(21, 0) is the Chhant first line (opening ੴ gone)',
    !!r21 && r21.g === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥' && r21.baniTitle === 'ਰਹਰਾਸਿ ਸਾਹਿਬ');
  const r127 = GS.lookupBani(127, 0);
  ok('vm: lookupBani(127, 0) returns the first line with the Bhog title',
    !!r127 && r127.g === ONKAR && r127.baniTitle === BHOG_PA);
  const qChhant = await GS.query('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ');
  ok('vm: the Chhant first line is searchable and finds Bani 21 idx 0',
    qChhant.some((r) => r.src === 'bani' && r.baniId === 21 && r.idx === 0));
  const qFateh = await GS.query('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ');
  ok('vm: Fateh line still searchable (baniId 4, idx 1)',
    qFateh.some((r) => r.src === 'bani' && r.baniId === 4 && r.idx === 1 && r.g === FATEH));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
