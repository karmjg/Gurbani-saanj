/* Gurbani Saanjh v2.2.73 — Karamjit 2026-11-18 (his instruction: "don't
 * remove the mic — my main focus was the mic; make it listen 5/7/8/10
 * seconds per stretch, do it however you like").
 *
 * Exactly 3 changes vs v2.2.72, nothing else:
 * (1) Karaoke timing fix — the timing file only. Whisper rendered 6
 *     stretches in Shahmukhi (Urdu script), so those words got invented
 *     times; the fixed file re-times them (line 21 now 80.8-83.4 s,
 *     biggest gap 1.64 s, 366 words moved). Recording + player untouched.
 * (2) Mic stops on leaving the page — go() stops the mic when he leaves
 *     Search or Ask, and visibilitychange/pagehide stop it when the app
 *     goes to the background. No more listening (and beeping) on another
 *     page or in another app.
 * (3) Mic listens ~8s per stretch — a postinstall patch
 *     (scripts/patch-speech-silence.mjs) sets the speech plugin's silence
 *     timeouts to 8000 ms, so each stretch lasts ~8s of silence before
 *     it ends and restarts (was ~2s) — far fewer beeps. The mic is NOT
 *     removed. Run: node test-v293.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v293-rollback';
const AUDIO_SRC = '/home/hatch/workspace/gurbani/audio/japji-full-clear.mp3';
const AUDIO_BYTES = 18301908, AUDIO_SECS = 1143.798;
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const md5 = (p) => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.73', vj.version === '2.2.73');
ok('package.json is 2.2.73', pj.version === '2.2.73');
ok('native-build-config.js is 2.2.73', nbc.includes('"version":"2.2.73"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.73 entry (mic kept, 8s, timing fix)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.73:') &&
  vj.notes.includes('do NOT remove it') && vj.notes.includes('8 seconds'));
ok('native-build-config.js differs from v2.2.72 ONLY in the version string',
  nbc.replace('2.2.73', '2.2.72') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.72 ONLY in the version string + the postinstall line',
  read('package.json').replace('2.2.73', '2.2.72')
    .replace('    "postinstall": "node scripts/patch-speech-silence.mjs",\n', '') === readR('package.json'));

// ---- 1. Timing file (the fix) ----
const times = j('www/offline/japji-word-times.json');
const timesR = jr('www/offline/japji-word-times.json');
ok('timing file has 2,150 entries', Array.isArray(times) && times.length === 2150);
ok('timing entries carry only line/g/s/e (no Whisper debug fields)',
  times.every(x => Object.keys(x).sort().join(',') === 'e,g,line,s'));
ok('timing covers all 385 Bani 2 lines',
  new Set(times.map(x => x.line)).size === 385 &&
  Math.min(...times.map(x => x.line)) === 0 && Math.max(...times.map(x => x.line)) === 384);
ok('timing times are within the audio duration and in order',
  times.every(x => 0 <= x.s && x.s <= x.e && x.e <= AUDIO_SECS) &&
  times.every((x, i) => i === 0 || x.s >= times[i - 1].s - 0.01));
ok('timing ends at 1,119.89 s (last word) inside the 1,143.8 s file',
  Math.abs(times[times.length - 1].e - 1119.886) < 0.001);
ok('timing starts at 4.58 s (first word, unchanged)',
  Math.abs(times[0].s - 4.58) < 0.001);
const lineTimes = (ln) => times.filter(x => x.line === ln);
const l21 = lineTimes(21), l123 = lineTimes(123), l124 = lineTimes(124);
ok('line 21 fixed: 80.82-83.44 s (was 59.39-85.11, a 24.8 s dead stretch)',
  l21[0].s > 80 && l21[l21.length - 1].e < 84);
ok('lines 123-124 fixed: 365.87-370.15 s (was stretched over 72 s)',
  l123[0].s > 365 && l124[l124.length - 1].e < 371);
const gaps = times.slice(1).map((x, i) => x.s - times[i].e);
ok('biggest gap between words is 1.64 s (was 24.79 s)',
  Math.max(...gaps) <= 2.0, `got ${Math.max(...gaps).toFixed(2)}`);
const moved = times.filter((x, i) => Math.abs(x.s - timesR[i].s) > 0.05 || Math.abs(x.e - timesR[i].e) > 0.05).length;
ok('366 words moved by >0.05 s vs v2.2.72 (the 6 Shahmukhi stretches re-timed)',
  moved === 366, `got ${moved}`);
ok('timing words are the same words in the same order as v2.2.72 (only times changed)',
  times.every((x, i) => x.g === timesR[i].g && x.line === timesR[i].line));
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('timing words match the Bani 2 words exactly, in order',
  times.map(x => x.g).every((w, i) => w === expectedWords[i]));

// ---- 2. Mic-stop wiring (static checks on app.js) ----
const app = read('www/app.js');
ok('go() stops the mic when leaving Search or Ask for another view',
  app.includes("(oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('go() does NOT stop the mic when moving between Search and Ask (both voice screens)',
  app.includes("(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('app stops the mic when it goes to the background (visibilitychange hidden)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('app stops the mic on pagehide (switching apps / leaving)',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));
ok('stopVoiceSearch is safe when the mic is idle (resetVoiceNow resolves at once with no run)',
  app.includes('if(!needsStop)return Promise.resolve();'));
ok('not-hearing message waits the full 8 seconds before it appears (was 4s)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app) &&
  !/noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},4000\);/.test(app));

// ---- 3. Silence patch (script + postinstall; plugin java only where node_modules exists) ----
ok('patch script exists', fs.existsSync(path.join(ROOT, 'scripts/patch-speech-silence.mjs')));
const ps = read('scripts/patch-speech-silence.mjs');
ok('patch script sets both silence timeouts to 8000 ms',
  ps.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000') &&
  ps.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000'));
ok('patch script is idempotent (no-op when already applied)',
  ps.includes('already applied'));
ok('patch script fails loudly if the plugin anchor changed (no silent ship)',
  ps.includes('anchor changed'));
ok('package.json runs the patch on postinstall',
  pj.scripts && pj.scripts.postinstall === 'node scripts/patch-speech-silence.mjs');
const javaRel = 'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
if (fs.existsSync(path.join(ROOT, javaRel))) {
  const js = read(javaRel);
  ok('plugin java has exactly one copy of each silence extra (patch applied locally)',
    (js.match(/EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS/g) || []).length === 1 &&
    (js.match(/EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS/g) || []).length === 1);
} else {
  console.log('SKIP  plugin java check (no node_modules in this copy — postinstall applies it at build)');
}

// ---- 4. Nothing else changed ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js', 'www/offline/japji-word-times.json'];
const added = ['scripts/fix-v293.py', 'scripts/patch-speech-silence.mjs', 'test-v293.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.72 (only app.js, version files, timing file)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('no offline file was removed',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every other offline file is byte-identical to v2.2.72',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (rel === 'www/offline/japji-word-times.json') return true;
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));
ok('the recording is byte-identical to v2.2.72 (unchanged)',
  fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')) &&
  md5(path.join(ROOT, 'www/audio/japji-full-clear.mp3')) === md5(AUDIO_SRC));
ok('styles.css is byte-identical to v2.2.72 (no CSS changes in this build)',
  fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(path.join(ROLL, 'www/styles.css'))));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
