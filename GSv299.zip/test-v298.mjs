/* Gurbani Saanjh v2.2.78 - one session per tap (Karamjit 2026-11-18:
 * "after 30 sec mic should stop" + "then person can restart it" +
 * "and when a person leave the page mic should stop").
 *
 * v2.2.77 lengthened stretches to 30s, but the segment loop still
 * RESTARTED the mic after each segment ended - so while he was quiet it
 * would stop at 30s and start again on its own, beeping each time. This
 * build removes the restart loop entirely.
 *
 * Exactly 1 change vs v2.2.77:
 *  ONE SESSION PER TAP. The mic listens for one segment (up to 30s of
 *  silence, or until the spoken line ends), then it STOPS and does not
 *  restart on its own. The person taps the mic again to start a new
 *  session. Leaving the page still stops the mic right away (bottom nav,
 *  back button, or switching apps - the v2.2.73/75 stops are untouched).
 * Run: node test-v298.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v298-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.78', vj.version === '2.2.78');
ok('package.json is 2.2.78', pj.version === '2.2.78');
ok('native-build-config.js is 2.2.78', nbc.includes('"version":"2.2.78"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.78 entry',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.78:') &&
  vj.notes.includes('one session per tap') && vj.notes.includes('STOPS'));
ok('native-build-config.js differs from v2.2.77 ONLY in the version string',
  nbc.replace('2.2.78', '2.2.77') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.77 ONLY in the version string',
  read('package.json').replace('2.2.78', '2.2.77') === readR('package.json'));

// ---- 1. The restart loop is gone (one session per tap) ----
const app = read('www/app.js');
ok('restart loop is gone (no for(;;) in app.js)', !app.includes('for(;;){'));
ok('400ms restart pause is gone', !app.includes('await new Promise(r=>setTimeout(r,400));'));
ok('restart call is gone (no beginSegment retry after a segment)',
  !app.includes('if(!(await beginSegment()))break;'));
ok('beginSegment is called exactly once (the first start)',
  (app.match(/await beginSegment\(\)/g) || []).length === 1);
ok('single-segment wait is present (await segEnded, then commit, then done)',
  app.includes('await segEnded;\n     commitSegment();'));
ok('v2.2.78 one-session comment is present',
  app.includes('v2.2.78: one session per tap'));
// Runtime proof: run the segment-wait code path in a sandbox and confirm
// it never calls beginSegment a second time. Extract the wait block and
// the beginSegment definition, then simulate one segment ending.
const waitBlock = app.match(/\/\/ v2\.2\.78: one session per tap\.[\s\S]*?await segEnded;\n     commitSegment\(\);/);
ok('one-session wait block is extractable from app.js', !!waitBlock);
if (waitBlock) {
  const sb = {
    segEnded: Promise.resolve(),
    commitSegment: function () { sb.committed = (sb.committed || 0) + 1; },
    beginSegment: function () { sb.restarts = (sb.restarts || 0) + 1; return Promise.resolve(true); },
    committed: 0, restarts: 0,
  };
  vm.createContext(sb);
  // The wait block awaits segEnded then commits; it must not restart.
  vm.runInContext('(async()=>{ ' + waitBlock[0].replace(/\/\/ v2\.2\.78: one session per tap\.[^\n]*\n/, '').replace(/\/\/[^\n]*\n/g, '') + ' })();', sb);
  // Give the microtask a turn to run.
  await new Promise(r => setTimeout(r, 50));
  ok('one segment ending commits exactly once', sb.committed === 1, `committed=${sb.committed}`);
  ok('one segment ending never restarts the mic', sb.restarts === 0, `restarts=${sb.restarts}`);
}

// ---- 2. Leaving the page still stops the mic (v2.2.73/75, untouched) ----
ok('go() stops the mic when leaving Search/Ask (bottom nav)',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('popstate stops the mic when leaving Search/Ask (back button)',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('visibilitychange hidden stops the mic (switching apps)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('pagehide stops the mic',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));

// ---- 3. 30s stretches + sound meter + music still present ----
ok('app guard arms at 30000ms', app.includes('armSegGuard(30000);'));
ok('app guard quiet-check uses 30000ms',
  app.includes('if(quietFor<30000){armSegGuard(30000-quietFor);return;}'));
ok('not-hearing message still waits 8s (only a message, not a restart trigger)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app));
ok('voiceMeter div is in BOTH search and ask screens', (app.match(/id="voiceMeter"/g) || []).length === 2);
ok('rmsChanged listener is registered (native plugin event)',
  app.includes("native.addListener('rmsChanged'"));
const css = read('www/styles.css');
ok('voice meter CSS exists (.gs-voice-meter + fill)',
  css.includes('.gs-voice-meter{') && css.includes('.gs-voice-meter-fill{'));
ok('styles.css is byte-identical to v2.2.77 (no CSS changes in this build)',
  fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(path.join(ROLL, 'www/styles.css'))));
const patch = read('scripts/patch-speech-mic.mjs');
ok('patch still sets the recognizer silence timeouts to 30000ms',
  patch.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000') &&
  patch.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000'));
ok('patch mute is still system + notification only (music keeps playing)',
  patch.includes('int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };'));

// ---- 4. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));

// ---- 5. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.77',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 6. Nothing else changed vs v2.2.77 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js'];
const added = ['scripts/fix-v298.py', 'test-v298.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
for (const f of walk(path.join(ROLL, 'scripts'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.77 (only app.js + version files)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.77 (no files missing)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.77',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
