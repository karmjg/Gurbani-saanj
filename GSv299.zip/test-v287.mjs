/* Gurbani Saanj v2.2.67 — Rehras opening ੴ deleted (Karamjit's screenshot
 * 2026-11-15, the TOP "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥" circled in red, "Delete this").
 * Exactly 1 change against v2.2.66:
 * (1) Rehras Sahib (Taksal, ID 21) loses its opening Manglacharan line [0]
 * "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥" — the Bani now opens directly with the Chhant
 * "ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥". The ੴ before
 * "ਸਲੋਕੁ ਮਃ ੧ ॥" (added in v2.2.64) STAYS — it was not circled, and it is
 * still at index 4 after the deletion. The Short Rehras (ID 107) never had
 * an opening ੴ, so it is unchanged.
 * Data changes (all verified): 21.json 422 -> 421 lines; vishraam.json
 * b21 keys shifted -1 (420 keys, total marks still 86,833, line [0] had no
 * marks); manifest searchVerseCount 60386 -> 60385; bani-search.json
 * rebuilt (9,316 -> 9,315 lines; the only removed tuple is the (21,0)
 * manglacharan, every other 21 tuple shifts idx -1, all other Banis
 * byte-identical). No other Bani file changed; app.js / catalog.js
 * untouched. SIDE EFFECT (named to Karamjit): deleting a line shifts all
 * later Rehras Taksal line indices -1, so a previously saved Rehras verse
 * (baniId 21 + idx) now points one line down; Kirtan saves (Ang-based)
 * are unaffected.
 * Kept from v2.2.66: all 5 renames/move (Bhog title, Sundar Gutka, Dasam
 * section, Ardas in Nitnem, Aarti (Vaddi)). Kept from v2.2.65: Mundavni
 * still gone. Kept from v2.2.64: Jaap Fateh (4,1), Rehras Short ੴ (107,4).
 * Mockup (white, our style): rehras-onkar-deleted-mockup-white.webp.
 * Run: node test-v287.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v267-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const catSrc = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
const bani = (id) => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8'));
const g = (lines, i) => (lines[i] && lines[i].g) || '';
const ONKAR = 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const FATEH = 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥';
const BHOG_PA = 'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ';
const BHOG_EN = 'Sri Guru Granth Sahib Ji de Paath de Bhog de Salok';
const AARTI_PA = 'ਆਰਤੀ (ਵੱਡੀ)';
const AARTI_EN = 'Aarti (Vaddi)';

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.67', vj.version === '2.2.67');
ok('package.json is 2.2.67', pj.version === '2.2.67');
ok('native-build-config.js is 2.2.67', nbc.includes('"version":"2.2.67"'));
ok('version notes mention v2.2.67 + Rehras opening ੴ removed + kept ੴ stays',
  vj.notes.includes('v2.2.67:') && vj.notes.includes('Rehras Sahib (Taksal)') &&
  vj.notes.includes('opens directly with the Chhant') && vj.notes.includes('stays'));

// ---- 1a. The deletion: 21.json loses ONLY its opening Manglacharan line ----
{
  const L21 = bani(21).lines;
  const R21 = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/bani/21.json'), 'utf8')).lines;
  ok('21.json: 421 lines now (was 422)', L21.length === 421 && R21.length === 422);
  ok('21.json: new [0] is the Chhant first line "ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ..."',
    g(L21, 0) === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥');
  ok('21.json: new [4] is the KEPT ੴ (v2.2.64, before ਸਲੋਕੁ ਮਃ ੧)',
    g(L21, 4) === ONKAR && L21[4].id === 'PXES');
  ok('21.json: new [5] is ਸਲੋਕੁ ਮਃ ੧ ॥, new [6] is the Dukh Daru first line',
    g(L21, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥' && g(L21, 6) === 'ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ ਭਇਆ ਜਾ ਸੁਖੁ ਤਾਮਿ ਨ ਹੋਈ ॥');
  ok('21.json: the opening Manglacharan is gone (no line with id manglacharan, no line with its English meaning)',
    !L21.some((l) => l.id === 'manglacharan') &&
    !L21.some((l) => l.en === 'One Universal Creator God. By The Grace Of The True Guru.'));
  ok('21.json: every other line is the old line shifted -1 (old [1..421] == new [0..420])',
    L21.every((l, i) => JSON.stringify(l) === JSON.stringify(R21[i + 1])));
  ok('21.json: last line unchanged (ਜਿਸੁ ਸਿਮਰਤ ਸੁਖੁ ਹੋਇ...)',
    g(L21, 420) === 'ਜਿਸੁ ਸਿਮਰਤ ਸੁਖੁ ਹੋਇ ਸਗਲੇ ਦੂਖ ਜਾਹਿ ॥੨॥');
  const L107 = bani(107).lines;
  ok('107.json (Short Rehras): UNCHANGED, still 340 lines, [4] ੴ, [5] ਸਲੋਕੁ ਮਃ ੧',
    L107.length === 340 && g(L107, 4) === ONKAR && g(L107, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥' &&
    JSON.stringify(L107) === JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/bani/107.json'), 'utf8')).lines));
}

// ---- 1b. Vishraam: b21 keys shifted -1, totals unchanged ----
{
  const v = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/vishraam.json'), 'utf8'));
  const rv = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/vishraam.json'), 'utf8'));
  const b21 = Object.entries(v.marks).filter(([k]) => k.startsWith('b21:'));
  const rb21 = Object.entries(rv.marks).filter(([k]) => k.startsWith('b21:'));
  ok('vishraam: total marks still 86,833', Object.keys(v.marks).length === 86833);
  ok('vishraam: b21 keys still 420', b21.length === 420 && rb21.length === 420);
  ok('vishraam: no b21 key with lineIdx 421 (max is now 420)',
    Math.max(...b21.map(([k]) => Number(k.split(':')[1]))) === 420);
  ok('vishraam: every old b21 key (i>=1) is now (i-1) with the same value',
    rb21.every(([k, val]) => {
      const [, li, wi] = k.split(':');
      return v.marks[`b21:${Number(li) - 1}:${wi}`] === val;
    }));
  ok('vishraam: every other Bani\'s marks are byte-identical to v2.2.66',
    Object.entries(rv.marks).every(([k, val]) => k.startsWith('b21:') || v.marks[k] === val) &&
    Object.entries(v.marks).every(([k, val]) => k.startsWith('b21:') || rv.marks[k] === val));
}

// ---- 1c. Manifest: only searchVerseCount changed (60386 -> 60385) ----
{
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8'));
  const rm = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/manifest.json'), 'utf8'));
  ok('manifest: searchVerseCount is 60385 (was 60386)', m.searchVerseCount === 60385 && rm.searchVerseCount === 60386);
  ok('manifest: baniCount still 29, banis list still 29, all titles byte-identical',
    m.baniCount === 29 && m.banis.length === 29 &&
    m.banis.every((b) => { const r = rm.banis.find((x) => x.id === b.id); return !!r && r.titlePa === b.titlePa && r.titleEn === b.titleEn; }));
  ok('manifest: vishraam counts unchanged (86833/28342/58491), angCount 1430',
    m.vishraamMarkCount === 86833 && m.vishraamShortCount === 28342 &&
    m.vishraamLongCount === 58491 && m.angCount === 1430);
}

// ---- 1d. Search index: 9,315 lines; only the (21,0) tuple removed, 21 shifted -1 ----
{
  const bs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const rbs = JSON.parse(fs.readFileSync(path.join(ROLL, 'www/offline/bani-search.json'), 'utf8'));
  ok('bani-search.json: 9,315 lines (was 9,316)', bs.length === 9315 && rbs.length === 9316);
  const per = {};
  for (const r of bs) per[r[0]] = (per[r[0]] || 0) + 1;
  ok('bani-search.json: 421 entries for 21 (was 422), 340 for 107 (unchanged)',
    per[21] === 421 && per[107] === 340);
  ok('bani-search.json: new (21,0) is the Chhant first line, (21,4) the kept ੴ, (21,5) ਸਲੋਕੁ ਮਃ ੧',
    bs.find((r) => r[0] === 21 && r[1] === 0)[2] === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥' &&
    bs.find((r) => r[0] === 21 && r[1] === 4)[2] === ONKAR &&
    bs.find((r) => r[0] === 21 && r[1] === 5)[2] === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  ok('bani-search.json: the only removed tuple is the (21,0) Manglacharan',
    !bs.some((r) => r[0] === 21 && r[2] === ONKAR && r[3] === 'One Universal Creator God. By The Grace Of The True Guru.'));
  ok('bani-search.json: every old 21 tuple with idx>=1 reappears with idx-1, same text',
    rbs.filter((r) => r[0] === 21 && r[1] >= 1).every((r) => {
      const n = bs.find((x) => x[0] === 21 && x[1] === r[1] - 1);
      return !!n && JSON.stringify(n.slice(2)) === JSON.stringify(r.slice(2));
    }));
  ok('bani-search.json: every other Bani\'s tuples are byte-identical to v2.2.66',
    (() => {
      const newSet = new Set(bs.filter((r) => r[0] !== 21).map((r) => JSON.stringify(r)));
      const oldSet = new Set(rbs.filter((r) => r[0] !== 21).map((r) => JSON.stringify(r)));
      return rbs.filter((r) => r[0] !== 21).every((r) => newSet.has(JSON.stringify(r))) &&
        bs.filter((r) => r[0] !== 21).every((r) => oldSet.has(JSON.stringify(r)));
    })());
  ok('bani-search.json: 29 distinct Bani ids', Object.keys(per).length === 29);
}

// ---- 1e. Kept from v2.2.66: the 5 renames / one move still hold ----
{
  ok("v2.2.66 kept: Pa string catalog is 'ਸੁੰਦਰ ਗੁਟਕਾ', En 'Sundar Gutka'",
    app.includes("catalog:'ਸੁੰਦਰ ਗੁਟਕਾ'") && app.includes("catalog:'Sundar Gutka'"));
  ok('v2.2.66 kept: Dasam section + section 3 strings unchanged',
    app.includes("catalogSection2:'ਦਸਮ ਪਾਤਸ਼ਾਹ ਦੀਆਂ ਬਾਣੀਆਂ'") &&
    app.includes("catalogSection2:'Dasam Patshah Dian Banian'") &&
    app.includes("catalogSection3:'ਹੋਰ ਪਾਠ ਅਤੇ ਬਾਣੀ ਰੂਪ'") &&
    app.includes("catalogSection3:'Other recitations and Bani forms'"));
  ok('v2.2.66 kept: Ardas (114) still in NITNEM_LIST between 21 and 130',
    (() => { const m = app.match(/const NITNEM_LIST=\[([\s\S]*?)\];/);
      return !!m && m[1].includes("['ਅਰਦਾਸ','Ardas',114]") &&
        m[1].indexOf("['ਰਹਰਾਸਿ ਸਾਹਿਬ','Rehras Sahib',21]") < m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") &&
        m[1].indexOf("['ਅਰਦਾਸ','Ardas',114]") < m[1].indexOf("['ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ','Rakhia De Shabad',130]"); })());
  const catCtx = { window: {} };
  vm.runInNewContext(catSrc, catCtx);
  const cat = catCtx.window.GS_CATALOG || [];
  ok('v2.2.66 kept: catalog still 20 entries, no 114, 127 Bhog + 110 Aarti (Vaddi) titles',
    cat.length === 20 && !cat.some((c) => c.id === 114) &&
    cat.find((c) => c.id === 127).titlePa === BHOG_PA &&
    cat.find((c) => c.id === 127).titleEn === BHOG_EN &&
    cat.find((c) => c.id === 110).titlePa === AARTI_PA &&
    cat.find((c) => c.id === 110).titleEn === AARTI_EN);
  ok('v2.2.66 kept: build script header counts updated (29 Banis, 9,315 lines, 20 catalog, 9 Nitnem)',
    fs.readFileSync(path.join(ROOT, 'scripts/build-bani-search.mjs'), 'utf8').includes('29 Banis, 9,315 lines') &&
    fs.readFileSync(path.join(ROOT, 'scripts/build-bani-search.mjs'), 'utf8').includes('20 catalog Banis') &&
    fs.readFileSync(path.join(ROOT, 'scripts/build-bani-search.mjs'), 'utf8').includes('9 Nitnem titles'));
}

// ---- 2. Kept from v2.2.65: Mundavni still gone ----
ok('v2.2.65: 126.json still deleted', !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
ok('v2.2.65: no Mundavni title in catalog, manifest or search index',
  !/Mundav|ਮੁੰਦਾਵਣੀ/.test(
    catSrc + JSON.stringify(JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8')).banis.map((b) => b.titlePa + ' ' + b.titleEn).join(' ')) +
    JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8')).map((r) => r[6] + ' ' + r[7]).join(' ')));

// ---- 3. Kept from v2.2.64 ----
{
  const d4 = bani(4), L4 = d4.lines;
  ok('v2.2.64: Jaap (ID 4) still 802 lines, [1] is the Fateh line',
    L4.length === 802 && g(L4, 1) === FATEH && g(L4, 0) === ONKAR && g(L4, 2) === 'ਜਾਪੁ ॥');
  const d21 = bani(21), L21 = d21.lines;
  ok('v2.2.64: Rehras Taksal (ID 21) now 421 lines (opening ੴ deleted in v2.2.67), [4] is the kept ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L21.length === 421 && g(L21, 4) === ONKAR && g(L21, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥' &&
    g(L21, 0) === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥');
  const d107 = bani(107), L107 = d107.lines;
  ok('v2.2.64: Rehras Short (ID 107) still 340 lines, [4] is ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L107.length === 340 && g(L107, 4) === ONKAR && g(L107, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
}

// ---- 4. Kept markers (v2.2.63 / 62 / 61 / 60 / 59 / 58 / 57, no Help) ----
ok('v2.2.63: Kirtan fallback present (save from kirtanBookList when lookup() is null)',
  app.includes('Kirtan book fallback') && app.includes('const s=kb.find(x=>x.ang===ang&&x.lineStart===idx);'));
ok('v2.2.63: stay-put — heart updates in place, no render() on the save-hit path',
  app.includes("save.classList.toggle('selected',added);") && app.includes("save.textContent=added?'♥':'♡';"));
ok('v2.2.63: no navigation to bookmarks anywhere (no go(bookmarks))',
  !app.includes("go('bookmarks')"));
ok('v2.2.63: Saved tab rows have a remove control (data-remove-saved ♥)',
  (() => { const bm = app.split('\n').find((l) => l.startsWith('function bookmarksScreen(){')); return !!bm && bm.includes('data-remove-saved=') && bm.includes('</button><button data-remove-saved='); })());
ok('v2.2.62: language-toggle hang guards still in ensureHukamnama',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.60: Kirtan heart button still on each Shabad row (data-save-hit ang:lineStart)',
  app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: History clock still AFTER the ਪੁ/EN button in the search box',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 5. Mockup exists (v2.2.67, white, our style) ----
{
  const gfxAbs = '/home/hatch/workspace/gurbani/play-store/graphics';
  for (const f of ['rehras-onkar-deleted-mockup-white.webp']) {
    ok(`mockup exists: ${f}`, fs.existsSync(path.join(gfxAbs, f)) && fs.statSync(path.join(gfxAbs, f)).size > 10000);
  }
}

// ---- 6. vm: the REAL scripture search over the REAL rebuilt index ----
{
  const ssSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sggs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
  const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const sandbox = {
    console,
    window: {},
    fetch: (url) => {
      const data = String(url).includes('bani-search') ? baniIdx : sggs;
      return Promise.resolve({ ok: true, json: async () => data });
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(ssSrc, sandbox);
  const GS = sandbox.window.GS_SCRIPTURE_SEARCH;
  ok('vm: real scripture-search loads (lookupBani + query available)', !!GS && typeof GS.lookupBani === 'function' && typeof GS.query === 'function');
  await GS.load();
  const r21 = GS.lookupBani(21, 0);
  ok('vm: lookupBani(21, 0) is now the Chhant first line (opening ੴ gone)',
    !!r21 && r21.g === 'ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ ਪੈਜ ਰਖਦਾ ਆਇਆ ਰਾਮ ਰਾਜੇ ॥' && r21.baniTitle === 'ਰਹਰਾਸਿ ਸਾਹਿਬ');
  const r21k = GS.lookupBani(21, 4);
  ok('vm: lookupBani(21, 4) is the kept ੴ before ਸਲੋਕੁ ਮਃ ੧',
    !!r21k && r21k.g === ONKAR);
  const r127 = GS.lookupBani(127, 0);
  ok('vm: lookupBani(127, 0) returns the first line with the NEW Bhog title',
    !!r127 && r127.g === ONKAR && r127.baniTitle === BHOG_PA);
  const r110 = GS.lookupBani(110, 0);
  ok('vm: lookupBani(110, 0) returns the first line with the NEW Aarti title',
    !!r110 && r110.baniTitle === AARTI_PA);
  const r114 = GS.lookupBani(114, 0);
  ok('vm: lookupBani(114, 0) still returns Ardas (title ਅਰਦਾਸ, group tradition)',
    !!r114 && r114.baniTitle === 'ਅਰਦਾਸ' && r114.group === 'tradition');
  // NOTE: GS.query() matches LINE TEXT (first letters), not Bani titles,
  // and caps at 40 results — so a title-only word like "ਅਰਦਾਸ" returns
  // SGGS lines that contain it, not the Bani itself. That is pre-existing
  // search behaviour, not a v2.2.66 change, so the vm checks below assert
  // the renamed Banis are findable by their actual lines instead.
  const qArdas = await GS.query('ਦਸਾਂ ਪਾਤਿਸ਼ਾਹੀਆਂ ਦੀ ਜੋਤ');
  ok('vm: an Ardas line is searchable and finds Bani 114',
    qArdas.some((r) => r.src === 'bani' && r.baniId === 114 && r.idx === 11));
  const qBhog = await GS.query('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦੇ ਭੋਗ ਦੇ ਸਲੋਕ');
  ok('vm: searching the new Bhog title finds Bani 127',
    qBhog.some((r) => r.src === 'bani' && r.baniId === 127));
  const qAarti = await GS.query('ਗਗਨ ਮੈ ਥਾਲੁ');
  ok('vm: an Aarti (Vaddi) line is searchable and finds Bani 110',
    qAarti.some((r) => r.src === 'bani' && r.baniId === 110 && r.idx === 2));
  const qChhant = await GS.query('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ');
  ok('vm: the Chhant first line is searchable and finds Bani 21 idx 0',
    qChhant.some((r) => r.src === 'bani' && r.baniId === 21 && r.idx === 0));
  const qFateh = await GS.query('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ');
  ok('vm: v2.2.64 Fateh line still searchable (baniId 4, idx 1)',
    qFateh.some((r) => r.src === 'bani' && r.baniId === 4 && r.idx === 1 && r.g === FATEH));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
