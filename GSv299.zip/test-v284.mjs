/* Gurbani Saanj v2.2.64 — missing lines added to Jaap Sahib + Rehras Sahib
 * (Karamjit, 2026-11-14, from his two reference photos):
 * Photo 1 = REHRAS SAHIB: the closing Salok (Mehla 1, "ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ
 * ਭਇਆ", Ang 469) is preceded in the photo by a teal "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ॥"
 * line right after the "ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ" Shabad ending
 * "॥੪॥੧੩॥੨੦॥" (Ang 451) — the app had NO ੴ line before "ਸਲੋਕੁ ਮਃ ੧ ॥".
 * Photo 2 = JAAP SAHIB: the photo shows "ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥"
 * (ਫ਼ with nukta) between "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥" and "ਜਾਪੁ ॥" — the app
 * went straight from ੴ to ਜਾਪੁ, the Fateh line was missing entirely.
 * FIX (data only, no app.js change):
 * (1) Jaap Sahib (Bani ID 4): insert "ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥" at
 * index 1, after [0] "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥" and before "ਜਾਪੁ ॥" — 801→802
 * lines. New line id EP94 (fresh, unique in the file); en/pa/roman filled
 * from the same Fateh line used in other Banis.
 * (2) Rehras Sahib Taksal (ID 21): insert "ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥" at index 5,
 * immediately before "ਸਲੋਕੁ ਮਃ ੧ ॥" — 421→422 lines. The ੴ already at [0]
 * is untouched. Same line (id PXES, same en/pa/roman as Jaap [0]).
 * (3) Rehras Sahib Short (ID 107): same insertion at index 4, immediately
 * before "ਸਲੋਕੁ ਮਃ ੧ ॥" — 339→340 lines.
 * Derived data updated so the new lines are searchable and carry meanings:
 * www/offline/bani-search.json rebuilt with scripts/build-bani-search.mjs
 * (9,482→9,485 lines; the script's stale nitnem mirror was missing Rakhia
 * De Shabad ID 130, so the rebuild would have retitled it "Bani 130" —
 * fixed by adding [130, 'ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ', 'Rakhia De Shabad', 'sggs'] to the
 * script, and the file keeps the old tuple order with Rakhia last, so the
 * diff is exactly the 3 inserted tuples). Vishraam pause marks in
 * www/offline/vishraam.json shifted by +1 for every line at/after each
 * insertion point (b4: lineIdx>=1, b21: >=5, b107: >=4 — 851 keys), so each
 * mark stays on the same text; total marks unchanged at 87,112 and the
 * inserted Manglacharan lines carry no marks (as the existing ੴ at Jaap [0]
 * does not either). Nothing else added, nothing removed.
 * Kept from v2.2.63: Kirtan heart fallback + stay-put save + Saved remove,
 * language-toggle hang guards, no Mool Mantar in the drawer, ensureCatalog,
 * icon row gone, clock after ਪੁ/EN, pills nowrap. No Help button (cancelled).
 * Run: node test-v284.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const bani = (id) => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8'));
const g = (lines, i) => (lines[i] && lines[i].g) || '';
const ONKAR = 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const FATEH = 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥';

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.64', vj.version === '2.2.64');
ok('package.json is 2.2.64', pj.version === '2.2.64');
ok('native-build-config.js is 2.2.64', nbc.includes('"version":"2.2.64"'));
ok('version notes mention v2.2.64 + Jaap Fateh + Rehras ੴ before Salok',
  vj.notes.includes('v2.2.64:') && vj.notes.includes('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ') && vj.notes.includes('ਸਲੋਕੁ ਮਃ ੧'));

// ---- 1a. Jaap Sahib (ID 4): Fateh line added at index 1 ----
{
  const d = bani(4), L = d.lines;
  ok('Jaap (ID 4): 802 lines (was 801)', L.length === 802);
  ok('Jaap (ID 4): [0] is still ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥', g(L, 0) === ONKAR);
  ok('Jaap (ID 4): [1] is exactly ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥', g(L, 1) === FATEH);
  ok('Jaap (ID 4): [1] uses ਫ਼ with nukta (U+0A2B U+0A3C), as in the photo',
    g(L, 1).includes('\u0a2b\u0a3c'));
  ok('Jaap (ID 4): [1] carries English + Punjabi + Roman meanings',
    (L[1].en || '').includes('Victory') && (L[1].pa || '').includes('ਫਤਹ') && (L[1].roman || '').includes('fatah'));
  ok('Jaap (ID 4): [1] has a fresh unique id (EP94), no duplicate ids in the file',
    L[1].id === 'EP94' && new Set(L.map((l) => l.id)).size === L.length);
  ok('Jaap (ID 4): [2] is ਜਾਪੁ ॥, [3] ਸ੍ਰੀ ਮੁਖਵਾਕ ਪਾਤਿਸਾਹੀ ੧੦ ॥, [4] ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥',
    g(L, 2) === 'ਜਾਪੁ ॥' && g(L, 3) === 'ਸ੍ਰੀ ਮੁਖਵਾਕ ਪਾਤਿਸਾਹੀ ੧੦ ॥' && g(L, 4) === 'ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥');
  ok('Jaap (ID 4): opening order matches the photo (ੴ / Fateh / ਜਾਪੁ / ਮੁਖਵਾਕ / ਛਪੈ ਛੰਦ / ਚੱਕ੍ਰ ਚਿਹਨ)',
    g(L, 0) === ONKAR && g(L, 1) === FATEH && g(L, 2) === 'ਜਾਪੁ ॥' &&
    g(L, 3) === 'ਸ੍ਰੀ ਮੁਖਵਾਕ ਪਾਤਿਸਾਹੀ ੧੦ ॥' && g(L, 4) === 'ਛਪੈ ਛੰਦ ॥ ਤ੍ਵ ਪ੍ਰਸਾਦਿ ॥' && g(L, 5).startsWith('ਚੱਕ੍ਰ ਚਿਹਨ'));
  ok('Jaap (ID 4): lines after the insertion are unchanged (old [4] ਚੱਕ੍ਰ ਚਿਹਨ now [5], old [5] ਰੂਪ ਰੰਗ now [6])',
    g(L, 5).startsWith('ਚੱਕ੍ਰ ਚਿਹਨ') && g(L, 6).startsWith('ਰੂਪ ਰੰਗ') && g(L, 801).length > 0);
}

// ---- 1b. Rehras Sahib Taksal (ID 21): ੴ added before ਸਲੋਕੁ ਮਃ ੧ ----
{
  const d = bani(21), L = d.lines;
  ok('Rehras Taksal (ID 21): 422 lines (was 421)', L.length === 422);
  ok('Rehras Taksal (ID 21): [0] ੴ at the top is untouched', g(L, 0) === ONKAR);
  ok('Rehras Taksal (ID 21): [4] is the ਹਰਿ ਜੁਗੁ ਜੁਗੁ Shabad ending ॥੪॥੧੩॥੨੦॥',
    g(L, 4).startsWith('ਜਨ ਨਾਨਕ ਐਸਾ ਹਰਿ ਸੇਵਿਆ') && g(L, 4).includes('॥੪॥੧੩॥੨੦॥'));
  ok('Rehras Taksal (ID 21): [5] is the added ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ (id PXES, same as Jaap [0])',
    g(L, 5) === ONKAR && L[5].id === 'PXES' && L[5].en === bani(4).lines[0].en && L[5].roman === bani(4).lines[0].roman);
  ok('Rehras Taksal (ID 21): [6] is ਸਲੋਕੁ ਮਃ ੧ ॥ and [7] starts ਦੁਖੁ ਦਾਰੂ',
    g(L, 6) === 'ਸਲੋਕੁ ਮਃ ੧ ॥' && g(L, 7).startsWith('ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ ਭਇਆ'));
  ok('Rehras Taksal (ID 21): [5] sits exactly between the Shabad ending and the Salok heading',
    g(L, 4).includes('॥੪॥੧੩॥੨੦॥') && g(L, 5) === ONKAR && g(L, 6) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  ok('Rehras Taksal (ID 21): last line unchanged (Anand ending)',
    g(L, 421) === 'ਜਿਸੁ ਸਿਮਰਤ ਸੁਖੁ ਹੋਇ ਸਗਲੇ ਦੂਖ ਜਾਹਿ ॥੨॥');
  ok('Rehras Taksal (ID 21): no duplicate line ids in the file',
    new Set(L.map((l) => l.id)).size === L.length);
}

// ---- 1c. Rehras Sahib Short (ID 107): same ੴ before ਸਲੋਕੁ ਮਃ ੧ ----
{
  const d = bani(107), L = d.lines;
  ok('Rehras Short (ID 107): 340 lines (was 339)', L.length === 340);
  ok('Rehras Short (ID 107): [3] is the ਹਰਿ ਜੁਗੁ ਜੁਗੁ Shabad ending ॥੪॥੧੩॥੨੦॥',
    g(L, 3).startsWith('ਜਨ ਨਾਨਕ ਐਸਾ ਹਰਿ ਸੇਵਿਆ') && g(L, 3).includes('॥੪॥੧੩॥੨੦॥'));
  ok('Rehras Short (ID 107): [4] is the added ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥ (id PXES)',
    g(L, 4) === ONKAR && L[4].id === 'PXES');
  ok('Rehras Short (ID 107): [5] is ਸਲੋਕੁ ਮਃ ੧ ॥ and [6] starts ਦੁਖੁ ਦਾਰੂ',
    g(L, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥' && g(L, 6).startsWith('ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ ਭਇਆ'));
  ok('Rehras Short (ID 107): [0] is unchanged (starts with the ਹਰਿ ਜੁਗੁ ਜੁਗੁ Shabad)',
    g(L, 0).startsWith('ਹਰਿ ਜੁਗੁ ਜੁਗੁ ਭਗਤ ਉਪਾਇਆ'));
  ok('Rehras Short (ID 107): no duplicate line ids in the file',
    new Set(L.map((l) => l.id)).size === L.length);
}

// ---- 1d. Search index (bani-search.json) includes the new lines ----
{
  const bs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  ok('bani-search.json: 9,485 lines (was 9,482)', bs.length === 9485);
  const per = {};
  for (const r of bs) per[r[0]] = (per[r[0]] || 0) + 1;
  ok('bani-search.json: per-Bani counts 802 / 422 / 340 for IDs 4 / 21 / 107',
    per[4] === 802 && per[21] === 422 && per[107] === 340);
  const find = (id, idx) => bs.find((r) => r[0] === id && r[1] === idx);
  ok('bani-search.json: Jaap Fateh line at (4,1) with en/pa/roman + Dasam group',
    (() => { const r = find(4, 1); return !!r && r[2] === FATEH && r[3].includes('Victory') && r[5].includes('fatah') && r[6] === 'ਜਾਪੁ ਸਾਹਿਬ' && r[8] === 'dasam'; })());
  ok('bani-search.json: Rehras ੴ at (21,5) and (107,4) with meanings',
    (() => { const a = find(21, 5), b = find(107, 4); return !!a && !!b && a[2] === ONKAR && b[2] === ONKAR && a[3].includes('true Guru') && b[3].includes('true Guru'); })());
  ok('bani-search.json: shifted neighbours correct — (4,2) ਜਾਪੁ, (21,6) ਸਲੋਕੁ ਮਃ ੧, (107,5) ਸਲੋਕੁ ਮਃ ੧',
    find(4, 2)[2] === 'ਜਾਪੁ ॥' && find(21, 6)[2] === 'ਸਲੋਕੁ ਮਃ ੧ ॥' && find(107, 5)[2] === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  ok('bani-search.json: Rakhia De Shabad (ID 130) still 30 lines, correctly titled (not "Bani 130")',
    per[130] === 30 && find(130, 0)[6] === 'ਰੱਖਿਆ ਦੇ ਸ਼ਬਦ' && find(130, 0)[7] === 'Rakhia De Shabad');
  ok('bani-search.json: old lines still present — (4,0) ੴ, (21,0) ੴ, (21,7) ਦੁਖੁ ਦਾਰੂ',
    find(4, 0)[2] === ONKAR && find(21, 0)[2] === ONKAR && find(21, 7)[2].startsWith('ਦੁਖੁ ਦਾਰੂ'));
}

// ---- 1e. Vishraam marks shifted with the lines (same text, same total) ----
{
  const v = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/vishraam.json'), 'utf8'));
  const marks = v.marks;
  const count = (p) => Object.keys(marks).filter((k) => k.startsWith(p)).length;
  ok('vishraam.json: total marks unchanged at 87,112', Object.keys(marks).length === 87112);
  ok('vishraam.json: per-Bani counts unchanged (b4:61, b21:420, b107:388)',
    count('b4:') === 61 && count('b21:') === 420 && count('b107:') === 388);
  ok('vishraam.json: Jaap mark shifted with its line (old b4:4:3 is now b4:5:3)',
    marks['b4:5:3'] === 'l' && !('b4:4:3' in marks));
  ok('vishraam.json: no marks on the inserted Manglacharan lines (b4:1, b21:5, b107:4)',
    !Object.keys(marks).some((k) => k.startsWith('b4:1:') || k.startsWith('b21:5:') || k.startsWith('b107:4:')));
  ok('vishraam.json: max line index moved +1 per Bani (b4:800, b21:421, b107:339)',
    Math.max(...Object.keys(marks).filter((k) => k.startsWith('b4:')).map((k) => +k.split(':')[1])) === 800 &&
    Math.max(...Object.keys(marks).filter((k) => k.startsWith('b21:')).map((k) => +k.split(':')[1])) === 421 &&
    Math.max(...Object.keys(marks).filter((k) => k.startsWith('b107:')).map((k) => +k.split(':')[1])) === 339);
  ok('vishraam.json: Salok headings carry no marks (b21:6, b107:5 empty)',
    !Object.keys(marks).some((k) => k.startsWith('b21:6:') || k.startsWith('b107:5:')));
}

// ---- 2. v2.2.63 markers intact ----
ok('v2.2.63: Kirtan fallback present (save from kirtanBookList when lookup() is null)',
  app.includes('Kirtan book fallback') && app.includes('const s=kb.find(x=>x.ang===ang&&x.lineStart===idx);'));
ok('v2.2.63: stay-put — heart updates in place, no render() on the save-hit path',
  app.includes("save.classList.toggle('selected',added);") && app.includes("save.textContent=added?'♥':'♡';"));
ok('v2.2.63: no navigation to bookmarks anywhere (no go(bookmarks))',
  !app.includes("go('bookmarks')"));
ok('v2.2.63: Saved tab rows have a remove control (data-remove-saved ♥)',
  (() => { const bm = app.split('\n').find((l) => l.startsWith('function bookmarksScreen(){')); return !!bm && bm.includes('data-remove-saved=') && bm.includes('</button><button data-remove-saved='); })());
ok('v2.2.62: language-toggle hang guards still in ensureHukamnama',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.60: Kirtan heart button still on each Shabad row (data-save-hit ang:lineStart)',
  app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: History clock still AFTER the ਪੁ/EN button in the search box',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 3. vm: the REAL scripture search over the REAL rebuilt index ----
{
  const ssSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sggs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
  const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const sandbox = {
    console,
    window: {},
    fetch: (url) => {
      const data = String(url).includes('bani-search') ? baniIdx : sggs;
      return Promise.resolve({ ok: true, json: async () => data });
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(ssSrc, sandbox);
  const GS = sandbox.window.GS_SCRIPTURE_SEARCH;
  ok('vm: real scripture-search loads (lookupBani + query available)', !!GS && typeof GS.lookupBani === 'function' && typeof GS.query === 'function');
  await GS.load();
  const f = GS.lookupBani(4, 1);
  ok('vm: lookupBani(4,1) returns the added Fateh line (Dasam, Jaap Sahib)',
    !!f && f.g === FATEH && f.group === 'dasam' && f.baniTitle === 'ਜਾਪੁ ਸਾਹਿਬ');
  const o21 = GS.lookupBani(21, 5), o107 = GS.lookupBani(107, 4);
  ok('vm: lookupBani(21,5) and lookupBani(107,4) return the added ੴ line',
    !!o21 && o21.g === ONKAR && !!o107 && o107.g === ONKAR);
  ok('vm: shifted lookups still resolve — (4,2) ਜਾਪੁ, (21,7) ਦੁਖੁ ਦਾਰੂ, (107,6) ਦੁਖੁ ਦਾਰੂ',
    GS.lookupBani(4, 2).g === 'ਜਾਪੁ ॥' &&
    GS.lookupBani(21, 7).g.startsWith('ਦੁਖੁ ਦਾਰੂ') &&
    GS.lookupBani(107, 6).g.startsWith('ਦੁਖੁ ਦਾਰੂ'));
  const qFateh = await GS.query('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ');
  ok('vm: searching "ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ" finds the new Jaap line (baniId 4, idx 1)',
    qFateh.some((r) => r.src === 'bani' && r.baniId === 4 && r.idx === 1 && r.g === FATEH),
    JSON.stringify(qFateh.slice(0, 3).map((r) => [r.src, r.baniId, r.idx])));
  const qDukh = await GS.query('ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ');
  ok('vm: searching "ਦੁਖੁ ਦਾਰੂ ਸੁਖੁ ਰੋਗੁ" still finds the Salok in both Rehras files (shifted idx)',
    qDukh.some((r) => r.src === 'bani' && r.baniId === 21 && r.idx === 7) &&
    qDukh.some((r) => r.src === 'bani' && r.baniId === 107 && r.idx === 6),
    JSON.stringify(qDukh.slice(0, 4).map((r) => [r.src, r.baniId, r.idx])));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
