/* Gurbani Saanjh v2.2.76 - offline mic improvement (Karamjit 2026-11-18:
 * "lets improve the mic" + "so no beep?" + "find a way offline, we don't
 * want to do it online").
 *
 * Exactly 2 new changes vs v2.2.75, both offline (no cloud, no internet):
 *  1. BEEP MUTED in the app. The beep is the phone's speech-service sound
 *     (no off switch), so the app quiets the sound streams it plays on
 *     (music/system/notification) while the mic listens, and restores them
 *     when it stops. Done in the speech plugin via a postinstall patch
 *     (scripts/patch-speech-mic.mjs). Only streams that were unmuted are
 *     muted, so the user's own mute settings are preserved.
 *  2. SOUND METER. The plugin forwards the mic sound level (onRmsChanged)
 *     as an "rmsChanged" event (~10/s); search + ask show a live green
 *     bar so he can SEE the mic hearing him. Ask also gains a voice-status
 *     line (it had none).
 * Fuzzy matching is NOT a change: it is already in the app (v2.2.44
 * skeleton/matra matching in scripture-search.js, verified here).
 * Run: node test-v296.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import { execSync } from 'node:child_process';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v296-rollback';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.76', vj.version === '2.2.76');
ok('package.json is 2.2.76', pj.version === '2.2.76');
ok('native-build-config.js is 2.2.76', nbc.includes('"version":"2.2.76"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.76 entry',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.76:') &&
  vj.notes.includes('offline mic') && vj.notes.includes('beep') && vj.notes.includes('sound bar'));
ok('native-build-config.js differs from v2.2.75 ONLY in the version string',
  nbc.replace('2.2.76', '2.2.75') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.75 ONLY in version + postinstall script',
  read('package.json').replace('2.2.76', '2.2.75').replace('patch-speech-mic.mjs', 'patch-speech-silence.mjs') === readR('package.json'));

// ---- 1. The mic patch script (mute + RMS + manifest + 8s silence) ----
const patch = read('scripts/patch-speech-mic.mjs');
ok('patch script exists (scripts/patch-speech-mic.mjs)', fs.existsSync(path.join(ROOT, 'scripts/patch-speech-mic.mjs')));
ok('old silence-only patch script is gone', !fs.existsSync(path.join(ROOT, 'scripts/patch-speech-silence.mjs')));
ok('patch covers the beep mute (mute/unmute + AudioManager streams)',
  patch.includes('muteBeepStreams') && patch.includes('unmuteBeepStreams') &&
  patch.includes('AudioManager.STREAM_MUSIC') && patch.includes('AudioManager.STREAM_SYSTEM') &&
  patch.includes('AudioManager.STREAM_NOTIFICATION') && patch.includes('ADJUST_MUTE') && patch.includes('ADJUST_UNMUTE'));
ok('patch preserves already-muted streams (only unmuted ones are muted)',
  patch.includes('isStreamMute') && patch.includes('mutedStreams'));
ok('patch covers the RMS forward (rmsChanged event)',
  patch.includes('rmsChanged') && patch.includes('onRmsChanged') && patch.includes('lastRmsTime'));
ok('patch covers the manifest permission (MODIFY_AUDIO_SETTINGS)',
  patch.includes('MODIFY_AUDIO_SETTINGS'));
ok('patch keeps the 8s silence fix (both timeouts 8000ms)',
  patch.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000') &&
  patch.includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000'));
ok('patch is idempotent (every patch guarded by a marker check)',
  (patch.match(/patchOnce\(/g) || []).length >= 10);
ok('package.json runs the mic patch on postinstall',
  pj.scripts && pj.scripts.postinstall === 'node scripts/patch-speech-mic.mjs');
// The plugin Java lives in node_modules (not in the zip): check it only when present.
const PLUGIN_JAVA = 'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
const PLUGIN_MANIFEST = 'node_modules/@capacitor-community/speech-recognition/android/src/main/AndroidManifest.xml';
if (fs.existsSync(path.join(ROOT, PLUGIN_JAVA))) {
  const java = read(PLUGIN_JAVA);
  ok('plugin Java has the mute calls (mute on start, unmute on stop/end/error)',
    java.includes('muteBeepStreams();') && (java.match(/unmuteBeepStreams\(\);/g) || []).length >= 3);
  ok('plugin Java forwards RMS (rmsChanged notify)',
    java.includes('notifyListeners("rmsChanged"'));
  ok('plugin Java still has the 8s silence extras',
    java.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000'));
  ok('plugin manifest has MODIFY_AUDIO_SETTINGS',
    fs.existsSync(path.join(ROOT, PLUGIN_MANIFEST)) && read(PLUGIN_MANIFEST).includes('MODIFY_AUDIO_SETTINGS'));
  // The patch script must re-apply cleanly (idempotent) on the already-patched tree.
  try {
    const out = execSync('node scripts/patch-speech-mic.mjs', { cwd: ROOT, encoding: 'utf8' });
    ok('patch script re-runs cleanly on the patched tree (idempotent, nothing freshly applied)',
      out.includes('already applied') && !out.includes(': applied\n') && out.includes('speech mic patch done'));
  } catch (e) {
    ok('patch script re-runs cleanly on the patched tree (idempotent, nothing freshly applied)', false, String(e && e.message || e));
  }
} else {
  console.log('SKIP  plugin Java checks (no node_modules in this copy — the postinstall patch applies them at build time)');
}

// ---- 2. Sound meter (app.js + styles.css, search + ask) ----
const app = read('www/app.js');
ok('voiceMeter div is in the search screen', app.includes('<div id="voiceMeter" class="gs-voice-meter" hidden><div id="voiceMeterFill" class="gs-voice-meter-fill"></div></div>'));
ok('voiceMeter div is in BOTH search and ask screens', (app.match(/id="voiceMeter"/g) || []).length === 2);
ok('voiceStatus is in BOTH search and ask screens (ask had none)', (app.match(/id="voiceStatus"/g) || []).length === 2);
ok('rmsToLevel + setVoiceMeter + hideVoiceMeter functions exist',
  app.includes('function rmsToLevel') && app.includes('function setVoiceMeter') && app.includes('function hideVoiceMeter'));
ok('rmsChanged listener is registered (native plugin event)',
  app.includes("native.addListener('rmsChanged'"));
ok('setListeningUI shows/hides the meter with the listening state',
  app.includes('hideVoiceMeter();') && app.includes('if(m)m.hidden=false;'));
const css = read('www/styles.css');
ok('voice meter CSS exists (.gs-voice-meter + fill)',
  css.includes('.gs-voice-meter{') && css.includes('.gs-voice-meter-fill{'));
ok('voice meter has dark/charcoal/nightmode track colours',
  css.includes('html[data-tone="dark"] .gs-voice-meter') && css.includes('html[data-nightmode="on"] .gs-voice-meter'));
// Extract the REAL rmsToLevel from app.js and run it (vm sandbox).
const rmsFnSrc = app.match(/function rmsToLevel\(rms\)\{[^}]*\}/);
ok('rmsToLevel is extractable from app.js', !!rmsFnSrc);
if (rmsFnSrc) {
  const sb = {};
  vm.createContext(sb);
  vm.runInContext(rmsFnSrc[0] + ';this.__rms=rmsToLevel;', sb);
  const rmsToLevel = sb.__rms;
  ok('rmsToLevel: silence (-20) maps to 0', rmsToLevel(-20) === 0);
  ok('rmsToLevel: quiet (-15) maps to ~0.28', Math.abs(rmsToLevel(-15) - 5 / 18) < 0.001);
  ok('rmsToLevel: normal speech (-8) maps to ~0.67', Math.abs(rmsToLevel(-8) - 12 / 18) < 0.001);
  ok('rmsToLevel: loud (-2) maps to 1', rmsToLevel(-2) === 1);
  ok('rmsToLevel: louder than -2 clamps to 1', rmsToLevel(0) === 1);
  ok('rmsToLevel: quieter than -20 clamps to 0', rmsToLevel(-40) === 0);
  ok('rmsToLevel: non-number input maps to 0', rmsToLevel('x') === 0 && rmsToLevel(NaN) === 0);
}

// ---- 3. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));

// ---- 4. Mic fixes from v2.2.73/75 still present ----
ok('app stops the mic on background (visibilitychange hidden)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('app stops the mic on pagehide',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));
ok('popstate mic-stop still present (back button)',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('go() mic-stop still present (bottom-nav path)',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('not-hearing message waits the full 8 seconds (8000ms)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app));

// ---- 5. Fuzzy matching already present (v2.2.44), no change needed ----
const ss = read('www/scripture-search.js');
ok('fuzzy skeleton matching present (stripMatras + longestRun)',
  ss.includes('stripMatras') && ss.includes('longestRun') && ss.includes('skelTokens'));
ok('skeleton matching is used in the query scorer',
  ss.includes('longestRun(') && ss.includes('qSkel'));

// ---- 6. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.75',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 7. Nothing else changed vs v2.2.75 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/styles.css', 'www/version.json', 'package.json', 'www/native-build-config.js'];
const added = ['scripts/fix-v296.py', 'test-v296.mjs', 'scripts/patch-speech-mic.mjs'];
const removed = ['scripts/patch-speech-silence.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
for (const f of walk(path.join(ROLL, 'scripts'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!removed.includes(rel) && !fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.75 (only app.js + styles.css + version files + mic patch)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.75 except the replaced silence-only patch script',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.75',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
