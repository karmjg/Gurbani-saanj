/* Runtime navigation test — verifies the mic REALLY stops when the user
 * leaves Search/Ask, on BOTH navigation paths, using the REAL code from
 * www/app.js (not a copy): the go() function and the popstate handler are
 * extracted from the shipped source and executed in a sandbox with mocks.
 *
 * Karamjit 2026-11-18: "test it here instead of installing it again and
 * again." This is that test — it runs here, before any build is delivered.
 * The real microphone still needs his phone (no real mic here), but the
 * navigation -> mic-stop wiring is proven here, on both paths:
 *   1. go() — bottom-nav buttons (Home/Search/Saved/Ask).
 *   2. popstate — Android back button (history.back()).
 * v2.2.73/74 fixed only (1); the back button bypassed go() entirely, so
 * the mic kept running — that is why v2.2.74 still beeped on Home.
 * Run: node test-nav-stop.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

// ---- extract the REAL go() function (brace-matched, it spans lines) ----
// The signature has a default param opts={} whose braces must NOT count:
// start depth at 1 on the body's opening brace (the marker's last char).
function extractFn(src, startMarker) {
  const start = src.indexOf(startMarker);
  if (start === -1) return null;
  let depth = 1, i = start + startMarker.length;
  for (; i < src.length; i++) {
    if (src[i] === '{') depth++;
    else if (src[i] === '}') { depth--; if (depth === 0) return src.slice(start, i + 1); }
  }
  return null;
}
const goFn = extractFn(app, 'function go(view,opts={}){');
ok('go() function found in app.js', !!goFn);
// ---- extract the REAL popstate handler line ----
const popLine = app.split('\n').find(l => l.includes("addEventListener('popstate'"));
ok('popstate handler found in app.js', !!popLine);

// ---- sandbox: mocks for everything go()/popstate touch ----
function makeCtx() {
  const calls = { stop: 0 };
  const ctx = {
    state: { view: 'search', readView: 'sggs', baniDrawer: false },
    homeEditing: false, highlightLine: -1, readerBarHidden: false,
    stopVoiceSearch: () => { calls.stop++; },
    capture: () => {}, closeWord: () => {}, closeSettings: () => {},
    persist: () => {}, render: () => {},
    history: { pushState: () => {} },
    window: { scrollTo: () => {}, addEventListener: (type, fn) => { ctx._handlers[type] = fn; } },
    _handlers: {},
    calls,
  };
  ctx.window.addEventListener = (type, fn) => { ctx._handlers[type] = fn; };
  return ctx;
}

// ---- test go() ----
{
  const ctx = makeCtx();
  vm.createContext(ctx);
  vm.runInContext(goFn, ctx);
  // search -> home : must stop
  ctx.state.view = 'search'; ctx.calls.stop = 0;
  vm.runInContext(`go('home')`, ctx);
  ok("go('home') from Search stops the mic", ctx.calls.stop === 1, `stop called ${ctx.calls.stop}x`);
  ok("go('home') sets view to home", ctx.state.view === 'home');
  // search -> ask : must NOT stop (same voice screen)
  ctx.state.view = 'search'; ctx.calls.stop = 0;
  vm.runInContext(`go('ask')`, ctx);
  ok("go('ask') from Search does NOT stop the mic", ctx.calls.stop === 0, `stop called ${ctx.calls.stop}x`);
  // ask -> home : must stop
  ctx.state.view = 'ask'; ctx.calls.stop = 0;
  vm.runInContext(`go('home')`, ctx);
  ok("go('home') from Ask stops the mic", ctx.calls.stop === 1, `stop called ${ctx.calls.stop}x`);
  // home -> search : must NOT stop (nothing listening)
  ctx.state.view = 'home'; ctx.calls.stop = 0;
  vm.runInContext(`go('search')`, ctx);
  ok("go('search') from Home does NOT stop the mic", ctx.calls.stop === 0, `stop called ${ctx.calls.stop}x`);
}

// ---- test popstate (back button) ----
{
  const ctx = makeCtx();
  vm.createContext(ctx);
  // register the real popstate handler via the extracted line
  vm.runInContext(popLine, ctx);
  const handler = ctx._handlers.popstate;
  ok('popstate handler registered', typeof handler === 'function');
  // search -> home (back button) : must stop
  ctx.state.view = 'search'; ctx.calls.stop = 0;
  handler({ state: { gsView: 'home' } });
  ok("back button Search -> Home stops the mic", ctx.calls.stop === 1, `stop called ${ctx.calls.stop}x`);
  ok('back button sets view to home', ctx.state.view === 'home');
  // search -> ask (back button) : must NOT stop
  ctx.state.view = 'search'; ctx.calls.stop = 0;
  handler({ state: { gsView: 'ask' } });
  ok("back button Search -> Ask does NOT stop the mic", ctx.calls.stop === 0, `stop called ${ctx.calls.stop}x`);
  // ask -> home (back button) : must stop
  ctx.state.view = 'ask'; ctx.calls.stop = 0;
  handler({ state: { gsView: 'home' } });
  ok("back button Ask -> Home stops the mic", ctx.calls.stop === 1, `stop called ${ctx.calls.stop}x`);
  // search -> search (back button, no state) defaults home : must stop
  ctx.state.view = 'search'; ctx.calls.stop = 0;
  handler({ state: null });
  ok("back button with no history state defaults to Home and stops the mic", ctx.calls.stop === 1 && ctx.state.view === 'home', `stop=${ctx.calls.stop} view=${ctx.state.view}`);
  // home -> home : must NOT stop
  ctx.state.view = 'home'; ctx.calls.stop = 0;
  handler({ state: { gsView: 'home' } });
  ok("back button Home -> Home does NOT stop the mic", ctx.calls.stop === 0, `stop called ${ctx.calls.stop}x`);
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
