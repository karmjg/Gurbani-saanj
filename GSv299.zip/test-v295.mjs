/* Gurbani Saanjh v2.2.75 — mic stops on the BACK BUTTON too (Karamjit
 * 2026-11-18: "test it here instead of installing it again and again").
 *
 * v2.2.73/74 stopped the mic only in go() (bottom-nav buttons). The Android
 * BACK button fires popstate, which set state.view directly without calling
 * go() or stopVoiceSearch() — so the mic kept running (and beeping) on
 * Home. This build adds the same mic-stop to popstate. The runtime proof
 * is test-nav-stop.mjs (14 passed, run separately): it extracts the REAL
 * go() and popstate handler from app.js and runs them with a mock mic.
 * Run: node test-v295.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v295-rollback';
const V271_REF = '/tmp/v271-ref/www/styles.css';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));
const PLAYER = ['japjiPlay', 'japji-play', 'toggleJapjiAudio', 'stopJapjiAudio',
  'buildJapjiWordIndex', 'ensureJapjiTimes', 'japjiWords', 'japjiAudio',
  'japjiTimes', 'japjiPlaying', 'japjiRaf', 'japjiNow', 'isJapjiReader',
  'japjiSeekFromWord', 'japjiWordForTime', 'japjiScrollToLine', 'japjiTick',
  'japjiClearHighlight', 'pauseJapjiAudio', 'updateJapjiPlayBtn',
  'gs-audio-now', 'gs-japji-play', 'japji-full-clear', 'japji-word-times',
  'JAPJI_BANI_ID', 'JAPJI_DANDA'];

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.75', vj.version === '2.2.75');
ok('package.json is 2.2.75', pj.version === '2.2.75');
ok('native-build-config.js is 2.2.75', nbc.includes('"version":"2.2.75"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.75 entry (back button)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.75:') &&
  vj.notes.includes('BACK BUTTON') && vj.notes.includes('popstate'));
ok('native-build-config.js differs from v2.2.74 ONLY in the version string',
  nbc.replace('2.2.75', '2.2.74') === readR('www/native-build-config.js'));
ok('package.json differs from v2.2.74 ONLY in the version string',
  read('package.json').replace('2.2.75', '2.2.74') === readR('package.json'));

// ---- 1. The back-button fix (the whole point of v2.2.75) ----
const app = read('www/app.js');
ok('popstate handler stops the mic when leaving Search/Ask',
  app.includes("if((state.view==='search'||state.view==='ask')&&(nv!=='search'&&nv!=='ask'))stopVoiceSearch();"));
ok('popstate still computes the new view from history state first',
  app.includes("const nv=(e.state?.gsView)||'home';"));
ok('go() mic-stop is still present (bottom-nav path)',
  app.includes("if((oldView==='search'||oldView==='ask')&&(view!=='search'&&view!=='ask'))stopVoiceSearch();"));
ok('popstate still captures, closes word/settings, renders and scrolls',
  app.includes("if(state.view==='reader'&&state.readView==='sggs')capture();closeWord();closeSettings();") &&
  app.includes("state.view=nv;render();if(state.view!=='reader')window.scrollTo(0,0)"));

// ---- 2. Audio + player still gone (Play Store build) ----
ok('audio file is gone (no japji-full-clear.mp3)',
  !fs.existsSync(path.join(ROOT, 'www/audio/japji-full-clear.mp3')));
ok('www/audio/ directory is gone',
  !fs.existsSync(path.join(ROOT, 'www/audio')));
ok('timing file is gone (no japji-word-times.json)',
  !fs.existsSync(path.join(ROOT, 'www/offline/japji-word-times.json')));
ok('no player identifiers in app.js',
  PLAYER.every(n => !app.includes(n)), PLAYER.filter(n => app.includes(n)).join(', '));
const css = read('www/styles.css');
ok('no player identifiers in styles.css',
  PLAYER.every(n => !css.includes(n)), PLAYER.filter(n => css.includes(n)).join(', '));
if (fs.existsSync(V271_REF)) {
  ok('styles.css is byte-identical to v2.2.71 (no CSS changes at all)',
    fs.readFileSync(path.join(ROOT, 'www/styles.css')).equals(fs.readFileSync(V271_REF)));
} else {
  console.log('SKIP  styles.css vs v2.2.71 byte check (reference not on disk)');
}

// ---- 3. Mic fixes from v2.2.73 still present ----
ok('app stops the mic on background (visibilitychange hidden)',
  app.includes("if(document.visibilityState==='hidden'){capture();stopVoiceSearch();}"));
ok('app stops the mic on pagehide',
  app.includes("window.addEventListener('pagehide',()=>{capture();stopVoiceSearch();});"));
ok('not-hearing message waits the full 8 seconds (8000ms)',
  /noHeardTimer=setTimeout\(\(\)=>\{[\s\S]*?\},8000\);/.test(app));
ok('silence patch script exists + sets both timeouts to 8000ms',
  fs.existsSync(path.join(ROOT, 'scripts/patch-speech-silence.mjs')) &&
  read('scripts/patch-speech-silence.mjs').includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000') &&
  read('scripts/patch-speech-silence.mjs').includes('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000'));
ok('package.json runs the patch on postinstall',
  pj.scripts && pj.scripts.postinstall === 'node scripts/patch-speech-silence.mjs');

// ---- 4. Bani text untouched, reader still renders ----
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
ok('Bani 2 text is byte-identical to v2.2.74',
  fs.readFileSync(path.join(ROOT, 'www/offline/bani/2.json')).equals(fs.readFileSync(path.join(ROLL, 'www/offline/bani/2.json'))));
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 still has 2,150 non-danda words', expectedWords.length === 2150);
const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show: { translit: false, en: false, pa: false, arth: false }, foundIdx: -1 });
const rendered = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]).filter(w => !DANDA.test(w));
ok('reader still renders 2,150 non-danda word buttons',
  rendered.length === 2150, `got ${rendered.length}`);
ok('rendered word buttons match the Bani 2 words exactly, in order',
  rendered.every((w, i) => w === expectedWords[i]));

// ---- 5. Nothing else changed vs v2.2.74 ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/version.json', 'package.json', 'www/native-build-config.js'];
const added = ['scripts/fix-v295.py', 'test-v295.mjs', 'test-nav-stop.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (added.includes(rel)) continue;
    const rf = path.join(ROLL, rel);
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.74 (only app.js + version files)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('nothing removed vs v2.2.74 (no files missing)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every offline file is byte-identical to v2.2.74',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
