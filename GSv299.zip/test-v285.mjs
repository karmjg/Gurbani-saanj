/* Gurbani Saanj v2.2.65 — Mundavni deleted, Ragmala renamed, mockups in OUR style
 * (Karamjit, 2026-11-14, confirmed "Right"):
 * (1) DELETE Bani ID 126 "Sri Guru Granth Sahib Paath Bhog (Mundavni)"
 * (Mundavnni) — removed completely: manifest, catalog, Bani file, search
 * index, Vishraam marks. It must not appear anywhere.
 * (2) KEEP Bani ID 127 but RENAME it — the bracketed part is removed from
 * BOTH titles, so it reads titlePa "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ"
 * and titleEn "Sri Guru Granth Sahib Paath Bhog" (no "(Ragmala)", no
 * "(ਰਾਗਮਾਲਾ)"). The Bani's lines/content are unchanged — only the title.
 * (3) Mockups redone in OUR style (white reader, our look) — not the dark
 * reference style: jaap-fateh-added-mockup-white.webp,
 * rehras-onkar-added-mockup-white.webp, plus a menu mockup
 * menu-bhog-renamed-mockup.webp showing the drawer after the change
 * (Mundavni gone, Bhog entry without the bracket).
 * Data changes (all verified): catalog.js loses the 126 entry and renames
 * 127; manifest banis 30→29, baniCount 30→29, searchVerseCount 60555→60386
 * (-169), vishraamMarkCount 87112→86833 (-279: 163 long + 116 short);
 * www/offline/bani/126.json deleted; vishraam.json loses the 279 b126:*
 * keys (b127's 305 kept); bani-search.json rebuilt with
 * scripts/build-bani-search.mjs (9,485→9,316 lines; the diff is exactly the
 * 169 removed 126 tuples plus the 231 retitled 127 tuples).
 * NOTE: the WORD "ਮੁੰਦਾਵਣੀ" still exists as scripture text — the line
 * "ਮੁੰਦਾਵਣੀ ਮਹਲਾ ੫ ॥" inside Rehras (IDs 21, 107) and Ragmala (ID 127)
 * itself. Only the Bani TITLE / entry is gone, never the scripture line.
 * Kept from v2.2.64: Jaap Fateh line at (4,1), Rehras ੴ before the Salok
 * in IDs 21 + 107. Kept from v2.2.63: Kirtan heart fallback + stay-put
 * save + Saved remove, language-toggle hang guards, no Mool Mantar in the
 * drawer, ensureCatalog, icon row gone, clock after ਪੁ/EN, pills nowrap.
 * No Help button (cancelled).
 * Run: node test-v285.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');
const catSrc = fs.readFileSync(path.join(ROOT, 'www/catalog.js'), 'utf8');
const bani = (id) => JSON.parse(fs.readFileSync(path.join(ROOT, `www/offline/bani/${id}.json`), 'utf8'));
const g = (lines, i) => (lines[i] && lines[i].g) || '';
const ONKAR = 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥';
const FATEH = 'ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ ॥';
const BHOG_PA = 'ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ';
const BHOG_EN = 'Sri Guru Granth Sahib Paath Bhog';

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.65', vj.version === '2.2.65');
ok('package.json is 2.2.65', pj.version === '2.2.65');
ok('native-build-config.js is 2.2.65', nbc.includes('"version":"2.2.65"'));
ok('version notes mention v2.2.65 + Mundavni delete + Ragmala rename',
  vj.notes.includes('v2.2.65:') && vj.notes.includes('Mundavni') && vj.notes.includes('Ragmala'));

// ---- 1a. Bani file 126.json is gone ----
ok('www/offline/bani/126.json is deleted (file does not exist)',
  !fs.existsSync(path.join(ROOT, 'www/offline/bani/126.json')));
ok('www/offline/bani/127.json still exists, 231 lines',
  fs.existsSync(path.join(ROOT, 'www/offline/bani/127.json')) && bani(127).lines.length === 231);

// ---- 1b. Manifest: 29 Banis, no 126, 127 renamed, counts updated ----
{
  const m = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/manifest.json'), 'utf8'));
  ok('manifest: baniCount is 29 (was 30)', m.baniCount === 29);
  ok('manifest: banis list has 29 entries', m.banis.length === 29);
  ok('manifest: no entry with id 126', !m.banis.some((b) => b.id === 126));
  ok('manifest: no title mentions Mundavni / Mundavnni / ਮੁੰਦਾਵਣੀ',
    !m.banis.some((b) => /Mundav|ਮੁੰਦਾਵਣੀ/.test(b.titlePa + ' ' + b.titleEn)));
  const b127 = m.banis.find((b) => b.id === 127);
  ok('manifest: ID 127 titlePa is exactly "ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ" (no bracket)',
    !!b127 && b127.titlePa === BHOG_PA);
  ok('manifest: ID 127 titleEn is exactly "Sri Guru Granth Sahib Paath Bhog" (no bracket)',
    !!b127 && b127.titleEn === BHOG_EN);
  ok('manifest: searchVerseCount is 60386 (was 60555, -169)',
    m.searchVerseCount === 60386);
  ok('manifest: vishraam counts are 86833 / 28342 / 58491 (was 87112 / 28458 / 58654)',
    m.vishraamMarkCount === 86833 && m.vishraamShortCount === 28342 && m.vishraamLongCount === 58491);
  ok('manifest: angCount still 1430, kirtanShabadCount still 1618',
    m.angCount === 1430 && m.kirtanShabadCount === 1618);
}

// ---- 1c. Catalog (www/catalog.js): 21 entries, no 126, 127 renamed ----
{
  const catCtx = { window: {} };
  vm.runInNewContext(catSrc, catCtx);
  const cat = catCtx.window.GS_CATALOG || [];
  ok('catalog: 21 entries (was 22)', cat.length === 21);
  ok('catalog: no entry with id 126', !cat.some((c) => c.id === 126));
  ok('catalog: no title mentions Mundavni / Mundavnni / ਮੁੰਦਾਵਣੀ',
    !cat.some((c) => /Mundav|ਮੁੰਦਾਵਣੀ/.test(c.titlePa + ' ' + c.titleEn)));
  const c127 = cat.find((c) => c.id === 127);
  ok('catalog: ID 127 titlePa is exactly the Bhog title (no bracket)',
    !!c127 && c127.titlePa === BHOG_PA);
  ok('catalog: ID 127 titleEn is exactly the Bhog title (no bracket)',
    !!c127 && c127.titleEn === BHOG_EN);
  ok('catalog: ID 127 still in group sggs, and its neighbours are 109 (Aarti) then 117',
    !!c127 && c127.group === 'sggs' &&
    cat[cat.findIndex((c) => c.id === 127) - 1].id === 109 &&
    cat[cat.findIndex((c) => c.id === 127) + 1].id === 117);
  ok('catalog: no "126" id string anywhere in catalog.js', !/\"id\":\s*126/.test(catSrc));
}

// ---- 1d. Bani 127 lines are byte-identical to before (only the title changed) ----
{
  const old127 = JSON.parse(fs.readFileSync('/tmp/v265-rollback/127.json', 'utf8'));
  const new127 = bani(127);
  ok('127.json: lines identical to the v2.2.64 copy (same 231 lines, same ids, same text)',
    JSON.stringify(new127.lines) === JSON.stringify(old127.lines));
  ok('127.json: first line still ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥, last line still the Nanak closing',
    g(new127.lines, 0) === ONKAR &&
    g(new127.lines, 230) === 'ਨਾਨਕ ਤੇ ਮੁਖ ਉਜਲੇ ਕੇਤੀ ਛੁਟੀ ਨਾਲਿ ॥੧॥');
}

// ---- 1e. Search index (bani-search.json): 126 gone, 127 retitled ----
{
  const bs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  ok('bani-search.json: 9,316 lines (was 9,485, -169)', bs.length === 9316);
  const per = {};
  for (const r of bs) per[r[0]] = (per[r[0]] || 0) + 1;
  ok('bani-search.json: zero entries for baniId 126', (per[126] || 0) === 0);
  ok('bani-search.json: 231 entries for baniId 127, all with the new titles',
    per[127] === 231 && bs.filter((r) => r[0] === 127).every((r) => r[6] === BHOG_PA && r[7] === BHOG_EN));
  ok('bani-search.json: no entry title contains (ਰਾਗਮਾਲਾ) or (Ragmala)',
    !bs.some((r) => (r[6] || '').includes('(ਰਾਗਮਾਲਾ)') || (r[7] || '').includes('(Ragmala)')));
  ok('bani-search.json: no entry title contains Mundavni / Mundavnni / ਮੁੰਦਾਵਣੀ',
    !bs.some((r) => /Mundav|ਮੁੰਦਾਵਣੀ/.test((r[6] || '') + ' ' + (r[7] || ''))));
  ok('bani-search.json: the scripture WORD "ਮੁੰਦਾਵਣੀ ਮਹਲਾ ੫ ॥" still exists as a line (IDs 21, 107, 127) — only the Bani title is gone',
    bs.filter((r) => r[2] === 'ਮੁੰਦਾਵਣੀ ਮਹਲਾ ੫ ॥').map((r) => r[0]).sort().join(',') === '107,127,21');
  ok('bani-search.json: 29 distinct Bani ids, 126 not among them',
    Object.keys(per).length === 29 && !('126' in per));
}

// ---- 1f. Vishraam marks: b126 gone, b127 kept ----
{
  const v = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/vishraam.json'), 'utf8'));
  const marks = v.marks;
  const count = (p) => Object.keys(marks).filter((k) => k.startsWith(p)).length;
  ok('vishraam.json: total marks 86,833 (was 87,112, -279)', Object.keys(marks).length === 86833);
  ok('vishraam.json: zero b126 keys', count('b126:') === 0);
  ok('vishraam.json: b127 keys still 305 (127 unchanged)', count('b127:') === 305);
  ok('vishraam.json: short+long still add up (28342 + 58491 = 86833)',
    Object.values(marks).filter((x) => x === 's').length === 28342 &&
    Object.values(marks).filter((x) => x === 'l').length === 58491);
}

// ---- 2. v2.2.64 additions still present ----
{
  const d4 = bani(4), L4 = d4.lines;
  ok('v2.2.64: Jaap (ID 4) still 802 lines, [1] is the Fateh line',
    L4.length === 802 && g(L4, 1) === FATEH && g(L4, 0) === ONKAR && g(L4, 2) === 'ਜਾਪੁ ॥');
  const d21 = bani(21), L21 = d21.lines;
  ok('v2.2.64: Rehras Taksal (ID 21) still 422 lines, [5] is ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L21.length === 422 && g(L21, 5) === ONKAR && g(L21, 6) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  const d107 = bani(107), L107 = d107.lines;
  ok('v2.2.64: Rehras Short (ID 107) still 340 lines, [4] is ੴ before ਸਲੋਕੁ ਮਃ ੧',
    L107.length === 340 && g(L107, 4) === ONKAR && g(L107, 5) === 'ਸਲੋਕੁ ਮਃ ੧ ॥');
  const bs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const find = (id, idx) => bs.find((r) => r[0] === id && r[1] === idx);
  ok('v2.2.64: search index still has the Fateh line (4,1) and the Rehras ੴ (21,5)/(107,4)',
    find(4, 1)[2] === FATEH && find(21, 5)[2] === ONKAR && find(107, 4)[2] === ONKAR);
}

// ---- 3. v2.2.63 markers intact ----
ok('v2.2.63: Kirtan fallback present (save from kirtanBookList when lookup() is null)',
  app.includes('Kirtan book fallback') && app.includes('const s=kb.find(x=>x.ang===ang&&x.lineStart===idx);'));
ok('v2.2.63: stay-put — heart updates in place, no render() on the save-hit path',
  app.includes("save.classList.toggle('selected',added);") && app.includes("save.textContent=added?'♥':'♡';"));
ok('v2.2.63: no navigation to bookmarks anywhere (no go(bookmarks))',
  !app.includes("go('bookmarks')"));
ok('v2.2.63: Saved tab rows have a remove control (data-remove-saved ♥)',
  (() => { const bm = app.split('\n').find((l) => l.startsWith('function bookmarksScreen(){')); return !!bm && bm.includes('data-remove-saved=') && bm.includes('</button><button data-remove-saved='); })());
ok('v2.2.62: language-toggle hang guards still in ensureHukamnama',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.60: Kirtan heart button still on each Shabad row (data-save-hit ang:lineStart)',
  app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: History clock still AFTER the ਪੁ/EN button in the search box',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 4. Mockups exist (white reader + menu) ----
{
  const gfx = path.join(ROOT, '..', 'play-store', 'graphics');
  // NOTE: the graphics folder lives outside the zip source tree; resolve it
  // from the workspace layout (~/workspace/gurbani/play-store/graphics).
  const gfxAbs = '/home/hatch/workspace/gurbani/play-store/graphics';
  for (const f of ['jaap-fateh-added-mockup-white.webp', 'rehras-onkar-added-mockup-white.webp', 'menu-bhog-renamed-mockup.webp']) {
    ok(`mockup exists: ${f}`, fs.existsSync(path.join(gfxAbs, f)) && fs.statSync(path.join(gfxAbs, f)).size > 10000);
  }
}

// ---- 5. vm: the REAL scripture search over the REAL rebuilt index ----
{
  const ssSrc = fs.readFileSync(path.join(ROOT, 'www/scripture-search.js'), 'utf8');
  const sggs = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/search.json'), 'utf8'));
  const baniIdx = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/offline/bani-search.json'), 'utf8'));
  const sandbox = {
    console,
    window: {},
    fetch: (url) => {
      const data = String(url).includes('bani-search') ? baniIdx : sggs;
      return Promise.resolve({ ok: true, json: async () => data });
    },
  };
  vm.createContext(sandbox);
  vm.runInContext(ssSrc, sandbox);
  const GS = sandbox.window.GS_SCRIPTURE_SEARCH;
  ok('vm: real scripture-search loads (lookupBani + query available)', !!GS && typeof GS.lookupBani === 'function' && typeof GS.query === 'function');
  await GS.load();
  ok('vm: lookupBani(126, 0) returns null — Mundavni is gone',
    GS.lookupBani(126, 0) === null);
  const r127 = GS.lookupBani(127, 0);
  ok('vm: lookupBani(127, 0) returns the first line with the NEW Bhog title (no bracket)',
    !!r127 && r127.g === ONKAR && r127.baniTitle === BHOG_PA);
  const qBhog = await GS.query('ਸ੍ਰੀ ਗੁਰੂ ਗ੍ਰੰਥ ਸਾਹਿਬ ਜੀ ਦੇ ਪਾਠ ਦਾ ਭੋਗ');
  ok('vm: searching the Bhog title finds Bani 127 (not 126)',
    qBhog.some((r) => r.src === 'bani' && r.baniId === 127) &&
    !qBhog.some((r) => r.src === 'bani' && r.baniId === 126));
  const qMund = await GS.query('ਮੁੰਦਾਵਣੀ');
  ok('vm: searching "ਮੁੰਦਾਵਣੀ" finds only the scripture line (no Bani titled Mundavni)',
    qMund.length > 0 &&
    qMund.every((r) => r.src !== 'bani' || !/Mundav|ਮੁੰਦਾਵਣੀ/.test(r.baniTitle || '')) &&
    qMund.some((r) => r.src === 'bani' && r.g === 'ਮੁੰਦਾਵਣੀ ਮਹਲਾ ੫ ॥'),
    JSON.stringify(qMund.slice(0, 4).map((r) => [r.src, r.baniId, r.idx, r.baniTitle])));
  const qFateh = await GS.query('ਸ੍ਰੀ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫ਼ਤਹ');
  ok('vm: v2.2.64 Fateh line still searchable (baniId 4, idx 1)',
    qFateh.some((r) => r.src === 'bani' && r.baniId === 4 && r.idx === 1 && r.g === FATEH));
}

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
