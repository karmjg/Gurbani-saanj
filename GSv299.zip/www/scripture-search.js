/* iGranth-style Gurbani search: first letter of each word (from start / anywhere),
 * full phrase, word, Romanized, and Ang. All matching runs against the SGGS
 * offline index AND the Bani index (all 29 Banis incl. Dasam Granth + Nitnem)
 * packaged during the Android build; no query is sent to a server.
 * The scripture corpus is from the separately credited BaniDB snapshot.
 * v2.2.28: unified SGGS + Bani index. SGGS rows come from offline/search.json
 * ([ang, idx, g, en, pa, roman]); Bani rows from offline/bani-search.json
 * ([baniId, idx, g, en, pa, roman, titlePa, titleEn, group]), built by
 * scripts/build-bani-search.mjs. Every prepared entry carries src ('sggs' or
 * 'bani'); SGGS entries keep ang, Bani entries carry baniId + baniTitle +
 * group (the catalog group: 'sggs', 'dasam' or 'tradition'), so a result can
 * be labelled Dasam Granth.
 * Ang mode (typing just a number) stays SGGS-only: Bani rows have no Ang.
 */
(()=>{'use strict';
let loading=null,rows=[],baniRows=[];
const norm=s=>String(s||'').normalize('NFC').toLocaleLowerCase().replace(/[\u200c\u200d]/gu,'').trim();
// Strip leading/trailing punctuation from tokens so ॥੧॥ and । don't contribute
// spurious first-letter characters. Preserve vowels and matras inside words.
const words=s=>norm(s).split(/[\s,;?!.।॥:()"'\[\]{}\-।੦-੯\d|]+/u).map(w=>w.replace(/^[^\p{L}\p{N}ੴ]+|[^\p{L}\p{N}\p{M}]+$/gu,'')).filter(Boolean);
const compact=s=>norm(s).replace(/[^\p{L}\p{N}ੴ]/gu,'');
// iGranth rule: a word's first letter is its BARE base letter — no matra on top.
// ਐਸੇ/ਐਸਾ start with ਅ (ਐ is ਅ + ੈ), ਤੂ starts with ਤ, ਮਾਧੋ with ਮ.
// So ਮਾਧੋ ਹਮ ਐਸੇ ਤੂ ਐਸਾ is typed as ਮਹਅਤਅ. Fold precomposed vowels to base.
const foldFirst=ch=>({'ਆ':'ਅ','ਈ':'ਇ','ਊ':'ਉ','ਏ':'ਅ','ਐ':'ਅ','ਓ':'ਅ','ਔ':'ਅ'})[ch]||ch;
// v2.2.44: matra-tolerant "skeleton" matching — the voice mic drops dependent
// vowel signs (ਹਰਿ→ਹਰ, ਜੁਗੁ→ਜੁਗ) and mishears a matra (ਬੋਲੈ→ਬੋਲੇ, ਭਗਤ→ਭਗਤਿ),
// so a spoken line must still match the written line. Stripping the dependent
// vowel signs (U+0A3E–U+0A4C) from both sides makes them identical, so the
// right pangti comes first even when the user pronounces it wrong.
const stripMatras=s=>String(s||'').normalize('NFC').replace(/[\u0A3E-\u0A4C]/gu,'');
const skelWords=s=>words(s).map(stripMatras);
// v2.2.44: longest run of consecutive query words (compared by skeleton) that
// appear consecutively in the line, in order. Tolerates a wrong word anywhere
// in the spoken line: for "ਮੈ ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੇ ਨਾਲ", Ang 588 wins with the
// 4-word run "ਸਤਿਗੁਰੁ ਪਿਆਰਾ ਮੇਰੈ ਨਾਲਿ" while rivals only manage 2.
function longestRun(lineWords,qWords){
 if(!qWords.length||!lineWords.length)return 0;
 let best=0;
 for(let i=0;i<lineWords.length;i++){
  for(let j=0;j<qWords.length;j++){
   if(lineWords[i]!==qWords[j])continue;
   let run=1;
   while(i+run<lineWords.length&&j+run<qWords.length&&lineWords[i+run]===qWords[j+run])run++;
   if(run>best)best=run;
   if(best===qWords.length)return best;
  }
 }
 return best;
}
const initials=s=>words(s).filter(w=>w!=='ੴ').map(w=>foldFirst(Array.from(w)[0]||'')).join('');
const romanized=s=>/[a-z]/i.test(s);
const stopwords=new Set(['why','how','can','the','and','what','where','with','about','from','are','does','have','for','search','find','gurbani','guru','sahib','granth','is','of','to','a','in','say','says','tell','tells','mean','means','explain','explains','answer','question','please','ਮੈਨੂੰ','ਵਿੱਚ','ਅਤੇ','ਕਿਵੇਂ','ਕੀ','ਤੋਂ','ਦਾ','ਦੀ','ਦੇ','ਹੈ','ਗੁਰਬਾਣੀ','ਬਾਰੇ','ਕਹਿੰਦੀ','ਕਹਿੰਦਾ','ਕਹਿੰਦੇ','ਦੱਸੋ','ਦੱਸ','ਕਿਉਂ','ਕਿਹੜਾ','ਕਿਹੜੀ','ਕਿਸ','ਲਈ','ਕਰਕੇ','ਕਰਦਾ','ਕਰਦੀ','ਕਰਦੇ','ਹੋਵੇ','ਨਾਲ','ਨੂੰ','ਤੇ','ਭੀ','ਵੀ','ਜੇ','ਜੋ','ਇਹ','ਉਹ','ਕਰੋ','ਚਾਹੀਦਾ','ਚਾਹੀਦੀ']);
const useful=s=>words(s).filter(w=>w.length>1&&!stopwords.has(w)).slice(0,10);
let prepared=[],lookupMap=new Map();
function prepareChunk(arr,src){
 return arr.map(r=>{
  const [a,i,g,en='',pa='',roman='']=r;
  const base={idx:Number(i),g:String(g||''),text:norm(g),trans:norm(roman),roman:String(roman||''),
   all:norm([g,en,pa,roman].join(' ')),initial:compact(initials(g)),romanInitial:compact(initials(roman)),tokens:words(g),romanTokens:words(roman),
   skel:stripMatras(norm([g,en,pa,roman].join(' '))),skelTokens:skelWords(g)};
  if(src==='bani')return {...base,src:'bani',baniId:Number(a),en:String(en||''),titlePa:String(r[6]||''),titleEn:String(r[7]||''),baniTitle:String(r[6]||r[7]||''),group:String(r[8]||'sggs')};
  return {...base,src:'sggs',ang:Number(a)};
 });
}
function prepare(arr,src){return prepareChunk(arr,src||'sggs')}
async function load(){
 if(!loading)loading=(async()=>{
  const sggs=await fetch('offline/search.json',{cache:'force-cache'}).then(async r=>{
   if(!r.ok)throw Error('Offline index missing');const arr=await r.json();
   if(!Array.isArray(arr)||arr.length<1000)throw Error('Offline scripture index incomplete');
   return arr;
  });
  // Bani index is additive: if it is missing, search still works for SGGS.
  let bani=[];
  try{
   bani=await fetch('offline/bani-search.json',{cache:'force-cache'}).then(async r=>{
    if(!r.ok)throw Error('Offline Bani index missing');const arr=await r.json();
    if(!Array.isArray(arr)||arr.length<100)throw Error('Offline Bani index incomplete');
    return arr;
   });
  }catch(e){console.warn('Bani search index unavailable; search covers SGGS only',e)}
  rows=sggs;baniRows=bani;
  prepared=[...prepareChunk(sggs,'sggs'),...prepareChunk(bani,'bani')];
  lookupMap=new Map();
  for(const x of prepared){
   if(x.src==='bani')lookupMap.set(`bani:${x.baniId}:${x.idx}`,{src:'bani',baniId:x.baniId,idx:x.idx,g:x.g,baniTitle:x.baniTitle,titlePa:x.titlePa,titleEn:x.titleEn,group:x.group});
   else lookupMap.set(`${x.ang}:${x.idx}`,{src:'sggs',ang:x.ang,idx:x.idx,g:x.g});
  }
  return prepared;
 })().catch(e=>{loading=null;throw e});
 return loading;
}
function matchRows(arr,q,limit=40,mode='auto'){
 const needle=norm(q),signature=Array.from(compact(needle)).map(foldFirst).join(''),terms=useful(q);if(!needle)return [];
 // v2.2.44: skeleton (matra-stripped) query + skeleton words for the run score.
 const skelNeedle=stripMatras(needle),qSkel=skelWords(q);
 const n=/^(?:ang\s*)?(\d{1,4})$/i.exec(needle);
 const selection=mode==='auto'&&n?'ang':mode;
 // Unified index: a raw SGGS array or the prepared array both resolve to the
 // merged prepared index; any other raw tuple array is treated as SGGS (the
 // old call shape) so older callers keep working.
 const data=(arr===rows||arr===prepared||(Array.isArray(arr)&&arr.length&&typeof arr[0]==='object'&&'text' in arr[0]))
  ?(arr===rows?prepared:arr)
  :arr.map(r=>{
   const [a,i,g,en='',pa='',roman='']=r;
   return {src:'sggs',ang:Number(a),idx:Number(i),g:String(g||''),text:norm(g),trans:norm(roman),roman:String(roman||''),
    all:norm([g,en,pa,roman].join(' ')),initial:compact(initials(g)),romanInitial:compact(initials(roman)),tokens:words(g),romanTokens:words(roman),
    skel:stripMatras(norm([g,en,pa,roman].join(' '))),skelTokens:skelWords(g)};
  });
 const found=[];
 for(const x of data){
  if(!x.g)continue;
  let score=0;
  if(selection==='ang')score=(n&&x.ang===Number(n[1]))?150:0;
  else if(selection==='first')score=signature&&x.initial.startsWith(signature)?150:0;
  // v2.2.56: first letters of the LAST words of a line rank above a
  // middle match — start 150, end 145, anywhere 130 (any-first); the same
  // end boost (100, below start 105) applies to the auto-mode initials
  // fallback and to roman initials (90, below start 95). E.g. "ਸਹਗ"
  // now surfaces Ang 614 "ਸੰਤ ਹਮਾਰੀ ਓਟ ਸਤਾਣੀ ਸੰਤ ਹਮਾਰਾ ਗਹਣਾ".
  else if(selection==='any-first')score=signature?(x.initial.startsWith(signature)?150:(x.initial.endsWith(signature)?145:(x.initial.includes(signature)?130:0))):0;
  else if(selection==='roman')score=(x.trans.includes(needle)?100:0)||(signature?(x.romanInitial.startsWith(signature)?95:(signature.length>=2&&x.romanInitial.endsWith(signature)?90:0)):0);
  else if(selection==='word')score=x.tokens.some(w=>w===needle||w.includes(needle))||x.romanTokens.some(w=>w===needle||w.includes(needle))?110:0;
  else{
   if(x.all.includes(needle))score=120;
   // v2.2.56 skeleton guard: the skeleton phrase is only for multi-word
   // phrases (the v2.2.44 voice-search case). A single token like the
   // initials "ਸਹਗ" would match inside longer skeleton words
   // ("ਸੋਹਾਗਣੀ" -> "ਸਹਗਣੀ", 203 lines at 115) and bury the initials
   // end-match (100). Single-token queries skip it so initials can score.
   else if(needle.includes(' ')&&skelNeedle.length>=2&&x.skel&&x.skel.includes(skelNeedle))score=115;
   else{
    // v2.2.44: longest consecutive run of query words (by skeleton) in the
    // line. Beats the old terms/first-letters scores so the intended line
    // wins even with a wrong word, but stays below skeleton phrase (115).
    const run=longestRun(romanized(needle)?x.romanTokens:(x.skelTokens||[]),qSkel);
    if(run>=2)score=Math.min(112,106+run);
    if(!score&&terms.length){const hits=terms.filter(w=>x.all.includes(w)).length;
     if(hits>=Math.min(2,terms.length))score=hits*8;}
   }
   if(!score&&signature){
    // In auto mode, short Gurmukhi sequences are also first-letter searches.
    const candidate=romanized(needle)?x.romanInitial:x.initial;
    if(candidate.startsWith(signature))score=105;
    else if(signature.length>=2&&candidate.endsWith(signature))score=100;
    else if(signature.length>=2&&candidate.includes(signature))score=70;
    if(!score){
     // v2.2.21: a full phrase is also tried by its first letters. The
     // spoken/typed words may be slightly off (a matra or spelling), but the
     // first letter of each word still matches the line. e.g. "ਬਬੀਹਾ ਅੰਮ੍ਰਿਤ
     // ਵੇਲੇ" gives first letters "ਬਅਵ", which matches "ਬਾਬੀਹਾ ਅੰਮ੍ਰਿਤ ਵੇਲੈ
     // ਬੋਲਿਆ" (Ang 1285). Only for 2+ words, so the signature stays specific.
     const firstSig=compact(initials(needle));
     if(firstSig.length>=2&&candidate.startsWith(firstSig))score=105;
     else if(firstSig.length>=2&&candidate.endsWith(firstSig))score=100;
     else if(firstSig.length>=2&&candidate.includes(firstSig))score=70;
    }
   }
  }
  if(score)found.push(x.src==='bani'?{src:'bani',baniId:x.baniId,en:x.en,baniTitle:x.baniTitle,titlePa:x.titlePa,titleEn:x.titleEn,group:x.group,idx:x.idx,g:x.g,roman:x.roman,score}:{src:'sggs',ang:x.ang,idx:x.idx,g:x.g,roman:x.roman,score});
 }
 // Same score as before; ties break by source (SGGS first), then Ang/Bani, then idx.
 found.sort((a,b)=>b.score-a.score||(a.src===b.src?0:(a.src==='sggs'?-1:1))||(a.src==='sggs'?a.ang-b.ang:a.baniId-b.baniId)||a.idx-b.idx);
 return found.slice(0,Math.max(1,Math.min(100,Number(limit)||40))).map(({score,...rest})=>rest);
}
async function query(q,limit=40,mode='auto'){await load();return matchRows(prepared,q,limit,mode)}
function lookup(ang,idx){return lookupMap.get(`${Number(ang)}:${Number(idx)}`)||null}
function lookupBani(baniId,idx){return lookupMap.get(`bani:${Number(baniId)}:${Number(idx)}`)||null}
window.GS_SCRIPTURE_SEARCH={load,query,lookup,lookupBani,matchRows};
})();
