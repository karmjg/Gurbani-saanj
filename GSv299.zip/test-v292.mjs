/* Gurbani Saanjh v2.2.72 — Karamjit 2026-11-17 (his go: "Can we try in
 * apk" + "First" = APK try first, before any Play Store release).
 * His verdict on the karaoke demo: "Almost perfect" + "Sometimes not
 * right" — the highlight is mostly right, a few words off. The timing
 * file is just a list, so single wrong words can be corrected one by one.
 *
 * Exactly what this build adds (Japji Sahib reader only, Bani 2):
 * (1) The enhanced Bhai Jarnail Singh recording (the chain he approved
 *     on the 60 s sample: "Sounds good") bundled under www/audio/.
 * (2) A word-timing file www/offline/japji-word-times.json — 2,150 words.
 * (3) A play button in the Japji reader: audio plays, the word being
 *     sung lights up orange, the page scrolls to follow, tapping a word
 *     while playing jumps the audio there. Tapping a word while paused
 *     still shows the line meaning, as before.
 * The audio stops when he leaves the reader or opens another text.
 * No other Bani or Ang changes; no lines added or removed, saved verses
 * unaffected. Run: node test-v292.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
const ROOT = path.resolve(import.meta.dirname);
const ROLL = '/tmp/v292-rollback';
const AUDIO_SRC = '/home/hatch/workspace/gurbani/audio/japji-full-clear.mp3';
const AUDIO_BYTES = 18301908, AUDIO_SECS = 1143.798;
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const readR = (p) => fs.readFileSync(path.join(ROLL, p), 'utf8');
const j = (p) => JSON.parse(read(p));
const jr = (p) => JSON.parse(readR(p));
const md5 = (p) => crypto.createHash('md5').update(fs.readFileSync(p)).digest('hex');
const DANDA = /^[॥੦-੯]+$/;
const tokens = (g) => String(g || '').trim().split(/\s+/).filter(Boolean);
const loadV = (src) => { const sb = { window: {} }; vm.createContext(sb); vm.runInContext(src, sb); return sb.window.GS_VERSES; };
const V = loadV(read('www/render-verses.js'));

// ---- 0. Version ----
const vj = j('www/version.json');
const vjR = jr('www/version.json');
const pj = j('package.json');
const nbc = read('www/native-build-config.js');
ok('version.json is 2.2.72', vj.version === '2.2.72');
ok('package.json is 2.2.72', pj.version === '2.2.72');
ok('native-build-config.js is 2.2.72', nbc.includes('"version":"2.2.72"'));
ok('version notes keep ALL earlier notes verbatim + append the v2.2.72 entry (karaoke + T-Series note)',
  vj.notes.startsWith(vjR.notes) && vj.notes.includes('v2.2.72:') &&
  vj.notes.includes('Almost perfect') && vj.notes.includes('T-Series'));
ok('package.json + native-build-config.js differ from v2.2.71 ONLY in the version string',
  read('package.json').replace('2.2.72', '2.2.71') === readR('package.json') &&
  nbc.replace('2.2.72', '2.2.71') === readR('www/native-build-config.js'));

// ---- 1. Audio file ----
const audioPath = path.join(ROOT, 'www/audio/japji-full-clear.mp3');
ok('audio file exists in www/audio/', fs.existsSync(audioPath));
ok('audio file is the approved enhanced recording (18,301,908 bytes)',
  fs.statSync(audioPath).size === AUDIO_BYTES);
ok('audio file is byte-identical to the approved source',
  md5(audioPath) === md5(AUDIO_SRC));

// ---- 2. Timing file ----
const times = j('www/offline/japji-word-times.json');
ok('timing file has 2,150 entries', Array.isArray(times) && times.length === 2150);
ok('timing entries carry only line/g/s/e (no Whisper debug fields)',
  times.every(x => Object.keys(x).sort().join(',') === 'e,g,line,s'));
ok('timing covers all 385 Bani 2 lines',
  new Set(times.map(x => x.line)).size === 385 &&
  Math.min(...times.map(x => x.line)) === 0 && Math.max(...times.map(x => x.line)) === 384);
ok('timing times are within the audio duration and in order',
  times.every(x => 0 <= x.s && x.s <= x.e && x.e <= AUDIO_SECS) &&
  times.every((x, i) => i === 0 || x.s >= times[i - 1].s - 0.01));
ok('timing ends at 1,119.89 s (last word) inside the 1,143.8 s file',
  Math.abs(times[times.length - 1].e - 1119.886) < 0.001);

// ---- 3. Timing words match the Bani 2 text, line by line ----
// The alignment split each line on spaces and dropped danda-only tokens.
// The app's reader does the same split (tokens()) and keeps the dandas
// as buttons — so the timing words must equal the non-danda tokens.
const bani2 = j('www/offline/bani/2.json').lines;
ok('Bani 2 still has 385 lines', bani2.length === 385);
const expectedWords = [];
for (const line of bani2) for (const w of tokens(line.g)) if (!DANDA.test(w)) expectedWords.push(w);
ok('Bani 2 has 2,150 non-danda words (timing count)',
  expectedWords.length === 2150);
const timingWords = times.map(x => x.g);
ok('timing words match the Bani 2 words exactly, in order',
  timingWords.length === expectedWords.length &&
  timingWords.every((w, i) => w === expectedWords[i]));
ok('timing line numbers match the word positions',
  times.every((x, i) => {
    let n = 0;
    for (let l = 0; l < x.line; l++) n += tokens(bani2[l].g).filter(w => !DANDA.test(w)).length;
    return i >= n && i < n + tokens(bani2[x.line].g).filter(w => !DANDA.test(w)).length;
  }));

// ---- 4. The rendered reader produces the same 2,150 word buttons ----
// baniFlowHTML renders one button per token (paragraph path AND the
// per-pankti verseHTML path), in line order — so the DOM index and the
// timing file align 1:1 in both layer modes.
const renderWords = (show) => {
  const html = V.baniFlowHTML(bani2, { vishraamOn: false, koshHas: () => false, show, foundIdx: -1 });
  const words = [...html.matchAll(/data-word="([^"]*)"/g)].map(m => m[1]);
  return { html, words, nonDanda: words.filter(w => !DANDA.test(w)) };
};
const noLayers = renderWords({ translit: false, en: false, pa: false, arth: false });
const layers = renderWords({ translit: true, en: true, pa: true, arth: false });
ok('reader (no layers) renders 2,150 non-danda word buttons',
  noLayers.nonDanda.length === 2150, `got ${noLayers.nonDanda.length}`);
ok('reader (layers on) renders the same 2,150 non-danda word buttons',
  layers.nonDanda.length === 2150, `got ${layers.nonDanda.length}`);
ok('rendered word buttons match the timing file exactly, in order (no layers)',
  noLayers.nonDanda.every((w, i) => w === timingWords[i]));
ok('rendered word buttons match the timing file exactly, in order (layers on)',
  layers.nonDanda.every((w, i) => w === timingWords[i]));
ok('rendered buttons carry data-idx/data-widx (seek + highlight addressing)',
  /data-idx="0" data-widx="0"/.test(noLayers.html) && /data-idx="384"/.test(noLayers.html));

// ---- 5. App wiring (static checks on app.js / styles.css) ----
const app = read('www/app.js');
const css = read('www/styles.css');
ok('play button renders in the Japji reader only (Bani 2)',
  app.includes("kind==='bani'&&Number(activeRemote.id)===2") &&
  app.includes('id="japjiPlayBtn"') && app.includes('data-action="japji-play"'));
ok('play button HTML appears exactly once (the gated Bani 2 render line)',
  (app.match(/id="japjiPlayBtn"/g) || []).length === 1);
ok('action() handles japji-play', app.includes("case'japji-play':toggleJapjiAudio();break;"));
ok('word tap seeks while playing, meaning while paused',
  app.includes('if(japjiSeekFromWord(word))return;openLineMeaning(word);return'));
ok('attach() stops audio outside the Japji reader and rebuilds the index inside it',
  app.includes('if(!isJapjiReader())stopJapjiAudio();else buildJapjiWordIndex();'));
ok('audio path is the bundled file', app.includes("new Audio('audio/japji-full-clear.mp3')"));
ok('timing fetch uses the bundled file', app.includes("fetch('offline/japji-word-times.json'"));
ok('audio stops on end + on navigation (ended listener + stopJapjiAudio)',
  app.includes("addEventListener('ended',()=>stopJapjiAudio())") &&
  app.includes('function stopJapjiAudio()'));
ok('highlight uses the orange karaoke class', css.includes('.word.gs-audio-now{color:#e07b00'));
ok('floating play button styled above the bottom nav', css.includes('.gs-japji-play{position:fixed'));

// ---- 6. Nothing else changed ----
const walk = (dir) => {
  const out = [];
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...walk(p)); else out.push(p);
  }
  return out;
};
const changed = ['www/app.js', 'www/styles.css', 'www/version.json', 'package.json', 'www/native-build-config.js'];
const added = ['www/audio/japji-full-clear.mp3', 'www/offline/japji-word-times.json', 'scripts/fix-v292.py', 'test-v292.mjs'];
let otherChanged = [], missing = [];
for (const scope of ['www', 'scripts']) {
  for (const f of walk(path.join(ROOT, scope))) {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    const rf = path.join(ROLL, rel);
    if (added.includes(rel)) continue;
    if (!fs.existsSync(rf)) { otherChanged.push(rel + ' (new, unexpected)'); continue; }
    if (changed.includes(rel)) continue;
    if (fs.readFileSync(f).equals(fs.readFileSync(rf))) continue;
    otherChanged.push(rel);
  }
}
for (const rel of ['package.json', 'package-lock.json', 'capacitor.config.json']) {
  const rf = path.join(ROLL, rel);
  if (!changed.includes(rel) && fs.existsSync(rf) && !fs.readFileSync(path.join(ROOT, rel)).equals(fs.readFileSync(rf))) otherChanged.push(rel);
}
for (const f of walk(path.join(ROLL, 'www'))) {
  const rel = path.relative(ROLL, f).replace(/\\/g, '/');
  if (!fs.existsSync(path.join(ROOT, rel))) missing.push(rel);
}
ok('no other file changed vs v2.2.71 (only app.js, styles.css, version files)',
  otherChanged.length === 0, otherChanged.join(', '));
ok('no offline file was removed or altered (only the timing file added)',
  missing.length === 0, missing.join(', '));
const allOffline = walk(path.join(ROOT, 'www/offline'));
ok('every other offline file is byte-identical to v2.2.71',
  allOffline.every(f => {
    const rel = path.relative(ROOT, f).replace(/\\/g, '/');
    if (rel === 'www/offline/japji-word-times.json') return true;
    return fs.existsSync(path.join(ROLL, rel)) && fs.readFileSync(f).equals(fs.readFileSync(path.join(ROLL, rel)));
  }));

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
