import fs from 'node:fs';
// Gurbani Saanjh v2.2.76: offline mic patches for the speech plugin.
// Runs on postinstall (after `npm ci`), so the patches survive a clean
// install - node_modules is NOT in the source zip. Every patch is
// idempotent: a second run is a no-op. Fails loudly if a plugin file or
// anchor changed, so a build never silently ships without the fix.
//
// What it patches (all offline, no cloud, no internet):
//  1. Silence 8s (v2.2.73): keep each listening stretch to ~8s of silence
//     before the service ends it (stock ~2s ends the segment and beeps
//     every ~2s while idle; the app restarts after each stop).
//  2. Beep mute (v2.2.76): the beep is the phone's speech-service sound
//     and has no off switch, so the app quiets the sound streams it
//     plays on (music/system/notification) while the mic listens, and
//     restores them when the mic stops. Only streams that were unmuted
//     are muted, so the user's own mute settings are preserved.
//  3. RMS meter (v2.2.76): forward the mic sound level (onRmsChanged)
//     to JS as an "rmsChanged" event, throttled to ~10/s, so the app can
//     show a live "mic is hearing you" bar.
//  4. Manifest: MODIFY_AUDIO_SETTINGS (normal permission, auto-granted)
//     so the mute calls are allowed.
const JAVA =
  'node_modules/@capacitor-community/speech-recognition/android/src/main/java/com/getcapacitor/community/speechrecognition/SpeechRecognition.java';
const MANIFEST =
  'node_modules/@capacitor-community/speech-recognition/android/src/main/AndroidManifest.xml';

function must(cond, msg) {
  if (!cond) throw new Error(msg);
}
function patchOnce(s, marker, anchor, insert, label) {
  if (s.includes(marker)) {
    console.log(label + ': already applied');
    return s;
  }
  must(s.includes(anchor), label + ': anchor changed - investigate before shipping');
  console.log(label + ': applied');
  return s.replace(anchor, insert);
}

must(fs.existsSync(JAVA), 'speech plugin not installed - mic patch cannot apply; investigate before shipping');
must(fs.existsSync(MANIFEST), 'speech plugin manifest missing - mic patch cannot apply; investigate before shipping');

let s = fs.readFileSync(JAVA, 'utf8');

// 1. Silence 30s (v2.2.77): keep each listening stretch to ~30s of silence
// before the service ends it. v2.2.73 used 8s, but the mic still restarted
// again and again (each restart beeps), so the stretch is now 30s. The
// app-side guard (armSegGuard in app.js) is 30s too, so the app does not
// force a restart before the recognizer stops on its own.
// Three cases: fresh tree (insert), 8s tree (upgrade in place), 30s tree (skip).
if (s.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000')) {
  console.log('silence 30s: already applied');
} else if (s.includes('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000')) {
  s = s.replace('EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 8000', 'EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000')
       .replace('EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 8000', 'EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000');
  console.log('silence 30s: upgraded from 8s');
} else {
  const anchor = '        intent.putExtra("android.speech.extra.DICTATION_MODE", partialResults);';
  must(s.includes(anchor), 'silence 30s: anchor changed - investigate before shipping');
  s = s.replace(anchor, anchor + '\n' +
    '        // Gurbani Saanjh v2.2.77: keep each listening stretch to ~30s of silence\n' +
    '        // before the service ends it (8s still restarted again and again,\n' +
    '        // and each restart beeps; the app-side guard is 30s too).\n' +
    '        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 30000);\n' +
    '        intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 30000);');
  console.log('silence 30s: applied');
}

// Imports for the mute (AudioManager, Context) and the muted-set (HashSet, Set).
s = patchOnce(
  s,
  'import android.media.AudioManager;',
  'import android.content.Intent;',
  'import android.content.Context;\nimport android.content.Intent;\nimport android.media.AudioManager;',
  'imports (AudioManager/Context)'
);
s = patchOnce(
  s,
  'import java.util.HashSet;',
  'import java.util.List;',
  'import java.util.HashSet;\nimport java.util.List;\nimport java.util.Set;',
  'imports (HashSet/Set)'
);

// 2. Beep-mute state fields.
s = patchOnce(
  s,
  'mutedStreams',
  '    private boolean listening = false;',
  '    private boolean listening = false;\n\n' +
    '    // Gurbani Saanjh v2.2.76: beep mute state. The beep is the phone\'s\n' +
    '    // speech-service sound (no off switch), so the app quiets the sound\n' +
    '    // streams it plays on while the mic listens, and restores them after.\n' +
    '    private AudioManager audioManager;\n' +
    '    private final Set<Integer> mutedStreams = new HashSet<>();',
  'mute fields'
);

// 2. Beep-mute methods (inserted before stopListening).
const MUTE_METHODS =
  '    // Gurbani Saanjh v2.2.77: quiet the beep streams while the mic listens.\n' +
  '    // Only streams that are currently unmuted are muted, and only those\n' +
  '    // are unmuted again, so the user\'s own mute settings are preserved.\n' +
  '    // MUSIC is deliberately NOT muted: music playing on the phone keeps\n' +
  '    // playing while the mic listens. The beep rides the system /\n' +
  '    // notification streams (it stops when the phone is on vibration,\n' +
  '    // which silences those streams but not music), so muting those two\n' +
  '    // silences the beep without touching music.\n' +
  '    private void muteBeepStreams() {\n' +
  '        try {\n' +
  '            if (audioManager == null) {\n' +
  '                audioManager = (AudioManager) bridge.getActivity().getSystemService(Context.AUDIO_SERVICE);\n' +
  '            }\n' +
  '            if (audioManager == null) return;\n' +
  '            int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };\n' +
  '            for (int stream : streams) {\n' +
  '                if (!audioManager.isStreamMute(stream)) {\n' +
  '                    audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, 0);\n' +
  '                    mutedStreams.add(stream);\n' +
  '                }\n' +
  '            }\n' +
  '        } catch (Exception ignored) {}\n' +
  '    }\n\n' +
  '    private void unmuteBeepStreams() {\n' +
  '        try {\n' +
  '            if (audioManager == null || mutedStreams.isEmpty()) return;\n' +
  '            for (int stream : mutedStreams) {\n' +
  '                audioManager.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0);\n' +
  '            }\n' +
  '            mutedStreams.clear();\n' +
  '        } catch (Exception ignored) {}\n' +
  '    }\n\n';
s = patchOnce(s, 'muteBeepStreams() {', '    private void stopListening() {', MUTE_METHODS + '    private void stopListening() {', 'mute methods');
// Upgrade a v2.2.76 mute (which also muted STREAM_MUSIC, so music went
// quiet) to the v2.2.77 mute (system + notification only; music keeps playing).
if (s.includes('AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION')) {
  s = s.replace('int[] streams = { AudioManager.STREAM_MUSIC, AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };',
    'int[] streams = { AudioManager.STREAM_SYSTEM, AudioManager.STREAM_NOTIFICATION };');
  console.log('mute streams: MUSIC removed (music keeps playing now)');
}

// 2. Mute right before the recognizer starts.
s = patchOnce(
  s,
  'muteBeepStreams();\n                        speechRecognizer.startListening(intent);',
  '                        speechRecognizer.startListening(intent);',
  '                        muteBeepStreams();\n                        speechRecognizer.startListening(intent);',
  'mute on start'
);

// 2. Unmute when stopListening runs (always, even if not listening).
s = patchOnce(
  s,
  '                    }\n                    unmuteBeepStreams();\n                } catch (Exception ex) {',
  '                    if (SpeechRecognition.this.listening) {\n                        speechRecognizer.stopListening();\n                        SpeechRecognition.this.listening(false);\n                    }\n                } catch (Exception ex) {',
  '                    if (SpeechRecognition.this.listening) {\n                        speechRecognizer.stopListening();\n                        SpeechRecognition.this.listening(false);\n                    }\n                    unmuteBeepStreams();\n                } catch (Exception ex) {',
  'unmute on stop'
);

// 2. Unmute when the recognizer ends speech on its own.
s = patchOnce(
  s,
  '                        SpeechRecognition.this.listening(false);\n                        unmuteBeepStreams();\n\n                        JSObject ret = new JSObject();\n                        ret.put("status", "stopped");',
  '                        SpeechRecognition.this.listening(false);\n\n                        JSObject ret = new JSObject();\n                        ret.put("status", "stopped");',
  '                        SpeechRecognition.this.listening(false);\n                        unmuteBeepStreams();\n\n                        JSObject ret = new JSObject();\n                        ret.put("status", "stopped");',
  'unmute on end-of-speech'
);

// 2. Unmute on recognizer error.
s = patchOnce(
  s,
  '        public void onError(int error) {\n            unmuteBeepStreams();',
  '        public void onError(int error) {\n            SpeechRecognition.this.stopListening();',
  '        public void onError(int error) {\n            unmuteBeepStreams();\n            SpeechRecognition.this.stopListening();',
  'unmute on error'
);

// 3. RMS meter: throttle field on the listener.
s = patchOnce(
  s,
  'private long lastRmsTime = 0;',
  '        private PluginCall call;\n        private boolean partialResults;',
  '        private PluginCall call;\n        private boolean partialResults;\n        private long lastRmsTime = 0;',
  'RMS throttle field'
);

// 3. RMS meter: forward onRmsChanged to JS as "rmsChanged" (~10/s).
s = patchOnce(
  s,
  'notifyListeners("rmsChanged"',
  '        public void onRmsChanged(float rmsdB) {}',
  '        public void onRmsChanged(float rmsdB) {\n' +
    '            // Gurbani Saanjh v2.2.76: forward the mic sound level so the\n' +
    '            // app can show a live "mic is hearing you" bar. Throttled\n' +
    '            // to ~10/s so the bridge is not flooded.\n' +
    '            long now = System.currentTimeMillis();\n' +
    '            if (now - lastRmsTime < 100) return;\n' +
    '            lastRmsTime = now;\n' +
    '            JSObject ret = new JSObject();\n' +
    '            ret.put("rms", rmsdB);\n' +
    '            notifyListeners("rmsChanged", ret);\n' +
    '        }',
  'RMS forward'
);

fs.writeFileSync(JAVA, s);

// 4. Manifest: MODIFY_AUDIO_SETTINGS (normal permission, auto-granted).
let m = fs.readFileSync(MANIFEST, 'utf8');
if (!m.includes('MODIFY_AUDIO_SETTINGS')) {
  const anchor = '    <uses-permission android:name="android.permission.RECORD_AUDIO" />';
  must(m.includes(anchor), 'manifest: RECORD_AUDIO anchor changed - investigate before shipping');
  m = m.replace(
    anchor,
    anchor + '\n    <uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />'
  );
  fs.writeFileSync(MANIFEST, m);
  console.log('manifest MODIFY_AUDIO_SETTINGS: applied');
} else {
  console.log('manifest MODIFY_AUDIO_SETTINGS: already applied');
}

console.log('speech mic patch done');
