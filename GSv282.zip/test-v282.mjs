/* Gurbani Saanj v2.2.62 — language toggle no longer hangs the app (Karamjit, 2026-11-13):
 * A tester reported the app HANGS after tapping the Home language toggle
 * (ਪੰਜਾਬੀ / English): the screen flickers and re-renders and nothing is
 * clickable afterwards. It ONLY hangs after the toggle. Karamjit's own phone
 * works fine; the first version (v2.2.55) had no issue.
 * ROOT CAUSE (render loop in the Hukamnama fetch, app.js):
 * render() -> attach() -> ensureHukamnama() -> fetchHukamnama().then(render).
 * (1) Tight loop: fetchHukamnama's hukamFetching guard returns the current
 * state.hukamnama — an async function wraps that in an IMMEDIATELY-RESOLVED
 * promise. So a render() while a fetch is in-flight attaches .then(render)
 * to a promise that resolves on the next microtask; that render calls
 * ensureHukamnama() again, which gets another immediately-resolved promise,
 * which renders again — a microtask loop that saturates the main thread.
 * Tapping the toggle while the Hukamnama is loading starts it. (2) Failure
 * loop: a failed fetch sets state.hukamnama=null, and the old .then()
 * re-rendered unconditionally, which started another fetch, which failed,
 * which re-rendered — render -> fetch -> fail -> render, forever.
 * Karamjit's phone is fine because his Hukamnama IS cached (he opens the app
 * daily), so ensureHukamnama() returns early and never fetches. A fresh
 * tester phone (or one whose fetch fails / is slow) has nothing cached, so
 * every render fetches and the loops above run.
 * FIX (minimal, in ensureHukamnama only): (a) return early while a fetch is
 * already in-flight — the fetch's own .then() renders when it lands; (b) the
 * .then() only re-renders when the fetch actually delivered today's lines —
 * a failed fetch never re-renders. The toggle design, the Hukamnama card and
 * everything else are unchanged. The switch is now one clean render per tap:
 * no loop, no flicker, no layout jump (the hero keeps the same structure
 * whether the Hukamnama is loaded or still loading).
 * Kept from v2.2.61: no Mool Mantar in the drawer, Kirtan heart, ensureCatalog,
 * icon row gone, clock after ਪੁ/EN, pills nowrap. No Help button (cancelled).
 * Run: node test-v282.mjs
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
const ROOT = path.resolve(import.meta.dirname);
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log(`PASS  ${n}`); } else { fail++; console.log(`FAIL  ${n} ${x}`); } };

const app = fs.readFileSync(path.join(ROOT, 'www/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'www/index.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'www/styles.css'), 'utf8');

// ---- 0. Version ----
const vj = JSON.parse(fs.readFileSync(path.join(ROOT, 'www/version.json'), 'utf8'));
const pj = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const nbc = fs.readFileSync(path.join(ROOT, 'www/native-build-config.js'), 'utf8');
ok('version.json is 2.2.62', vj.version === '2.2.62');
ok('package.json is 2.2.62', pj.version === '2.2.62');
ok('native-build-config.js is 2.2.62', nbc.includes('"version":"2.2.62"'));
ok('version notes mention v2.2.62 + language toggle hang + one render per tap',
  vj.notes.includes('v2.2.62:') && vj.notes.includes('language toggle') && vj.notes.includes('one render per tap'));

// ---- 1. The fix, statically ----
ok('ensureHukamnama returns early while a fetch is in-flight (v2.2.62 guard)',
  /function ensureHukamnama\(\)\{[\s\S]*?if\(hukamFetching\)return;/.test(app));
ok('ensureHukamnama .then only re-renders when today\'s lines were delivered',
  app.includes("state.hukamnama.date===hukamTodayKey()") &&
  /fetchHukamnama\(\)\.then\(\(\)=>\{[\s\S]*?if\(state\.view==='home'\|\|state\.view==='hukamnama'\)render\(\);/.test(app));
ok('language handlers unchanged: lang-pa/lang-en set state.lang and render once',
  app.includes("case'lang-pa':state.lang='pa';state.aiLangManual=false;state.aiLang='pa';persist();if(state.view==='reader')refreshReader();else render();break;") &&
  app.includes("case'lang-en':state.lang='en';state.aiLangManual=false;state.aiLang='en';persist();if(state.view==='reader')refreshReader();else render();break;"));
ok('fetchHukamnama still has its in-flight guard and still caches on success',
  app.includes('if(hukamFetching)return state.hukamnama;') &&
  app.includes('state.hukamnama={date:key,ang:'));
ok('no Help button anywhere (cancelled — it would be confusing)',
  !app.includes('helpScreen') && !app.includes('data-action="help"') && !app.includes('ਮਦਦ') &&
  !html.includes('data-action="help"'));

// ---- 2. v2.2.61 markers intact ----
ok('v2.2.61: Mool Mantar entry gone from the Banis drawer (code line deleted)',
  !app.includes("ghead(age('ਮੂਲ ਮੰਤਰ','Mool Mantar'))") && !app.includes("row(2,age('ਮੂਲ ਮੰਤਰ'"));
ok('v2.2.61: drawer still starts with the NITNEM group (Japji Sahib kept)',
  app.includes("const nitnemIds=[2,4,6,9,10,21,130,23]") &&
  app.includes("html+=ghead(age('ਨਿਤਨੇਮ','Nitnem'))+nitnemRows") &&
  app.indexOf("ghead(age('ਨਿਤਨੇਮ','Nitnem'))") < app.indexOf("ghead(age('ਬਾਣੀਆਂ','Banis'))"));
ok('v2.2.60: Kirtan heart button on each Shabad row (♡/♥, data-save-hit ang:lineStart)',
  app.includes('class="favorite') && app.includes('data-save-hit="${s.ang}:${s.lineStart}"'));
ok('v2.2.59: ensureCatalog exists and the reader view calls it',
  app.includes('function ensureCatalog()') && app.includes("if(state.view==='reader')ensureCatalog();"));
ok('v2.2.58: Search/Saved/History icon row gone; History is the clock AFTER the ਪੁ/EN button',
  (() => { const m = app.match(/<div class="inputrow gs-search-box">([\s\S]*?)<\/div>/); return !!m && m[1].indexOf('id="kbToggle"') > 0 && m[1].indexOf('id="iconHistory"') > m[1].indexOf('id="kbToggle"'); })());
ok('v2.2.57: search-mode pills stay on one line (nowrap + horizontal scroll)',
  /\.gs-search-modes\s*\{[^}]*flex-wrap:\s*nowrap;[^}]*overflow-x:\s*auto;/.test(css));

// ---- 3. vm simulation: the real fetchHukamnama/ensureHukamnama ----
// Extract the real Hukamnama functions verbatim (markers, not line numbers).
const hukamSlice = app.slice(app.indexOf('function hukamTodayKey'), app.indexOf('let hukamNotifScheduled'));
if (!hukamSlice.includes('function fetchHukamnama') || !hukamSlice.includes('function ensureHukamnama'))
  throw new Error('hukam slice did not capture the real functions');
// Harness inside the vm: render() mirrors the real one (rebuild + attach);
// attach() mirrors app.js Home wiring (ensureHukamnama). A render cap stops a
// runaway loop so a looping build terminates and is caught by the count.
const harness = `
globalThis.__renders = 0; globalThis.__capHit = false;
globalThis.render = function(){ globalThis.__renders++; if(globalThis.__renders > 200){ globalThis.__capHit = true; return; } attach(); };
globalThis.attach = function(){ if(state.view==='home'||state.view==='hukamnama') ensureHukamnama(); };
globalThis.tapLangPa = function(){ state.lang='pa'; persist(); render(); };
globalThis.tapLangEn = function(){ state.lang='en'; persist(); render(); };
`;
function makeHukamCtx(fetchStub) {
  let fetches = 0;
  const state = { view: 'home', lang: 'en', hukamnama: null };
  const sandbox = {
    state, console,
    fetch: (...a) => { fetches++; return fetchStub(...a); },
    persist: () => {},
    enrichLines: async (ls) => ls,
  };
  const ctx = vm.createContext(sandbox);
  vm.runInContext(hukamSlice, ctx);
  vm.runInContext(harness, ctx);
  return {
    ctx, state,
    get renders() { return ctx.__renders; },
    get fetches() { return fetches; },
    get capHit() { return ctx.__capHit; },
    render() { vm.runInContext('render()', ctx); },
    tapLangPa() { vm.runInContext('tapLangPa()', ctx); },
    tapLangEn() { vm.runInContext('tapLangEn()', ctx); },
  };
}
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const todayKey = () => { const n = new Date(); return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`; };
const goodHukamResponse = () => ({
  ok: true,
  json: async () => ({
    shabads: [{
      verses: [
        { verse: { unicode: 'ਸੰਤ ਹਮਾਰੀ ਓਟ ਸਤਾਣੀ' }, translation: { en: { bdb: 'The Saint is my shelter' }, pu: { ss: { unicode: 'ਸੰਤ ਹਮਾਰੀ ਓਟ ਸਤਾਣੀ' } } }, transliteration: { english: 'sant hamaaree ot sataanee' } },
        { verse: { unicode: 'ਸੰਤ ਹਮਾਰਾ ਗਹਣਾ' }, translation: { en: { bdb: 'The Saint is my ornament' }, pu: { ss: { unicode: 'ਸੰਤ ਹਮਾਰਾ ਗਹਣਾ' } } }, transliteration: { english: 'sant hamaaraa gahnaa' } },
      ],
      shabadInfo: { pageNo: 682, raag: { unicode: 'ਧਨਾਸਰੀ', english: 'Dhanaasree' }, writer: { english: 'Guru Arjan Dev Ji' }, shabadId: 2602 },
    }],
  }),
});

// (A) The reported hang: fetch in-flight when the toggle is tapped.
// Before the fix this hit the 200-render cap in <200ms (microtask loop);
// after the fix the tap is exactly ONE render and nothing more follows.
{
  const t = makeHukamCtx(() => new Promise(() => {})); // never resolves: slow network
  t.render(); // boot render -> fetch starts (hukamFetching=true)
  await sleep(20);
  const before = t.renders;
  t.tapLangPa();
  await sleep(250);
  ok('(A) in-flight fetch + lang tap: exactly ONE render for the tap (smooth switch, no loop)',
    t.renders - before === 1 && !t.capHit, `renders after tap=${t.renders - before} fetches=${t.fetches}`);
  ok('(A) in-flight fetch + lang tap: no further renders over 250ms (no flicker)',
    t.renders - before === 1, `renders after tap=${t.renders - before}`);
  ok('(A) in-flight fetch + lang tap: language actually switched to Punjabi',
    t.state.lang === 'pa');
  ok('(A) in-flight fetch + lang tap: only ONE fetch attempt was made',
    t.fetches === 1, `fetches=${t.fetches}`);
}
// (B) Failing fetch (offline / BaniDB unreachable): no render/fetch loop.
{
  const t = makeHukamCtx(async () => { throw new Error('offline'); });
  t.render();
  await sleep(300);
  ok('(B) failing fetch: exactly ONE render and ONE fetch attempt (no loop)',
    t.renders === 1 && t.fetches === 1 && !t.capHit, `renders=${t.renders} fetches=${t.fetches}`);
  t.tapLangEn();
  await sleep(150);
  // The tap is one render; its render retries the fetch once (still uncached,
  // previous fetch finished) — a single background attempt that cannot
  // re-render (the .then guard), so renders stay at 2 and no loop follows.
  ok('(B) failing fetch + lang tap afterwards: tap = one render, one retry fetch, then settles',
    t.renders === 2 && t.fetches === 2 && !t.capHit, `renders=${t.renders} fetches=${t.fetches}`);
}
// (D) Fetch succeeds: the hero fills in exactly ONCE, then settles.
{
  const t = makeHukamCtx(async () => { await sleep(60); return goodHukamResponse(); });
  t.render(); // boot: fetch starts
  t.tapLangPa(); // tap while loading: one render
  await sleep(250); // fetch lands -> one data-arrival render
  ok('(D) successful fetch: boot + tap + one data-arrival render = 3 renders, 1 fetch',
    t.renders === 3 && t.fetches === 1 && !t.capHit, `renders=${t.renders} fetches=${t.fetches}`);
  ok('(D) successful fetch: today\'s Hukamnama is cached with lines (Ang 682)',
    t.state.hukamnama && t.state.hukamnama.date === todayKey() && t.state.hukamnama.lines.length === 2 && t.state.hukamnama.ang === 682);
  const r0 = t.renders, f0 = t.fetches;
  t.render(); t.tapLangEn(); // cached now: renders are just the taps
  await sleep(50);
  ok('(D) cached Hukamnama: further renders do NOT re-fetch',
    t.renders === r0 + 2 && t.fetches === f0, `renders=${t.renders} fetches=${t.fetches}`);
}
// (E) Rapid toggling with a cached Hukamnama: one render per tap, no extras.
{
  const t = makeHukamCtx(async () => { throw new Error('should not be called'); });
  t.state.hukamnama = { date: todayKey(), lines: [{ g: 'x' }], ang: 682 };
  t.render();
  t.tapLangPa(); t.tapLangEn(); t.tapLangPa(); t.tapLangEn();
  await sleep(50);
  ok('(E) rapid toggling (4 taps, cached): exactly 5 renders = boot + one per tap',
    t.renders === 5 && t.fetches === 0, `renders=${t.renders} fetches=${t.fetches}`);
  ok('(E) rapid toggling ends in English', t.state.lang === 'en');
}

// ---- 4. vm: the real Home screen in both languages ----
const homeSlice = [
  app.slice(app.indexOf('const HOME_IDS='), app.indexOf('let homeEditing=false')),
  app.slice(app.indexOf('const txt={'), app.indexOf('const t=')),
  app.slice(app.indexOf('const t='), app.indexOf('function persist()')),
  app.slice(app.indexOf('function homeCard'), app.indexOf('function moveHomeCard')),
  app.slice(app.indexOf('function hukamHeroHTML'), app.indexOf('function hukamnamaScreen')),
].join('\n');
if (!homeSlice.includes('function homeScreen') || !homeSlice.includes('function hukamHeroHTML') || !homeSlice.includes('const txt='))
  throw new Error('home slice did not capture the real Home functions');
function makeHomeCtx() {
  const state = { view: 'home', lang: 'pa', homeOrder: ['reader', 'nitnem', 'catalog', 'kirtan', 'ask'], ang: 1, hukamnama: null };
  const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const sandbox = { state, console, esc, persist: () => {}, };
  const ctx = vm.createContext(sandbox);
  vm.runInContext('let homeEditing=false;\n' + homeSlice, ctx);
  return { ctx, state, html: () => vm.runInContext('homeScreen()', ctx) };
}
{
  const h = makeHomeCtx();
  const pa = h.html();
  ok('Home (Punjabi): brand is ਗੁਰਬਾਣੀ ਸਾਂਝ, Punjabi pill selected, Nitnem card in Punjabi',
    pa.includes('ਗੁਰਬਾਣੀ ਸਾਂਝ') && pa.includes('data-action="lang-pa" class="sel"') && pa.includes('ਨਿਤਨੇਮ'));
  ok('Home (Punjabi): language toggle has both pills (ਪੰਜਾਬੀ / English)',
    pa.includes('data-action="lang-pa"') && pa.includes('data-action="lang-en"') && pa.includes('>ਪੰਜਾਬੀ<') && pa.includes('>English<'));
  ok('Home (Punjabi, no Hukamnama yet): hero shows the loading line, same hero structure',
    pa.includes('hukam-hero') && pa.includes('ਅੱਜ ਦਾ ਹੁਕਮਨਾਮਾ ਖੋਲ੍ਹ ਰਿਹਾ ਹੈ…'));
  h.state.lang = 'en';
  const en = h.html();
  ok('Home (English): brand is Gurbani Saanjh, English pill selected, Nitnem card in English',
    en.includes('Gurbani Saanjh') && en.includes('data-action="lang-en" class="sel"') && en.includes('Nitnem'));
  ok('Home (English): no Punjabi pill selected, toggle still both pills',
    !en.includes('data-action="lang-pa" class="sel"') && en.includes('data-action="lang-pa"') && en.includes('data-action="lang-en"'));
  h.state.hukamnama = { date: todayKey(), ang: 682, raag: 'ਧਨਾਸਰੀ', raagEn: 'Dhanaasree', lines: [{ g: 'ਲਾਈਨ ਇੱਕ' }, { g: 'ਸੰਤ ਹਮਾਰਾ ਗਹਣਾ' }] };
  const loaded = h.html();
  ok('Home (English, Hukamnama loaded): hero shows the preview + Ang meta, same hero element',
    loaded.includes('hukam-hero') && loaded.includes('ਸੰਤ ਹਮਾਰਾ ਗਹਣਾ') && loaded.includes('Ang 682'));
}

console.log(`\n${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
