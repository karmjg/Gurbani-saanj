/* Gurbani Saanjh v2.2.0 verification suite (node, offline).
 * Run: node test-v220.mjs
 * Per-item checklist for the v2.2.0 rebuild. Each item prints PASS/FAIL.
 * Uses fixture data in /tmp/v220test/offline (created by the build) and the
 * real bundled corpus where safe. No network, no device.
 */
import fs from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname);
const FIX = '/tmp/v220test/offline';
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log(`PASS  ${name}`); }
  else { fail++; console.log(`FAIL  ${name} ${extra}`); }
};
const read = p => fs.readFileSync(path.join(ROOT, p), 'utf8');
// Minimal browser-ish sandbox with stubbed fetch.
function sandbox(extra = {}) {
  const store = {};
  const sb = {
    window: {},
    localStorage: {
      getItem: k => (k in store ? store[k] : null),
      setItem: (k, v) => { store[k] = String(v); },
      removeItem: k => { delete store[k]; },
    },
    fetch: async (url) => {
      const u = String(url);
      const file = u.includes('vishraam.json') ? `${FIX}/vishraam.json`
        : u.includes('kosh-stems.json') ? `${FIX}/kosh-stems.json`
        : u.includes('kirtan-shabads.json') ? `${FIX}/kirtan-shabads.json`
        : u.includes('kosh.json') ? `${ROOT}/www/offline/kosh.json`
        : u.includes('search.json') ? `${ROOT}/www/offline/search.json`
        : null;
      if (!file || !fs.existsSync(file)) return { ok: false };
      return { ok: true, json: async () => JSON.parse(fs.readFileSync(file, 'utf8')) };
    },
    console,
    ...extra,
  };
  sb.window = sb.window || {};
  return sb;
}
function loadScript(sb, rel) {
  vm.runInNewContext(read(rel), sb, { filename: rel });
}

/* ---------- 1. Vishraam colors + toggle ---------- */
{
  const sb = sandbox(); loadScript(sb, 'www/render-verses.js'); loadScript(sb, 'www/vishraam.js');
  const V = sb.window.GS_VERSES, VH = sb.window.GS_VISHRAAM;
  // exact contract tokenization
  ok('1a tokens() uses exact contract (incl. numeral tokens)',
    JSON.stringify(V.tokens('ਆਦਿ ਸਚੁ ॥੧॥')) === JSON.stringify(['ਆਦਿ', 'ਸਚੁ', '॥੧॥']));
  const marks = await VH.marksForText('a', 1);
  ok('1b marksForText loads sample marks', marks?.[0]?.[1] === 's' && marks?.[0]?.[3] === 'l');
  ok('1c invalid mark value ignored', !(marks?.[5]?.[2]));
  const line = { g: 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ਨਿਰਭਉ ॥', roman: 'Ik Oankaar Sat Naam', en: 'One Creator', pa: 'ਵਾਹਿਗੁਰੂ' };
  const show = { translit: true, en: true, pa: true, hi: false, arth: false };
  const html = V.verseHTML(line, { idx: 0, kind: 'bani', vishraamOn: true, marks: marks[0], koshHas: () => false, show });
  ok('1d short pause renders GREEN class', html.includes('data-widx="1"') && /data-widx="1"[^>]*vishraam-short|vishraam-short[^>]*data-widx="1"/.test(html));
  ok('1e long pause renders ORANGE class', /vishraam-long/.test(html));
  const off = V.verseHTML(line, { idx: 0, kind: 'bani', vishraamOn: false, marks: marks[0], koshHas: () => false, show });
  ok('1f vishraam OFF strips ALL green/orange', !/vishraam-(short|long)/.test(off));
  const noMarks = V.verseHTML(line, { idx: 0, kind: 'bani', vishraamOn: true, marks: null, koshHas: () => false, show });
  ok('1g missing vishraam file -> plain text, no crash', !/vishraam-(short|long)/.test(noMarks) && noMarks.includes('ਸਤਿ'));
  // toggle exists in app source: home switch card + settings + viewprefs
  const app = read('www/app.js');
  ok('1h vishraam switch on home screen', app.includes('vishraam-switch-card') && app.includes("data-action=\"toggle-vishraam\""));
  ok('1i vishraam toggle in reading settings', app.includes("choice('vishraams'"));
  ok('1j vishraam defaults ON', /vishraams:true/.test(app));
}

/* ---------- 2. Layered Bani translations ---------- */
{
  const sb = sandbox(); loadScript(sb, 'www/render-verses.js');
  const V = sb.window.GS_VERSES;
  const line = { g: 'ਸਤਿ ਨਾਮੁ', roman: 'Sat Naam', en: 'True Name', pa: 'ਸੱਚਾ ਨਾਮ' };
  const html = V.verseHTML(line, { idx: 0, kind: 'bani', vishraamOn: true, marks: null, koshHas: () => false, arth: [{ word: 'ਸਤਿ', meaning: 'ਸੱਚ' }], show: { translit: true, en: true, pa: true, hi: false, arth: true } });
  const order = ['verse-text', 'verse-roman', 'verse-en', 'verse-pa', 'verse-arth'].map(c => html.indexOf(c));
  ok('2a layer order Gurmukhi/roman/en/pa/arth', order.every((v, i) => i === 0 || v > order[i - 1]) && order[0] >= 0);
  ok('2b all layer contents present', html.includes('>ਸਤਿ</button>') && html.includes('>ਨਾਮੁ</button>') && html.includes('Sat Naam') && html.includes('True Name') && html.includes('ਸੱਚਾ ਨਾਮ') && html.includes('ਸਤਿ</b> = ਸੱਚ'));
  const sparse = { g: 'ਸਤਿ ਨਾਮੁ', roman: '', en: '', pa: '' };
  const html2 = V.verseHTML(sparse, { idx: 0, kind: 'bani', vishraamOn: true, marks: null, koshHas: () => false, show: { translit: true, en: true, pa: true, hi: false, arth: false } });
  ok('2c empty layers omitted (no empty divs)', !/verse-(roman|en|pa|arth)/.test(html2));
  ok('2d bani header rule (no duplicate manglacharan)',
    V.baniHeaderNeeded([{ g: 'ੴ ਸਤਿ ਨਾਮੁ ਕਰਤਾ ਪੁਰਖੁ ॥' }]) === true &&
    V.baniHeaderNeeded([{ g: 'ੴ ਸਤਿਗੁਰ ਪ੍ਰਸਾਦਿ ॥' }]) === false &&
    V.baniHeaderNeeded([{ g: 'ੴ ਵਾਹਿਗੁਰੂ ਜੀ ਕੀ ਫਤਹ ॥' }]) === false);
  ok('2e chhand heading detection', V.isBaniHeading('॥ ਜਪੁ ॥') && V.isBaniHeading('ਛਪੈ ਛੰਦ ॥') && !V.isBaniHeading('ਸੋਚੈ ਸੋਚਿ ਨ ਹੋਵਈ ਜੇ ਸੋਚੀ ਲਖ ਵਾਰ ॥'));
}

/* ---------- 3. iGranth keyboard ---------- */
{
  const app = read('www/app.js');
  const m = app.match(/const GS_KEYS=\[([\s\S]*?)\];/);
  const keys = [...m[1].matchAll(/'([^']+)'/g)].map(x => x[1]);
  ok('3a 35 keyboard keys present', keys.length === 35, `found ${keys.length}`);
  const expected = ['ੳ/ਓ', 'ਅ', 'ੲ', 'ਸ', 'ਹ', 'ਕ', 'ਖ', 'ਗ', 'ਘ', 'ਙ', 'ਚ', 'ਛ', 'ਜ', 'ਝ', 'ਞ', 'ਟ', 'ਠ', 'ਡ', 'ਢ', 'ਣ', 'ਤ', 'ਥ', 'ਦ', 'ਧ', 'ਨ', 'ਪ', 'ਫ', 'ਬ', 'ਭ', 'ਮ', 'ਯ', 'ਰ', 'ਲ', 'ਵ', 'ੜ'];
  ok('3b exact key rows', JSON.stringify(keys) === JSON.stringify(expected));
  ok('3c keys append letters (data-gs-key handler)', app.includes('data-gs-key') && app.includes("input.value+=GS_KEY_VALUE[k]||k"));
  const sb = sandbox(); loadScript(sb, 'www/scripture-search.js');
  const res = await sb.window.GS_SCRIPTURE_SEARCH.query('ਸਨਕਪ', 5, 'first');
  ok('3d first-letter search returns Ang 1 line 0', res[0]?.ang === 1 && res[0]?.idx === 0);
  const angRes = await sb.window.GS_SCRIPTURE_SEARCH.query('1', 5, 'ang');
  ok('3e Ang-number jump works', angRes.length > 0 && angRes[0].ang === 1);
}

/* ---------- 4. Ang view layers + Bani View Preferences ---------- */
{
  const app = read('www/app.js');
  for (const key of ['showTranslit', 'showEn', 'showPa', 'showHi', 'showArth']) {
    ok(`4a toggle exists: ${key}`, app.includes(`toggle('${key}'`) || app.includes(`choice('${key}'`));
  }
  ok('4b nightMode toggle exists', (app.includes("toggle('nightMode'") || app.includes("choice('nightMode'")) && app.includes("html.dataset.nightmode"));
  ok('4c baniTextSize toggle exists (3 sizes)', app.includes("choice('baniTextSize'") && app.includes("'xlarge'"));
  ok('4d Ang header "SGGS, Ang N" + settings + share', app.includes('SGGS,') && app.includes('data-action="share-current"'));
  ok('4e Ang Gurmukhi blue/bold class wired', app.includes('gs-gurmukhi-blue'));
  const css = read('www/styles.css');
  ok('4f night mode CSS (near-black bg, white gurmukhi, green translit/en, maroon pa)',
    css.includes('html[data-nightmode="on"]') && css.includes('--bg: #070908') && css.includes('.verse-roman, html[data-nightmode="on"] .verse-en'));
  ok('4g layer colors (roman red, en black, pa maroon)', css.includes('.verse-roman { color: #b3261e') && css.includes('.verse-en { color: #1c1c1c') && css.includes('.verse-pa, .verse-hi { color: #7b1e2b'));
  // functional toggle test: render with each layer on/off
  const sb = sandbox(); loadScript(sb, 'www/render-verses.js');
  const V = sb.window.GS_VERSES;
  const line = { g: 'ਸਤਿ', roman: 'Sat', en: 'True', pa: 'ਸੱਚ' };
  const base = { idx: 0, kind: 'ang', vishraamOn: false, marks: null, koshHas: () => false };
  ok('4h translit toggle gates roman layer',
    V.verseHTML(line, { ...base, show: { translit: true, en: false, pa: false, arth: false } }).includes('verse-roman') &&
    !V.verseHTML(line, { ...base, show: { translit: false, en: false, pa: false, arth: false } }).includes('verse-roman'));
  ok('4i en/pa toggles gate their layers',
    V.verseHTML(line, { ...base, show: { translit: false, en: true, pa: false, arth: false } }).includes('verse-en') &&
    V.verseHTML(line, { ...base, show: { translit: false, en: false, pa: true, arth: false } }).includes('verse-pa'));
}

/* ---------- 5. Voice search wiring ---------- */
{
  const app = read('www/app.js');
  ok('5a runtime permission request BEFORE listening', app.indexOf('requestPermissions') < app.indexOf("native.start(opts('pa-IN'))"));
  ok('5b clear permission prompt text', app.includes('ਮਾਈਕ ਦੀ ਇਜਾਜ਼ਤ ਚਾਹੀਦੀ ਹੈ'));
  ok('5c heard text fills search box live', app.includes('partialResults') && app.includes('input.value=m') || app.includes('fill(m)'));
  ok('5d unavailable fallback intact (typed search guidance)', app.includes('Type to search instead') || app.includes('ਲਿਖ ਕੇ ਖੋਜੋ'));
  ok('5e no getSupportedLanguages hang (not awaited pre-listen)', !/await native\.getSupportedLanguages/.test(app));
  ok('5f mic button on search screen + ask screen', app.includes('id="voiceBtn"') && app.includes('id="askVoiceBtn"'));
  ok('5g mic self-test in settings', app.includes('mic-test') && app.includes('async function micTest'));
  const patch = read('scripts/patch-android.mjs');
  ok('5h patch-android.mjs adds RECORD_AUDIO', patch.includes('android.permission.RECORD_AUDIO'));
  const wf = read('.github/workflows/android-apk-1.yml');
  const ciPos = wf.indexOf('npm ci'), syncPos = wf.indexOf('npx cap sync');
  ok('5i workflow: npm ci BEFORE cap sync', ciPos > 0 && syncPos > 0 && ciPos < syncPos, `ci@${ciPos} sync@${syncPos}`);
  ok('5j workflow verifies voice bundle (GS_SPEECH)', wf.includes('GS_SPEECH'));
  ok('5k workflow verifies RECORD_AUDIO in manifest', wf.includes('RECORD_AUDIO'));
}

/* ---------- 6. Tap-a-word chain ---------- */
{
  const sb = sandbox(); loadScript(sb, 'www/word-kosh.js');
  const K = sb.window.GS_KOSH;
  await K.ready();
  const exact = await K.lookup('ਸਤਿ', 'pa');
  ok('6a exact match', exact.definitions.length > 0);
  const stem = await K.lookup('ਕਰਦਾ', 'pa');
  ok('6b stem-strip (ਕਰਦਾ -> ਕਰ)', stem.definitions.length > 0 && stem.source === 'offline-kosh-stem', JSON.stringify(stem.source));
  const punct = await K.lookup('ਸਚੁ॥', 'pa');
  ok('6c punctuation/numeral strip (ਸਚੁ॥ -> ਸਚੁ)', punct.definitions.length > 0);
  const missing = await K.lookup('ਝਖੜ', 'pa');
  ok('6d give up silently (no definitions)', missing.definitions.length === 0);
  ok('6e orange only for words with entries', K.hasEntrySync('ਕਰਦਾ') === true && K.hasEntrySync('ਝਖੜ') === false);
  const arth = await K.arthFor({ g: 'ਸਤਿ ਨਾਮੁ ਝਖੜ' }, 'pa');
  ok('6f shabad arth word=meaning pairs', arth.length >= 2 && arth.every(a => a.word && a.meaning));
  const app = read('www/app.js');
  ok('6g orange class wired in renderer', app.includes('koshHas') && read('www/styles.css').includes('.word.kosh-word'));
}

/* ---------- 7. Kirtan Shabad book ---------- */
{
  const sb = sandbox({
    GS_REMOTE: {
      read: async (kind, id) => {
        const data = JSON.parse(fs.readFileSync(`${ROOT}/www/offline/ang/${id}.json`, 'utf8'));
        return { ...data, offline: true };
      },
    },
  });
  sb.window.GS_REMOTE = sb.GS_REMOTE;
  loadScript(sb, 'www/kirtan-book.js');
  const list = await sb.window.GS_KIRTAN.list();
  ok('7a book loads entries from sample file', list.length === 2 && list[0].id === 'k1');
  const { meta, lines } = await sb.window.GS_KIRTAN.shabad('k1');
  ok('7b shabad slices ang lines (no fabricated text)', lines.length === 3 && lines[0].g.startsWith('ੴ ਸਤਿ ਨਾਮੁ'));
  ok('7c raag/mahla/ang refs present', meta.ang === 1);
  // missing file -> graceful []
  const sb2 = sandbox(); sb2.fetch = async () => ({ ok: false }); sb2.window.GS_REMOTE = sb.GS_REMOTE;
  loadScript(sb2, 'www/kirtan-book.js');
  ok('7d missing file -> empty list, no crash', (await sb2.window.GS_KIRTAN.list()).length === 0);
  const www = ['www/app.js', 'www/kirtan-book.js', 'www/index.html', 'www/styles.css'].map(read).join('\n');
  ok('7e NO YouTube button/action anywhere in kirtan UI', !/youtube/i.test(www));
  const app = read('www/app.js');
  ok('7f "View full Ang" link on shabad', app.includes('view-full-ang') && app.includes('data-ang'));
  ok('7g layered display reused for kirtan verses', app.includes("verseBlock(v,i,'kirtan')"));
  // render one kirtan entry with layers
  const sb3 = sandbox(); loadScript(sb3, 'www/render-verses.js');
  const html = sb3.window.GS_VERSES.verseHTML(lines[0], { idx: 0, kind: 'kirtan', vishraamOn: true, marks: null, koshHas: () => false, show: { translit: true, en: true, pa: true, arth: false } });
  ok('7h kirtan verse renders layers', html.includes('verse-text') && html.includes('verse-en'));
}

/* ---------- 8. AI Q&A ---------- */
{
  const sb = sandbox(); loadScript(sb, 'www/scripture-search.js');
  const res = await sb.window.GS_SCRIPTURE_SEARCH.query('ਸਚੁ', 5);
  ok('8a offline retrieval returns ranked Shabads with Ang refs', res.length > 0 && res.every(r => Number.isInteger(r.ang) && typeof r.g === 'string'));
  const app = read('www/app.js');
  ok('8b API key settings field exists + persists', app.includes('id="aiKeyInput"') && app.includes("state.aiApiKey=e.target.value.trim();persist()"));
  ok('8c endpoint + model configurable', app.includes('id="aiApiEndpointInput"') && app.includes('id="aiModelInput"'));
  ok('8d system prompt: GGS-only constraint', app.includes('Answer ONLY from the provided Gurbani passages'));
  ok('8e system prompt: Ang citation requirement', app.includes('Cite Ang numbers for every claim'));
  ok('8f system prompt: one-sentence fallback', app.includes('say so plainly in one sentence'));
  ok('8g passages sent with Ang refs as context', app.includes('[Ang ${m.ang}]'));
  ok('8h retrieval labeled "Related Shabads (offline)", never "AI answered"',
    app.includes("t('relatedOffline')") && !/AI answered/.test(app));
  ok('8i AI answer labeled distinctly', app.includes("t('aiAnswerLabel')"));
  ok('8j legacy server hook kept (AI_SERVER_SETUP.md path)', app.includes('aiAccessToken') && fs.existsSync(path.join(ROOT, 'AI_SERVER_SETUP.md')));
  ok('8k conversational UI (type or voice)', app.includes('id="questionInput"') && app.includes('id="askVoiceBtn"'));
}

/* ---------- 9. Regression: nothing broken ---------- */
{
  const app = read('www/app.js');
  for (const [name, needle] of [
    ['page-turn mode', "state.mode==='page'"], ['scroll mode', "t('scroll')"],
    ['daily screen', 'dailyScreen'], ['kirtan corpus search', 'kirtanSearch'],
    ['favorites/saved', 'savedVerses'], ['auto-scroll capture', 'function capture()'],
    ['bookmarks view', 'bookmarksScreen'], ['no alarm', ], ['no notes',], ['no kid modes',],
  ]) {
    if (needle) ok(`9 ${name} still wired`, app.includes(needle));
  }
  ok('9 NO alarm feature', !/alarm/i.test(app));
  ok('9 NO notes feature', !/\bnotes\b/i.test(app.replace('footnote', '')));
  const files = ['www/app.js', 'www/word-kosh.js', 'www/vishraam.js', 'www/kirtan-book.js', 'www/render-verses.js', 'www/scripture-search.js', 'www/remote-library.js', 'www/page-turn.js', 'www/catalog.js', 'www/data.js', 'scripts/patch-android.mjs', 'scripts/build-web.mjs', 'scripts/bundle-offline.mjs'];
  // node --check via child process
  const { execSync } = await import('node:child_process');
  let allOk = true;
  for (const f of files) {
    try { execSync(`node --check ${path.join(ROOT, f)}`, { stdio: 'pipe' }); }
    catch { allOk = false; console.log(`   syntax FAIL: ${f}`); }
  }
  ok('9 node --check on every JS/MJS file', allOk);
  // existing test suites
  try {
    execSync(`node scripts/bundle-offline.mjs --fixture`, { cwd: ROOT, stdio: 'pipe' });
    execSync(`node test-reader.mjs`, { cwd: ROOT, stdio: 'pipe' });
    ok('9 existing suites (bundle-offline --fixture, test-reader.mjs)', true);
  } catch (e) { ok('9 existing suites (bundle-offline --fixture, test-reader.mjs)', false, String(e.message).slice(0, 200)); }
  // drawer + gutka menu
  ok('9 bani drawer wired', app.includes('gs-drawer') && app.includes("data-action=\"toggle-drawer\""));
  const gutkaIds=['mool','nitnem','gutka-list','beant','buddha-dal','hazoori','mylist'];
  ok('9 gutka menu 7 items', gutkaIds.every(id=>app.includes(`['${id}'`)) && app.includes('data-gutka='));
}

console.log(`\n==== ${pass} passed, ${fail} failed ====`);
process.exit(fail ? 1 : 0);
